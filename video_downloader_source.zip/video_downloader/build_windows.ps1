# 无水印视频下载器 - Windows 一键构建脚本
# 使用方法：右键 -> 使用 PowerShell 运行，或在 PowerShell 中执行 .\build_windows.ps1

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  无水印视频下载器 - Windows 构建工具" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# 检查 Flutter 是否安装
Write-Host "[1/4] 检查 Flutter 环境..." -ForegroundColor Yellow
try {
    $flutterVersion = flutter --version 2>&1 | Select-Object -First 1
    Write-Host "    Flutter 已安装: $flutterVersion" -ForegroundColor Green
} catch {
    Write-Host "    错误: 未找到 Flutter SDK" -ForegroundColor Red
    Write-Host "    请先安装 Flutter: https://docs.flutter.dev/get-started/install/windows" -ForegroundColor Red
    Read-Host "按回车键退出"
    exit 1
}

# 检查 Visual Studio
Write-Host "[2/4] 检查 Visual Studio..." -ForegroundColor Yellow
$vsPath = Get-ChildItem "C:\Program Files\Microsoft Visual Studio" -ErrorAction SilentlyContinue | Select-Object -First 1
if ($vsPath) {
    Write-Host "    Visual Studio 已安装: $($vsPath.Name)" -ForegroundColor Green
} else {
    Write-Host "    警告: 未检测到 Visual Studio，构建可能失败" -ForegroundColor Yellow
    Write-Host "    请安装 Visual Studio 2022 并勾选 '使用 C++ 的桌面开发'" -ForegroundColor Yellow
}

# 获取依赖
Write-Host "[3/4] 获取依赖..." -ForegroundColor Yellow
flutter pub get
if ($LASTEXITCODE -ne 0) {
    Write-Host "    错误: 依赖获取失败" -ForegroundColor Red
    Read-Host "按回车键退出"
    exit 1
}
Write-Host "    依赖获取成功" -ForegroundColor Green

# 构建 Release 版本
Write-Host "[4/4] 构建 Windows Release 版本..." -ForegroundColor Yellow
flutter build windows --release
if ($LASTEXITCODE -ne 0) {
    Write-Host "    错误: 构建失败" -ForegroundColor Red
    Read-Host "按回车键退出"
    exit 1
}
Write-Host "    构建成功！" -ForegroundColor Green

# 输出结果
$buildDir = "build\windows\x64\runner\Release"
Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "  构建完成！" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Write-Host "  可执行文件位置:" -ForegroundColor Cyan
Write-Host "  $PWD\$buildDir\video_downloader.exe" -ForegroundColor White
Write-Host ""
Write-Host "  便携式版本:" -ForegroundColor Cyan
Write-Host "  将整个 '$buildDir' 文件夹复制出来即可使用" -ForegroundColor White
Write-Host ""

# 询问是否打开构建目录
$openFolder = Read-Host "是否打开构建产物文件夹? (Y/N)"
if ($openFolder -eq 'Y' -or $openFolder -eq 'y') {
    explorer.exe $buildDir
}

Write-Host ""
Write-Host "按回车键退出..."
Read-Host
