# 无水印视频下载器 - Windows 构建包

## 快速开始（只需 3 步）

### 第一步：安装 Flutter（如果还没装）
1. 下载 Flutter SDK: https://docs.flutter.dev/get-started/install/windows
2. 解压到 `C:\src\flutter`
3. 把 `C:\src\flutter\bin` 加到系统环境变量 PATH

### 第二步：安装 Visual Studio 2022（如果还没装）
1. 下载: https://visualstudio.microsoft.com/downloads/
2. 安装时勾选 **"使用 C++ 的桌面开发"**
3. 安装完成后重启电脑

### 第三步：一键构建
双击 `build_windows.bat`（或右键 → 以管理员身份运行）

等待构建完成后，exe 文件在：
```
build\windows\x64\runner\Release\video_downloader.exe
```

把整个 `Release` 文件夹复制出来就是绿色便携式版本。

---

## 构建安装版（MSIX）

在项目目录打开 PowerShell，运行：
```powershell
flutter pub add -d msix
flutter pub run msix:create
```

生成的安装包在：
```
build\windows\x64\runner\Release\video_downloader.msix
```

---

## 文件说明

| 文件 | 说明 |
|------|------|
| build_windows.bat | 一键构建脚本（推荐，双击即用） |
| build_windows.ps1 | PowerShell 版本构建脚本 |
| lib/ | 应用源代码 |
| windows/ | Windows 平台配置 |
| pubspec.yaml | 项目依赖配置 |

---

## 常见问题

**Q: 双击 bat 一闪而过？**
A: 右键 bat 文件 → 以管理员身份运行，或者先打开 cmd 再拖入 bat 文件执行。

**Q: 提示找不到 flutter 命令？**
A: 确保 Flutter SDK 的 bin 目录已加到系统 PATH，并且重启了终端。

**Q: 构建时报 CMake 错误？**
A: 没装 Visual Studio 2022，或者没勾选 "使用 C++ 的桌面开发"。

**Q: 运行 exe 闪退？**
A: 不能只复制 exe 单独文件，要把整个 Release 文件夹一起复制。

**Q: 怎么改应用图标？**
A: 替换 `windows\runner\resources\app_icon.ico`，然后重新构建。
