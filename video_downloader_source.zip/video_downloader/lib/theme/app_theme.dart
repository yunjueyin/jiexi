import 'package:flutter/material.dart';
import 'app_colors.dart';

/// UI 密度级别
enum DensityLevel {
  /// 紧凑模式：字体、间距、图标都更小，一屏能展示更多内容
  compact,
  /// 标准模式：均衡的视觉体验（默认）
  standard,
  /// 长辈模式：字体更大、间距更宽、便于阅读和点击
  large,
}

/// 密度级别扩展
extension DensityLevelX on DensityLevel {
  /// 文字缩放比例
  double get textScale {
    switch (this) {
      case DensityLevel.compact:
        return 0.85;
      case DensityLevel.standard:
        return 1.0;
      case DensityLevel.large:
        return 1.25;
    }
  }

  /// 图标缩放比例
  double get iconScale {
    switch (this) {
      case DensityLevel.compact:
        return 0.85;
      case DensityLevel.standard:
        return 1.0;
      case DensityLevel.large:
        return 1.2;
    }
  }

  /// 间距缩放比例
  double get spacingScale {
    switch (this) {
      case DensityLevel.compact:
        return 0.8;
      case DensityLevel.standard:
        return 1.0;
      case DensityLevel.large:
        return 1.2;
    }
  }

  /// 圆角缩放比例
  double get radiusScale {
    switch (this) {
      case DensityLevel.compact:
        return 0.85;
      case DensityLevel.standard:
        return 1.0;
      case DensityLevel.large:
        return 1.15;
    }
  }

  /// 显示名称
  String get label {
    switch (this) {
      case DensityLevel.compact:
        return '紧凑';
      case DensityLevel.standard:
        return '标准';
      case DensityLevel.large:
        return '长辈';
    }
  }

  /// 描述文字
  String get description {
    switch (this) {
      case DensityLevel.compact:
        return '更小更密，一屏展示更多';
      case DensityLevel.standard:
        return '均衡舒适，推荐使用';
      case DensityLevel.large:
        return '大字大间距，更易读易点';
    }
  }

  /// 从字符串解析
  static DensityLevel fromString(String? value) {
    switch (value) {
      case 'compact':
        return DensityLevel.compact;
      case 'large':
        return DensityLevel.large;
      case 'standard':
      default:
        return DensityLevel.standard;
    }
  }

  /// 存储用字符串
  String get storageValue {
    switch (this) {
      case DensityLevel.compact:
        return 'compact';
      case DensityLevel.standard:
        return 'standard';
      case DensityLevel.large:
        return 'large';
    }
  }
}

/// 设计系统：精致简约风
/// 核心特征：柔和渐变、大圆角、多层阴影、宽松间距、玻璃拟态元素
class AppTheme {
  // ============================================================
  // 颜色系统
  // ============================================================
  
  /// 品牌主色：青绿色渐变起点（更现代、更有科技感）
  static const Color primaryColor = Color(0xFF06B6D4);
  /// 品牌主色：青绿色渐变终点
  static const Color primaryColorDark = Color(0xFF0891B2);
  /// 辅助色：翠绿
  static const Color secondaryColor = Color(0xFF10B981);
  /// 强调色：暖橙（用于警告、高亮）
  static const Color accentColor = Color(0xFFF59E0B);
  
  /// 背景色（浅色）：极淡的灰青底
  static const Color backgroundColor = Color(0xFFF8FAFC);
  /// 卡片背景色（浅色）：纯白
  static const Color cardColor = Colors.white;
  /// 次级背景色（浅色）：用于输入框、Chip 等
  static const Color surfaceColor = Color(0xFFF1F5F9);
  
  /// 文字颜色层级
  static const Color textPrimary = Color(0xFF0F172A);
  static const Color textSecondary = Color(0xFF475569);
  static const Color textTertiary = Color(0xFF94A3B8);
  static const Color textMuted = Color(0xFFCBD5E1);
  
  /// 功能色
  static const Color successColor = Color(0xFF10B981);
  static const Color errorColor = Color(0xFFEF4444);
  static const Color warningColor = Color(0xFFF59E0B);
  static const Color infoColor = Color(0xFF3B82F6);
  
  /// 边框色
  static const Color borderColorLight = Color(0xFFE2E8F0);
  static const Color borderColorDark = Color(0xFF334155);
  
  // ============================================================
  // 文字样式系统
  // ============================================================
  
  static const TextStyle displayLarge = TextStyle(
    fontSize: 28,
    fontWeight: FontWeight.w700,
    color: textPrimary,
    height: 1.2,
    letterSpacing: -0.3,
  );
  
  static const TextStyle displayMedium = TextStyle(
    fontSize: 22,
    fontWeight: FontWeight.w700,
    color: textPrimary,
    height: 1.25,
    letterSpacing: -0.2,
  );
  
  static const TextStyle titleLarge = TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.w600,
    color: textPrimary,
    height: 1.3,
  );
  
  static const TextStyle titleMedium = TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.w600,
    color: textPrimary,
    height: 1.4,
  );
  
  static const TextStyle titleSmall = TextStyle(
    fontSize: 14,
    fontWeight: FontWeight.w600,
    color: textPrimary,
    height: 1.4,
  );
  
  static const TextStyle bodyLarge = TextStyle(
    fontSize: 15,
    fontWeight: FontWeight.w500,
    color: textPrimary,
    height: 1.5,
  );
  
  static const TextStyle bodyMedium = TextStyle(
    fontSize: 14,
    fontWeight: FontWeight.w400,
    color: textPrimary,
    height: 1.5,
  );
  
  static const TextStyle bodySmall = TextStyle(
    fontSize: 13,
    fontWeight: FontWeight.w400,
    color: textSecondary,
    height: 1.4,
  );
  
  static const TextStyle caption = TextStyle(
    fontSize: 12,
    fontWeight: FontWeight.w400,
    color: textTertiary,
    height: 1.3,
  );
  
  static const TextStyle overline = TextStyle(
    fontSize: 11,
    fontWeight: FontWeight.w600,
    color: textTertiary,
    height: 1.2,
    letterSpacing: 0.5,
  );
  
  // ============================================================
  // 圆角系统
  // ============================================================
  
  static const double radiusSm = 8.0;
  static const double radiusMd = 12.0;
  static const double radiusLg = 16.0;
  static const double radiusXl = 20.0;
  static const double radius2Xl = 24.0;
  static const double radiusFull = 999.0;
  
  // ============================================================
  // 阴影系统
  // ============================================================
  
  /// 微小阴影：用于小卡片、按钮
  static List<BoxShadow> shadowSm = [
    BoxShadow(
      color: const Color(0xFF0F172A).withOpacity(0.05),
      blurRadius: 4,
      offset: const Offset(0, 1),
    ),
  ];
  
  /// 中等阴影：用于普通卡片
  static List<BoxShadow> shadowMd = [
    BoxShadow(
      color: const Color(0xFF0F172A).withOpacity(0.06),
      blurRadius: 12,
      offset: const Offset(0, 2),
    ),
    BoxShadow(
      color: const Color(0xFF0F172A).withOpacity(0.04),
      blurRadius: 4,
      offset: const Offset(0, 1),
    ),
  ];
  
  /// 大阴影：用于悬浮卡片、弹窗
  static List<BoxShadow> shadowLg = [
    BoxShadow(
      color: const Color(0xFF0F172A).withOpacity(0.1),
      blurRadius: 24,
      offset: const Offset(0, 8),
    ),
    BoxShadow(
      color: const Color(0xFF0F172A).withOpacity(0.06),
      blurRadius: 8,
      offset: const Offset(0, 2),
    ),
  ];
  
  /// 超大阴影：用于底部抽屉、大弹窗
  static List<BoxShadow> shadowXl = [
    BoxShadow(
      color: const Color(0xFF0F172A).withOpacity(0.15),
      blurRadius: 40,
      offset: const Offset(0, -12),
    ),
  ];
  
  // ============================================================
  // 间距系统
  // ============================================================
  
  static const double spacingXs = 4.0;
  static const double spacingSm = 8.0;
  static const double spacingMd = 12.0;
  static const double spacingLg = 16.0;
  static const double spacingXl = 20.0;
  static const double spacing2Xl = 24.0;
  static const double spacing3Xl = 32.0;
  
  // ============================================================
  // 渐变系统
  // ============================================================
  
  /// 主渐变：青 → 绿
  static LinearGradient get primaryGradient => const LinearGradient(
    colors: [primaryColor, secondaryColor],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  /// 主渐变（水平）
  static LinearGradient get primaryGradientHorizontal => const LinearGradient(
    colors: [primaryColor, secondaryColor],
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
  );
  
  /// 背景渐变：用于页面顶部装饰
  static LinearGradient get heroGradient => LinearGradient(
    colors: [
      primaryColor.withOpacity(0.08),
      secondaryColor.withOpacity(0.04),
      Colors.transparent,
    ],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );
  
  // ============================================================
  // 浅色主题
  // ============================================================
  
  static ThemeData lightTheme = ThemeData(
    useMaterial3: true,
    primaryColor: primaryColor,
    scaffoldBackgroundColor: backgroundColor,
    colorScheme: ColorScheme.light(
      primary: primaryColor,
      secondary: secondaryColor,
      surface: cardColor,
      error: errorColor,
      onPrimary: Colors.white,
      onSurface: textPrimary,
      onBackground: textPrimary,
    ),
    splashFactory: InkSparkle.splashFactory,
    splashColor: primaryColor.withOpacity(0.1),
    highlightColor: primaryColor.withOpacity(0.05),
    
    // AppBar
    appBarTheme: AppBarTheme(
      backgroundColor: backgroundColor,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
      titleSpacing: spacingLg,
      titleTextStyle: const TextStyle(
        color: textPrimary,
        fontSize: 20,
        fontWeight: FontWeight.w700,
        letterSpacing: -0.3,
      ),
      iconTheme: const IconThemeData(color: textPrimary, size: 24),
      actionsIconTheme: const IconThemeData(color: textSecondary, size: 22),
    ),
    
    // 卡片
    cardTheme: CardTheme(
      color: cardColor,
      elevation: 0,
      shadowColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(radiusLg),
        side: BorderSide(color: borderColorLight, width: 0.5),
      ),
      margin: EdgeInsets.zero,
    ),
    
    // 主按钮
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: primaryColor,
        foregroundColor: Colors.white,
        elevation: 0,
        shadowColor: Colors.transparent,
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(radiusMd),
        ),
        textStyle: const TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w600,
        ),
      ),
    ),
    
    // 描边按钮
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: primaryColor,
        side: BorderSide(color: primaryColor.withOpacity(0.3), width: 1.5),
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(radiusMd),
        ),
        textStyle: const TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w600,
        ),
      ),
    ),
    
    // 文字按钮
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        foregroundColor: primaryColor,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(radiusSm),
        ),
        textStyle: const TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w600,
        ),
      ),
    ),
    
    // 输入框
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: surfaceColor,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(radiusMd),
        borderSide: BorderSide.none,
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(radiusMd),
        borderSide: BorderSide.none,
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(radiusMd),
        borderSide: const BorderSide(color: primaryColor, width: 2),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(radiusMd),
        borderSide: BorderSide(color: errorColor.withOpacity(0.5), width: 1.5),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(radiusMd),
        borderSide: const BorderSide(color: errorColor, width: 2),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      hintStyle: const TextStyle(color: textTertiary, fontSize: 14),
      labelStyle: const TextStyle(color: textSecondary, fontSize: 14),
      prefixIconColor: textTertiary,
      suffixIconColor: textTertiary,
    ),
    
    // 底部导航
    bottomNavigationBarTheme: BottomNavigationBarThemeData(
      backgroundColor: cardColor,
      selectedItemColor: primaryColor,
      unselectedItemColor: textTertiary,
      type: BottomNavigationBarType.fixed,
      elevation: 0,
      selectedLabelStyle: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, height: 1.5),
      unselectedLabelStyle: const TextStyle(fontSize: 11, fontWeight: FontWeight.w500, height: 1.5),
      showSelectedLabels: true,
      showUnselectedLabels: true,
    ),
    
    // 分割线
    dividerColor: borderColorLight,
    dividerTheme: const DividerThemeData(
      color: borderColorLight,
      thickness: 0.5,
      space: 1,
    ),
    
    // 列表项
    listTileTheme: const ListTileThemeData(
      iconColor: textSecondary,
      textColor: textPrimary,
      contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      minLeadingWidth: 32,
      horizontalTitleGap: 12,
    ),
    
    // 开关
    switchTheme: SwitchThemeData(
      thumbColor: MaterialStateProperty.resolveWith((states) {
        if (states.contains(MaterialState.selected)) {
          return Colors.white;
        }
        return Colors.white;
      }),
      trackColor: MaterialStateProperty.resolveWith((states) {
        if (states.contains(MaterialState.selected)) {
          return primaryColor;
        }
        return const Color(0xFFCBD5E1);
      }),
      trackOutlineColor: MaterialStateProperty.all(Colors.transparent),
    ),
    
    // 复选框
    checkboxTheme: CheckboxThemeData(
      fillColor: MaterialStateProperty.resolveWith((states) {
        if (states.contains(MaterialState.selected)) {
          return primaryColor;
        }
        return Colors.transparent;
      }),
      checkColor: MaterialStateProperty.all(Colors.white),
      side: const BorderSide(color: Color(0xFFCBD5E1), width: 2),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
    ),
    
    // 弹窗
    dialogTheme: DialogTheme(
      backgroundColor: cardColor,
      elevation: 0,
      shadowColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radiusXl)),
      titleTextStyle: const TextStyle(
        color: textPrimary,
        fontSize: 18,
        fontWeight: FontWeight.w700,
        letterSpacing: -0.2,
      ),
      contentTextStyle: const TextStyle(color: textSecondary, fontSize: 14, height: 1.5),
    ),
    
    // 底部抽屉
    bottomSheetTheme: BottomSheetThemeData(
      backgroundColor: cardColor,
      elevation: 0,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(radiusXl)),
      ),
      dragHandleColor: const Color(0xFFE2E8F0),
      dragHandleSize: const Size(36, 4),
    ),
    
    // SnackBar
    snackBarTheme: SnackBarThemeData(
      backgroundColor: textPrimary,
      contentTextStyle: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w500),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radiusMd)),
      behavior: SnackBarBehavior.floating,
      elevation: 0,
      insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
    ),
    
    // TabBar
    tabBarTheme: TabBarTheme(
      labelColor: primaryColor,
      unselectedLabelColor: textTertiary,
      indicatorColor: primaryColor,
      indicatorSize: TabBarIndicatorSize.label,
      labelStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
      unselectedLabelStyle: const TextStyle(fontWeight: FontWeight.w500, fontSize: 14),
      dividerColor: Colors.transparent,
    ),
    
    // 文字主题
    textTheme: const TextTheme(
      displayLarge: displayLarge,
      displayMedium: displayMedium,
      titleLarge: titleLarge,
      titleMedium: titleMedium,
      titleSmall: titleSmall,
      bodyLarge: bodyLarge,
      bodyMedium: bodyMedium,
      bodySmall: bodySmall,
      labelSmall: caption,
    ),
    
    // 图标主题
    iconTheme: const IconThemeData(
      color: textSecondary,
      size: 22,
    ),
  );
  
  // ============================================================
  // 深色主题
  // ============================================================
  
  static ThemeData darkTheme = ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    primaryColor: primaryColor,
    scaffoldBackgroundColor: const Color(0xFF0B1120),
    colorScheme: const ColorScheme.dark(
      primary: primaryColor,
      secondary: secondaryColor,
      surface: Color(0xFF1E293B),
      error: errorColor,
      onPrimary: Colors.white,
      onSurface: Color(0xFFF1F5F9),
      onBackground: Color(0xFFF1F5F9),
    ),
    splashFactory: InkSparkle.splashFactory,
    splashColor: primaryColor.withOpacity(0.15),
    highlightColor: primaryColor.withOpacity(0.08),
    
    appBarTheme: const AppBarTheme(
      backgroundColor: Color(0xFF0B1120),
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
      titleSpacing: spacingLg,
      titleTextStyle: TextStyle(
        color: Colors.white,
        fontSize: 20,
        fontWeight: FontWeight.w700,
        letterSpacing: -0.3,
      ),
      iconTheme: IconThemeData(color: Colors.white, size: 24),
      actionsIconTheme: IconThemeData(color: Color(0xFF94A3B8), size: 22),
    ),
    
    cardTheme: CardTheme(
      color: const Color(0xFF1E293B),
      elevation: 0,
      shadowColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(radiusLg),
        side: BorderSide(color: const Color(0xFF334155), width: 0.5),
      ),
      margin: EdgeInsets.zero,
    ),
    
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: primaryColor,
        foregroundColor: Colors.white,
        elevation: 0,
        shadowColor: Colors.transparent,
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(radiusMd),
        ),
        textStyle: const TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w600,
        ),
      ),
    ),
    
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: primaryColor,
        side: BorderSide(color: primaryColor.withOpacity(0.4), width: 1.5),
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(radiusMd),
        ),
        textStyle: const TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w600,
        ),
      ),
    ),
    
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        foregroundColor: primaryColor,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(radiusSm),
        ),
        textStyle: const TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w600,
        ),
      ),
    ),
    
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: const Color(0xFF1E293B),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(radiusMd),
        borderSide: BorderSide.none,
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(radiusMd),
        borderSide: BorderSide.none,
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(radiusMd),
        borderSide: const BorderSide(color: primaryColor, width: 2),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      hintStyle: TextStyle(color: Colors.grey.shade600, fontSize: 14),
      prefixIconColor: Colors.grey.shade600,
      suffixIconColor: Colors.grey.shade600,
    ),
    
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor: Color(0xFF1E293B),
      selectedItemColor: primaryColor,
      unselectedItemColor: Color(0xFF64748B),
      type: BottomNavigationBarType.fixed,
      elevation: 0,
      selectedLabelStyle: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, height: 1.5),
      unselectedLabelStyle: TextStyle(fontSize: 11, fontWeight: FontWeight.w500, height: 1.5),
      showSelectedLabels: true,
      showUnselectedLabels: true,
    ),
    
    dividerColor: const Color(0xFF334155),
    dividerTheme: const DividerThemeData(
      color: Color(0xFF334155),
      thickness: 0.5,
      space: 1,
    ),
    
    listTileTheme: const ListTileThemeData(
      iconColor: Color(0xFF94A3B8),
      textColor: Colors.white,
      contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      minLeadingWidth: 32,
      horizontalTitleGap: 12,
    ),
    
    switchTheme: SwitchThemeData(
      thumbColor: MaterialStateProperty.resolveWith((states) {
        return Colors.white;
      }),
      trackColor: MaterialStateProperty.resolveWith((states) {
        if (states.contains(MaterialState.selected)) {
          return primaryColor;
        }
        return const Color(0xFF334155);
      }),
      trackOutlineColor: MaterialStateProperty.all(Colors.transparent),
    ),
    
    checkboxTheme: CheckboxThemeData(
      fillColor: MaterialStateProperty.resolveWith((states) {
        if (states.contains(MaterialState.selected)) {
          return primaryColor;
        }
        return Colors.transparent;
      }),
      checkColor: MaterialStateProperty.all(Colors.white),
      side: const BorderSide(color: Color(0xFF475569), width: 2),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
    ),
    
    dialogTheme: DialogTheme(
      backgroundColor: const Color(0xFF1E293B),
      elevation: 0,
      shadowColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radiusXl)),
      titleTextStyle: const TextStyle(
        color: Colors.white,
        fontSize: 18,
        fontWeight: FontWeight.w700,
        letterSpacing: -0.2,
      ),
      contentTextStyle: TextStyle(color: Colors.grey.shade300, fontSize: 14, height: 1.5),
    ),
    
    bottomSheetTheme: const BottomSheetThemeData(
      backgroundColor: Color(0xFF1E293B),
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(radiusXl)),
      ),
      dragHandleColor: Color(0xFF334155),
      dragHandleSize: Size(36, 4),
    ),
    
    snackBarTheme: SnackBarThemeData(
      backgroundColor: const Color(0xFF334155),
      contentTextStyle: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w500),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radiusMd)),
      behavior: SnackBarBehavior.floating,
      elevation: 0,
      insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
    ),
    
    tabBarTheme: const TabBarTheme(
      labelColor: primaryColor,
      unselectedLabelColor: Color(0xFF64748B),
      indicatorColor: primaryColor,
      indicatorSize: TabBarIndicatorSize.label,
      labelStyle: TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
      unselectedLabelStyle: TextStyle(fontWeight: FontWeight.w500, fontSize: 14),
      dividerColor: Colors.transparent,
    ),
    
    textTheme: const TextTheme(
      displayLarge: TextStyle(fontSize: 28, fontWeight: FontWeight.w700, color: Colors.white, height: 1.2, letterSpacing: -0.3),
      displayMedium: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: Colors.white, height: 1.25, letterSpacing: -0.2),
      titleLarge: TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: Colors.white, height: 1.3),
      titleMedium: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: Colors.white, height: 1.4),
      titleSmall: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.white, height: 1.4),
      bodyLarge: TextStyle(fontSize: 15, fontWeight: FontWeight.w500, color: Colors.white, height: 1.5),
      bodyMedium: TextStyle(fontSize: 14, fontWeight: FontWeight.w400, color: Color(0xFFE2E8F0), height: 1.5),
      bodySmall: TextStyle(fontSize: 13, fontWeight: FontWeight.w400, color: Color(0xFF94A3B8), height: 1.4),
      labelSmall: TextStyle(fontSize: 12, fontWeight: FontWeight.w400, color: Color(0xFF64748B), height: 1.3),
    ),
    
    iconTheme: const IconThemeData(
      color: Color(0xFF94A3B8),
      size: 22,
    ),
  );
  
  // ============================================================
  // OLED 纯黑主题
  // ============================================================
  
  static ThemeData oledDarkTheme = ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    primaryColor: primaryColor,
    scaffoldBackgroundColor: Colors.black,
    colorScheme: const ColorScheme.dark(
      primary: primaryColor,
      secondary: secondaryColor,
      surface: Color(0xFF0A0A0A),
      error: errorColor,
      onPrimary: Colors.white,
      onSurface: Color(0xFFE2E8F0),
      onBackground: Color(0xFFE2E8F0),
    ),
    splashFactory: InkSparkle.splashFactory,
    splashColor: primaryColor.withOpacity(0.2),
    highlightColor: primaryColor.withOpacity(0.1),
    
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.black,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
      titleSpacing: spacingLg,
      titleTextStyle: TextStyle(
        color: Colors.white,
        fontSize: 20,
        fontWeight: FontWeight.w700,
        letterSpacing: -0.3,
      ),
      iconTheme: IconThemeData(color: Colors.white, size: 24),
      actionsIconTheme: IconThemeData(color: Color(0xFF64748B), size: 22),
    ),
    
    cardTheme: CardTheme(
      color: const Color(0xFF0A0A0A),
      elevation: 0,
      shadowColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(radiusLg),
        side: BorderSide(color: const Color(0xFF1E293B), width: 0.5),
      ),
      margin: EdgeInsets.zero,
    ),
    
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: primaryColor,
        foregroundColor: Colors.white,
        elevation: 0,
        shadowColor: Colors.transparent,
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(radiusMd),
        ),
        textStyle: const TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w600,
        ),
      ),
    ),
    
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: primaryColor,
        side: BorderSide(color: primaryColor.withOpacity(0.5), width: 1.5),
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(radiusMd),
        ),
        textStyle: const TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w600,
        ),
      ),
    ),
    
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        foregroundColor: primaryColor,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(radiusSm),
        ),
        textStyle: const TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w600,
        ),
      ),
    ),
    
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: const Color(0xFF0A0A0A),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(radiusMd),
        borderSide: const BorderSide(color: Color(0xFF1E293B), width: 0.5),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(radiusMd),
        borderSide: const BorderSide(color: Color(0xFF1E293B), width: 0.5),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(radiusMd),
        borderSide: const BorderSide(color: primaryColor, width: 2),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      hintStyle: TextStyle(color: Colors.grey.shade700, fontSize: 14),
      prefixIconColor: Colors.grey.shade700,
      suffixIconColor: Colors.grey.shade700,
    ),
    
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor: Color(0xFF0A0A0A),
      selectedItemColor: primaryColor,
      unselectedItemColor: Color(0xFF475569),
      type: BottomNavigationBarType.fixed,
      elevation: 0,
      selectedLabelStyle: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, height: 1.5),
      unselectedLabelStyle: TextStyle(fontSize: 11, fontWeight: FontWeight.w500, height: 1.5),
      showSelectedLabels: true,
      showUnselectedLabels: true,
    ),
    
    dividerColor: const Color(0xFF1E293B),
    dividerTheme: const DividerThemeData(
      color: Color(0xFF1E293B),
      thickness: 0.5,
      space: 1,
    ),
    
    listTileTheme: const ListTileThemeData(
      iconColor: Color(0xFF64748B),
      textColor: Colors.white,
      contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      minLeadingWidth: 32,
      horizontalTitleGap: 12,
    ),
    
    switchTheme: SwitchThemeData(
      thumbColor: MaterialStateProperty.resolveWith((states) {
        return Colors.white;
      }),
      trackColor: MaterialStateProperty.resolveWith((states) {
        if (states.contains(MaterialState.selected)) {
          return primaryColor;
        }
        return const Color(0xFF1E293B);
      }),
      trackOutlineColor: MaterialStateProperty.all(Colors.transparent),
    ),
    
    checkboxTheme: CheckboxThemeData(
      fillColor: MaterialStateProperty.resolveWith((states) {
        if (states.contains(MaterialState.selected)) {
          return primaryColor;
        }
        return Colors.transparent;
      }),
      checkColor: MaterialStateProperty.all(Colors.white),
      side: const BorderSide(color: Color(0xFF334155), width: 2),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
    ),
    
    dialogTheme: DialogTheme(
      backgroundColor: const Color(0xFF0A0A0A),
      elevation: 0,
      shadowColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radiusXl)),
      titleTextStyle: const TextStyle(
        color: Colors.white,
        fontSize: 18,
        fontWeight: FontWeight.w700,
        letterSpacing: -0.2,
      ),
      contentTextStyle: TextStyle(color: Colors.grey.shade400, fontSize: 14, height: 1.5),
    ),
    
    bottomSheetTheme: const BottomSheetThemeData(
      backgroundColor: Color(0xFF0A0A0A),
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(radiusXl)),
      ),
      dragHandleColor: Color(0xFF1E293B),
      dragHandleSize: Size(36, 4),
    ),
    
    snackBarTheme: SnackBarThemeData(
      backgroundColor: const Color(0xFF1E293B),
      contentTextStyle: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w500),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radiusMd)),
      behavior: SnackBarBehavior.floating,
      elevation: 0,
      insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
    ),
    
    tabBarTheme: const TabBarTheme(
      labelColor: primaryColor,
      unselectedLabelColor: Color(0xFF475569),
      indicatorColor: primaryColor,
      indicatorSize: TabBarIndicatorSize.label,
      labelStyle: TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
      unselectedLabelStyle: TextStyle(fontWeight: FontWeight.w500, fontSize: 14),
      dividerColor: Colors.transparent,
    ),
    
    textTheme: const TextTheme(
      displayLarge: TextStyle(fontSize: 28, fontWeight: FontWeight.w700, color: Colors.white, height: 1.2, letterSpacing: -0.3),
      displayMedium: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: Colors.white, height: 1.25, letterSpacing: -0.2),
      titleLarge: TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: Colors.white, height: 1.3),
      titleMedium: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: Colors.white, height: 1.4),
      titleSmall: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.white, height: 1.4),
      bodyLarge: TextStyle(fontSize: 15, fontWeight: FontWeight.w500, color: Colors.white, height: 1.5),
      bodyMedium: TextStyle(fontSize: 14, fontWeight: FontWeight.w400, color: Color(0xFFCBD5E1), height: 1.5),
      bodySmall: TextStyle(fontSize: 13, fontWeight: FontWeight.w400, color: Color(0xFF64748B), height: 1.4),
      labelSmall: TextStyle(fontSize: 12, fontWeight: FontWeight.w400, color: Color(0xFF475569), height: 1.3),
    ),
    
    iconTheme: const IconThemeData(
      color: Color(0xFF64748B),
      size: 22,
    ),
  );
  
  // ============================================================
  // 动态主题色主题生成
  // ============================================================

  /// 根据主题色生成浅色主题
  static ThemeData lightThemeOf(ThemeColorData color) {
    return lightTheme.copyWith(
      primaryColor: color.primary,
      colorScheme: ColorScheme.light(
        primary: color.primary,
        secondary: color.secondary,
        surface: cardColor,
        error: errorColor,
        onPrimary: Colors.white,
        onSurface: textPrimary,
        onBackground: textPrimary,
      ),
      splashColor: color.primary.withOpacity(0.1),
      highlightColor: color.primary.withOpacity(0.05),
      appBarTheme: lightTheme.appBarTheme.copyWith(
        foregroundColor: textPrimary,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: color.primary,
          foregroundColor: Colors.white,
          elevation: 0,
          shadowColor: Colors.transparent,
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(radiusMd),
          ),
          textStyle: const TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: color.primary,
          side: BorderSide(color: color.primary.withOpacity(0.3), width: 1.5),
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(radiusMd),
          ),
          textStyle: const TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: color.primary,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(radiusSm),
          ),
          textStyle: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: surfaceColor,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(radiusMd),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(radiusMd),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(radiusMd),
          borderSide: BorderSide(color: color.primary, width: 2),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(radiusMd),
          borderSide: BorderSide(color: errorColor.withOpacity(0.5), width: 1.5),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(radiusMd),
          borderSide: const BorderSide(color: errorColor, width: 2),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        hintStyle: const TextStyle(color: textTertiary, fontSize: 14),
        labelStyle: const TextStyle(color: textSecondary, fontSize: 14),
        prefixIconColor: textTertiary,
        suffixIconColor: textTertiary,
      ),
      bottomNavigationBarTheme: BottomNavigationBarThemeData(
        backgroundColor: cardColor,
        selectedItemColor: color.primary,
        unselectedItemColor: textTertiary,
        type: BottomNavigationBarType.fixed,
        elevation: 0,
        selectedLabelStyle: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, height: 1.5),
        unselectedLabelStyle: const TextStyle(fontSize: 11, fontWeight: FontWeight.w500, height: 1.5),
        showSelectedLabels: true,
        showUnselectedLabels: true,
      ),
      switchTheme: SwitchThemeData(
        thumbColor: MaterialStateProperty.resolveWith((states) {
          return Colors.white;
        }),
        trackColor: MaterialStateProperty.resolveWith((states) {
          if (states.contains(MaterialState.selected)) {
            return color.primary;
          }
          return const Color(0xFFCBD5E1);
        }),
        trackOutlineColor: MaterialStateProperty.all(Colors.transparent),
      ),
      checkboxTheme: CheckboxThemeData(
        fillColor: MaterialStateProperty.resolveWith((states) {
          if (states.contains(MaterialState.selected)) {
            return color.primary;
          }
          return Colors.transparent;
        }),
        checkColor: MaterialStateProperty.all(Colors.white),
        side: const BorderSide(color: Color(0xFFCBD5E1), width: 2),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
      ),
      tabBarTheme: TabBarTheme(
        labelColor: color.primary,
        unselectedLabelColor: textTertiary,
        indicatorColor: color.primary,
        indicatorSize: TabBarIndicatorSize.label,
        labelStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
        unselectedLabelStyle: const TextStyle(fontWeight: FontWeight.w500, fontSize: 14),
        dividerColor: Colors.transparent,
      ),
    );
  }

  /// 根据主题色生成深色主题
  static ThemeData darkThemeOf(ThemeColorData color) {
    return darkTheme.copyWith(
      primaryColor: color.primary,
      colorScheme: ColorScheme.dark(
        primary: color.primary,
        secondary: color.secondary,
        surface: const Color(0xFF1E293B),
        error: errorColor,
        onPrimary: Colors.white,
        onSurface: const Color(0xFFF1F5F9),
        onBackground: const Color(0xFFF1F5F9),
      ),
      splashColor: color.primary.withOpacity(0.15),
      highlightColor: color.primary.withOpacity(0.08),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: color.primary,
          foregroundColor: Colors.white,
          elevation: 0,
          shadowColor: Colors.transparent,
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(radiusMd),
          ),
          textStyle: const TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: color.primary,
          side: BorderSide(color: color.primary.withOpacity(0.4), width: 1.5),
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(radiusMd),
          ),
          textStyle: const TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: color.primary,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(radiusSm),
          ),
          textStyle: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: const Color(0xFF1E293B),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(radiusMd),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(radiusMd),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(radiusMd),
          borderSide: BorderSide(color: color.primary, width: 2),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        hintStyle: TextStyle(color: Colors.grey.shade600, fontSize: 14),
        prefixIconColor: Colors.grey.shade600,
        suffixIconColor: Colors.grey.shade600,
      ),
      bottomNavigationBarTheme: BottomNavigationBarThemeData(
        backgroundColor: const Color(0xFF1E293B),
        selectedItemColor: color.primary,
        unselectedItemColor: const Color(0xFF64748B),
        type: BottomNavigationBarType.fixed,
        elevation: 0,
        selectedLabelStyle: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, height: 1.5),
        unselectedLabelStyle: const TextStyle(fontSize: 11, fontWeight: FontWeight.w500, height: 1.5),
        showSelectedLabels: true,
        showUnselectedLabels: true,
      ),
      switchTheme: SwitchThemeData(
        thumbColor: MaterialStateProperty.resolveWith((states) {
          return Colors.white;
        }),
        trackColor: MaterialStateProperty.resolveWith((states) {
          if (states.contains(MaterialState.selected)) {
            return color.primary;
          }
          return const Color(0xFF334155);
        }),
        trackOutlineColor: MaterialStateProperty.all(Colors.transparent),
      ),
      checkboxTheme: CheckboxThemeData(
        fillColor: MaterialStateProperty.resolveWith((states) {
          if (states.contains(MaterialState.selected)) {
            return color.primary;
          }
          return Colors.transparent;
        }),
        checkColor: MaterialStateProperty.all(Colors.white),
        side: const BorderSide(color: Color(0xFF475569), width: 2),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
      ),
      tabBarTheme: TabBarTheme(
        labelColor: color.primary,
        unselectedLabelColor: const Color(0xFF64748B),
        indicatorColor: color.primary,
        indicatorSize: TabBarIndicatorSize.label,
        labelStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
        unselectedLabelStyle: const TextStyle(fontWeight: FontWeight.w500, fontSize: 14),
        dividerColor: Colors.transparent,
      ),
    );
  }

  /// 根据主题色生成 OLED 纯黑主题
  static ThemeData oledDarkThemeOf(ThemeColorData color) {
    return oledDarkTheme.copyWith(
      primaryColor: color.primary,
      colorScheme: ColorScheme.dark(
        primary: color.primary,
        secondary: color.secondary,
        surface: const Color(0xFF0A0A0A),
        error: errorColor,
        onPrimary: Colors.white,
        onSurface: const Color(0xFFE2E8F0),
        onBackground: const Color(0xFFE2E8F0),
      ),
      splashColor: color.primary.withOpacity(0.2),
      highlightColor: color.primary.withOpacity(0.1),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: color.primary,
          foregroundColor: Colors.white,
          elevation: 0,
          shadowColor: Colors.transparent,
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(radiusMd),
          ),
          textStyle: const TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: color.primary,
          side: BorderSide(color: color.primary.withOpacity(0.5), width: 1.5),
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(radiusMd),
          ),
          textStyle: const TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: color.primary,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(radiusSm),
          ),
          textStyle: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: const Color(0xFF0A0A0A),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(radiusMd),
          borderSide: const BorderSide(color: Color(0xFF1E293B), width: 0.5),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(radiusMd),
          borderSide: const BorderSide(color: Color(0xFF1E293B), width: 0.5),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(radiusMd),
          borderSide: BorderSide(color: color.primary, width: 2),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        hintStyle: TextStyle(color: Colors.grey.shade700, fontSize: 14),
        prefixIconColor: Colors.grey.shade700,
        suffixIconColor: Colors.grey.shade700,
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: Color(0xFF0A0A0A),
        selectedItemColor: primaryColor,
        unselectedItemColor: Color(0xFF475569),
        type: BottomNavigationBarType.fixed,
        elevation: 0,
        selectedLabelStyle: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, height: 1.5),
        unselectedLabelStyle: TextStyle(fontSize: 11, fontWeight: FontWeight.w500, height: 1.5),
        showSelectedLabels: true,
        showUnselectedLabels: true,
      ).copyWith(
        selectedItemColor: color.primary,
      ),
      switchTheme: SwitchThemeData(
        thumbColor: MaterialStateProperty.resolveWith((states) {
          return Colors.white;
        }),
        trackColor: MaterialStateProperty.resolveWith((states) {
          if (states.contains(MaterialState.selected)) {
            return color.primary;
          }
          return const Color(0xFF1E293B);
        }),
        trackOutlineColor: MaterialStateProperty.all(Colors.transparent),
      ),
      checkboxTheme: CheckboxThemeData(
        fillColor: MaterialStateProperty.resolveWith((states) {
          if (states.contains(MaterialState.selected)) {
            return color.primary;
          }
          return Colors.transparent;
        }),
        checkColor: MaterialStateProperty.all(Colors.white),
        side: const BorderSide(color: Color(0xFF334155), width: 2),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
      ),
      tabBarTheme: TabBarTheme(
        labelColor: color.primary,
        unselectedLabelColor: const Color(0xFF475569),
        indicatorColor: color.primary,
        indicatorSize: TabBarIndicatorSize.label,
        labelStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
        unselectedLabelStyle: const TextStyle(fontWeight: FontWeight.w500, fontSize: 14),
        dividerColor: Colors.transparent,
      ),
    );
  }

  /// 根据主题色 key 获取对应渐变
  static LinearGradient primaryGradientOf(ThemeColorData color) {
    return LinearGradient(
      colors: [color.primary, color.secondary],
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
    );
  }

  /// 根据主题色 key 获取水平渐变
  static LinearGradient primaryGradientHorizontalOf(ThemeColorData color) {
    return LinearGradient(
      colors: [color.primary, color.secondary],
      begin: Alignment.centerLeft,
      end: Alignment.centerRight,
    );
  }

  // ============================================================
  // 便捷方法
  // ============================================================
  
  /// 获取当前主题是否为深色
  static bool isDark(BuildContext context) {
    return Theme.of(context).brightness == Brightness.dark;
  }
  
  /// 获取卡片背景色
  static Color cardBg(BuildContext context) {
    return isDark(context) ? const Color(0xFF1E293B) : cardColor;
  }
  
  /// 获取次级背景色
  static Color surfaceBg(BuildContext context) {
    return isDark(context) ? const Color(0xFF0F172A) : surfaceColor;
  }
  
  /// 获取主文字色
  static Color textPrimaryColor(BuildContext context) {
    return isDark(context) ? Colors.white : textPrimary;
  }
  
  /// 获取次文字色
  static Color textSecondaryColor(BuildContext context) {
    return isDark(context) ? const Color(0xFF94A3B8) : textSecondary;
  }
  
  /// 获取三级文字色
  static Color textTertiaryColor(BuildContext context) {
    return isDark(context) ? const Color(0xFF64748B) : textTertiary;
  }
  
  /// 获取边框色
  static Color borderColor(BuildContext context) {
    return isDark(context) ? borderColorDark : borderColorLight;
  }
  
  // ============================================================
  // 列表密度辅助方法（紧凑模式）
  // ============================================================
  
  /// 获取列表项水平内边距
  static double listHorizontalPadding(bool compact) => compact ? 10.0 : 12.0;
  
  /// 获取列表项垂直内边距
  static double listVerticalPadding(bool compact) => compact ? 8.0 : 12.0;
  
  /// 获取列表项间距
  static double listItemSpacing(bool compact) => compact ? 8.0 : 10.0;
  
  /// 获取列表缩略图宽度
  static double listThumbnailWidth(bool compact) => compact ? 56.0 : 70.0;
  
  /// 获取列表缩略图高度
  static double listThumbnailHeight(bool compact) => compact ? 44.0 : 56.0;
  
  /// 获取列表标题字体大小
  static double listTitleFontSize(bool compact) => compact ? 12.0 : 13.0;
  
  /// 获取列表副标题字体大小
  static double listSubtitleFontSize(bool compact) => compact ? 10.5 : 11.0;
  
  // ============================================================
  // 暗黑模式细节优化
  // ============================================================
  
  /// 获取分割线颜色（暗黑模式下更清晰）
  static Color dividerColor(BuildContext context) {
    if (isOledDark(context)) return const Color(0xFF1E293B);
    if (isDark(context)) return const Color(0xFF334155);
    return borderColorLight;
  }
  
  /// 获取输入框填充色（暗黑模式优化）
  static Color inputFillColor(BuildContext context) {
    if (isOledDark(context)) return const Color(0xFF0A0A0A);
    if (isDark(context)) return const Color(0xFF1E293B);
    return surfaceColor;
  }
  
  /// 获取卡片背景色与页面背景的对比度色（用于卡片边框增强）
  static Color cardBorderColor(BuildContext context) {
    if (isOledDark(context)) return const Color(0xFF1E293B);
    if (isDark(context)) return const Color(0xFF334155);
    return borderColorLight;
  }
  
  // ============================================================
  // 平台主题色
  // ============================================================
  
  /// 获取指定平台的主色调
  static Color platformPrimaryColor(String platform) {
    switch (platform) {
      case 'douyin':
        return const Color(0xFFFE2C55);
      case 'kuaishou':
        return const Color(0xFFFF6600);
      case 'xiaohongshu':
      case 'xhs':
        return const Color(0xFFFF2442);
      default:
        return primaryColor;
    }
  }
  
  /// 获取指定平台的辅助色
  static Color platformSecondaryColor(String platform) {
    switch (platform) {
      case 'douyin':
        return const Color(0xFF25F4EE);
      case 'kuaishou':
        return const Color(0xFFFF9500);
      case 'xiaohongshu':
      case 'xhs':
        return const Color(0xFFFF6B81);
      default:
        return secondaryColor;
    }
  }
  
  /// 获取平台渐变
  static LinearGradient platformGradient(String platform) {
    return LinearGradient(
      colors: [platformPrimaryColor(platform), platformSecondaryColor(platform)],
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
    );
  }
  
  /// 判断是否为 OLED 纯黑主题（通过 scaffold 背景色判断）
  static bool isOledDark(BuildContext context) {
    return Theme.of(context).scaffoldBackgroundColor == Colors.black;
  }
}
