import 'package:flutter/material.dart';

/// 预设主题色
enum AppThemeColor {
  /// 青色（默认）
  cyan,

  /// 蓝色
  blue,

  /// 紫色
  purple,

  /// 绿色
  green,

  /// 橙色
  orange,

  /// 粉色
  pink,
}

/// 主题色数据
class ThemeColorData {
  /// 主色
  final Color primary;

  /// 主色深色
  final Color primaryDark;

  /// 辅助色
  final Color secondary;

  /// 主题色标识
  final String key;

  /// 显示名称
  final String name;

  const ThemeColorData({
    required this.key,
    required this.name,
    required this.primary,
    required this.primaryDark,
    required this.secondary,
  });
}

/// 主题色扩展
extension AppThemeColorX on AppThemeColor {
  ThemeColorData get data {
    switch (this) {
      case AppThemeColor.cyan:
        return const ThemeColorData(
          key: 'cyan',
          name: '青色',
          primary: Color(0xFF06B6D4),
          primaryDark: Color(0xFF0891B2),
          secondary: Color(0xFF10B981),
        );
      case AppThemeColor.blue:
        return const ThemeColorData(
          key: 'blue',
          name: '蓝色',
          primary: Color(0xFF3B82F6),
          primaryDark: Color(0xFF2563EB),
          secondary: Color(0xFF6366F1),
        );
      case AppThemeColor.purple:
        return const ThemeColorData(
          key: 'purple',
          name: '紫色',
          primary: Color(0xFF8B5CF6),
          primaryDark: Color(0xFF7C3AED),
          secondary: Color(0xFFA855F7),
        );
      case AppThemeColor.green:
        return const ThemeColorData(
          key: 'green',
          name: '绿色',
          primary: Color(0xFF10B981),
          primaryDark: Color(0xFF059669),
          secondary: Color(0xFF34D399),
        );
      case AppThemeColor.orange:
        return const ThemeColorData(
          key: 'orange',
          name: '橙色',
          primary: Color(0xFFF59E0B),
          primaryDark: Color(0xFFD97706),
          secondary: Color(0xFFF97316),
        );
      case AppThemeColor.pink:
        return const ThemeColorData(
          key: 'pink',
          name: '粉色',
          primary: Color(0xFFEC4899),
          primaryDark: Color(0xFFDB2777),
          secondary: Color(0xFFF472B6),
        );
    }
  }

  static AppThemeColor fromKey(String? key) {
    switch (key) {
      case 'blue':
        return AppThemeColor.blue;
      case 'purple':
        return AppThemeColor.purple;
      case 'green':
        return AppThemeColor.green;
      case 'orange':
        return AppThemeColor.orange;
      case 'pink':
        return AppThemeColor.pink;
      case 'cyan':
      default:
        return AppThemeColor.cyan;
    }
  }

  /// 获取所有预设主题色
  static List<ThemeColorData> get allPresets => [
        AppThemeColor.cyan.data,
        AppThemeColor.blue.data,
        AppThemeColor.purple.data,
        AppThemeColor.green.data,
        AppThemeColor.orange.data,
        AppThemeColor.pink.data,
      ];
}
