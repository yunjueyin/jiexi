import 'dart:io';
import 'package:excel/excel.dart' as excel;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:uuid/uuid.dart';
import '../../theme/app_theme.dart';
import '../../models/convert_record.dart';
import '../../models/convert_queue_item.dart';
import '../../providers/convert_history_provider.dart';
import '../../providers/settings_provider.dart';
import '../../services/convert_queue_service.dart';
import '../../utils/platform_detector.dart';
import '../../services/convert_service.dart';
import '../../widgets/link_input_card.dart';

/// 链接转换页面
/// 支持批量转换：标准链接 / 展开短链 / 转换队列
class ConvertPage extends StatefulWidget {
  const ConvertPage({super.key});

  @override
  State<ConvertPage> createState() => _ConvertPageState();
}

class _ConvertPageState extends State<ConvertPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final TextEditingController _inputController = TextEditingController();
  bool _isConverting = false;
  List<ConvertResultItem> _results = [];
  int _successCount = 0;
  int _failCount = 0;
  bool _dedupEnabled = false; // 去重开关，默认关闭

  final ConvertService _convertService = ConvertService();
  final _uuid = const Uuid();

  /// 下拉刷新的 RefreshIndicator 指示器 Key
  final GlobalKey<RefreshIndicatorState> _refreshIndicatorKey =
      GlobalKey<RefreshIndicatorState>();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _inputController.dispose();
    super.dispose();
  }

  /// 从文本中提取所有 URL
  List<String> _extractAllUrls(String text) {
    if (text.isEmpty) return [];
    final urlRegex = RegExp(r'https?://[^\s]+', caseSensitive: false);
    final matches = urlRegex.allMatches(text);
    if (_dedupEnabled) {
      // 去重模式
      final urls = <String>{};
      for (final match in matches) {
        final url = match.group(0);
        if (url != null && url.isNotEmpty) {
          urls.add(url);
        }
      }
      return urls.toList();
    } else {
      // 不去重，保留原始顺序
      final urls = <String>[];
      for (final match in matches) {
        final url = match.group(0);
        if (url != null && url.isNotEmpty) {
          urls.add(url);
        }
      }
      return urls;
    }
  }

  /// 获取平台名称
  String _getPlatformName(String? platform) {
    return VideoPlatformX.fromId(platform).name;
  }

  /// 对 URL 列表应用去重
  List<String> _applyDedup(List<String> urls) {
    if (!_dedupEnabled) return urls;
    final seen = <String>{};
    final result = <String>[];
    for (final url in urls) {
      if (seen.add(url)) {
        result.add(url);
      }
    }
    return result;
  }

  /// 批量转换为短链
  Future<void> _convertToShortLink(List<String> urls) async {
    final processedUrls = _applyDedup(urls);
    if (processedUrls.isEmpty) {
      _showError('未找到有效链接');
      return;
    }

    setState(() {
      _isConverting = true;
      _results = [];
      _successCount = 0;
      _failCount = 0;
    });

    final batchId = _uuid.v4();
    final records = <ConvertRecord>[];
    final results = <ConvertResultItem>[];

    // 并发限制为 3 个
    const concurrency = 3;
    int index = 0;

    Future<void> worker() async {
      while (index < processedUrls.length) {
        final currentIndex = index++;
        final url = processedUrls[currentIndex];
        final result = await _convertService.toShort(url);
        results.add(result);

        if (result.success) {
          _successCount++;
          // 保存到历史
          records.add(ConvertRecord(
            id: 'conv_${_uuid.v4()}',
            originalUrl: result.originalUrl,
            resultUrl: result.resultUrl!,
            platform: result.platform!,
            convertType: 'toShort',
            convertedAt: DateTime.now(),
            batchId: processedUrls.length > 1 ? 'conv_batch_$batchId' : null,
            success: true,
          ));
        } else {
          _failCount++;
        }

        setState(() {
          _results = List.from(results);
        });
      }
    }

    // 启动并发 worker
    final workers = <Future<void>>[];
    for (int i = 0; i < concurrency && i < processedUrls.length; i++) {
      workers.add(worker());
    }
    await Future.wait(workers);

    // 保存到历史
    if (records.isNotEmpty) {
      if (!mounted) return;
      await context.read<ConvertHistoryProvider>().addRecords(records);
    }

    setState(() {
      _isConverting = false;
    });
  }

  /// 批量转换为长链
  Future<void> _convertToLongLink(List<String> urls) async {
    final processedUrls = _applyDedup(urls);
    if (processedUrls.isEmpty) {
      _showError('未找到有效链接');
      return;
    }

    setState(() {
      _isConverting = true;
      _results = [];
      _successCount = 0;
      _failCount = 0;
    });

    final batchId = _uuid.v4();
    final records = <ConvertRecord>[];
    final results = <ConvertResultItem>[];

    // 并发限制为 3 个
    const concurrency = 3;
    int index = 0;

    Future<void> worker() async {
      while (index < processedUrls.length) {
        final currentIndex = index++;
        final url = processedUrls[currentIndex];
        final result = await _convertService.toLong(url);
        results.add(result);

        if (result.success) {
          _successCount++;
          records.add(ConvertRecord(
            id: 'conv_${_uuid.v4()}',
            originalUrl: result.originalUrl,
            resultUrl: result.resultUrl!,
            platform: result.platform!,
            convertType: 'toLong',
            convertedAt: DateTime.now(),
            batchId: processedUrls.length > 1 ? 'conv_batch_$batchId' : null,
            success: true,
          ));
        } else {
          _failCount++;
        }

        setState(() {
          _results = List.from(results);
        });
      }
    }

    final workers = <Future<void>>[];
    for (int i = 0; i < concurrency && i < processedUrls.length; i++) {
      workers.add(worker());
    }
    await Future.wait(workers);

    if (records.isNotEmpty) {
      if (!mounted) return;
      await context.read<ConvertHistoryProvider>().addRecords(records);
    }

    setState(() {
      _isConverting = false;
    });
  }

  /// 添加到转换队列
  Future<void> _addToQueue(List<String> urls, ConvertQueueType type) async {
    final processedUrls = _applyDedup(urls);
    if (processedUrls.isEmpty) {
      _showError('未找到有效链接');
      return;
    }

    final queueService = context.read<ConvertQueueService>();
    final items = await queueService.addTasks(
      urls: processedUrls,
      type: type,
      source: 'manual',
    );

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('已添加 ${items.length} 个任务到转换队列'),
          duration: const Duration(seconds: 2),
        ),
      );
      // 切换到队列 Tab
      _tabController.animateTo(2);
    }
  }

  void _showError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), duration: const Duration(seconds: 2)),
    );
  }

  /// 粘贴剪贴板内容
  Future<void> _pasteFromClipboard() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    final text = data?.text ?? '';
    if (text.isEmpty) return;

    final smartMode = context.read<SettingsProvider>().smartPasteAppendMode;
    final currentText = _inputController.text;

    String newText;
    if (!smartMode || currentText.isEmpty || currentText.trim() == text.trim()) {
      newText = text;
    } else {
      newText = '${currentText.trim()}\n${text.trim()}';
    }

    _inputController.text = newText;
    _inputController.selection = TextSelection.fromPosition(
      TextPosition(offset: newText.length),
    );
    setState(() {
      _results = [];
      _successCount = 0;
      _failCount = 0;
    });
  }

  /// 复制所有成功的结果
  Future<void> _copyAllResults() async {
    final successResults = _results.where((r) => r.success).toList();
    if (successResults.isEmpty) return;
    final text = successResults.map((r) => r.resultUrl!).join('\n');
    await Clipboard.setData(ClipboardData(text: text));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('已复制 ${successResults.length} 条结果'),
          duration: const Duration(seconds: 2),
        ),
      );
    }
  }

  /// 显示复制字段选择菜单
  void _showCopyFieldMenu() {
    final successResults = _results.where((r) => r.success).toList();
    if (successResults.isEmpty) return;

    final fields = <_ConvertCopyField>[
      _ConvertCopyField('resultUrl', '转换后链接', (r) => r.resultUrl ?? ''),
      _ConvertCopyField('originalUrl', '原始链接', (r) => r.originalUrl),
      _ConvertCopyField('platform', '平台', (r) => _platformName(r.platform)),
    ];

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        final dividerColor = isDark ? Colors.grey.shade700 : Colors.grey.shade300;
        return StatefulBuilder(
          builder: (context, setModalState) {
            return DraggableScrollableSheet(
              initialChildSize: 0.5,
              maxChildSize: 0.7,
              minChildSize: 0.35,
              builder: (_, controller) => Container(
                decoration: BoxDecoration(
                  color: Theme.of(context).cardColor,
                  borderRadius:
                      const BorderRadius.vertical(top: Radius.circular(20)),
                ),
                child: Column(
                  children: [
                    const SizedBox(height: 12),
                    Center(
                      child: Container(
                        width: 40,
                        height: 4,
                        decoration: BoxDecoration(
                          color: dividerColor,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Row(
                        children: [
                          const Text(
                            '复制字段',
                            style: TextStyle(
                                fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                          const Spacer(),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: Colors.orange.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(
                              '${successResults.length} 条记录',
                              style: const TextStyle(
                                fontSize: 12,
                                color: Colors.orange,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 8),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Text(
                        '选择要复制的字段，每条一行',
                        style:
                            TextStyle(fontSize: 13, color: secondaryTextColor),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Divider(height: 1, color: dividerColor),
                    // 全部字段选项
                    InkWell(
                      onTap: () {
                        _copyAllResults();
                        Navigator.pop(context);
                      },
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 14),
                        child: Row(
                          children: [
                            Container(
                              width: 36,
                              height: 36,
                              decoration: BoxDecoration(
                                color: Colors.blue.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: const Icon(Icons.copy_all,
                                  color: Colors.blue, size: 20),
                            ),
                            const SizedBox(width: 12),
                            const Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('转换后链接（全部）',
                                      style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.w600)),
                                  SizedBox(height: 2),
                                  Text('快速复制所有转换结果链接',
                                      style: TextStyle(fontSize: 12)),
                                ],
                              ),
                            ),
                            Icon(Icons.chevron_right,
                                color: secondaryTextColor, size: 18),
                          ],
                        ),
                      ),
                    ),
                    Divider(height: 1, color: dividerColor, indent: 68),
                    // 单字段列表
                    Expanded(
                      child: ListView.builder(
                        controller: controller,
                        shrinkWrap: true,
                        itemCount: fields.length,
                        itemBuilder: (context, index) {
                          final field = fields[index];
                          return InkWell(
                            onTap: () {
                              _copyFieldValues(successResults, field);
                              Navigator.pop(context);
                            },
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 20, vertical: 13),
                              child: Row(
                                children: [
                                  Container(
                                    width: 36,
                                    height: 36,
                                    decoration: BoxDecoration(
                                      color: AppTheme.primaryColor
                                          .withOpacity(0.1),
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: Icon(Icons.text_fields,
                                        color: AppTheme.primaryColor,
                                        size: 18),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Text(
                                      field.label,
                                      style: const TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.w500),
                                    ),
                                  ),
                                  Icon(Icons.chevron_right,
                                      color: secondaryTextColor, size: 18),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  String _platformName(String? platform) {
    switch (platform) {
      case 'douyin':
        return '抖音';
      case 'kuaishou':
        return '快手';
      case 'xiaohongshu':
      case 'xhs':
        return '小红书';
      default:
        return '未知';
    }
  }

  /// 复制指定字段的所有值
  void _copyFieldValues(
      List<ConvertResultItem> items, _ConvertCopyField field) {
    final values = items
        .map((i) => field.getValue(i))
        .where((v) => v.isNotEmpty)
        .toList();
    if (values.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('暂无可复制的内容')),
      );
      return;
    }
    Clipboard.setData(ClipboardData(text: values.join('\n')));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('已复制 ${values.length} 条${field.label}')),
    );
  }

  /// 复制单条结果
  Future<void> _copyResult(String url) async {
    await Clipboard.setData(ClipboardData(text: url));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('已复制到剪贴板'),
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  /// 显示导出格式选择弹窗
  void _showExportDialog() {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;

    showModalBottomSheet(
      context: context,
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 16),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                '导出格式',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
              ),
            ),
            const SizedBox(height: 8),
            ListTile(
              leading: const Icon(Icons.grid_on_outlined, color: Colors.teal),
              title: const Text('导出 Excel (.xlsx)'),
              subtitle: Text(
                '标准 Excel 表格格式，支持 WPS / Office 打开',
                style: TextStyle(fontSize: 11, color: secondaryTextColor),
              ),
              onTap: () {
                Navigator.pop(context);
                _exportExcel();
              },
            ),
            ListTile(
              leading: const Icon(Icons.description_outlined, color: Colors.blue),
              title: const Text('导出 TXT 文本'),
              subtitle: Text(
                '纯文本格式，方便查看和复制',
                style: TextStyle(fontSize: 11, color: secondaryTextColor),
              ),
              onTap: () {
                Navigator.pop(context);
                _exportTxt();
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  /// 导出 Excel 表格
  Future<void> _exportExcel() async {
    final successResults = _results.where((r) => r.success).toList();
    if (successResults.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('没有可导出的成功结果')),
      );
      return;
    }

    try {
      final now = DateTime.now();
      final timestamp = '${now.year}${now.month.toString().padLeft(2, '0')}${now.day.toString().padLeft(2, '0')}_'
          '${now.hour.toString().padLeft(2, '0')}${now.minute.toString().padLeft(2, '0')}';
      final typeLabel = _tabController.index == 0 ? '标准链接' : '展开短链';

      // 创建 Excel 工作簿
      final book = excel.Excel.createExcel();
      const defaultSheetName = 'Sheet1';
      const sheetName = '转换结果';

      // 重命名默认 Sheet
      book.rename(defaultSheetName, sheetName);

      // 获取 Sheet 对象
      final sheet = book[sheetName];

      // 表头样式
      final headerStyle = excel.CellStyle(
        bold: true,
        horizontalAlign: excel.HorizontalAlign.Center,
        verticalAlign: excel.VerticalAlign.Center,
      );

      // 数据样式
      final dataStyle = excel.CellStyle(
        verticalAlign: excel.VerticalAlign.Center,
        textWrapping: excel.TextWrapping.WrapText,
      );

      // 表头
      final headers = ['序号', '平台', '原始链接', '转换结果', '状态'];
      for (var i = 0; i < headers.length; i++) {
        final cell = sheet.cell(
            excel.CellIndex.indexByColumnRow(columnIndex: i, rowIndex: 0));
        cell.value = excel.TextCellValue(headers[i]);
        cell.cellStyle = headerStyle;
      }

      // 写入成功数据
      for (var i = 0; i < successResults.length; i++) {
        final r = successResults[i];
        final rowIdx = i + 1;
        final cells = [
          (i + 1).toString(),
          _getPlatformName(r.platform),
          r.originalUrl,
          r.resultUrl ?? '',
          '成功',
        ];
        for (var j = 0; j < cells.length; j++) {
          final cell = sheet.cell(
              excel.CellIndex.indexByColumnRow(columnIndex: j, rowIndex: rowIdx));
          cell.value = excel.TextCellValue(cells[j]);
          cell.cellStyle = dataStyle;
        }
      }

      // 如果有失败的，追加失败记录
      if (_failCount > 0) {
        final failResults = _results.where((r) => !r.success).toList();
        final startRow = successResults.length + 2; // 空一行

        // 失败标题行
        final failTitleCell = sheet.cell(
            excel.CellIndex.indexByColumnRow(columnIndex: 0, rowIndex: startRow - 1));
        failTitleCell.value = excel.TextCellValue('--- 失败记录 ---');
        failTitleCell.cellStyle = excel.CellStyle(
          bold: true,
        );

        // 失败数据
        for (var i = 0; i < failResults.length; i++) {
          final r = failResults[i];
          final rowIdx = startRow + i;
          final cells = [
            (i + 1).toString(),
            _getPlatformName(r.platform),
            r.originalUrl,
            '',
            '失败：${r.errorMessage ?? '未知错误'}',
          ];
          for (var j = 0; j < cells.length; j++) {
            final cell = sheet.cell(
                excel.CellIndex.indexByColumnRow(columnIndex: j, rowIndex: rowIdx));
            cell.value = excel.TextCellValue(cells[j]);
            cell.cellStyle = dataStyle;
          }
        }
      }

      // 设置列宽
      try {
        sheet.setColumnWidth(0, 8);
        sheet.setColumnWidth(1, 10);
        sheet.setColumnWidth(2, 50);
        sheet.setColumnWidth(3, 50);
        sheet.setColumnWidth(4, 20);
      } catch (_) {}

      // 生成文件
      final bytes = book.save();
      if (bytes == null) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('生成 Excel 文件失败')),
          );
        }
        return;
      }

      // 保存到临时文件
      final tempDir = await getTemporaryDirectory();
      final fileName = 'convert_result_${timestamp}.xlsx';
      final file = File('${tempDir.path}/$fileName');
      await file.writeAsBytes(bytes);

      // 分享文件
      await Share.shareFiles(
        [file.path],
        subject: '链接转换结果 - $typeLabel',
        text: '链接转换结果（成功 ${successResults.length} 条）',
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('导出失败：${e.toString()}')),
        );
      }
    }
  }

  /// 导出 TXT 文本
  Future<void> _exportTxt() async {
    final successResults = _results.where((r) => r.success).toList();
    if (successResults.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('没有可导出的成功结果')),
      );
      return;
    }

    try {
      // 生成文件内容
      final now = DateTime.now();
      final timestamp = '${now.year}${now.month.toString().padLeft(2, '0')}${now.day.toString().padLeft(2, '0')}_'
          '${now.hour.toString().padLeft(2, '0')}${now.minute.toString().padLeft(2, '0')}';
      final typeLabel = _tabController.index == 0 ? '标准链接' : '展开短链';

      final buffer = StringBuffer();
      buffer.writeln('# 链接转换结果 - $typeLabel');
      buffer.writeln('# 导出时间：${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')} '
          '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}');
      buffer.writeln('# 成功 ${successResults.length} 条，失败 $_failCount 条');
      buffer.writeln('');
      buffer.writeln('=== 成功结果 ===');
      for (var i = 0; i < successResults.length; i++) {
        final r = successResults[i];
        buffer.writeln('--- 第 ${i + 1} 条 (${_getPlatformName(r.platform)}) ---');
        buffer.writeln('原始：${r.originalUrl}');
        buffer.writeln('结果：${r.resultUrl}');
        buffer.writeln('');
      }
      if (_failCount > 0) {
        final failResults = _results.where((r) => !r.success).toList();
        buffer.writeln('=== 失败记录 ===');
        for (var i = 0; i < failResults.length; i++) {
          final r = failResults[i];
          buffer.writeln('--- 第 ${i + 1} 条 ---');
          buffer.writeln('原始：${r.originalUrl}');
          buffer.writeln('原因：${r.errorMessage ?? '未知错误'}');
          buffer.writeln('');
        }
      }

      // 保存到临时文件
      final tempDir = await getTemporaryDirectory();
      final fileName = 'convert_result_${timestamp}.txt';
      final file = File('${tempDir.path}/$fileName');
      await file.writeAsString(buffer.toString());

      // 分享/导出文件
      await Share.shareFiles(
        [file.path],
        subject: '链接转换结果 - $typeLabel',
        text: '链接转换结果（成功 ${successResults.length} 条）',
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('导出失败：${e.toString()}')),
        );
      }
    }
  }

  /// 清空
  void _clearAll() {
    _inputController.clear();
    setState(() {
      _results = [];
      _successCount = 0;
      _failCount = 0;
    });
  }

  /// 构建去重开关选项
  Widget _buildDedupOption(Color mutedTextColor) {
    return Row(
      children: [
        Switch(
          value: _dedupEnabled,
          onChanged: _isConverting
              ? null
              : (value) {
                  setState(() {
                    _dedupEnabled = value;
                  });
                },
          materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
        ),
        const SizedBox(width: 4),
        Text(
          '自动去重',
          style: TextStyle(fontSize: 12, color: mutedTextColor),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final urls = _extractAllUrls(_inputController.text);
    final urlCount = urls.length;

    return Scaffold(
      appBar: AppBar(
        title: const Text('链接转换', style: TextStyle(fontWeight: FontWeight.w700)),
        bottom: TabBar(
          controller: _tabController,
          labelColor: AppTheme.primaryColor,
          unselectedLabelColor: isDark ? Colors.grey.shade400 : Colors.grey,
          indicatorColor: AppTheme.primaryColor,
          labelStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
          tabs: const [
            Tab(text: '标准链接'),
            Tab(text: '展开短链'),
            Tab(text: '转换队列'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildConvertPanel(
            isShortMode: true,
            onConvert: _convertToShortLink,
            onAddToQueue: (urls) => _addToQueue(urls, ConvertQueueType.toShort),
            urlCount: urlCount,
          ),
          _buildConvertPanel(
            isShortMode: false,
            onConvert: _convertToLongLink,
            onAddToQueue: (urls) => _addToQueue(urls, ConvertQueueType.toLong),
            urlCount: urlCount,
          ),
          _buildQueuePanel(),
        ],
      ),
    );
  }

  Widget _buildConvertPanel({
    required bool isShortMode,
    required Future<void> Function(List<String> urls) onConvert,
    required Future<void> Function(List<String> urls) onAddToQueue,
    required int urlCount,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textColor = isDark ? Colors.white : AppTheme.textPrimary;
    final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
    final mutedTextColor = isDark ? Colors.grey.shade500 : Colors.grey.shade500;
    final cardBgColor = Theme.of(context).cardColor;
    final cardShadow = isDark ? <BoxShadow>[] : AppTheme.shadowMd;
    final hasInput = _inputController.text.isNotEmpty;
    final hasResults = _results.isNotEmpty;
    final totalCount = _successCount + _failCount;
    final isDone = !_isConverting && hasResults;
    // 键盘适配：获取键盘高度，添加底部间距
    final keyboardHeight = MediaQuery.of(context).viewInsets.bottom;

    return SingleChildScrollView(
      physics: const ClampingScrollPhysics(),
      padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + keyboardHeight),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 输入卡片（使用通用 LinkInputCard）
          LinkInputCard(
            controller: _inputController,
            title: isShortMode ? '标准链接' : '展开短链',
            titleIcon: isShortMode ? Icons.link : Icons.open_in_new,
            hintText: '每行一条链接，支持批量转换',
            actions: [
              LinkInputAction(
                id: isShortMode ? 'toShort' : 'toLong',
                label: isShortMode ? '转为标准链接' : '展开为长链',
                icon: isShortMode ? Icons.link : Icons.open_in_new,
                isPrimary: true,
                onTap: _isConverting ? null : (urls) => onConvert(urls),
              ),
              LinkInputAction(
                id: 'addToQueue',
                label: '加入队列',
                icon: Icons.queue_outlined,
                isPrimary: false,
                onTap: _isConverting ? null : (urls) => onAddToQueue(urls),
              ),
            ],
            loadingActionId: _isConverting
                ? (isShortMode ? 'toShort' : 'toLong')
                : null,
            loadingProgressText: hasInput
                ? '$totalCount/$urlCount'
                : null,
            child: _buildDedupOption(mutedTextColor),
          ),

          // 结果卡片
          if (hasResults) ...[
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: cardBgColor,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: _failCount == 0
                      ? AppTheme.successColor.withOpacity(0.3)
                      : AppTheme.warningColor.withOpacity(0.3),
                ),
                boxShadow: cardShadow,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(
                        _failCount == 0 ? Icons.check_circle : Icons.error_outline,
                        color: _failCount == 0 ? AppTheme.successColor : AppTheme.warningColor,
                        size: 20,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        _isConverting
                            ? '转换中...'
                            : (_failCount == 0 ? '全部成功' : '部分成功'),
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: _failCount == 0
                              ? AppTheme.successColor
                              : AppTheme.warningColor,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                          color: AppTheme.successColor.withOpacity(isDark ? 0.2 : 0.1),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          '成功 $_successCount',
                          style: TextStyle(
                            fontSize: 11,
                            color: isDark ? Colors.green.shade300 : Colors.green,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                      if (_failCount > 0) ...[
                        const SizedBox(width: 6),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            color: AppTheme.errorColor.withOpacity(isDark ? 0.2 : 0.1),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            '失败 $_failCount',
                            style: TextStyle(
                              fontSize: 11,
                              color: isDark ? Colors.red.shade300 : Colors.red,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ],
                      const Spacer(),
                      if (isDone && _successCount > 0)
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            TextButton.icon(
                              onPressed: _showExportDialog,
                              icon: const Icon(Icons.file_download_outlined, size: 16),
                              label: const Text('导出文件', style: TextStyle(fontSize: 13)),
                              style: TextButton.styleFrom(
                                foregroundColor: AppTheme.primaryColor,
                                padding: const EdgeInsets.symmetric(horizontal: 8),
                                minimumSize: const Size(0, 32),
                              ),
                            ),
                            const SizedBox(width: 4),
                            TextButton.icon(
                              onPressed: _showCopyFieldMenu,
                              icon: const Icon(Icons.content_copy, size: 16),
                              label: const Text('复制字段', style: TextStyle(fontSize: 13)),
                              style: TextButton.styleFrom(
                                foregroundColor: AppTheme.primaryColor,
                                padding: const EdgeInsets.symmetric(horizontal: 8),
                                minimumSize: const Size(0, 32),
                              ),
                            ),
                            const SizedBox(width: 4),
                            TextButton.icon(
                              onPressed: _copyAllResults,
                              icon: const Icon(Icons.copy_all, size: 16),
                              label: const Text('复制全部', style: TextStyle(fontSize: 13)),
                              style: TextButton.styleFrom(
                                foregroundColor: AppTheme.primaryColor,
                                padding: const EdgeInsets.symmetric(horizontal: 8),
                                minimumSize: const Size(0, 32),
                              ),
                            ),
                          ],
                        ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  const Divider(height: 1),
                  const SizedBox(height: 12),
                  // 结果列表
                  ..._results.asMap().entries.map((entry) {
                    final idx = entry.key;
                    final item = entry.value;
                    return Padding(
                      padding: EdgeInsets.only(bottom: idx == _results.length - 1 ? 0 : 12),
                      child: _buildResultItem(item, isDark, textColor, secondaryTextColor),
                    );
                  }),
                ],
              ),
            ),
          ],

          // 使用说明
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppTheme.primaryColor.withOpacity(isDark ? 0.1 : 0.05),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppTheme.primaryColor.withOpacity(isDark ? 0.25 : 0.15)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.info_outline, size: 18, color: AppTheme.primaryColor),
                    const SizedBox(width: 8),
                    Text(
                      '使用说明',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: textColor,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  isShortMode
                      ? '• 支持批量转换，可粘贴多条链接（换行分隔）\n'
                         '• 支持粘贴分享文案，自动提取所有有效链接\n'
                         '• 勾选「自动去重」后，相同链接只转换一次\n'
                         '• 点击「加入队列」可添加到后台转换队列\n'
                         '• 支持视频/笔记链接和作者主页链接\n'
                         '• 抖音视频：www.douyin.com/video/视频ID\n'
                         '• 抖音作者：www.douyin.com/user/作者ID\n'
                         '• 快手视频：www.kuaishou.com/short-video/视频ID\n'
                         '• 快手作者：www.kuaishou.com/profile/作者ID\n'
                         '• 小红书笔记：www.xiaohongshu.com/explore/笔记ID\n'
                         '• 小红书作者：www.xiaohongshu.com/user/profile/作者ID\n'
                         '• 短链解析需要网络请求'
                      : '• 支持批量转换，可粘贴多条短链（换行分隔）\n'
                         '• 支持粘贴分享文案，自动提取所有有效链接\n'
                         '• 勾选「自动去重」后，相同链接只转换一次\n'
                         '• 点击「加入队列」可添加到后台转换队列\n'
                         '• 支持视频/笔记链接和作者主页链接\n'
                         '• 自动跟随重定向，获取完整带参数的长链接\n'
                         '• 长链接包含来源、渠道等追踪参数\n'
                         '• 需要网络请求，单条约 1-3 秒',
                  style: TextStyle(
                    fontSize: 13,
                    color: secondaryTextColor,
                    height: 1.6,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildResultItem(
    ConvertResultItem item,
    bool isDark,
    Color textColor,
    Color secondaryTextColor,
  ) {
    final platform = item.platform;
    final Color platformColor;
    final Color platformBg;
    if (platform == 'douyin') {
      platformColor = isDark ? Colors.purple.shade300 : Colors.purple;
      platformBg = Colors.purple.withOpacity(isDark ? 0.2 : 0.1);
    } else if (platform == 'kuaishou') {
      platformColor = isDark ? Colors.orange.shade300 : Colors.orange;
      platformBg = Colors.orange.withOpacity(isDark ? 0.2 : 0.1);
    } else if (platform == 'xiaohongshu') {
      platformColor = isDark ? Colors.red.shade300 : Colors.red;
      platformBg = Colors.red.withOpacity(isDark ? 0.2 : 0.1);
    } else {
      platformColor = Colors.grey;
      platformBg = Colors.grey.withOpacity(0.1);
    }

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: item.success
            ? AppTheme.successColor.withOpacity(isDark ? 0.05 : 0.03)
            : AppTheme.errorColor.withOpacity(isDark ? 0.05 : 0.03),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: item.success
              ? AppTheme.successColor.withOpacity(0.2)
              : AppTheme.errorColor.withOpacity(0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                item.success ? Icons.check_circle : Icons.error_outline,
                size: 16,
                color: item.success ? AppTheme.successColor : AppTheme.errorColor,
              ),
              const SizedBox(width: 6),
              if (platform != null) ...[
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                  decoration: BoxDecoration(
                    color: platformBg,
                    borderRadius: BorderRadius.circular(3),
                  ),
                  child: Text(
                    _getPlatformName(platform),
                    style: TextStyle(fontSize: 10, color: platformColor, fontWeight: FontWeight.w500),
                  ),
                ),
                const SizedBox(width: 6),
              ],
              Expanded(
                child: Text(
                  item.success ? '转换成功' : (item.errorMessage ?? '转换失败'),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 12,
                    color: item.success ? AppTheme.successColor : AppTheme.errorColor,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
              if (item.success && item.resultUrl != null)
                InkWell(
                  onTap: () => _copyResult(item.resultUrl!),
                  child: Icon(Icons.copy, size: 16, color: secondaryTextColor),
                ),
            ],
          ),
          const SizedBox(height: 8),
          // 原始链接
          Text(
            '原始：${item.originalUrl}',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(fontSize: 12, color: secondaryTextColor),
          ),
          if (item.success && item.resultUrl != null) ...[
            const SizedBox(height: 4),
            SelectableText(
              item.resultUrl!,
              style: TextStyle(
                fontSize: 12,
                color: AppTheme.primaryColor,
                fontWeight: FontWeight.w500,
                height: 1.4,
              ),
            ),
          ],
        ],
      ),
    );
  }

  // ==================== 转换队列面板 ====================

  Widget _buildQueuePanel() {
    return Consumer<ConvertQueueService>(
      builder: (context, queueService, child) {
        final allItems = queueService.getAll();
        final pending = queueService.pendingCount;
        final processing = queueService.processingCount;
        final completed = queueService.completedCount;
        final failed = queueService.failedCount;

        return RefreshIndicator(
          key: _refreshIndicatorKey,
          onRefresh: () async {
            await queueService.refresh();
          },
          child: ListView(
            physics: const ClampingScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
            children: [
              // 队列统计卡片
              _buildQueueStatsCard(pending, processing, completed, failed),
              const SizedBox(height: 16),
              // 操作栏
              _buildQueueActionBar(queueService),
              const SizedBox(height: 16),
              // 队列列表
              if (allItems.isEmpty)
                _buildEmptyQueue()
              else
                ...allItems.map((item) => Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: _buildQueueItem(item, queueService),
                    )),
            ],
          ),
        );
      },
    );
  }

  Widget _buildQueueStatsCard(
    int pending,
    int processing,
    int completed,
    int failed,
  ) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: AppTheme.primaryGradient,
        borderRadius: BorderRadius.circular(16),
        boxShadow: AppTheme.shadowMd,
      ),
      child: Row(
        children: [
          _buildStatItem('待转换', '$pending', Colors.white),
          Container(
            width: 1,
            height: 36,
            color: Colors.white.withOpacity(0.3),
          ),
          _buildStatItem('进行中', '$processing', Colors.white),
          Container(
            width: 1,
            height: 36,
            color: Colors.white.withOpacity(0.3),
          ),
          _buildStatItem('已完成', '$completed', Colors.white),
          Container(
            width: 1,
            height: 36,
            color: Colors.white.withOpacity(0.3),
          ),
          _buildStatItem('失败', '$failed', Colors.white),
        ],
      ),
    );
  }

  Widget _buildStatItem(String label, String value, Color color) {
    return Expanded(
      child: Column(
        children: [
          Text(
            value,
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w700,
              color: color,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              fontSize: 12,
              color: color.withOpacity(0.85),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQueueActionBar(ConvertQueueService queueService) {
    return Row(
      children: [
        Expanded(
          child: OutlinedButton.icon(
            onPressed: queueService.failedCount > 0
                ? () => queueService.retryFailed()
                : null,
            icon: const Icon(Icons.refresh, size: 18),
            label: const Text('重试失败'),
            style: OutlinedButton.styleFrom(
              foregroundColor: AppTheme.warningColor,
              side: BorderSide(color: AppTheme.warningColor.withOpacity(0.5)),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: OutlinedButton.icon(
            onPressed: queueService.completedCount > 0
                ? () => _confirmClearCompleted(queueService)
                : null,
            icon: const Icon(Icons.delete_sweep_outlined, size: 18),
            label: const Text('清除已完成'),
            style: OutlinedButton.styleFrom(
              foregroundColor: AppTheme.errorColor,
              side: BorderSide(color: AppTheme.errorColor.withOpacity(0.5)),
            ),
          ),
        ),
      ],
    );
  }

  Future<void> _confirmClearCompleted(ConvertQueueService queueService) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('清除已完成'),
        content: const Text('确定要清除所有已完成的转换任务吗？'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('确定', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      await queueService.clearCompleted();
    }
  }

  Widget _buildEmptyQueue() {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      padding: const EdgeInsets.all(32),
      decoration: BoxDecoration(
        color: AppTheme.cardBg(context),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
          width: 0.5,
        ),
      ),
      child: Column(
        children: [
          Icon(
            Icons.queue_outlined,
            size: 48,
            color: AppTheme.textMuted,
          ),
          const SizedBox(height: 12),
          Text(
            '转换队列为空',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: AppTheme.textSecondaryColor(context),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            '在转换页面点击「加入队列」添加任务',
            style: TextStyle(
              fontSize: 12,
              color: AppTheme.textTertiaryColor(context),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQueueItem(ConvertQueueItem item, ConvertQueueService queueService) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final borderColor = isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0);

    Color statusColor;
    IconData statusIcon;
    switch (item.status) {
      case ConvertQueueStatus.pending:
        statusColor = AppTheme.textSecondaryColor(context);
        statusIcon = Icons.schedule_outlined;
        break;
      case ConvertQueueStatus.processing:
        statusColor = AppTheme.infoColor;
        statusIcon = Icons.autorenew;
        break;
      case ConvertQueueStatus.completed:
        statusColor = AppTheme.successColor;
        statusIcon = Icons.check_circle_outline;
        break;
      case ConvertQueueStatus.failed:
        statusColor = AppTheme.errorColor;
        statusIcon = Icons.error_outline;
        break;
    }

    return Container(
      decoration: BoxDecoration(
        color: AppTheme.cardBg(context),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: borderColor, width: 0.5),
        boxShadow: AppTheme.shadowSm,
      ),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            // 状态图标
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: statusColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(
                statusIcon,
                size: 20,
                color: statusColor,
              ),
            ),
            const SizedBox(width: 12),
            // 主体内容
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      // 类型标签
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: AppTheme.primaryColor.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          item.typeLabel,
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                            color: AppTheme.primaryColor,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      // 状态标签
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: statusColor.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          item.statusLabel,
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                            color: statusColor,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    item.videoTitle ?? item.originalUrl,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      color: AppTheme.textPrimaryColor(context),
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    item.originalUrl,
                    style: TextStyle(
                      fontSize: 11,
                      color: AppTheme.textTertiaryColor(context),
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  if (item.status == ConvertQueueStatus.completed &&
                      item.resultUrl != null) ...[
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Icon(
                          Icons.link_outlined,
                          size: 12,
                          color: AppTheme.successColor,
                        ),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(
                            item.resultUrl!,
                            style: TextStyle(
                              fontSize: 11,
                              color: AppTheme.successColor,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        InkWell(
                          onTap: () => _copyResult(item.resultUrl!),
                          child: Icon(
                            Icons.copy,
                            size: 14,
                            color: AppTheme.textTertiaryColor(context),
                          ),
                        ),
                      ],
                    ),
                  ],
                  if (item.status == ConvertQueueStatus.failed &&
                      item.errorMessage != null) ...[
                    const SizedBox(height: 4),
                    Text(
                      '错误：${item.errorMessage}',
                      style: TextStyle(
                        fontSize: 11,
                        color: AppTheme.errorColor,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ],
              ),
            ),
            // 删除按钮
            IconButton(
              icon: const Icon(Icons.close, size: 20),
              onPressed: () => queueService.removeTask(item.id),
              color: AppTheme.textTertiaryColor(context),
              constraints: const BoxConstraints(),
              padding: const EdgeInsets.all(4),
            ),
          ],
        ),
      ),
    );
  }
}

/// 转换记录复制字段配置
class _ConvertCopyField {
  final String key;
  final String label;
  final String Function(ConvertResultItem item) getValue;

  _ConvertCopyField(this.key, this.label, this.getValue);
}
