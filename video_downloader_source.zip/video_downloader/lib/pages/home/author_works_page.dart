import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:provider/provider.dart';
import '../../theme/app_theme.dart';
import '../../models/video_info.dart';
import '../../providers/download_provider.dart';
import '../../services/proxy_service.dart';
import '../../widgets/empty_state.dart';
import '../../widgets/gradient_button.dart';
import '../../widgets/platform_badge.dart';
import '../../widgets/skeleton.dart';

/// 作者主页作品展示页面
///
/// 接收参数：
/// - [authorUrl] 作者主页 URL
/// - [authorName] 作者名称
/// - [authorAvatar] 作者头像
/// - [platform] 平台名称（douyin / kuaishou）
class AuthorWorksPage extends StatefulWidget {
  final String authorUrl;
  final String authorName;
  final String authorAvatar;
  final String platform;

  const AuthorWorksPage({
    super.key,
    required this.authorUrl,
    required this.authorName,
    required this.authorAvatar,
    required this.platform,
  });

  @override
  State<AuthorWorksPage> createState() => _AuthorWorksPageState();
}

class _AuthorWorksPageState extends State<AuthorWorksPage> {
  final Dio _dio = Dio();
  final ScrollController _scrollController = ScrollController();

  // 作品列表
  List<VideoInfo> _works = [];

  // 分页相关
  int _cursor = 0;
  bool _hasMore = true;
  bool _loading = false;
  bool _loadingMore = false;

  // 错误信息
  String? _errorMessage;

  // 作者信息
  String? _signature;
  int? _followerCount;
  int? _awemeCount;
  int? _totalFavorited;

  // 批量选择模式
  bool _selectMode = false;
  final Set<String> _selectedIds = {};

  // ==================== 生命周期 ====================

  @override
  void initState() {
    super.initState();
    _dio.options = BaseOptions(
      connectTimeout: const Duration(seconds: 15),
      receiveTimeout: const Duration(seconds: 20),
      validateStatus: (status) => status! < 500,
    );
    _scrollController.addListener(_onScroll);
    // 应用代理配置
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final proxyService = context.read<ProxyService>();
      proxyService.applyToDio(_dio);
      proxyService.addListener(_onProxyChanged);
    });
    // 首次加载
    _loadWorks();
  }

  void _onProxyChanged() {
    final proxyService = context.read<ProxyService>();
    proxyService.applyToDio(_dio);
  }

  @override
  void dispose() {
    _scrollController.dispose();
    try {
      context.read<ProxyService>().removeListener(_onProxyChanged);
    } catch (_) {}
    _dio.close();
    super.dispose();
  }

  // ==================== 主题辅助方法 ====================

  bool get _isDark => Theme.of(context).brightness == Brightness.dark;
  Color get _textColor => _isDark ? Colors.white : AppTheme.textPrimary;
  Color get _secondaryTextColor =>
      _isDark ? Colors.grey.shade400 : AppTheme.textSecondary;
  Color get _mutedTextColor =>
      _isDark ? Colors.grey.shade500 : AppTheme.textMuted;
  Color get _cardBgColor => Theme.of(context).cardColor;
  Color get _borderColor =>
      _isDark ? Colors.grey.shade700 : Colors.grey.shade200;

  // ==================== 滚动监听（上拉加载更多） ====================

  void _onScroll() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent - 200) {
      _loadMoreWorks();
    }
  }

  // ==================== 数据加载 ====================

  /// 首次加载 / 下拉刷新
  Future<void> _loadWorks() async {
    if (_loading) return;
    setState(() {
      _loading = true;
      _errorMessage = null;
      _cursor = 0;
      _hasMore = true;
    });

    try {
      final result = await _fetchWorks(cursor: 0);
      setState(() {
        _works = result.works;
        _cursor = result.nextCursor;
        _hasMore = result.hasMore;
        _loading = false;
        // 更新作者信息
        if (result.authorInfo != null) {
          _signature = result.authorInfo!['signature'];
          _followerCount = result.authorInfo!['followerCount'];
          _awemeCount = result.authorInfo!['awemeCount'];
          _totalFavorited = result.authorInfo!['totalFavorited'];
        }
      });
    } catch (e) {
      setState(() {
        _errorMessage = _formatError(e);
        _loading = false;
      });
    }
  }

  /// 上拉加载更多
  Future<void> _loadMoreWorks() async {
    if (_loadingMore || !_hasMore || _loading) return;
    setState(() {
      _loadingMore = true;
    });

    try {
      final result = await _fetchWorks(cursor: _cursor);
      setState(() {
        _works.addAll(result.works);
        _cursor = result.nextCursor;
        _hasMore = result.hasMore;
        _loadingMore = false;
      });
    } catch (e) {
      setState(() {
        _loadingMore = false;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('加载更多失败：${_formatError(e)}'),
            duration: const Duration(seconds: 2),
          ),
        );
      }
    }
  }

  /// 从作者主页 URL 解析并获取作品列表
  ///
  /// 抖音：通过 sec_uid 调用 aweme/post 接口
  /// 快手：通过用户 ID 获取作品列表
  Future<_WorksFetchResult> _fetchWorks({required int cursor}) async {
    final platform = widget.platform;

    if (platform == 'douyin') {
      return await _fetchDouyinWorks(cursor: cursor);
    } else if (platform == 'kuaishou') {
      return await _fetchKuaishouWorks(cursor: cursor);
    }

    throw Exception('不支持的平台：$platform');
  }

  // ==================== 抖音作品抓取 ====================

  /// 从 URL 提取 sec_uid
  String? _extractSecUid(String url) {
    final patterns = [
      RegExp(r'/share/user/([A-Za-z0-9_-]{15,})'),
      RegExp(r'/user/([A-Za-z0-9_-]{15,})'),
      RegExp(r'[?&]sec_uid=([A-Za-z0-9_-]{15,})'),
    ];
    for (final p in patterns) {
      final m = p.firstMatch(url);
      if (m != null) {
        final id = m.group(1)!;
        if (!RegExp(r'^\d+$').hasMatch(id)) return id;
      }
    }
    return null;
  }

  Future<_WorksFetchResult> _fetchDouyinWorks({required int cursor}) async {
    final secUid = _extractSecUid(widget.authorUrl);
    if (secUid == null) {
      throw Exception('无法从链接中识别作者 sec_uid');
    }

    final count = 20;
    final response = await _dio.get(
      'https://www.iesdouyin.com/web/api/v2/aweme/post/',
      queryParameters: {
        'sec_uid': secUid,
        'count': count.toString(),
        'max_cursor': cursor.toString(),
      },
      options: Options(headers: _douyinHeaders()),
    );

    dynamic data = response.data;
    if (data is String) data = jsonDecode(data);
    if (data is! Map) {
      throw Exception('抖音接口返回数据格式异常');
    }

    final awemeList = data['aweme_list'];
    if (awemeList is! List) {
      // 可能被风控拦截
      final statusCode = data['status_code'];
      final statusMsg = data['status_msg'];
      if (statusCode != null && statusCode != 0) {
        throw Exception('抖音接口错误：${statusMsg ?? statusCode}');
      }
      throw Exception('未获取到作品列表数据');
    }

    final works = <VideoInfo>[];
    for (final aweme in awemeList) {
      if (aweme is! Map) continue;
      try {
        final video = _parseDouyinAweme(aweme);
        works.add(video);
      } catch (_) {
        // 跳过解析失败的条目
        continue;
      }
    }

    // 分页信息
    final hasMore = data['has_more'] == true || data['hasMore'] == true;
    final nextCursor = data['max_cursor'] ?? data['nextCursor'] ?? 0;

    // 首次加载时尝试提取作者信息
    Map<String, dynamic>? authorInfo;
    if (cursor == 0 && awemeList.isNotEmpty) {
      final first = awemeList.first;
      if (first is Map) {
        final author = first['author'];
        if (author is Map) {
          authorInfo = {
            'signature': author['signature']?.toString(),
            'followerCount': author['follower_count'] is int
                ? author['follower_count']
                : int.tryParse(author['follower_count']?.toString() ?? ''),
            'awemeCount': author['aweme_count'] is int
                ? author['aweme_count']
                : int.tryParse(author['aweme_count']?.toString() ?? ''),
            'totalFavorited': author['total_favorited'] is int
                ? author['total_favorited']
                : int.tryParse(
                    author['total_favorited']?.toString() ?? ''),
          };
        }
      }
    }

    return _WorksFetchResult(
      works: works,
      hasMore: hasMore && works.isNotEmpty,
      nextCursor: nextCursor is int ? nextCursor : int.tryParse(nextCursor.toString()) ?? 0,
      authorInfo: authorInfo,
    );
  }

  /// 解析抖音 aweme 对象为 VideoInfo
  VideoInfo _parseDouyinAweme(Map aweme) {
    final video = aweme['video'];
    final author = aweme['author'];
    final images = aweme['images'];

    // 图文类型判断
    List<String>? imageList;
    if (images is List && images.isNotEmpty) {
      imageList = <String>[];
      for (final img in images) {
        if (img is Map) {
          final urlList = img['url_list'];
          if (urlList is List && urlList.isNotEmpty) {
            imageList.add(urlList.first.toString());
            continue;
          }
          final u = img['url'] ?? img['src'];
          if (u != null && u.toString().isNotEmpty) {
            imageList.add(u.toString());
          }
        } else if (img is String && img.isNotEmpty) {
          imageList.add(img);
        }
      }
      if (imageList.isEmpty) imageList = null;
    }
    final isImage = imageList != null && imageList.isNotEmpty;

    // 视频地址
    String? videoUrl;
    String? videoUrlHd;
    if (!isImage && video is Map) {
      final playAddr = video['play_addr'];
      if (playAddr is Map) {
        final urls = playAddr['url_list'];
        if (urls is List && urls.isNotEmpty) {
          videoUrl = urls.first.toString().replaceAll('/playwm/', '/play/');
          if (urls.length > 1) {
            videoUrlHd = urls.last.toString().replaceAll('/playwm/', '/play/');
          }
        }
      }
      // bit_rate 高清地址
      final bitRate = video['bit_rate'];
      if (bitRate is List && bitRate.isNotEmpty) {
        for (final rate in bitRate) {
          if (rate is Map) {
            final addr = rate['play_addr'] ?? rate['download_addr'];
            if (addr is Map) {
              final urls = addr['url_list'];
              if (urls is List && urls.isNotEmpty) {
                final u = urls.first.toString().replaceAll('/playwm/', '/play/');
                videoUrlHd ??= u;
                videoUrl ??= u;
                break;
              }
            }
          }
        }
      }
    }

    // 封面
    String cover = '';
    if (isImage) {
      cover = imageList!.first;
    } else if (video is Map) {
      for (final field in ['cover', 'origin_cover', 'dynamic_cover']) {
        final cv = video[field];
        if (cv is Map) {
          final urls = cv['url_list'];
          if (urls is List && urls.isNotEmpty) {
            cover = urls.first.toString();
            break;
          }
        }
      }
    }

    // 基本信息
    final id = aweme['aweme_id']?.toString() ??
        aweme['item_id']?.toString() ??
        DateTime.now().millisecondsSinceEpoch.toString();

    int? durationSeconds;
    if (!isImage && video is Map) {
      final d = video['duration'];
      if (d is int) durationSeconds = d ~/ 1000;
      if (d is String) durationSeconds = (int.tryParse(d) ?? 0) ~/ 1000;
    }

    // 点赞数（存在 statistics 中）
    final statistics = aweme['statistics'];
    int? diggCount;
    if (statistics is Map) {
      diggCount = statistics['digg_count'] is int
          ? statistics['digg_count']
          : int.tryParse(statistics['digg_count']?.toString() ?? '');
    }

    return VideoInfo(
      id: id,
      url: 'https://www.douyin.com/video/$id',
      platform: 'douyin',
      title: _cleanTitle(aweme['desc']?.toString() ??
          aweme['item_title']?.toString() ??
          '无标题'),
      author: author is Map
          ? (author['nickname']?.toString() ?? widget.authorName)
          : widget.authorName,
      cover: cover,
      videoUrl: isImage ? null : videoUrl,
      videoUrlHd: isImage ? null : videoUrlHd,
      durationSeconds: durationSeconds,
      parsedAt: DateTime.now(),
      type: isImage ? 'image' : 'video',
      images: imageList,
    );
  }

  Map<String, String> _douyinHeaders() => {
        'User-Agent':
            'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
        'Accept': 'application/json, text/plain, */*',
        'Referer': 'https://www.iesdouyin.com/',
      };

  // ==================== 快手作品抓取 ====================

  /// 从 URL 提取快手用户 ID
  String? _extractKuaishouUserId(String url) {
    final patterns = [
      RegExp(r'/profile/([A-Za-z0-9_-]{5,})'),
      RegExp(r'/fw/user/([A-Za-z0-9_-]{5,})'),
      RegExp(r'/u/([A-Za-z0-9_-]{10,})'),
      RegExp(r'[?&]userId=([A-Za-z0-9_-]{5,})'),
      RegExp(r'[?&]principalId=([A-Za-z0-9_-]{5,})'),
    ];
    for (final p in patterns) {
      final m = p.firstMatch(url);
      if (m != null) return m.group(1);
    }
    return null;
  }

  Future<_WorksFetchResult> _fetchKuaishouWorks({required int cursor}) async {
    final userId = _extractKuaishouUserId(widget.authorUrl);
    if (userId == null) {
      throw Exception('无法从链接中识别快手用户 ID');
    }

    // 先获取 Cookie
    final home = await _dio.get(
      'https://www.kuaishou.com/',
      options: Options(headers: _kuaishouPcHeaders()),
    );
    final setCookies = home.headers['set-cookie'] ?? const <String>[];
    final cookiePairs = setCookies
        .map((c) => c.split(';').first.trim())
        .where((c) => c.contains('='))
        .toList();
    final cookie = cookiePairs.join('; ');

    // 调用 GraphQL 接口获取作者作品列表
    final query = jsonEncode({
      'operationName': 'visionProfilePhotoList',
      'variables': {
        'userId': userId,
        'pcursor': cursor == 0 ? '' : cursor.toString(),
        'page': 'profile',
        'count': 20,
      },
      'query':
          'query visionProfilePhotoList(\$userId: String, \$pcursor: String, \$page: String, \$count: Int) { visionProfilePhotoList(userId: \$userId, pcursor: \$pcursor, page: \$page, count: \$count) { result { llsid pcursor photoList { id duration caption likeCount viewCount coverUrl photoUrl user { id name avatar } } } } }',
    });

    final response = await _dio.post(
      'https://www.kuaishou.com/graphql',
      data: query,
      options: Options(
        headers: {
          ..._kuaishouPcHeaders(),
          'Cookie': cookie,
          'Content-Type': 'application/json',
          'Origin': 'https://www.kuaishou.com',
        },
      ),
    );

    dynamic data = response.data;
    if (data is String) data = jsonDecode(data);
    if (data is! Map) {
      throw Exception('快手接口返回数据格式异常');
    }

    final errors = data['errors'];
    if (errors is List && errors.isNotEmpty) {
      final msg = errors[0] is Map ? errors[0]['message']?.toString() : '';
      if (msg?.contains('captcha') == true) {
        throw Exception('快手需要人机验证，请稍后重试');
      }
      throw Exception('快手接口错误：$msg');
    }

    final result = data['data']?['visionProfilePhotoList']?['result'];
    if (result is! Map) {
      throw Exception('未获取到作品列表数据');
    }

    final photoList = result['photoList'];
    final works = <VideoInfo>[];
    if (photoList is List) {
      for (final photo in photoList) {
        if (photo is! Map) continue;
        try {
          final video = _parseKuaishouPhoto(photo, userId);
          works.add(video);
        } catch (_) {
          continue;
        }
      }
    }

    // 分页信息
    final pcursor = result['pcursor']?.toString() ?? '';
    final hasMore = pcursor.isNotEmpty && pcursor != 'no_more' && works.isNotEmpty;
    int nextCursor = 0;
    if (hasMore) {
      nextCursor = int.tryParse(pcursor) ?? (cursor + works.length);
    }

    return _WorksFetchResult(
      works: works,
      hasMore: hasMore,
      nextCursor: nextCursor,
    );
  }

  /// 解析快手 photo 对象为 VideoInfo
  VideoInfo _parseKuaishouPhoto(Map photo, String userId) {
    String? videoUrl;
    String? videoUrlHd;

    final photoUrl = photo['photoUrl'];
    if (photoUrl is String && photoUrl.isNotEmpty) {
      videoUrl = photoUrl;
    }

    final mainMvUrls = photo['mainMvUrls'];
    if (mainMvUrls is List && mainMvUrls.isNotEmpty) {
      for (final mv in mainMvUrls) {
        if (mv is Map) {
          final u = mv['url']?.toString();
          if (u != null && u.isNotEmpty) {
            videoUrl ??= u;
            if (videoUrlHd == null || u.length > videoUrlHd.length) {
              videoUrlHd = u;
            }
          }
        } else if (mv is String && videoUrl == null) {
          videoUrl = mv;
        }
      }
    }

    // 封面
    final cover = photo['coverUrl']?.toString() ??
        photo['poster']?.toString() ??
        photo['thumbnail']?.toString() ??
        '';

    final id = photo['photoId']?.toString() ??
        photo['id']?.toString() ??
        DateTime.now().millisecondsSinceEpoch.toString();

    int? durationSeconds;
    final d = photo['duration'];
    if (d is int) durationSeconds = d ~/ 1000;
    if (d is String) durationSeconds = int.tryParse(d);

    final likeCount = photo['likeCount'] is int
        ? photo['likeCount']
        : int.tryParse(photo['likeCount']?.toString() ?? '');

    return VideoInfo(
      id: id,
      url: 'https://www.kuaishou.com/short-video/$id',
      platform: 'kuaishou',
      title: _cleanTitle(photo['caption']?.toString() ??
          photo['originCaption']?.toString() ??
          '无标题'),
      author: widget.authorName,
      cover: cover,
      videoUrl: videoUrl,
      videoUrlHd: videoUrlHd,
      durationSeconds: durationSeconds,
      parsedAt: DateTime.now(),
      type: 'video',
    );
  }

  Map<String, String> _kuaishouPcHeaders() => {
        'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'zh-CN,zh;q=0.9',
        'Referer': 'https://www.kuaishou.com/',
      };

  // ==================== 工具方法 ====================

  String _cleanTitle(String title) {
    var t = title.trim();
    if (t.isEmpty) return '无标题';
    if (t.length > 50) t = '${t.substring(0, 50)}...';
    return t;
  }

  String _formatError(Object e) {
    final msg = e.toString().replaceAll('Exception: ', '');
    return msg.length > 100 ? '${msg.substring(0, 100)}...' : msg;
  }

  String _formatCount(int? count) {
    if (count == null) return '-';
    if (count >= 10000) {
      return '${(count / 10000).toStringAsFixed(1)}万';
    }
    return count.toString();
  }

  // ==================== 选择模式操作 ====================

  void _toggleSelectMode() {
    setState(() {
      _selectMode = !_selectMode;
      if (!_selectMode) {
        _selectedIds.clear();
      }
    });
  }

  void _toggleSelect(String id) {
    setState(() {
      if (_selectedIds.contains(id)) {
        _selectedIds.remove(id);
      } else {
        _selectedIds.add(id);
      }
    });
  }

  void _selectAll() {
    setState(() {
      if (_selectedIds.length == _works.length) {
        _selectedIds.clear();
      } else {
        _selectedIds.addAll(_works.map((e) => e.id));
      }
    });
  }

  // ==================== 下载操作 ====================

  /// 批量下载选中的作品
  Future<void> _batchDownload() async {
    if (_selectedIds.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('请先选择要下载的作品')),
      );
      return;
    }

    final selectedVideos =
        _works.where((v) => _selectedIds.contains(v.id)).toList();

    // 确认弹窗
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('批量下载'),
        content: Text('确定要下载选中的 ${selectedVideos.length} 个作品吗？'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('确定下载'),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    final downloadProvider = context.read<DownloadProvider>();
    int successCount = 0;
    int failCount = 0;

    for (final video in selectedVideos) {
      try {
        await downloadProvider.addDownload(video, 'hd');
        successCount++;
      } catch (_) {
        failCount++;
      }
    }

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('已添加 $successCount 个下载任务${failCount > 0 ? '，$failCount 个失败' : ''}'),
          duration: const Duration(seconds: 2),
        ),
      );
      // 退出选择模式
      setState(() {
        _selectMode = false;
        _selectedIds.clear();
      });
    }
  }

  /// 单个作品下载
  Future<void> _downloadSingle(VideoInfo video) async {
    try {
      await context.read<DownloadProvider>().addDownload(video, 'hd');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('已添加到下载队列')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('下载失败：${_formatError(e)}')),
        );
      }
    }
  }

  /// 显示作品详情底部弹窗
  void _showWorkDetail(VideoInfo video) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => _WorkDetailSheet(
        video: video,
        onDownload: () {
          Navigator.pop(context);
          _downloadSingle(video);
        },
      ),
    );
  }

  // ==================== 构建方法 ====================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: _buildAppBar(),
      body: Column(
        children: [
          Expanded(child: _buildBody()),
          if (_selectMode) _buildBottomActionBar(),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      title: Text(widget.authorName),
      leading: IconButton(
        icon: const Icon(Icons.arrow_back_ios_new, size: 20),
        onPressed: () => Navigator.of(context).pop(),
      ),
      actions: [
        if (!_loading && _works.isNotEmpty)
          TextButton(
            onPressed: _toggleSelectMode,
            child: Text(
              _selectMode ? '取消' : '选择',
              style: TextStyle(
                color: Theme.of(context).primaryColor,
                fontSize: 15,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        const SizedBox(width: 4),
      ],
    );
  }

  Widget _buildBody() {
    // 加载中
    if (_loading && _works.isEmpty) {
      return _buildLoadingState();
    }

    // 错误状态
    if (_errorMessage != null && _works.isEmpty) {
      return _buildErrorState();
    }

    // 空状态
    if (_works.isEmpty && !_loading) {
      return _buildEmptyState();
    }

    // 正常列表
    return RefreshIndicator(
      onRefresh: _loadWorks,
      color: AppTheme.primaryColor,
      child: CustomScrollView(
        controller: _scrollController,
        physics: const AlwaysScrollableScrollPhysics(),
        slivers: [
          // 作者信息区域
          SliverToBoxAdapter(
            child: _buildAuthorHeader(),
          ),
          // 作品数量标题
          SliverToBoxAdapter(
            child: _buildSectionTitle(),
          ),
          // 作品网格
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            sliver: SliverGrid(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: 0.72,
              ),
              delegate: SliverChildBuilderDelegate(
                (context, index) => _buildWorkCard(index),
                childCount: _works.length,
              ),
            ),
          ),
          // 加载更多状态
          SliverToBoxAdapter(
            child: _buildLoadMoreFooter(),
          ),
          const SliverToBoxAdapter(
            child: SizedBox(height: 16),
          ),
        ],
      ),
    );
  }

  // ==================== 作者信息头部 ====================

  Widget _buildAuthorHeader() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 8, 16, 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _cardBgColor,
        borderRadius: BorderRadius.circular(16),
        boxShadow: _isDark ? null : AppTheme.shadowMd,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 头像
          _buildAvatar(),
          const SizedBox(width: 14),
          // 信息
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        widget.authorName,
                        style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                          color: _textColor,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    PlatformBadge(platform: widget.platform, size: 20),
                  ],
                ),
                const SizedBox(height: 6),
                if (_signature != null && _signature!.isNotEmpty)
                  Text(
                    _signature!,
                    style: TextStyle(
                      fontSize: 13,
                      color: _secondaryTextColor,
                      height: 1.4,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    _buildStatItem('粉丝', _followerCount),
                    const SizedBox(width: 16),
                    _buildStatItem('作品', _awemeCount),
                    const SizedBox(width: 16),
                    _buildStatItem('获赞', _totalFavorited),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAvatar() {
    return Container(
      width: 64,
      height: 64,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(
          color: _borderColor,
          width: 1.5,
        ),
      ),
      child: ClipOval(
        child: widget.authorAvatar.isNotEmpty
            ? Image.network(
                widget.authorAvatar,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => _buildAvatarPlaceholder(),
              )
            : _buildAvatarPlaceholder(),
      ),
    );
  }

  Widget _buildAvatarPlaceholder() {
    return Container(
      color: _isDark ? Colors.grey.shade800 : Colors.grey.shade200,
      child: Icon(
        Icons.person,
        size: 32,
        color: _isDark ? Colors.grey.shade600 : Colors.grey.shade400,
      ),
    );
  }

  Widget _buildStatItem(String label, int? value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          _formatCount(value),
          style: TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w700,
            color: _textColor,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: _mutedTextColor,
          ),
        ),
      ],
    );
  }

  // ==================== 作品标题栏 ====================

  Widget _buildSectionTitle() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: Row(
        children: [
          Text(
            '全部作品',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: _textColor,
            ),
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            decoration: BoxDecoration(
              color: AppTheme.primaryColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              '${_works.length}',
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: AppTheme.primaryColor,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== 作品卡片 ====================

  Widget _buildWorkCard(int index) {
    final work = _works[index];
    final isSelected = _selectedIds.contains(work.id);

    return GestureDetector(
      onTap: () {
        if (_selectMode) {
          _toggleSelect(work.id);
        } else {
          _showWorkDetail(work);
        }
      },
      onLongPress: () {
        if (!_selectMode) {
          setState(() {
            _selectMode = true;
            _selectedIds.add(work.id);
          });
        }
      },
      child: Container(
        decoration: BoxDecoration(
          color: _cardBgColor,
          borderRadius: BorderRadius.circular(12),
          boxShadow: _isDark ? null : AppTheme.shadowMd,
          border: Border.all(
            color: isSelected
                ? AppTheme.primaryColor
                : (_isDark ? Colors.grey.shade700 : Colors.grey.shade200),
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Stack(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // 封面图
                Expanded(
                  child: ClipRRect(
                    borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(11),
                    ),
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        work.cover.isNotEmpty
                            ? Image.network(
                                work.cover,
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) =>
                                    _buildCoverPlaceholder(work.platform),
                              )
                            : _buildCoverPlaceholder(work.platform),
                        // 类型标签
                        Positioned(
                          top: 8,
                          left: 8,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 6,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.black.withOpacity(0.5),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              work.typeName,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 10,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ),
                        // 时长（仅视频）
                        if (work.isVideo && work.durationSeconds != null)
                          Positioned(
                            bottom: 8,
                            right: 8,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 6,
                                vertical: 2,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.black.withOpacity(0.5),
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: Text(
                                _formatDuration(work.durationSeconds!),
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
                // 标题和信息
                Padding(
                  padding: const EdgeInsets.fromLTRB(8, 8, 8, 8),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        work.title,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                          height: 1.3,
                          color: _textColor,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Row(
                        children: [
                          Icon(
                            Icons.favorite_border,
                            size: 12,
                            color: _mutedTextColor,
                          ),
                          const SizedBox(width: 3),
                          Text(
                            _formatCount(_getDiggCount(work)),
                            style: TextStyle(
                              fontSize: 11,
                              color: _mutedTextColor,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
            // 选择模式勾选框
            if (_selectMode)
              Positioned(
                top: 6,
                right: 6,
                child: Container(
                  width: 22,
                  height: 22,
                  decoration: BoxDecoration(
                    color: isSelected
                        ? AppTheme.primaryColor
                        : Colors.white.withOpacity(0.9),
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: isSelected
                          ? AppTheme.primaryColor
                          : Colors.grey.shade300,
                      width: 1.5,
                    ),
                  ),
                  child: isSelected
                      ? const Icon(
                          Icons.check,
                          size: 14,
                          color: Colors.white,
                        )
                      : null,
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildCoverPlaceholder(String platform) {
    return Container(
      color: _isDark ? Colors.grey.shade800 : Colors.grey.shade200,
      child: Center(
        child: PlatformBadge(platform: platform, size: 32),
      ),
    );
  }

  /// 从 VideoInfo 中获取点赞数（存储在 extra 或解析时附带）
  int? _getDiggCount(VideoInfo video) {
    // 抖音作品解析时没有直接存储点赞数到 VideoInfo
    // 这里返回 null，UI 会显示为 "-"
    // 实际项目中可以扩展 VideoInfo 或使用额外的 map 存储
    return null;
  }

  String _formatDuration(int seconds) {
    final min = seconds ~/ 60;
    final sec = seconds % 60;
    return '${min.toString().padLeft(2, '0')}:${sec.toString().padLeft(2, '0')}';
  }

  // ==================== 底部加载更多 ====================

  Widget _buildLoadMoreFooter() {
    if (_loadingMore) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 16),
        child: Center(
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  valueColor:
                      AlwaysStoppedAnimation<Color>(AppTheme.primaryColor),
                ),
              ),
              const SizedBox(width: 10),
              Text(
                '加载中...',
                style: TextStyle(color: _secondaryTextColor, fontSize: 13),
              ),
            ],
          ),
        ),
      );
    }

    if (!_hasMore && _works.isNotEmpty) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 16),
        child: Center(
          child: Text(
            '— 已经到底啦 —',
            style: TextStyle(color: _mutedTextColor, fontSize: 12),
          ),
        ),
      );
    }

    return const SizedBox.shrink();
  }

  // ==================== 状态页面 ====================

  Widget _buildLoadingState() {
    return GridView.builder(
      padding: const EdgeInsets.all(12),
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
        childAspectRatio: 0.72,
      ),
      itemCount: 6,
      itemBuilder: (_, __) => _buildSkeletonCard(),
    );
  }

  Widget _buildSkeletonCard() {
    return Container(
      decoration: BoxDecoration(
        color: _cardBgColor,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: ClipRRect(
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(11)),
              child: Skeleton.rect(
                width: double.infinity,
                height: double.infinity,
                radius: 0,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(8, 8, 8, 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Skeleton.textLine(width: double.infinity, height: 12),
                const SizedBox(height: 4),
                Skeleton.textLine(width: 60, height: 10),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: EmptyState(
        title: '加载失败',
        subtitle: _errorMessage,
        iconData: Icons.error_outline,
        iconBgColor: Colors.red.withOpacity(0.1),
        iconColor: Colors.red,
        buttonText: '重新加载',
        onButtonTap: _loadWorks,
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: EmptyState(
        title: '暂无作品',
        subtitle: '该作者还没有发布任何作品',
        iconData: Icons.video_library_outlined,
        iconBgColor: Colors.blue.withOpacity(0.1),
        iconColor: Colors.blue,
      ),
    );
  }

  // ==================== 底部操作栏 ====================

  Widget _buildBottomActionBar() {
    final allSelected =
        _works.isNotEmpty && _selectedIds.length == _works.length;
    final selectedCount = _selectedIds.length;

    return Container(
      padding: EdgeInsets.fromLTRB(
        16,
        12,
        16,
        12 + MediaQuery.of(context).padding.bottom,
      ),
      decoration: BoxDecoration(
        color: _cardBgColor,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, -2),
          ),
        ],
        borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            // 全选按钮
            GestureDetector(
              onTap: _selectAll,
              behavior: HitTestBehavior.opaque,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 22,
                    height: 22,
                    decoration: BoxDecoration(
                      color: allSelected ? AppTheme.primaryColor : Colors.transparent,
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: allSelected
                            ? AppTheme.primaryColor
                            : (_isDark
                                ? Colors.grey.shade600
                                : Colors.grey.shade400),
                        width: 1.5,
                      ),
                    ),
                    child: allSelected
                        ? const Icon(Icons.check, size: 14, color: Colors.white)
                        : null,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    allSelected ? '取消全选' : '全选',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      color: _textColor,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            // 已选数量
            Text(
              '已选 $selectedCount 个',
              style: TextStyle(
                fontSize: 13,
                color: _secondaryTextColor,
              ),
            ),
            const Spacer(),
            // 批量下载按钮
            SizedBox(
              width: 130,
              height: 42,
              child: GradientButton(
                text: '批量下载',
                icon: Icons.download_rounded,
                height: 42,
                onPressed: selectedCount > 0 ? _batchDownload : null,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ==================== 作品抓取结果 ====================

class _WorksFetchResult {
  final List<VideoInfo> works;
  final bool hasMore;
  final int nextCursor;
  final Map<String, dynamic>? authorInfo;

  _WorksFetchResult({
    required this.works,
    required this.hasMore,
    required this.nextCursor,
    this.authorInfo,
  });
}

// ==================== 作品详情底部弹窗 ====================

class _WorkDetailSheet extends StatelessWidget {
  final VideoInfo video;
  final VoidCallback onDownload;

  const _WorkDetailSheet({
    required this.video,
    required this.onDownload,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textColor = isDark ? Colors.white : Colors.black87;
    final secondaryColor =
        isDark ? Colors.grey.shade400 : Colors.grey.shade600;

    return Container(
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF1E293B) : Colors.white,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 顶部拖拽条
          Center(
            child: Container(
              margin: const EdgeInsets.only(top: 10, bottom: 6),
              width: 36,
              height: 4,
              decoration: BoxDecoration(
                color: isDark ? Colors.grey.shade700 : Colors.grey.shade300,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          // 封面和信息
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 16),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // 封面
                ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: Container(
                    width: 100,
                    height: 130,
                    color: Colors.grey.shade200,
                    child: video.cover.isNotEmpty
                        ? Image.network(
                            video.cover,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) =>
                                const Center(child: Icon(Icons.broken_image)),
                          )
                        : const Center(child: Icon(Icons.video_library)),
                  ),
                ),
                const SizedBox(width: 14),
                // 信息
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          PlatformBadge(platform: video.platform, size: 18),
                          const SizedBox(width: 6),
                          Text(
                            video.platformName,
                            style: TextStyle(
                              fontSize: 12,
                              color: secondaryColor,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 6,
                              vertical: 1,
                            ),
                            decoration: BoxDecoration(
                              color: AppTheme.primaryColor.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              video.typeName,
                              style: const TextStyle(
                                fontSize: 11,
                                color: AppTheme.primaryColor,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        video.title,
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                          color: textColor,
                          height: 1.4,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        '作者：${video.author}',
                        style: TextStyle(
                          fontSize: 12,
                          color: secondaryColor,
                        ),
                      ),
                      if (video.durationSeconds != null) ...[
                        const SizedBox(height: 4),
                        Text(
                          '时长：${_formatDuration(video.durationSeconds!)}',
                          style: TextStyle(
                            fontSize: 12,
                            color: secondaryColor,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ],
            ),
          ),
          // 分割线
          Divider(
            height: 1,
            thickness: 1,
            color: isDark ? Colors.grey.shade800 : Colors.grey.shade100,
          ),
          // 下载按钮
          Padding(
            padding: const EdgeInsets.fromLTRB(
              16,
              14,
              16,
              14,
            ),
            child: SizedBox(
              width: double.infinity,
              child: GradientButton(
                text: '下载此作品',
                icon: Icons.download_rounded,
                onPressed: onDownload,
              ),
            ),
          ),
          SizedBox(height: MediaQuery.of(context).padding.bottom),
        ],
      ),
    );
  }

  static String _formatDuration(int seconds) {
    final min = seconds ~/ 60;
    final sec = seconds % 60;
    return '${min.toString().padLeft(2, '0')}:${sec.toString().padLeft(2, '0')}';
  }
}
