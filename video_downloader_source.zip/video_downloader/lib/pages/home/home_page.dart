import 'dart:async';
import 'dart:io';
import 'dart:ui';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:share_plus/share_plus.dart';
import '../../theme/app_theme.dart';
import '../../providers/history_provider.dart';
import '../../providers/crawl_history_provider.dart';
import '../../providers/download_provider.dart';
import '../../providers/settings_provider.dart';
import '../../providers/source_stats_provider.dart';
import '../../services/history_service.dart';
import '../../services/parser/parser_service.dart';
import '../../services/parser/base_parser.dart';
import '../../services/proxy_service.dart';
import '../../services/share_service.dart';
import '../../services/haptic_service.dart';
import '../../services/shake_service.dart';
import '../../services/advanced_haptic_service.dart';
import '../../services/quick_actions_service.dart';
import '../../models/video_info.dart';
import '../../models/api_source.dart';
import '../../models/bottom_nav_config.dart';
import '../../widgets/gradient_button.dart';
import '../../widgets/link_input_card.dart';
import '../../widgets/video_card.dart';
import '../../widgets/platform_badge.dart';
import '../../widgets/friendly_error_widget.dart';
import '../../widgets/input_suggestion_list.dart';
import '../../widgets/pull_down_quick_menu.dart';
import '../../widgets/two_finger_gesture_detector.dart';
import '../../widgets/batch_guide_overlay.dart';
import '../../widgets/result_card_swiper.dart';
import '../../utils/page_route.dart';
import '../../utils/platform_detector.dart';
import '../../widgets/skeleton.dart';
import '../../widgets/desktop_shell.dart';
import '../downloads/downloads_page.dart';
import '../settings/settings_page.dart';
import '../settings/source_stats_page.dart';
import '../history/history_page.dart';
import '../crawl/crawl_page.dart';
import '../convert/convert_page.dart';
import '../favorites/favorites_page.dart';
import 'author_works_page.dart';
import 'parse_result_detail_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController _urlController = TextEditingController();
  late final ParserService _parserService;
  final GlobalKey<HistoryPageState> _historyPageKey = GlobalKey();
  final ScrollController _homeScrollController = ScrollController();
  StreamSubscription<String>? _shareSubscription;
  Timer? _debounceTimer;
  int _currentIndex = 0;
  bool _parsing = false;
  /// 当前正在解析的按钮：'parse' = 仅解析，'download' = 解析并下载，null = 未解析
  String? _parsingAction;
  bool _expanding = false;
  String? _expandedUrl;
  VideoInfo? _parsedVideo;
  String? _errorMessage;
  /// 错误类型
  ParseErrorType? _errorType;
  /// 提示类型：'authorProfile'（作者主页）、'unsupportedPlatform'（不支持的平台）、null（普通错误）
  String? _tipType;
  /// 双击首页按钮检测
  DateTime? _lastHomeTap;

  /// 返回键退出检测
  DateTime? _lastBackPress;

  /// 收藏动画状态（解析结果卡片双击收藏动画）
  String? _favoriteAnimatingId;

  // 批量模式相关
  bool _isBatchMode = false;
  List<_BatchParseItem> _batchResults = [];
  int _batchCurrent = 0;
  int _batchTotal = 0;

  // 摇一摇服务
  final ShakeService _shakeService = ShakeService();
  StreamSubscription<void>? _shakeSubscription;

  // 桌面快捷方式订阅
  StreamSubscription<ShortcutAction>? _shortcutSubscription;

  // 输入联想
  List<SuggestionItem> _suggestions = [];
  bool _showSuggestions = false;

  // 批量引导
  bool _showBatchGuide = false;

  // FAB 展开状态
  bool _fabExpanded = false;

  // 剪贴板检测到的链接（用于提示条显示）
  String? _clipboardDetectedUrl;
  // 是否显示剪贴板提示条
  bool _showClipboardBanner = false;

  @override
  void initState() {
    super.initState();
    // 监听输入框文本变化，用于自动解析和字数统计
    _urlController.addListener(_onTextChanged);
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      // 从 Provider 获取共享解析服务实例（连接了统计）
      _parserService = context.read<ParserService>();

      // 显示开屏免责声明弹窗
      _showDisclaimerDialog();

      final settings = context.read<SettingsProvider>();
      // 设置 API 源
      _syncParserService(settings);
      // 设置代理服务
      _parserService.setProxyService(context.read<ProxyService>());
      // 同步下载路径
      final downloadProvider = context.read<DownloadProvider>();
      if (settings.downloadPath.isNotEmpty) {
        downloadProvider.setDownloadPath(settings.downloadPath);
      }
      // 加载解析历史（Provider 构造函数不再自动加载，需手动触发）
      try {
        context.read<HistoryProvider>().loadHistory();
      } catch (_) {}
      // 监听设置变化，实时同步到解析服务
      settings.addListener(_onSettingsChanged);
      // 订阅分享事件
      _listenToShareEvents();
      // 主动检查剪贴板（解决订阅前就已检测到的链接丢失问题）
      if (settings.autoParseClipboard || settings.autoPasteAndDownload) {
        await _checkClipboardOnStartup();
      }

      // 初始化摇一摇服务
      _initShakeService();

      // 检查是否显示批量引导
      if (!settings.batchGuideShown) {
        setState(() {
          _showBatchGuide = true;
        });
      }

      // 检测剪贴板链接（用于显示提示条）
      if (settings.clipboardDetectionEnabled) {
        _detectClipboardForBanner();
      }

      // 初始化桌面快捷方式监听
      _initQuickActions();
    });
  }

  /// 初始化摇一摇服务
  void _initShakeService() {
    final settings = context.read<SettingsProvider>();
    if (settings.shakeToParseEnabled) {
      _shakeService.startListening();
      _shakeSubscription = _shakeService.onShake.listen((_) {
        _handleShake();
      });
    }
  }

  /// 初始化桌面快捷方式监听
  void _initQuickActions() {
    try {
      final quickActions = context.read<QuickActionsService>();

      // 处理初始快捷方式（冷启动）
      final initial = quickActions.initialAction;
      if (initial != null) {
        _handleShortcutAction(initial);
        quickActions.resetInitialAction();
      }

      // 监听后续快捷方式事件（应用在后台时点击）
      _shortcutSubscription = quickActions.onActionStream.listen((action) {
        _handleShortcutAction(action);
      });
    } catch (e) {
      debugPrint('Init quick actions failed: $e');
    }
  }

  /// 处理快捷方式导航
  void _handleShortcutAction(ShortcutAction action) {
    final settings = context.read<SettingsProvider>();
    final navConfig = BottomNavConfig.fromJsonString(settings.bottomNavConfigJson);
    final tabs = navConfig.visibleTabs;

    int? targetIndex;
    switch (action) {
      case ShortcutAction.parse:
        // 一键解析：切换到首页并聚焦输入框
        targetIndex = _findTabIndex(tabs, BottomNavTab.home);
        if (targetIndex != null) {
          _switchTab(targetIndex);
          // 延迟聚焦输入框
          Future.delayed(const Duration(milliseconds: 300), () {
            _urlController.selection = TextSelection(
              baseOffset: 0,
              extentOffset: _urlController.text.length,
            );
          });
        }
        break;
      case ShortcutAction.crawl:
        // 批量抓取：切换到抓取页
        targetIndex = _findTabIndex(tabs, BottomNavTab.crawl);
        if (targetIndex != null) {
          _switchTab(targetIndex);
        }
        break;
      case ShortcutAction.downloads:
        // 下载管理：切换到下载页
        targetIndex = _findTabIndex(tabs, BottomNavTab.downloads);
        if (targetIndex != null) {
          _switchTab(targetIndex);
        }
        break;
    }
  }

  /// 查找指定 tab 在可见 tab 列表中的索引
  int? _findTabIndex(List<BottomNavTab> tabs, BottomNavTab target) {
    for (int i = 0; i < tabs.length; i++) {
      if (tabs[i] == target) return i;
    }
    return null;
  }

  /// 切换到底部导航的指定 tab
  void _switchTab(int index) {
    if (mounted && index != _currentIndex) {
      setState(() {
        _currentIndex = index;
      });
    }
  }

  /// 处理摇一摇事件
  Future<void> _handleShake() async {
    if (!mounted) return;
    if (_parsing) return;

    // 震动反馈
    HapticService.mediumImpact();

    // 读取剪贴板
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    final text = data?.text ?? '';
    if (text.isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('剪贴板为空'), duration: Duration(seconds: 1)),
        );
      }
      return;
    }

    // 填入输入框并解析
    _urlController.text = text;
    _parseUrl();

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('摇一摇触发解析'), duration: Duration(seconds: 1)),
      );
    }
  }

  /// 将 SettingsProvider 的配置同步到 ParserService
  void _syncParserService(SettingsProvider settings) {
    final source = ApiSource.fromId(settings.apiSourceId) ?? ApiSource.builtIn;
    _parserService.setApiSource(
      source,
      apiKey: settings.getApiKey(source.id),
      customUrl: source.id == 'custom' ? settings.customApiUrl : null,
    );
    // 同步抖音 Cookie
    _parserService.setDouyinCookies(settings.douyinCookies);
    // 同步解析重试次数
    _parserService.setParseRetryCount(settings.parseRetryCount);
  }

  /// 设置变化回调：同步解析配置
  void _onSettingsChanged() {
    final settings = context.read<SettingsProvider>();
    _syncParserService(settings);
  }

  /// 启动时检查剪贴板
  Future<void> _checkClipboardOnStartup() async {
    final shareService = context.read<ShareService>();
    final settings = context.read<SettingsProvider>();

    // 先取消防抖定时器
    _debounceTimer?.cancel();
    _debounceTimer = null;

    // 临时移除文本监听器，避免编程式设置文本时触发 _onTextChanged 的防抖解析
    _urlController.removeListener(_onTextChanged);

    // 先尝试从缓存中获取（App 启动时已检测过一次）
    final lastUrl = shareService.getLastUrl();
    if (lastUrl != null && mounted) {
      _urlController.text = lastUrl;
      setState(() {
        _parsedVideo = null;
        _errorMessage = null;
        _tipType = null;
      });
      // 自动解析
      if (settings.autoPasteAndDownload) {
        // 自动粘贴解析下载：解析后自动下载
        _parseUrl(autoDownload: true);
      } else if (settings.autoParseClipboard) {
        _parseUrl();
      }
      // 恢复监听器
      _urlController.addListener(_onTextChanged);
      return;
    }

    // 缓存中没有，重新检测一次
    final url = await shareService.checkClipboardNow();
    if (url != null && mounted) {
      _urlController.text = url;
      setState(() {
        _parsedVideo = null;
        _errorMessage = null;
        _tipType = null;
      });
      // 自动解析
      if (settings.autoPasteAndDownload) {
        // 自动粘贴解析下载：解析后自动下载
        _parseUrl(autoDownload: true);
      } else if (settings.autoParseClipboard) {
        _parseUrl();
      }
    }

    // 恢复监听器
    if (mounted) {
      _urlController.addListener(_onTextChanged);
    }
  }

  /// 检测剪贴板链接，用于显示提示条（不自动解析，只提示）
  Future<void> _detectClipboardForBanner() async {
    try {
      final data = await Clipboard.getData(Clipboard.kTextPlain);
      final text = data?.text ?? '';
      if (text.isEmpty) {
        setState(() {
          _showClipboardBanner = false;
          _clipboardDetectedUrl = null;
        });
        return;
      }

      // 提取 URL
      final extractedUrl = _parserService.extractUrl(text);
      if (extractedUrl != null) {
        // 检测是否为支持的平台
        final platform = _parserService.detectPlatform(extractedUrl);
        if (platform != 'unknown') {
          // 如果输入框已经有这个链接了，就不显示提示
          if (_urlController.text.trim() == extractedUrl ||
              _urlController.text.trim().contains(extractedUrl)) {
            setState(() {
              _showClipboardBanner = false;
              _clipboardDetectedUrl = null;
            });
            return;
          }
          setState(() {
            _clipboardDetectedUrl = extractedUrl;
            _showClipboardBanner = true;
          });
          return;
        }
      }

      setState(() {
        _showClipboardBanner = false;
        _clipboardDetectedUrl = null;
      });
    } catch (_) {
      // 检测失败时静默处理
      setState(() {
        _showClipboardBanner = false;
        _clipboardDetectedUrl = null;
      });
    }
  }

  /// 开屏免责声明弹窗
  void _showDisclaimerDialog() {
    final settings = context.read<SettingsProvider>();
    if (settings.disclaimerShown) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text('使用声明'),
        content: const Text(
          '本应用只用于学习交流，且不允许传播，仅供内部使用。\n\n作者：云决吟',
          style: TextStyle(height: 1.6),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              context.read<SettingsProvider>().setDisclaimerShown(true);
            },
            child: const Text('我已知晓'),
          ),
        ],
      ),
    );
  }

  /// 清空解析历史（带二次确认）
  void _clearParseHistory() {
    final provider = context.read<HistoryProvider>();
    if (provider.videos.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('暂无解析记录')),
      );
      return;
    }

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('确认清空'),
        content: const Text('确定要清空所有解析历史记录吗？'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              provider.clearHistory();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('已清空解析记录')),
              );
            },
            child: const Text('确定', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _shareSubscription?.cancel();
    _shakeSubscription?.cancel();
    _shortcutSubscription?.cancel();
    _shakeService.dispose();
    _urlController.removeListener(_onTextChanged);
    _urlController.dispose();
    _debounceTimer?.cancel();
    _homeScrollController.dispose();
    // 移除设置监听
    try {
      context.read<SettingsProvider>().removeListener(_onSettingsChanged);
    } catch (_) {}
    super.dispose();
  }

  /// 监听分享事件，收到分享链接后自动填充并解析
  void _listenToShareEvents() {
    final shareService = context.read<ShareService>();
    _shareSubscription = shareService.onUrlReceived.listen((url) {
      if (!mounted) return;

      final settings = context.read<SettingsProvider>();
      final autoDownload = settings.autoPasteAndDownload;

      // 先取消防抖定时器，避免设置文本时触发 _onTextChanged 的普通解析
      _debounceTimer?.cancel();
      _debounceTimer = null;

      // 临时移除文本监听器，避免编程式设置文本时触发防抖
      _urlController.removeListener(_onTextChanged);

      setState(() {
        _urlController.text = url;
        _parsedVideo = null;
        _errorMessage = null;
        _tipType = null;
      });

      // 根据设置决定是普通解析还是解析并下载
      if (autoDownload) {
        _parseUrl(autoDownload: true);
      } else {
        _parseUrl();
      }

      // 恢复监听器
      if (mounted) {
        _urlController.addListener(_onTextChanged);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        final navConfig = _getBottomNavConfig(settings);
        final pages = _buildPages(navConfig);
        final pageIndex = _currentIndex < pages.length ? _currentIndex : 0;

        // 桌面端使用 DesktopShell 布局
        if (_isDesktop) {
          final desktopPages = _buildDesktopPages();
          final desktopIndex = _currentIndex < desktopPages.length ? _currentIndex : 0;
          return DesktopShell(
            currentIndex: desktopIndex,
            onDestinationSelected: _onDesktopNavSelected,
            pages: desktopPages,
          );
        }

        // 移动端使用底部导航
        return WillPopScope(
          onWillPop: _onWillPop,
          child: Scaffold(
            body: IndexedStack(
              index: pageIndex,
              children: pages,
            ),
            bottomNavigationBar: _buildAnimatedBottomNav(navConfig),
            floatingActionButton: _isHomeTab(navConfig) ? _buildFAB() : null,
          ),
        );
      },
    );
  }

  /// 判断是否为桌面端平台
  bool get _isDesktop {
    if (kIsWeb) return true;
    return Platform.isLinux || Platform.isWindows || Platform.isMacOS;
  }

  /// 构建桌面端页面列表（固定 7 项，顺序与导航栏一致）
  List<Widget> _buildDesktopPages() {
    return [
      // 首页
      _buildHomePage(),
      // 批量抓取
      const CrawlPage(),
      // 格式转换
      const ConvertPage(),
      // 历史记录
      HistoryPage(key: _historyPageKey),
      // 下载管理
      const DownloadsPage(),
      // 我的收藏
      const FavoritesPage(),
      // 设置
      const SettingsPage(),
    ];
  }

  /// 桌面端导航项点击处理
  void _onDesktopNavSelected(int index) {
    if (_currentIndex == index) {
      // 点击当前项时，首页双击回到顶部
      if (index == 0) {
        _onHomeDoubleTap();
      }
      return;
    }
    setState(() {
      _currentIndex = index;
    });
  }

  /// 获取底部导航配置
  BottomNavConfig _getBottomNavConfig(SettingsProvider settings) {
    final jsonStr = settings.bottomNavConfigJson;
    if (jsonStr.isEmpty) {
      return BottomNavConfig.defaultConfig;
    }
    try {
      return BottomNavConfig.fromJson(settings.bottomNavConfig);
    } catch (_) {
      return BottomNavConfig.defaultConfig;
    }
  }

  /// 判断当前是否在首页 Tab
  bool _isHomeTab(BottomNavConfig config) {
    if (_currentIndex >= config.visibleTabs.length) return false;
    return config.visibleTabs[_currentIndex] == BottomNavTab.home;
  }

  /// 根据配置构建页面列表
  List<Widget> _buildPages(BottomNavConfig config) {
    return config.visibleTabs.map((tab) {
      switch (tab) {
        case BottomNavTab.home:
          return _buildHomePage();
        case BottomNavTab.crawl:
          return const CrawlPage();
        case BottomNavTab.convert:
          return const ConvertPage();
        case BottomNavTab.history:
          return HistoryPage(key: _historyPageKey);
        case BottomNavTab.downloads:
          return const DownloadsPage();
        case BottomNavTab.favorites:
          return const FavoritesPage();
        case BottomNavTab.settings:
          return const SettingsPage();
      }
    }).toList();
  }

  /// 构建毛玻璃效果的底部导航栏
  ///
  /// 使用 BackdropFilter + ImageFilter.blur 实现毛玻璃效果，
  /// 选中的图标带缩放动画，颜色渐变过渡。
  Widget _buildAnimatedBottomNav(BottomNavConfig navConfig) {
    final isDark = AppTheme.isDark(context);
    final isOled = AppTheme.isOledDark(context);
    final primaryColor = Theme.of(context).primaryColor;
    final unselectedColor = isDark ? Colors.grey.shade500 : Colors.grey.shade600;

    // 根据配置构建导航项
    final items = navConfig.visibleTabs.map((tab) {
      return _NavItem(
        icon: tab.icon,
        activeIcon: tab.activeIcon,
        label: tab.label,
      );
    }).toList();

    return ClipRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
        child: Container(
          decoration: BoxDecoration(
            color: isOled
                ? Colors.black.withOpacity(0.85)
                : (isDark
                    ? const Color(0xFF1E293B).withOpacity(0.85)
                    : Colors.white.withOpacity(0.85)),
            border: Border(
              top: BorderSide(
                color: isDark ? const Color(0xFF334155).withOpacity(0.5) : Colors.grey.shade200.withOpacity(0.5),
                width: 0.5,
              ),
            ),
          ),
          child: SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: List.generate(items.length, (index) {
                  final isSelected = _currentIndex == index;
                  final item = items[index];
                  return _buildAnimatedNavItem(
                    item: item,
                    index: index,
                    isSelected: isSelected,
                    primaryColor: primaryColor,
                    unselectedColor: unselectedColor,
                  );
                }),
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// 构建单个带动画的导航项
  Widget _buildAnimatedNavItem({
    required _NavItem item,
    required int index,
    required bool isSelected,
    required Color primaryColor,
    required Color unselectedColor,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: () => _onNavItemTapped(index),
        behavior: HitTestBehavior.opaque,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOutCubic,
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                curve: Curves.easeOutCubic,
                // 选中时图标稍大，未选中时标准大小
                width: isSelected ? 28 : 24,
                height: isSelected ? 28 : 24,
                child: Icon(
                  isSelected ? item.activeIcon : item.icon,
                  // 颜色平滑过渡
                  color: isSelected ? primaryColor : unselectedColor,
                  size: isSelected ? 26 : 22,
                ),
              ),
              const SizedBox(height: 2),
              AnimatedDefaultTextStyle(
                duration: const Duration(milliseconds: 250),
                curve: Curves.easeOutCubic,
                style: TextStyle(
                  fontSize: isSelected ? 12 : 11,
                  fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                  color: isSelected ? primaryColor : unselectedColor,
                ),
                child: Text(item.label),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// 底部导航栏点击处理
  void _onNavItemTapped(int index) {
    final settings = context.read<SettingsProvider>();
    final navConfig = _getBottomNavConfig(settings);

    if (index >= navConfig.visibleTabs.length) return;

    final tappedTab = navConfig.visibleTabs[index];

    // 点击当前 Tab 时：首页双击回到顶部，其他 Tab 不做处理
    if (_currentIndex == index) {
      if (tappedTab == BottomNavTab.home) {
        _onHomeDoubleTap();
      }
      return;
    }

    setState(() {
      _currentIndex = index;
    });

    // 切换到历史页时刷新数据
    if (tappedTab == BottomNavTab.history) {
      try {
        context.read<HistoryProvider>().loadHistory();
        context.read<CrawlHistoryProvider>().loadHistory();
      } catch (_) {}
    }
    // 切换到收藏页时刷新数据
    if (tappedTab == BottomNavTab.favorites) {
      try {
        context.read<HistoryProvider>().loadHistory();
        context.read<CrawlHistoryProvider>().loadHistory();
      } catch (_) {}
    }
  }

  Widget _buildHomePage() {
    return Scaffold(
      body: RefreshIndicator(
        onRefresh: _onRefresh,
        color: AppTheme.primaryColor,
        child: CustomScrollView(
          controller: _homeScrollController,
          physics: const ClampingScrollPhysics(),
          slivers: [
          SliverAppBar(
            expandedHeight: 140,
            floating: false,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              background: GestureDetector(
                onDoubleTap: _scrollHomeToTop,
                behavior: HitTestBehavior.opaque,
                child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [AppTheme.primaryColor, AppTheme.secondaryColor],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.2),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: const Icon(
                                Icons.play_circle_fill,
                                color: Colors.white,
                                size: 28,
                              ),
                            ),
                            const SizedBox(width: 12),
                            const Text(
                              '无水印下载',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 0.5,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Text(
                          '复制链接，一键解析下载高清视频与图文',
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.85),
                            fontSize: 13,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 12),
                  // 剪贴板检测提示条
                  if (_showClipboardBanner && _clipboardDetectedUrl != null)
                    _buildClipboardBanner(),
                  // 解析输入区（突出显示，最大卡片）
                  _buildInputCard(),
                  const SizedBox(height: 20),
                  // 解析结果/错误
                  if (_isBatchMode) ...[
                    if (_batchResults.isNotEmpty) _buildBatchResultCard(),
                  ] else ...[
                    if (_parsing && _parsedVideo == null && _errorMessage == null)
                      const VideoParseSkeleton()
                    else ...[
                      if (_parsedVideo != null) _buildParseResult(),
                      if (_errorMessage != null) _buildErrorCard(),
                    ],
                  ],
                  const SizedBox(height: 24),
                  // 快捷功能入口
                  _buildSectionHeader('快捷功能'),
                  const SizedBox(height: 12),
                  _buildQuickActionsCard(),
                  const SizedBox(height: 24),
                  // 资源看板
                  _buildSectionHeader(
                    '资源看板',
                    action: TextButton(
                      onPressed: () {
                        Navigator.of(context).push(
                          AppPageRoute.slideRight(const SourceStatsPage()),
                        );
                      },
                      style: TextButton.styleFrom(
                        padding: const EdgeInsets.symmetric(horizontal: 6),
                        minimumSize: Size.zero,
                        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      ),
                      child: const Text('查看详情', style: TextStyle(fontSize: 12)),
                    ),
                  ),
                  const SizedBox(height: 12),
                  _buildSourceStatsGrid(),
                  const SizedBox(height: 24),
                  // 最近解析
                  _buildSectionHeader(
                    '最近解析',
                    action: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        TextButton(
                          onPressed: _clearParseHistory,
                          style: TextButton.styleFrom(
                            padding: const EdgeInsets.symmetric(horizontal: 6),
                            minimumSize: Size.zero,
                            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            foregroundColor: AppTheme.textMuted,
                          ),
                          child: const Text('清空', style: TextStyle(fontSize: 12)),
                        ),
                        TextButton(
                          onPressed: () {
                            setState(() {
                              _currentIndex = 3;
                            });
                            _historyPageKey.currentState?.switchToTab(0);
                          },
                          style: TextButton.styleFrom(
                            padding: const EdgeInsets.symmetric(horizontal: 6),
                            minimumSize: Size.zero,
                            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                          ),
                          child: const Text('查看全部', style: TextStyle(fontSize: 12)),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  _buildRecentList(),
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ),
          // 键盘适配：底部添加键盘高度间距，确保内容不被键盘遮挡
          SliverToBoxAdapter(
            child: SizedBox(
              height: MediaQuery.of(context).viewInsets.bottom,
            ),
          ),
        ],
      ),
      ),
    );
  }

  /// 构建剪贴板检测提示条
  Widget _buildClipboardBanner() {
    final isDark = AppTheme.isDark(context);
    final platform = _parserService.detectPlatform(_clipboardDetectedUrl!);
    final platformName = VideoPlatformX.fromId(platform).name;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppTheme.primaryColor.withOpacity(0.1),
            AppTheme.secondaryColor.withOpacity(0.1),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(AppTheme.radiusLg),
        border: Border.all(
          color: AppTheme.primaryColor.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: _fillClipboardUrl,
          borderRadius: BorderRadius.circular(AppTheme.radiusLg),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            child: Row(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    gradient: AppTheme.primaryGradient,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(
                    Icons.paste_rounded,
                    color: Colors.white,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        '检测到剪贴板链接',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: AppTheme.textPrimaryColor(context),
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        '来自$platformName · 点击填充到输入框',
                        style: TextStyle(
                          fontSize: 12,
                          color: AppTheme.textSecondaryColor(context),
                        ),
                        overflow: TextOverflow.ellipsis,
                        maxLines: 1,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  icon: Icon(
                    Icons.close,
                    size: 18,
                    color: AppTheme.textSecondaryColor(context),
                  ),
                  onPressed: _dismissClipboardBanner,
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(
                    minWidth: 32,
                    minHeight: 32,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// 填充剪贴板链接到输入框
  void _fillClipboardUrl() {
    if (_clipboardDetectedUrl == null) return;
    _urlController.text = _clipboardDetectedUrl!;
    setState(() {
      _showClipboardBanner = false;
    });
    // 移动光标到末尾
    _urlController.selection = TextSelection.fromPosition(
      TextPosition(offset: _urlController.text.length),
    );
  }

  /// 关闭剪贴板提示条
  void _dismissClipboardBanner() {
    setState(() {
      _showClipboardBanner = false;
    });
  }

  /// 构建首屏快捷操作横滑卡片
  Widget _buildQuickActions() {
    final isDark = AppTheme.isDark(context);

    final actions = [
      _QuickActionItem(
        icon: Icons.paste_rounded,
        label: '粘贴并解析',
        gradient: [AppTheme.primaryColor, AppTheme.secondaryColor],
        onTap: _pasteAndParse,
      ),
      _QuickActionItem(
        icon: Icons.history_rounded,
        label: '最近记录',
        gradient: [const Color(0xFF6366F1), const Color(0xFF8B5CF6)],
        onTap: () {
          setState(() {
            _currentIndex = 3;
          });
          _historyPageKey.currentState?.switchToTab(0);
        },
      ),
      _QuickActionItem(
        icon: Icons.star_rounded,
        label: '我的收藏',
        gradient: [AppTheme.accentColor, const Color(0xFFF97316)],
        onTap: () {
          setState(() {
            _currentIndex = 5;
          });
        },
      ),
      _QuickActionItem(
        icon: Icons.download_rounded,
        label: '下载管理',
        gradient: [AppTheme.infoColor, const Color(0xFF0EA5E9)],
        onTap: () {
          setState(() {
            _currentIndex = 4;
          });
        },
      ),
    ];

    return SizedBox(
      height: 95,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 4),
        itemCount: actions.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (context, index) {
          final action = actions[index];
          return _buildQuickActionCard(action, isDark);
        },
      ),
    );
  }

  Widget _buildQuickActionCard(_QuickActionItem action, bool isDark) {
    return GestureDetector(
      onTap: action.onTap,
      behavior: HitTestBehavior.opaque,
      child: Container(
        width: 80,
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: isDark ? const Color(0xFF1E293B) : Colors.white,
          borderRadius: BorderRadius.circular(AppTheme.radiusLg),
          border: Border.all(
            color: isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
            width: 0.5,
          ),
          boxShadow: AppTheme.shadowSm,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: action.gradient,
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(14),
                boxShadow: [
                  BoxShadow(
                    color: action.gradient.first.withOpacity(0.3),
                    blurRadius: 8,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: Icon(
                action.icon,
                color: Colors.white,
                size: 22,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              action.label,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: AppTheme.textPrimaryColor(context),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// 构建快捷功能卡片（分组样式）
  Widget _buildQuickActionsCard() {
    final isDark = AppTheme.isDark(context);
    final cardBg = AppTheme.cardBg(context);
    final borderColor = isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0);

    final actions = [
      _QuickActionItem(
        icon: Icons.paste_rounded,
        label: '粘贴解析',
        gradient: [AppTheme.primaryColor, AppTheme.secondaryColor],
        onTap: _pasteAndParse,
        onLongPress: _showPasteQuickActionMenu,
      ),
      _QuickActionItem(
        icon: Icons.history_rounded,
        label: '历史记录',
        gradient: [const Color(0xFF6366F1), const Color(0xFF8B5CF6)],
        onTap: () {
          setState(() {
            _currentIndex = 3;
          });
          _historyPageKey.currentState?.switchToTab(0);
        },
        onLongPress: _showHistoryQuickActionMenu,
      ),
      _QuickActionItem(
        icon: Icons.star_rounded,
        label: '我的收藏',
        gradient: [AppTheme.accentColor, const Color(0xFFF97316)],
        onTap: () {
          setState(() {
            _currentIndex = 5;
          });
        },
      ),
      _QuickActionItem(
        icon: Icons.download_rounded,
        label: '下载管理',
        gradient: [AppTheme.infoColor, const Color(0xFF0EA5E9)],
        onTap: () {
          setState(() {
            _currentIndex = 4;
          });
        },
      ),
    ];

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(AppTheme.radiusLg),
        border: Border.all(color: borderColor, width: 0.5),
        boxShadow: AppTheme.shadowSm,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: actions.map((action) {
          return _buildQuickActionItem(action);
        }).toList(),
      ),
    );
  }

  Widget _buildQuickActionItem(_QuickActionItem action) {
    return GestureDetector(
      onTap: action.onTap,
      onLongPress: action.onLongPress,
      behavior: HitTestBehavior.opaque,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: action.gradient,
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(14),
              boxShadow: [
                BoxShadow(
                  color: action.gradient.first.withOpacity(0.25),
                  blurRadius: 8,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            child: Icon(
              action.icon,
              color: Colors.white,
              size: 24,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            action.label,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              color: AppTheme.textPrimaryColor(context),
            ),
          ),
        ],
      ),
    );
  }

  /// 构建资源看板网格（2列）
  Widget _buildSourceStatsGrid() {
    return Consumer<SourceStatsProvider>(
      builder: (context, stats, child) {
        final isDark = AppTheme.isDark(context);
        final cardBg = AppTheme.cardBg(context);
        final borderColor = isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0);
        final textPrimary = AppTheme.textPrimaryColor(context);
        final textSecondary = AppTheme.textSecondaryColor(context);

        final totalRequests = stats.totalRequests;
        final totalSuccess = stats.totalSuccess;
        final successRate = stats.overallSuccessRate;
        final sourceCount = stats.allStats.length;

        final items = [
          _StatGridItem(
            icon: Icons.bar_chart_rounded,
            label: '总解析次数',
            value: totalRequests.toString(),
            gradient: [AppTheme.primaryColor, AppTheme.secondaryColor],
          ),
          _StatGridItem(
            icon: Icons.check_circle_rounded,
            label: '成功次数',
            value: totalSuccess.toString(),
            gradient: [AppTheme.successColor, const Color(0xFF10B981)],
          ),
          _StatGridItem(
            icon: Icons.trending_up_rounded,
            label: '成功率',
            value: '${(successRate * 100).toStringAsFixed(1)}%',
            gradient: [const Color(0xFF8B5CF6), const Color(0xFF6366F1)],
          ),
          _StatGridItem(
            icon: Icons.source_rounded,
            label: '解析源数',
            value: sourceCount.toString(),
            gradient: [AppTheme.infoColor, const Color(0xFF0EA5E9)],
          ),
        ];

        return Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: cardBg,
            borderRadius: BorderRadius.circular(AppTheme.radiusLg),
            border: Border.all(color: borderColor, width: 0.5),
            boxShadow: AppTheme.shadowSm,
          ),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: _buildStatGridItem(items[0], isDark),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _buildStatGridItem(items[1], isDark),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: _buildStatGridItem(items[2], isDark),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _buildStatGridItem(items[3], isDark),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildStatGridItem(_StatGridItem item, bool isDark) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF0F172A) : const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(AppTheme.radiusMd),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: item.gradient,
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(item.icon, color: Colors.white, size: 20),
          ),
          const SizedBox(height: 10),
          Text(
            item.value,
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: AppTheme.textPrimaryColor(context),
            ),
          ),
          const SizedBox(height: 2),
          Text(
            item.label,
            style: TextStyle(
              fontSize: 12,
              color: AppTheme.textSecondaryColor(context),
            ),
          ),
        ],
      ),
    );
  }

  /// 构建 FAB 悬浮操作按钮（Speed Dial 效果）
  Widget _buildFAB() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        if (_fabExpanded) ...[
          _buildFabChild(
            icon: Icons.qr_code_scanner_rounded,
            label: '扫码解析',
            gradient: [Colors.purple, Colors.deepPurple],
            onTap: () {
              _toggleFab();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('扫码功能开发中'), duration: Duration(seconds: 1)),
              );
            },
          ),
          const SizedBox(height: 12),
          _buildFabChild(
            icon: Icons.playlist_add_rounded,
            label: '批量导入',
            gradient: [Colors.teal, Colors.green],
            onTap: () {
              _toggleFab();
              setState(() {
                _isBatchMode = true;
              });
            },
          ),
          const SizedBox(height: 12),
          _buildFabChild(
            icon: Icons.paste_rounded,
            label: '粘贴解析',
            gradient: [AppTheme.primaryColor, AppTheme.secondaryColor],
            onTap: () {
              _toggleFab();
              _pasteAndParse();
            },
          ),
          const SizedBox(height: 16),
        ],
        // 主 FAB 按钮
        GestureDetector(
          onTap: _toggleFab,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeOutCubic,
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              gradient: AppTheme.primaryGradient,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: AppTheme.primaryColor.withOpacity(0.4),
                  blurRadius: 16,
                  spreadRadius: 1,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: AnimatedRotation(
              turns: _fabExpanded ? 0.125 : 0,
              duration: const Duration(milliseconds: 300),
              curve: Curves.easeOutCubic,
              child: const Icon(
                Icons.add_rounded,
                color: Colors.white,
                size: 28,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildFabChild({
    required IconData icon,
    required String label,
    required List<Color> gradient,
    required VoidCallback onTap,
  }) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            borderRadius: BorderRadius.circular(20),
            boxShadow: AppTheme.shadowSm,
          ),
          child: Text(
            label,
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: AppTheme.textPrimaryColor(context),
            ),
          ),
        ),
        const SizedBox(width: 10),
        GestureDetector(
          onTap: onTap,
          child: Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: gradient,
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: gradient.first.withOpacity(0.3),
                  blurRadius: 8,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            child: Icon(icon, color: Colors.white, size: 20),
          ),
        ),
      ],
    );
  }

  void _toggleFab() {
    setState(() {
      _fabExpanded = !_fabExpanded;
    });
  }

  /// 粘贴并解析
  Future<void> _pasteAndParse() async {
    final clipboardData = await Clipboard.getData('text/plain');
    final text = clipboardData?.text ?? '';
    if (text.isNotEmpty) {
      final smartMode = context.read<SettingsProvider>().smartPasteAppendMode;
      final currentText = _urlController.text;
      String newText;
      if (!smartMode || currentText.isEmpty || currentText.trim() == text.trim()) {
        newText = text;
      } else {
        newText = '${currentText.trim()}\n${text.trim()}';
      }
      _urlController.text = newText;
      setState(() {
        _parsedVideo = null;
        _errorMessage = null;
        _tipType = null;
      });
      _parseUrl();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('剪贴板为空'), duration: Duration(seconds: 1)),
      );
    }
  }

  /// 粘贴并下载
  Future<void> _pasteAndDownload() async {
    final clipboardData = await Clipboard.getData('text/plain');
    final text = clipboardData?.text ?? '';
    if (text.isNotEmpty) {
      final smartMode = context.read<SettingsProvider>().smartPasteAppendMode;
      final currentText = _urlController.text;
      String newText;
      if (!smartMode || currentText.isEmpty || currentText.trim() == text.trim()) {
        newText = text;
      } else {
        newText = '${currentText.trim()}\n${text.trim()}';
      }
      _urlController.text = newText;
      setState(() {
        _parsedVideo = null;
        _errorMessage = null;
        _tipType = null;
      });
      _parseAndDownload();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('剪贴板为空'), duration: Duration(seconds: 1)),
      );
    }
  }

  /// 显示解析按钮长按菜单
  void _showParseButtonMenu() {
    HapticService.selectionClick();
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => _buildQuickActionMenu(
        items: [
          _QuickMenuItem(
            icon: Icons.paste_rounded,
            label: '粘贴并解析',
            onTap: () {
              Navigator.pop(context);
              _pasteAndParse();
            },
          ),
          _QuickMenuItem(
            icon: Icons.clear_rounded,
            label: '清空输入框',
            onTap: () {
              Navigator.pop(context);
              _clearInput();
            },
          ),
        ],
      ),
    );
  }

  /// 显示下载按钮长按菜单
  void _showDownloadButtonMenu() {
    HapticService.selectionClick();
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => _buildQuickActionMenu(
        items: [
          _QuickMenuItem(
            icon: Icons.paste_rounded,
            label: '粘贴并下载',
            onTap: () {
              Navigator.pop(context);
              _pasteAndDownload();
            },
          ),
          _QuickMenuItem(
            icon: Icons.clear_rounded,
            label: '清空输入框',
            onTap: () {
              Navigator.pop(context);
              _clearInput();
            },
          ),
        ],
      ),
    );
  }

  /// 显示粘贴解析快捷功能长按菜单
  void _showPasteQuickActionMenu() {
    HapticService.selectionClick();
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => _buildQuickActionMenu(
        items: [
          _QuickMenuItem(
            icon: Icons.paste_rounded,
            label: '粘贴并解析',
            onTap: () {
              Navigator.pop(context);
              _pasteAndParse();
            },
          ),
          _QuickMenuItem(
            icon: Icons.download_rounded,
            label: '粘贴并下载',
            onTap: () {
              Navigator.pop(context);
              _pasteAndDownload();
            },
          ),
        ],
      ),
    );
  }

  /// 显示历史记录快捷功能长按菜单
  void _showHistoryQuickActionMenu() {
    HapticService.selectionClick();
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => _buildQuickActionMenu(
        items: [
          _QuickMenuItem(
            icon: Icons.history_rounded,
            label: '解析历史',
            onTap: () {
              Navigator.pop(context);
              setState(() {
                _currentIndex = 3;
              });
              _historyPageKey.currentState?.switchToTab(0);
            },
          ),
          _QuickMenuItem(
            icon: Icons.download_rounded,
            label: '下载记录',
            onTap: () {
              Navigator.pop(context);
              setState(() {
                _currentIndex = 4;
              });
            },
          ),
          _QuickMenuItem(
            icon: Icons.cloud_download_rounded,
            label: '抓取记录',
            onTap: () {
              Navigator.pop(context);
              setState(() {
                _currentIndex = 3;
              });
              _historyPageKey.currentState?.switchToTab(1);
            },
          ),
        ],
      ),
    );
  }

  /// 构建快捷操作菜单
  Widget _buildQuickActionMenu({required List<_QuickMenuItem> items}) {
    final isDark = AppTheme.isDark(context);
    return Container(
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF1E293B) : Colors.white,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // 顶部指示器
            Container(
              margin: const EdgeInsets.only(top: 12),
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: isDark ? Colors.grey.shade700 : Colors.grey.shade300,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 8),
            ...items.map((item) => ListTile(
              leading: Icon(item.icon, color: AppTheme.primaryColor),
              title: Text(item.label),
              onTap: item.onTap,
            )),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title, {Widget? action}) {
    return Row(
      children: [
        Container(
          width: 4,
          height: 16,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [AppTheme.primaryColor, AppTheme.secondaryColor],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 10),
        Text(
          title,
          style: const TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w700,
          ),
        ),
        const Spacer(),
        if (action != null) action,
      ],
    );
  }

  Widget _buildInputCard() {
    return LinkInputCard(
      controller: _urlController,
      title: '粘贴链接',
      titleIcon: Icons.link,
      hintText: '每行一个链接，支持批量解析下载',
      showPasteButton: true,
      loadingActionId: _parsingAction,
      loadingProgressText:
          _isBatchMode && _parsing ? '$_batchCurrent/$_batchTotal' : null,
      onClear: _clearInput,
      actions: [
        LinkInputAction(
          id: 'parse',
          label: '解析',
          icon: Icons.manage_search,
          isPrimary: false,
          onTap: (_) => _parseUrl(),
          onLongPress: _showParseButtonMenu,
        ),
        LinkInputAction(
          id: 'download',
          label: _isBatchMode ? '批量解析并下载' : '解析并下载',
          icon: Icons.download_for_offline,
          isPrimary: true,
          onTap: (_) => _parseAndDownload(),
          onLongPress: _showDownloadButtonMenu,
        ),
      ],
    );
  }

  Widget _buildParseResult() {
    final video = _parsedVideo!;
    final isImage = video.isImage;
    final isDark = AppTheme.isDark(context);
    final textPrimary = AppTheme.textPrimaryColor(context);
    final textSecondary = AppTheme.textSecondaryColor(context);
    final borderColor = AppTheme.borderColor(context);
    final fillColor = isDark ? const Color(0xFF1E293B) : Colors.grey.shade50;
    final placeholderColor = isDark ? Colors.grey.shade800 : Colors.grey.shade100;
    // 平台主题色
    final platformPrimary = AppTheme.platformPrimaryColor(video.platform);
    final platformGrad = AppTheme.platformGradient(video.platform);

    return Consumer<HistoryProvider>(
      builder: (context, historyProvider, child) {
        final isFavorite = historyProvider.isFavorite(video.id);
        final showAnim = _favoriteAnimatingId == video.id;

        return GestureDetector(
          onLongPress: () => _showParseResultActionMenu(video),
          onDoubleTap: () => _toggleParseResultFavorite(video),
          child: Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: platformPrimary.withOpacity(isDark ? 0.5 : 0.3)),
              boxShadow: isDark
                  ? []
                  : [
                      BoxShadow(
                        color: platformPrimary.withOpacity(0.08),
                        blurRadius: 20,
                        offset: const Offset(0, 4),
                      ),
                    ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // 顶部状态条
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: platformPrimary.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.check_circle, color: platformPrimary, size: 16),
                          const SizedBox(width: 5),
                          Text(
                            '解析成功',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              color: platformPrimary,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 10),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: isImage
                            ? Colors.purple.withOpacity(isDark ? 0.2 : 0.1)
                            : Colors.blue.withOpacity(isDark ? 0.2 : 0.1),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            isImage ? Icons.image : Icons.ondemand_video,
                            size: 12,
                            color: isImage ? Colors.purple : Colors.blue,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            isImage ? '${video.typeName} · ${video.imageCount}张' : video.typeName,
                            style: TextStyle(
                              fontSize: 11,
                              color: isImage ? Colors.purple : Colors.blue,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Spacer(),
                    // 收藏按钮（带动画）
                    AnimatedScale(
                      scale: showAnim ? 1.3 : 1.0,
                      duration: const Duration(milliseconds: 200),
                      curve: Curves.easeOutBack,
                      child: IconButton(
                        icon: Icon(
                          isFavorite ? Icons.favorite : Icons.favorite_border,
                          color: isFavorite ? Colors.red.shade400 : Colors.grey.shade400,
                          size: 22,
                        ),
                        onPressed: () => _toggleParseResultFavorite(video),
                        padding: EdgeInsets.zero,
                        constraints: const BoxConstraints(),
                        splashRadius: 20,
                      ),
                    ),
                    const SizedBox(width: 8),
                    PlatformBadge(platform: video.platform, size: 20),
                  ],
                ),
          const SizedBox(height: 16),
          // 封面/图片预览 + 标题信息
          isImage
              ? _buildImagePreview(video)
              : Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Container(
                        width: 100,
                        height: 100,
                        color: placeholderColor,
                        child: video.cover.isNotEmpty
                            ? Image.network(video.cover, fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) =>
                                    Center(child: PlatformBadge(platform: video.platform, size: 40)))
                            : Center(child: PlatformBadge(platform: video.platform, size: 40)),
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: SizedBox(
                        height: 100,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              video.title,
                              maxLines: 3,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w700,
                                height: 1.3,
                                color: textPrimary,
                              ),
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Icon(Icons.person_outline,
                                        size: 14, color: textSecondary),
                                    const SizedBox(width: 4),
                                    Expanded(
                                      child: Text(
                                        video.author,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                          fontSize: 12,
                                          color: textSecondary,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 4),
                                Row(
                                  children: [
                                    Icon(Icons.smart_display_outlined,
                                        size: 14, color: textSecondary),
                                    const SizedBox(width: 4),
                                    Text(
                                      video.platformName,
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: textSecondary,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
          if (isImage) ...[
            const SizedBox(height: 14),
            Text(
              video.title,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w700,
                height: 1.3,
                color: textPrimary,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(Icons.person_outline, size: 14, color: textSecondary),
                const SizedBox(width: 4),
                Expanded(
                  child: Text(
                    video.author,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 12,
                      color: textSecondary,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                PlatformBadge(platform: video.platform, size: 16),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              video.platformName,
              style: TextStyle(
                fontSize: 12,
                color: textSecondary,
              ),
            ),
          ],
          const SizedBox(height: 20),
          // 下载按钮
          isImage
              ? SizedBox(
                  width: double.infinity,
                  child: GradientButton(
                    text: '保存全部图片到相册',
                    icon: Icons.download_for_offline,
                    height: 50,
                    onPressed: () => _downloadImages(video),
                  ),
                )
              : Consumer<SettingsProvider>(
                  builder: (context, settings, child) {
                    final defaultQuality = settings.defaultQuality;
                    final hasHd = video.videoUrlHd != null;
                    final mainQuality =
                        (defaultQuality == 'hd' && hasHd) ? 'hd' : 'original';
                    final mainLabel = mainQuality == 'hd' ? '下载高清' : '下载原画';
                    final secondaryQuality =
                        mainQuality == 'hd' ? 'original' : 'hd';
                    final secondaryLabel =
                        secondaryQuality == 'hd' ? '高清' : '原画';
                    final showSecondary = hasHd;

                    return Column(
                      children: [
                        SizedBox(
                          width: double.infinity,
                          child: GradientButton(
                            text: '$mainLabel · 保存到相册',
                            icon: Icons.download_for_offline,
                            height: 50,
                            gradient: platformGrad,
                            shadowColor: platformPrimary,
                            onPressed: () => _downloadVideo(video, mainQuality),
                          ),
                        ),
                        if (showSecondary) ...[
                          const SizedBox(height: 10),
                          SizedBox(
                            width: double.infinity,
                            child: OutlinedButton.icon(
                              onPressed: () =>
                                  _downloadVideo(video, secondaryQuality),
                              style: OutlinedButton.styleFrom(
                                padding: const EdgeInsets.symmetric(vertical: 12),
                                side: BorderSide(
                                    color: borderColor, width: 1),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                foregroundColor: textPrimary,
                              ),
                              icon: Icon(Icons.file_download_outlined, size: 18),
                              label: Text(
                                '切换画质：$secondaryLabel',
                                style: const TextStyle(
                                    fontSize: 13, fontWeight: FontWeight.w500),
                              ),
                            ),
                          ),
                        ],
                        if (video.cover.isNotEmpty) ...[
                          const SizedBox(height: 10),
                          SizedBox(
                            width: double.infinity,
                            child: OutlinedButton.icon(
                              onPressed: () => _downloadCover(video),
                              style: OutlinedButton.styleFrom(
                                padding: const EdgeInsets.symmetric(vertical: 12),
                                side: BorderSide(
                                    color: borderColor, width: 1),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                foregroundColor: textPrimary,
                              ),
                              icon: const Icon(Icons.image_outlined, size: 18),
                              label: const Text(
                                '下载封面图',
                                style: TextStyle(
                                    fontSize: 13, fontWeight: FontWeight.w500),
                              ),
                            ),
                          ),
                        ],
                        const SizedBox(height: 10),
                        SizedBox(
                          width: double.infinity,
                          child: OutlinedButton.icon(
                            onPressed: () => _downloadAudio(video, mainQuality),
                            style: OutlinedButton.styleFrom(
                              padding: const EdgeInsets.symmetric(vertical: 12),
                              side: BorderSide(
                                  color: borderColor, width: 1),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                              foregroundColor: textPrimary,
                            ),
                            icon: const Icon(Icons.audiotrack_outlined, size: 18),
                            label: Text(
                              '仅音频下载（${settings.defaultAudioFormat.toUpperCase()}）',
                              style: const TextStyle(
                                  fontSize: 13, fontWeight: FontWeight.w500),
                            ),
                          ),
                        ),
                      ],
                    );
                  },
                ),
          const SizedBox(height: 14),
          // 次要操作
          Row(
            children: [
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: fillColor,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      borderRadius: BorderRadius.circular(10),
                      onTap: () => isImage
                          ? _copyImageUrls(video)
                          : _copyVideoUrl(video.videoUrl),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.copy, size: 16, color: textSecondary),
                            const SizedBox(width: 6),
                            Text(
                              isImage ? '复制链接' : '复制直链',
                              style: TextStyle(
                                fontSize: 12,
                                color: textPrimary,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: fillColor,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      borderRadius: BorderRadius.circular(10),
                      onTap: () => _openDetailPage(video),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.info_outline, size: 16,
                                color: textSecondary),
                            const SizedBox(width: 6),
                            Text(
                              '查看详情',
                              style: TextStyle(
                                fontSize: 12,
                                color: textPrimary,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: fillColor,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      borderRadius: BorderRadius.circular(10),
                      onTap: () => isImage
                          ? _openInBrowser(video.images?.first)
                          : _openInBrowser(video.videoUrl),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.open_in_new, size: 16,
                                color: textSecondary),
                            const SizedBox(width: 6),
                            Text(
                              '浏览器打开',
                              style: TextStyle(
                                fontSize: 12,
                                color: textPrimary,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
            ),
          ),
        );
      },
    );
  }

  /// 打开解析结果详情页
  void _openDetailPage(VideoInfo video) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ParseResultDetailPage(video: video),
      ),
    );
  }

  /// 解析结果卡片 - 显示长按操作菜单
  void _showParseResultActionMenu(VideoInfo video) {
    final isFav = context.read<HistoryProvider>().isFavorite(video.id);
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 12),
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.grey.shade700
                      : Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 8),
            ListTile(
              leading: const Icon(Icons.link, color: Colors.blue),
              title: const Text('复制链接'),
              onTap: () {
                Navigator.pop(context);
                Clipboard.setData(ClipboardData(text: video.url));
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('链接已复制')),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.share, color: Colors.green),
              title: const Text('分享'),
              onTap: () {
                Navigator.pop(context);
                Share.share(video.url);
              },
            ),
            ListTile(
              leading: Icon(
                isFav ? Icons.favorite : Icons.favorite_border,
                color: isFav ? Colors.red : Colors.grey,
              ),
              title: Text(isFav ? '取消收藏' : '收藏'),
              onTap: () {
                Navigator.pop(context);
                _toggleParseResultFavorite(video);
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete_outline, color: Colors.red),
              title: const Text('删除', style: TextStyle(color: Colors.red)),
              onTap: () async {
                Navigator.pop(context);
                final confirm = await showDialog<bool>(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: const Text('删除记录'),
                    content: const Text('确定要删除这条解析记录吗？'),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context, false),
                        child: const Text('取消'),
                      ),
                      TextButton(
                        onPressed: () => Navigator.pop(context, true),
                        child: const Text('删除', style: TextStyle(color: Colors.red)),
                      ),
                    ],
                  ),
                );
                if (confirm == true && mounted) {
                  await context.read<HistoryProvider>().removeVideo(video.id);
                  setState(() {
                    _parsedVideo = null;
                  });
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('已删除')),
                    );
                  }
                }
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  /// 解析结果卡片 - 切换收藏状态（带动画）
  Future<void> _toggleParseResultFavorite(VideoInfo video) async {
    HapticService.lightImpact();
    setState(() {
      _favoriteAnimatingId = video.id;
    });

    await context.read<HistoryProvider>().toggleFavorite(video.id);

    // 动画结束后清除状态
    Future.delayed(const Duration(milliseconds: 600), () {
      if (mounted) {
        setState(() {
          if (_favoriteAnimatingId == video.id) {
            _favoriteAnimatingId = null;
          }
        });
      }
    });
  }

  /// 图文预览网格
  Widget _buildImagePreview(VideoInfo video) {
    final images = video.images ?? [];
    final displayImages = images.take(3).toList();
    final total = images.length;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final placeholderColor = isDark ? Colors.grey.shade800 : Colors.grey.shade200;
    final errorIconColor = isDark ? Colors.grey.shade600 : Colors.grey;

    return SizedBox(
      height: 100,
      child: Row(
        children: [
          for (int i = 0; i < displayImages.length; i++) ...[
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Container(
                  color: placeholderColor,
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      Image.network(
                        displayImages[i],
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Icon(
                          Icons.broken_image,
                          color: errorIconColor,
                        ),
                      ),
                      if (i == 2 && total > 3)
                        Container(
                          color: Colors.black.withOpacity(0.5),
                          child: Center(
                            child: Text(
                              '+${total - 3}',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),
            if (i < displayImages.length - 1) const SizedBox(width: 6),
          ],
        ],
      ),
    );
  }

  Widget _buildErrorCard() {
    final tipType = _tipType;

    // 作者主页提示卡片：渐变风格 + 查看作品按钮
    if (tipType == 'authorProfile') {
      final isDark = Theme.of(context).brightness == Brightness.dark;
      return Container(
        padding: const EdgeInsets.all(20),
        margin: const EdgeInsets.only(bottom: 4),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: isDark
                ? [const Color(0xFF1E3A5F), const Color(0xFF0F172A)]
                : [const Color(0xFFE8F4FD), const Color(0xFFF0F7FF)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isDark
                ? Colors.blue.withOpacity(0.3)
                : Colors.blue.withOpacity(0.2),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.blue.withOpacity(isDark ? 0.1 : 0.08),
              blurRadius: 20,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [AppTheme.primaryColor, AppTheme.secondaryColor],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(14),
                    boxShadow: [
                      BoxShadow(
                        color: AppTheme.primaryColor.withOpacity(0.3),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: const Icon(Icons.person, color: Colors.white, size: 26),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '检测到作者主页',
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 16,
                          color: isDark ? Colors.white : AppTheme.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        '这是作者主页链接，点击下方按钮查看该作者的全部作品',
                        style: TextStyle(
                          color: isDark
                              ? Colors.grey.shade400
                              : AppTheme.textSecondary,
                          fontSize: 13,
                          height: 1.4,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),
            SizedBox(
              width: double.infinity,
              child: GradientButton(
                text: '查看全部作品',
                icon: Icons.video_library,
                height: 48,
                onPressed: _navigateToAuthorWorks,
              ),
            ),
          ],
        ),
      );
    }

    // 不支持的平台提示：蓝色风格
    if (tipType == 'unsupportedPlatform') {
      return Container(
        padding: const EdgeInsets.all(18),
        margin: const EdgeInsets.only(bottom: 4),
        decoration: BoxDecoration(
          color: AppTheme.secondaryColor.withOpacity(0.08),
          borderRadius: BorderRadius.circular(16),
          border:
              Border.all(color: AppTheme.secondaryColor.withOpacity(0.25)),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: AppTheme.secondaryColor.withOpacity(0.15),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.info_outline,
                  color: AppTheme.secondaryColor, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    '暂不支持该平台',
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 14,
                      color: AppTheme.secondaryColor,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _errorMessage!,
                    style: TextStyle(
                      color: AppTheme.secondaryColor.withOpacity(0.85),
                      fontSize: 12,
                      height: 1.4,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    // 普通错误：根据错误类型显示不同图标和标题，附带操作按钮
    final errorType = _errorType ?? ParseErrorType.parseFailed;
    // 是否显示换源相关按钮（仅解析失败和网络错误时显示）
    final showSourceActions = errorType == ParseErrorType.parseFailed ||
        errorType == ParseErrorType.networkError;

    return Container(
      padding: const EdgeInsets.all(18),
      margin: const EdgeInsets.only(bottom: 4),
      decoration: BoxDecoration(
        color: AppTheme.errorColor.withOpacity(0.08),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.errorColor.withOpacity(0.25)),
      ),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: AppTheme.errorColor.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(errorType.icon,
                    color: AppTheme.errorColor, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      errorType.title,
                      style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 14,
                        color: AppTheme.errorColor,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _errorMessage!,
                      style: TextStyle(
                        color: AppTheme.errorColor.withOpacity(0.85),
                        fontSize: 12,
                        height: 1.4,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          // 操作按钮行
          if (showSourceActions)
            Row(
              children: [
                Expanded(
                  child: _buildErrorActionButton(
                    icon: Icons.refresh_rounded,
                    label: '重试',
                    onPressed: _parsing ? null : _retryParse,
                    isPrimary: true,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _buildErrorActionButton(
                    icon: Icons.swap_horiz_rounded,
                    label: '换源试试',
                    onPressed: _parsing ? null : _switchSourceAndRetry,
                    isPrimary: false,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _buildErrorActionButton(
                    icon: Icons.settings_rounded,
                    label: '查看设置',
                    onPressed: _navigateToSourceSettings,
                    isPrimary: false,
                  ),
                ),
              ],
            )
          else
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: _parsing ? null : _parseUrl,
                icon: const Icon(Icons.refresh, size: 16),
                label: Text(
                  '重试',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.errorColor,
                  ),
                ),
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  side: BorderSide(color: AppTheme.errorColor.withOpacity(0.4)),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  foregroundColor: AppTheme.errorColor,
                ),
              ),
            ),
        ],
      ),
    );
  }

  /// 构建错误卡片操作按钮
  Widget _buildErrorActionButton({
    required IconData icon,
    required String label,
    required VoidCallback? onPressed,
    bool isPrimary = false,
  }) {
    final isDisabled = onPressed == null;
    return Material(
      color: isPrimary
          ? AppTheme.errorColor
          : Colors.transparent,
      borderRadius: BorderRadius.circular(10),
      child: InkWell(
        onTap: onPressed,
        borderRadius: BorderRadius.circular(10),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            border: isPrimary
                ? null
                : Border.all(
                    color: AppTheme.errorColor.withOpacity(isDisabled ? 0.2 : 0.4),
                  ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                size: 16,
                color: isPrimary
                    ? Colors.white.withOpacity(isDisabled ? 0.5 : 1.0)
                    : AppTheme.errorColor.withOpacity(isDisabled ? 0.4 : 1.0),
              ),
              const SizedBox(width: 4),
              Text(
                label,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: isPrimary
                      ? Colors.white.withOpacity(isDisabled ? 0.5 : 1.0)
                      : AppTheme.errorColor.withOpacity(isDisabled ? 0.4 : 1.0),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// 重试解析（使用当前源）
  Future<void> _retryParse() async {
    _parseUrl();
  }

  /// 切换到下一个可用解析源并重试
  Future<void> _switchSourceAndRetry() async {
    final settings = context.read<SettingsProvider>();
    final currentId = settings.apiSourceId;
    final presets = ApiSource.presets;

    // 找到当前源的索引
    int currentIndex = presets.indexWhere((s) => s.id == currentId);
    if (currentIndex == -1) currentIndex = 0;

    // 找到下一个可用源（跳过 custom，因为 custom 需要用户配置）
    int nextIndex = (currentIndex + 1) % presets.length;
    int attempts = 0;
    while (attempts < presets.length) {
      final nextSource = presets[nextIndex];
      // 跳过需要配置但未配置的源
      if (nextSource.id == 'custom') {
        nextIndex = (nextIndex + 1) % presets.length;
        attempts++;
        continue;
      }
      // 找到可用的下一个源
      if (nextSource.id != currentId) {
        break;
      }
      nextIndex = (nextIndex + 1) % presets.length;
      attempts++;
    }

    final newSource = presets[nextIndex];
    if (newSource.id == currentId) {
      // 没有其他可用源，直接重试
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('当前没有其他可用解析源'),
            duration: Duration(seconds: 2),
          ),
        );
      }
      _parseUrl();
      return;
    }

    // 切换到新源
    await settings.setApiSourceId(newSource.id);
    _syncParserService(settings);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('已切换到「${newSource.name}」，正在重新解析...'),
          duration: const Duration(seconds: 2),
        ),
      );
    }

    // 重新解析
    _parseUrl();
  }

  /// 跳转到设置页的解析源选项
  void _navigateToSourceSettings() {
    Navigator.of(context).push(
      AppPageRoute.fadeIn(const SettingsPage(initialSection: 'api_source')),
    );
  }

  Widget _buildPlatformRow() {
    return Row(
      children: [
        Expanded(child: _buildPlatformItem('douyin', '抖音', '支持解析下载', true)),
        const SizedBox(width: 10),
        Expanded(child: _buildPlatformItem('kuaishou', '快手', '支持解析下载', true)),
        const SizedBox(width: 10),
        Expanded(child: _buildPlatformItem('xiaohongshu', '小红书', '支持解析下载', true)),
        const SizedBox(width: 10),
        Expanded(child: _buildPlatformItem('more', '更多平台', '敬请期待', false)),
      ],
    );
  }

  Widget _buildPlatformItem(String platform, String name, String desc, bool supported) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final disabledBg = isDark ? const Color(0xFF1E293B) : Colors.grey.shade100;
    final disabledBorder = isDark ? Colors.grey.shade700 : Colors.grey.shade200;
    final disabledText = isDark ? Colors.grey.shade500 : Colors.grey.shade400;

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 8),
      decoration: BoxDecoration(
        color: supported
            ? Theme.of(context).cardColor
            : disabledBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: supported
              ? AppTheme.primaryColor.withOpacity(isDark ? 0.3 : 0.15)
              : disabledBorder,
        ),
        boxShadow: supported
            ? (isDark
                ? []
                : [
                    BoxShadow(
                      color: AppTheme.primaryColor.withOpacity(0.06),
                      blurRadius: 12,
                      offset: const Offset(0, 2),
                    ),
                  ])
            : null,
      ),
      child: Column(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: supported
                  ? AppTheme.primaryColor.withOpacity(isDark ? 0.2 : 0.1)
                  : disabledBorder,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Center(
              child: PlatformBadge(platform: platform, size: 26),
            ),
          ),
          const SizedBox(height: 10),
          Text(
            name,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w700,
              color: supported ? AppTheme.textPrimary : disabledText,
            ),
          ),
          const SizedBox(height: 2),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(
              color: supported
                  ? AppTheme.successColor.withOpacity(isDark ? 0.2 : 0.1)
                  : disabledBorder,
              borderRadius: BorderRadius.circular(4),
            ),
            child: Text(
              desc,
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w500,
                color: supported
                    ? AppTheme.successColor
                    : disabledText,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRecentList() {
    return Consumer<HistoryProvider>(
      builder: (context, history, child) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final skeletonColor = isDark ? Colors.grey.shade800 : Colors.grey.shade200;
        final emptyIconColor = isDark ? Colors.grey.shade600 : Colors.grey.shade400;
        final emptyTextPrimary = isDark ? Colors.grey.shade400 : Colors.grey.shade500;
        final emptyTextSecondary = isDark ? Colors.grey.shade600 : Colors.grey.shade400;

        // 加载中显示骨架屏
        if (history.loading) {
          return Column(
            children: List.generate(3, (index) => Padding(
              padding: EdgeInsets.only(bottom: index < 2 ? 8 : 0),
              child: Container(
                decoration: BoxDecoration(
                  color: Theme.of(context).cardColor,
                  borderRadius: BorderRadius.circular(12),
                ),
                padding: const EdgeInsets.all(12),
                child: Row(
                  children: [
                    Container(
                      width: 70,
                      height: 56,
                      decoration: BoxDecoration(
                        color: skeletonColor,
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: double.infinity,
                            height: 14,
                            decoration: BoxDecoration(
                              color: skeletonColor,
                              borderRadius: BorderRadius.circular(4),
                            ),
                          ),
                          const SizedBox(height: 8),
                          Container(
                            width: 80,
                            height: 12,
                            decoration: BoxDecoration(
                              color: skeletonColor,
                              borderRadius: BorderRadius.circular(4),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )),
          );
        }

        if (history.recentVideos.isEmpty) {
          return Container(
            padding: const EdgeInsets.all(28),
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Center(
              child: Column(
                children: [
                  Icon(Icons.history_outlined, size: 36, color: emptyIconColor),
                  const SizedBox(height: 10),
                  Text(
                    '暂无解析记录',
                    style: TextStyle(color: emptyTextPrimary, fontSize: 13),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '解析过的视频会显示在这里',
                    style: TextStyle(color: emptyTextSecondary, fontSize: 11),
                  ),
                ],
              ),
            ),
          );
        }

        return Column(
          children: history.recentVideos
              .asMap()
              .entries
              .map((entry) {
            return Padding(
              padding: EdgeInsets.only(bottom: entry.key < history.recentVideos.length - 1 ? 8 : 0),
              child: VideoCard(
                video: entry.value,
                onDownload: () => _downloadVideo(entry.value, 'original'),
              ),
            );
          })
              .toList(),
        );
      },
    );
  }

  void _clearInput() {
    _urlController.clear();
    setState(() {
      _parsedVideo = null;
      _errorMessage = null;
      _errorType = null;
      _tipType = null;
      _batchResults = [];
      _batchCurrent = 0;
      _batchTotal = 0;
    });
  }

  /// 切换单条/批量模式（供外部调用，如 SnackBar 操作）
  void _toggleBatchMode() {
    _handleBatchModeChanged(!_isBatchMode);
  }

  /// 处理批量模式变化（来自 LinkInputCard 回调或内部切换）
  void _handleBatchModeChanged(bool isBatchMode) {
    setState(() {
      _isBatchMode = isBatchMode;
      _parsedVideo = null;
      _errorMessage = null;
      _errorType = null;
      _tipType = null;
      _batchResults = [];
      _batchCurrent = 0;
      _batchTotal = 0;
    });
  }

  /// TextEditingController 监听器：输入变化时的防抖自动解析
  void _onTextChanged() {
    // 触发 UI 重建（用于更新 LinkInputCard 按钮文案等）
    setState(() {});

    // 更新输入联想
    _updateSuggestions();

    // 批量模式不自动解析
    if (_isBatchMode) return;

    final text = _urlController.text.trim();
    final url = _parserService.extractUrl(text);

    // 没有有效 URL 时取消防抖
    if (url == null) {
      _debounceTimer?.cancel();
      return;
    }

    // 正在解析时不重复触发
    if (_parsing) return;

    // 防抖：500ms 后自动解析
    _debounceTimer?.cancel();
    _debounceTimer = Timer(const Duration(milliseconds: 500), () {
      if (mounted && !_parsing) {
        _parseUrl();
      }
    });
  }

  /// 更新输入联想列表
  void _updateSuggestions() {
    final text = _urlController.text.trim();
    if (text.isEmpty) {
      setState(() {
        _suggestions = [];
        _showSuggestions = false;
      });
      return;
    }

    // 从历史记录中搜索匹配的 URL
    final history = context.read<HistoryProvider>().videos;
    final matches = <SuggestionItem>[];

    for (final video in history) {
      if (video.url.contains(text) || video.title.toLowerCase().contains(text.toLowerCase())) {
        matches.add(SuggestionItem(
          url: video.url,
          platform: VideoPlatformX.fromId(video.platform),
          title: video.title,
          timeLabel: _formatTimeAgo(video.parsedAt),
        ));
        if (matches.length >= 5) break;
      }
    }

    setState(() {
      _suggestions = matches;
      _showSuggestions = matches.isNotEmpty && text.length >= 2;
    });
  }

  /// 格式化时间为"多久前"
  String _formatTimeAgo(DateTime? time) {
    if (time == null) return '';
    final now = DateTime.now();
    final diff = now.difference(time);
    if (diff.inMinutes < 1) return '刚刚';
    if (diff.inHours < 1) return '${diff.inMinutes}分钟前';
    if (diff.inDays < 1) return '${diff.inHours}小时前';
    if (diff.inDays < 7) return '${diff.inDays}天前';
    return '${diff.inDays ~/ 7}周前';
  }

  /// 处理联想项选择
  void _onSuggestionSelected(SuggestionItem item) {
    _urlController.text = item.url;
    _urlController.selection = TextSelection.fromPosition(
      TextPosition(offset: item.url.length),
    );
    setState(() {
      _showSuggestions = false;
    });
    HapticService.selectionClick();
  }

  /// 处理快捷菜单选择
  void _onQuickMenuSelected(String itemId) {
    switch (itemId) {
      case 'paste':
        _pasteFromClipboard();
        break;
      case 'clear':
        _urlController.clear();
        break;
      case 'search':
        // 聚焦到输入框，进入搜索模式
        FocusScope.of(context).requestFocus(FocusNode());
        break;
    }
    HapticService.selectionClick();
  }

  /// 从剪贴板粘贴（支持智能粘贴模式）
  Future<void> _pasteFromClipboard() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    final text = data?.text ?? '';
    if (text.isEmpty) return;

    final smartMode = context.read<SettingsProvider>().smartPasteAppendMode;
    final currentText = _urlController.text;

    if (!smartMode || currentText.isEmpty || currentText.trim() == text.trim()) {
      // 非智能模式 / 输入框为空 / 内容相同 → 直接覆盖
      _urlController.text = text;
      _urlController.selection = TextSelection.fromPosition(
        TextPosition(offset: text.length),
      );
    } else {
      // 智能模式 + 内容不同 → 换行追加
      final newText = '${currentText.trim()}\n${text.trim()}';
      _urlController.text = newText;
      _urlController.selection = TextSelection.fromPosition(
        TextPosition(offset: newText.length),
      );
    }
  }

  /// 处理双指密度切换
  void _onDensityChanged(String newDensity) {
    final settings = context.read<SettingsProvider>();
    settings.setUiDensity(newDensity);
    HapticService.selectionClick();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('已切换到${DensityLevelX.fromString(newDensity).label}模式'),
        duration: const Duration(seconds: 1),
      ),
    );
  }

  /// 双指下滑进入搜索模式
  void _onTwoFingerSwipeDown() {
    // 聚焦到输入框
    FocusScope.of(context).requestFocus(FocusNode());
    HapticService.selectionClick();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('搜索模式'), duration: Duration(seconds: 1)),
    );
  }

  /// 批量引导完成
  void _onBatchGuideComplete() {
    final settings = context.read<SettingsProvider>();
    settings.setBatchGuideShown(true);
    setState(() {
      _showBatchGuide = false;
    });
  }

  /// 滚动首页到顶部
  void _scrollHomeToTop({bool triggerRefresh = false}) {
    if (_homeScrollController.hasClients) {
      _homeScrollController.animateTo(
        0,
        duration: const Duration(milliseconds: 500),
        curve: Curves.easeOutCubic,
      ).then((_) {
        if (triggerRefresh && mounted) {
          // 滚动到顶部后轻微下拉触发刷新
          _homeScrollController.animateTo(
            -80,
            duration: const Duration(milliseconds: 200),
            curve: Curves.easeOut,
          );
        }
      });
    }
  }

  /// 处理底部导航首页双击
  void _onHomeDoubleTap() {
    final now = DateTime.now();
    if (_lastHomeTap != null &&
        now.difference(_lastHomeTap!) < const Duration(milliseconds: 500)) {
      _scrollHomeToTop();
      _lastHomeTap = null;
    } else {
      _lastHomeTap = now;
    }
  }

  /// 返回键处理：首页按两次返回键退出应用
  Future<bool> _onWillPop() async {
    // 如果不是首页 tab，先回到首页
    if (_currentIndex != 0) {
      setState(() {
        _currentIndex = 0;
      });
      return false;
    }

    final now = DateTime.now();
    if (_lastBackPress != null &&
        now.difference(_lastBackPress!) <= const Duration(seconds: 2)) {
      // 2秒内连续按两次，退出应用
      _lastBackPress = null;
      return true;
    } else {
      // 第一次按，显示提示
      _lastBackPress = now;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('再按一次退出应用'),
          duration: const Duration(seconds: 2),
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          margin: const EdgeInsets.only(bottom: 20, left: 20, right: 20),
        ),
      );
      return false;
    }
  }

  /// 下拉刷新：重新解析当前链接
  Future<void> _onRefresh() async {
    // 刷新历史记录
    try {
      await context.read<HistoryProvider>().refresh();
    } catch (_) {}

    // 刷新资源看板数据
    try {
      context.read<SourceStatsProvider>().refresh();
    } catch (_) {}

    // 重新检测剪贴板
    final settings = context.read<SettingsProvider>();
    if (settings.clipboardDetectionEnabled) {
      _detectClipboardForBanner();
    }

    // 如果当前有输入内容，也重新解析
    if (_isBatchMode) {
      await _parseUrl();
    } else if (_urlController.text.trim().isNotEmpty && _parsedVideo != null) {
      await _parseUrl();
    }
  }

  /// 显示成功提示（顶部 SnackBar）
  void _showSuccessSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(Icons.check_circle, color: AppTheme.successColor, size: 18),
            const SizedBox(width: 8),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: Theme.of(context).cardColor,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.fromLTRB(12, 12, 12, 0),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  /// 显示失败提示（底部模态 BottomSheet）
  void _showErrorBottomSheet({
    required String title,
    required String message,
    IconData? icon,
    String? retryText,
    VoidCallback? onRetry,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => Container(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: SafeArea(
          top: false,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 36,
                height: 4,
                decoration: BoxDecoration(
                  color: isDark ? Colors.grey.shade700 : Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 16),
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: AppTheme.errorColor.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Icon(
                  icon ?? Icons.error_outline,
                  color: AppTheme.errorColor,
                  size: 28,
                ),
              ),
              const SizedBox(height: 14),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              Text(
                message,
                style: TextStyle(
                  fontSize: 13,
                  color: isDark ? Colors.grey.shade400 : Colors.grey.shade600,
                  height: 1.5,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 20),
              if (onRetry != null) ...[
                SizedBox(
                  width: double.infinity,
                  child: GradientButton(
                    text: retryText ?? '重试',
                    icon: Icons.refresh,
                    height: 46,
                    onPressed: () {
                      Navigator.pop(context);
                      onRetry();
                    },
                  ),
                ),
                const SizedBox(height: 10),
              ],
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: () => Navigator.pop(context),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: const Text('知道了'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// 检测是否为作者主页链接
  bool _isAuthorProfileUrl(String url) {
    final lower = url.toLowerCase();
    // 抖音用户页：含 /user/ 或 sec_uid 或 /profile/
    final isDouyinProfile = (lower.contains('douyin.com') ||
            lower.contains('iesdouyin.com')) &&
        (lower.contains('/user/') ||
            lower.contains('sec_uid') ||
            lower.contains('/profile/'));
    // 快手用户页：含 /profile/ 或 /user/
    final isKuaishouProfile = (lower.contains('kuaishou.com') ||
            lower.contains('chenzhongtech.com') ||
            lower.contains('gifshow.com')) &&
        (lower.contains('/profile/') || lower.contains('/user/'));
    // 小红书用户页：含 /user/profile/
    final isXiaohongshuProfile = (lower.contains('xiaohongshu.com') ||
            lower.contains('xhslink.com') ||
            lower.contains('xhslink.cn')) &&
        lower.contains('/user/profile/');
    return isDouyinProfile || isKuaishouProfile || isXiaohongshuProfile;
  }

  /// 从作者主页 URL 中检测平台
  String _detectAuthorPlatform(String url) {
    final lower = url.toLowerCase();
    if (lower.contains('douyin.com') || lower.contains('iesdouyin.com')) {
      return 'douyin';
    }
    if (lower.contains('kuaishou.com') ||
        lower.contains('chenzhongtech.com') ||
        lower.contains('gifshow.com')) {
      return 'kuaishou';
    }
    if (lower.contains('xiaohongshu.com') || lower.contains('xhslink.com') || lower.contains('xhslink.cn')) {
      return 'xiaohongshu';
    }
    return 'unknown';
  }

  /// 检测是否为有效的 http(s) 链接
  bool _isValidHttpUrl(String url) {
    try {
      final uri = Uri.parse(url);
      return uri.scheme == 'http' || uri.scheme == 'https';
    } catch (_) {
      return false;
    }
  }

  /// 跳转到抓取页（底部导航 index 1）
  void _navigateToCrawlTab() {
    setState(() {
      _currentIndex = 1;
    });
  }

  /// 跳转到作者作品页面
  void _navigateToAuthorWorks() async {
    final url = _urlController.text.trim();
    if (url.isEmpty) return;

    final extractedUrl = _parserService.extractUrl(url) ?? url;
    // 尝试展开短链接
    String expandedUrl = extractedUrl;
    try {
      expandedUrl = await _parserService.expandShortUrl(extractedUrl);
    } catch (_) {}

    final platform = _detectAuthorPlatform(expandedUrl);

    if (!mounted) return;

    // 检查平台是否支持作者作品抓取
    final supportedPlatforms = ['douyin', 'kuaishou'];
    if (!supportedPlatforms.contains(platform)) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('暂不支持${_platformName(platform)}作者作品抓取，敬请期待'),
          duration: const Duration(seconds: 2),
        ),
      );
      return;
    }

    Navigator.push(
      context,
      AppPageRoute.slideRight(
        AuthorWorksPage(
          authorUrl: expandedUrl,
          authorName: '',
          authorAvatar: '',
          platform: platform,
        ),
      ),
    );
  }

  /// 平台名称映射
  String _platformName(String platform) {
    switch (platform) {
      case 'douyin':
        return '抖音';
      case 'kuaishou':
        return '快手';
      case 'xiaohongshu':
      case 'xhs':
        return '小红书';
      default:
        return '该';
    }
  }

  Future<void> _parseUrl({bool autoDownload = false}) async {
    final text = _urlController.text.trim();
    if (text.isEmpty) {
      setState(() {
        _errorMessage = '请输入视频链接';
        _errorType = ParseErrorType.invalidUrl;
        _tipType = null;
      });
      return;
    }

    // 按行分割，过滤空行
    final lines = text.split('\n').map((l) => l.trim()).where((l) => l.isNotEmpty).toList();

    // 批量模式
    if (_isBatchMode) {
      await _doBatchParse(lines, autoDownload: autoDownload);
      return;
    }

    // 单条模式：检测是否有多行
    if (lines.length > 1) {
      // 只保留第一行第一个链接
      final firstUrl = _parserService.extractUrl(lines.first) ?? lines.first;
      _urlController.text = firstUrl;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('当前是单条解析模式，只保留了第一条链接\n如需批量解析，请点击右上角「单条模式」切换'),
          duration: const Duration(seconds: 3),
          action: SnackBarAction(
            label: '切换批量',
            onPressed: _toggleBatchMode,
          ),
        ),
      );
    }

    final url = _urlController.text.trim();
    final extractedUrl = _parserService.extractUrl(url);
    if (extractedUrl == null) {
      setState(() {
        _errorMessage = '未找到有效的视频链接';
        _errorType = ParseErrorType.invalidUrl;
        _tipType = null;
      });
      return;
    }

    setState(() {
      _parsing = true;
      _parsingAction = autoDownload ? 'download' : 'parse';
      _errorMessage = null;
      _errorType = null;
      _tipType = null;
      _parsedVideo = null;
    });

    try {
      // 先用原始 URL 检测平台（避免短链接展开失败导致误判为不支持的平台）
      var platform = _parserService.detectPlatform(extractedUrl);

      // 如果原始 URL 检测不到，再尝试展开短链接后检测
      String expandedUrl = extractedUrl;
      if (platform == 'unknown') {
        expandedUrl = await _parserService.expandShortUrl(extractedUrl);
        platform = _parserService.detectPlatform(expandedUrl);
      } else {
        // 能检测到平台，也展开短链接（用于后续解析获取真实地址）
        expandedUrl = await _parserService.expandShortUrl(extractedUrl);
        // 展开后再检测一次，确保用最终的 URL
        final expandedPlatform = _parserService.detectPlatform(expandedUrl);
        if (expandedPlatform != 'unknown') {
          platform = expandedPlatform;
        }
      }

      // 检测是否为不支持的平台
      if (platform == 'unknown') {
        setState(() {
          _errorMessage = '当前仅支持抖音、快手和小红书平台的视频链接，该链接来自其他平台';
          _tipType = 'unsupportedPlatform';
          _parsing = false;
          _parsingAction = null;
        });
        return;
      }

      // 检测是否为作者主页链接
      if (_isAuthorProfileUrl(expandedUrl)) {
        setState(() {
          _errorMessage = '检测到作者主页，点击查看全部作品';
          _tipType = 'authorProfile';
          _parsing = false;
          _parsingAction = null;
        });
        return;
      }

      // 检测链接是否包含作品ID（可能是无效的抖音/快手链接）
      if (platform == 'douyin') {
        final hasVideoId = expandedUrl.contains(RegExp(r'/video/\d+')) ||
            expandedUrl.contains(RegExp(r'/note/\d+')) ||
            expandedUrl.contains(RegExp(r'/slides/\d+')) ||
            expandedUrl.contains(RegExp(r'[?&]item_id=\d+')) ||
            expandedUrl.contains(RegExp(r'[?&]aweme_id=\d+'));
        final isUserPage = expandedUrl.contains('/user/') ||
            expandedUrl.contains('sec_uid=') ||
            expandedUrl.contains('/share/user/');
        if (!hasVideoId && !isUserPage) {
          setState(() {
            _errorMessage = '这不是一个有效的抖音视频或图文链接，请确认链接是否正确';
            _tipType = 'unsupportedPlatform';
            _parsing = false;
            _parsingAction = null;
          });
          return;
        }
      }

      final video = await _parserService.parse(expandedUrl);
      // 解析成功后写入历史（不依赖 mounted，确保数据持久化不丢失）
      try {
        await context.read<HistoryProvider>().addVideo(video);
      } catch (_) {
        // Provider 未就绪时兜底：直接通过 service 写入
        // （initState 阶段的自动解析可能遇到 Provider 时序问题）
        try {
          await context.read<HistoryService>().add(video);
        } catch (_) {
          // 双重兜底：忽略历史写入失败，不影响主流程
        }
      }
      if (mounted) {
        setState(() {
          _parsedVideo = video;
        });
      }

      // 解析成功后自动下载（自动粘贴解析下载场景）
      if (autoDownload && mounted) {
        if (video.isImage) {
          await _downloadImages(video);
        } else {
          // 使用默认画质下载
          final settings = context.read<SettingsProvider>();
          final quality = settings.defaultQuality;
          await _downloadVideo(video, quality);
        }
      }
    } catch (e) {
      final errorMsg = e.toString().replaceAll('ParseException: ', '');
      final errorType = e is ParseException ? e.type : ParseErrorType.parseFailed;
      setState(() {
        _errorMessage = errorMsg;
        _errorType = errorType;
        _tipType = null;
      });
    } finally {
      if (mounted) {
        setState(() {
          _parsing = false;
          _parsingAction = null;
        });
      }
    }
  }

  /// 解析并自动下载
  /// 
  /// 直接复用 _parseUrl(autoDownload: true) 的逻辑，
  /// 确保"解析并下载"按钮和自动粘贴解析下载走完全相同的流程
  Future<void> _parseAndDownload() async {
    await _parseUrl(autoDownload: true);
  }

  Future<void> _downloadVideo(VideoInfo video, String quality) async {
    final downloadProvider = context.read<DownloadProvider>();

    final hasPermission = await downloadProvider.checkPermission();
    if (!hasPermission) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('需要存储权限才能下载视频')),
        );
      }
      return;
    }

    try {
      await downloadProvider.addDownload(video, quality);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('已添加下载任务：${video.title}')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('添加下载失败：${e.toString()}')),
        );
      }
    }
  }

  /// 仅音频下载
  Future<void> _downloadAudio(VideoInfo video, String quality) async {
    final downloadProvider = context.read<DownloadProvider>();
    final settings = context.read<SettingsProvider>();

    final hasPermission = await downloadProvider.checkPermission();
    if (!hasPermission) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('需要存储权限才能下载音频')),
        );
      }
      return;
    }

    try {
      await downloadProvider.addAudioDownload(
        video,
        quality,
        audioFormat: settings.defaultAudioFormat,
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('已添加音频下载任务：${video.title}')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('添加下载失败：${e.toString()}')),
        );
      }
    }
  }

  /// 下载全部图片
  Future<void> _downloadImages(VideoInfo video) async {
    final downloadProvider = context.read<DownloadProvider>();

    final hasPermission = await downloadProvider.checkPermission();
    if (!hasPermission) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('需要存储权限才能保存图片')),
        );
      }
      return;
    }

    final images = video.images;
    if (images == null || images.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('没有可下载的图片')),
      );
      return;
    }

    try {
      // 直接调用 addDownload，DownloadManager 内部会自动创建分组任务
      await downloadProvider.addDownload(video, 'original');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('已添加${images.length}张图片到下载队列')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('添加下载失败：${e.toString()}')),
        );
      }
    }
  }

  /// 下载封面图
  Future<void> _downloadCover(VideoInfo video) async {
    final downloadProvider = context.read<DownloadProvider>();

    final hasPermission = await downloadProvider.checkPermission();
    if (!hasPermission) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('需要存储权限才能保存图片')),
        );
      }
      return;
    }

    if (video.cover.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('没有封面图可下载')),
      );
      return;
    }

    try {
      final coverTask = VideoInfo(
        id: '${video.id}_cover',
        url: video.cover,
        platform: video.platform,
        title: '${video.title}_封面',
        author: video.author,
        cover: video.cover,
        videoUrl: video.cover,
        parsedAt: DateTime.now(),
        type: 'image',
      );
      await downloadProvider.addDownload(coverTask, 'original');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('已添加封面图到下载队列')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('添加下载失败：${e.toString()}')),
        );
      }
    }
  }

  /// 复制图片链接
  Future<void> _copyImageUrls(VideoInfo video) async {
    final images = video.images;
    if (images == null || images.isEmpty) return;
    final text = images.join('\n');
    await Clipboard.setData(ClipboardData(text: text));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('已复制${images.length}张图片链接')),
      );
    }
  }

  Widget _buildExpandedUrlCard() {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final cardBg = isDark ? Colors.blue.shade900.withOpacity(0.3) : Colors.blue.shade50;
    final cardBorder = isDark ? Colors.blue.shade700 : Colors.blue.shade200;
    final iconColor = isDark ? Colors.blue.shade300 : Colors.blue.shade600;
    final titleColor = isDark ? Colors.blue.shade200 : Colors.blue.shade700;
    final contentColor = isDark ? Colors.white70 : Colors.black87;

    return Container(
      margin: const EdgeInsets.only(top: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: cardBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.link, color: iconColor, size: 16),
              const SizedBox(width: 6),
              Text(
                '长链接已展开',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: titleColor,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            _expandedUrl!,
            style: TextStyle(fontSize: 11, color: contentColor),
            maxLines: 3,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => _copyExpandedUrl(_expandedUrl!),
                  icon: const Icon(Icons.copy, size: 14),
                  label: const Text('复制', style: TextStyle(fontSize: 11)),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 6),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => _openInBrowser(_expandedUrl!),
                  icon: const Icon(Icons.open_in_browser, size: 14),
                  label: const Text('浏览器打开', style: TextStyle(fontSize: 11)),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 6),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Future<void> _expandShortUrl() async {
    final url = _urlController.text.trim();
    if (url.isEmpty) {
      setState(() {
        _errorMessage = '请输入视频链接';
        _errorType = ParseErrorType.invalidUrl;
        _tipType = null;
      });
      return;
    }

    final extractedUrl = _parserService.extractUrl(url);
    if (extractedUrl == null) {
      setState(() {
        _errorMessage = '未找到有效的视频链接';
        _errorType = ParseErrorType.invalidUrl;
        _tipType = null;
      });
      return;
    }

    setState(() {
      _expanding = true;
      _errorMessage = null;
      _tipType = null;
      _expandedUrl = null;
    });

    try {
      final expanded = await _parserService.expandShortUrl(extractedUrl);
      setState(() {
        _expandedUrl = expanded;
      });
    } catch (e) {
      setState(() {
        _errorMessage = '展开失败：${e.toString()}';
        _tipType = null;
      });
    } finally {
      setState(() {
        _expanding = false;
      });
    }
  }

  Future<void> _copyVideoUrl(String? url) async {
    if (url == null || url.isEmpty) return;
    await Clipboard.setData(ClipboardData(text: url));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('视频直链已复制到剪贴板')),
      );
    }
  }

  Future<void> _copyExpandedUrl(String url) async {
    await Clipboard.setData(ClipboardData(text: url));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('长链接已复制到剪贴板')),
      );
    }
  }

  Future<void> _openInBrowser(String? url) async {
    if (url == null || url.isEmpty) return;
    try {
      final uri = Uri.parse(url);
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('无法打开浏览器')),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('打开失败：${e.toString()}')),
        );
      }
    }
  }

  // ==================== 批量解析 ====================

  /// 执行批量解析
  Future<void> _doBatchParse(List<String> lines, {required bool autoDownload}) async {
    if (lines.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('请输入至少一个链接')),
      );
      return;
    }

    setState(() {
      _parsing = true;
      _parsingAction = autoDownload ? 'download' : 'parse';
      _errorMessage = null;
      _tipType = null;
      _parsedVideo = null;
      _batchResults = [];
      _batchCurrent = 0;
      _batchTotal = lines.length;
    });

    final results = <_BatchParseItem>[];
    final settings = context.read<SettingsProvider>();
    final quality = settings.defaultQuality;

    for (int i = 0; i < lines.length; i++) {
      final line = lines[i];
      final extractedUrl = _parserService.extractUrl(line);

      setState(() {
        _batchCurrent = i + 1;
      });

      if (extractedUrl == null) {
        results.add(_BatchParseItem(
          originalUrl: line,
          status: 'failed',
          error: '未找到有效的视频链接',
        ));
        continue;
      }

      // 检测是否为作者主页链接
      if (_isAuthorProfileUrl(extractedUrl)) {
        results.add(_BatchParseItem(
          originalUrl: line,
          status: 'failed',
          error: '作者主页链接，请查看作者全部作品',
        ));
        continue;
      }

      try {
        final video = await _parserService.parse(extractedUrl);
        // 写入历史（不依赖 mounted，确保数据持久化不丢失）
        try {
          await context.read<HistoryProvider>().addVideo(video);
        } catch (_) {
          try {
            await context.read<HistoryService>().add(video);
          } catch (_) {
            // 双重兜底：忽略历史写入失败，不影响主流程
          }
        }

        // 自动下载
        if (autoDownload && mounted) {
          if (video.isImage) {
            await _downloadImagesNoSwitch(video);
          } else {
            await _downloadVideoNoSwitch(video, quality);
          }
        }

        results.add(_BatchParseItem(
          originalUrl: line,
          status: 'success',
          video: video,
        ));
      } catch (e) {
        results.add(_BatchParseItem(
          originalUrl: line,
          status: 'failed',
          error: e.toString().replaceAll('ParseException: ', ''),
        ));
      }
    }

    if (mounted) {
      setState(() {
        _batchResults = results;
        _parsing = false;
        _parsingAction = null;
      });

      final successCount = results.where((r) => r.status == 'success').length;
      final failCount = results.where((r) => r.status == 'failed').length;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('批量解析完成：成功 $successCount 条，失败 $failCount 条'),
          duration: const Duration(seconds: 3),
        ),
      );
    }
  }

  /// 下载视频（不切换页面，用于批量下载）
  Future<void> _downloadVideoNoSwitch(VideoInfo video, String quality) async {
    final downloadProvider = context.read<DownloadProvider>();
    final hasPermission = await downloadProvider.checkPermission();
    if (!hasPermission) return;
    try {
      await downloadProvider.addDownload(video, quality);
    } catch (_) {}
  }

  /// 下载图片（不切换页面，用于批量下载）
  Future<void> _downloadImagesNoSwitch(VideoInfo video) async {
    final downloadProvider = context.read<DownloadProvider>();
    final hasPermission = await downloadProvider.checkPermission();
    if (!hasPermission) return;
    final images = video.images;
    if (images == null || images.isEmpty) return;
    try {
      // 直接调用 addDownload，DownloadManager 内部会自动创建分组任务
      await downloadProvider.addDownload(video, 'original');
    } catch (_) {}
  }

  /// 批量结果卡片
  Widget _buildBatchResultCard() {
    final successList = _batchResults.where((r) => r.status == 'success').toList();
    final failList = _batchResults.where((r) => r.status == 'failed').toList();
    final videoCount = successList.where((r) => r.video?.isVideo ?? false).length;
    final imageCount = successList.where((r) => r.video?.isImage ?? false).length;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final successBadgeBg = Colors.green.withOpacity(isDark ? 0.2 : 0.1);
    final successBadgeText = isDark ? Colors.green.shade300 : Colors.green.shade700;
    final failBadgeBg = Colors.red.withOpacity(isDark ? 0.2 : 0.1);
    final failBadgeText = isDark ? Colors.red.shade300 : Colors.red.shade700;
    final sectionTextColor = isDark ? Colors.white : Colors.black87;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.primaryColor.withOpacity(isDark ? 0.5 : 0.3)),
        boxShadow: isDark
            ? []
            : [
                BoxShadow(
                  color: AppTheme.primaryColor.withOpacity(0.1),
                  blurRadius: 10,
                ),
              ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.check_circle, color: AppTheme.successColor, size: 20),
              const SizedBox(width: 8),
              Text(
                '批量解析完成',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.successColor,
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: successBadgeBg,
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(
                  '成功 ${successList.length} 条',
                  style: TextStyle(
                    fontSize: 11,
                    color: successBadgeText,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
              if (failList.isNotEmpty) ...[
                const SizedBox(width: 6),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: failBadgeBg,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    '失败 ${failList.length} 条',
                    style: TextStyle(
                      fontSize: 11,
                      color: failBadgeText,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
              const Spacer(),
              if (successList.isNotEmpty)
                InkWell(
                  onTap: () => _showBatchParseCopyFieldMenu(successList),
                  borderRadius: BorderRadius.circular(6),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppTheme.primaryColor.withOpacity(isDark ? 0.18 : 0.1),
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(
                        color: AppTheme.primaryColor.withOpacity(0.4),
                        width: 0.8,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.content_copy,
                            size: 12, color: AppTheme.primaryColor),
                        const SizedBox(width: 3),
                        Text(
                          '复制字段',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                            color: isDark
                                ? AppTheme.primaryColor.withOpacity(0.95)
                                : AppTheme.primaryColorDark,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 12),
          // 一键下载按钮组
          if (successList.isNotEmpty) ...[
            Text(
              '一键下载',
              style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: sectionTextColor),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: videoCount > 0 ? _batchDownloadVideos : null,
                    icon: const Icon(Icons.videocam_outlined, size: 16),
                    label: Text(
                      '下载全部视频 ($videoCount)',
                      style: const TextStyle(fontSize: 11),
                    ),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: imageCount > 0 ? _batchDownloadImages : null,
                    icon: const Icon(Icons.image_outlined, size: 16),
                    label: Text(
                      '下载全部图片 ($imageCount)',
                      style: const TextStyle(fontSize: 11),
                    ),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: GradientButton(
                text: '一键下载全部（视频+图片）',
                icon: Icons.download,
                height: 38,
                onPressed: _batchDownloadAll,
              ),
            ),
            const SizedBox(height: 12),
          ],
          // 结果列表
          Text(
            '解析结果',
            style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: sectionTextColor),
          ),
          const SizedBox(height: 8),
          Container(
            constraints: const BoxConstraints(maxHeight: 300),
            child: ListView.builder(
              shrinkWrap: true,
              physics: const ClampingScrollPhysics(),
              itemCount: _batchResults.length,
              itemBuilder: (context, index) {
                final item = _batchResults[index];
                return Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: _buildBatchResultItem(item),
                );
              },
            ),
          ),
          // 重试失败项按钮
          if (failList.isNotEmpty) ...[
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: _parsing ? null : _retryFailedBatchItems,
                icon: const Icon(Icons.refresh, size: 16),
                label: Text(
                  '重试失败项（${failList.length}条）',
                  style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                ),
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  side: BorderSide(color: AppTheme.errorColor.withOpacity(0.4)),
                  foregroundColor: AppTheme.errorColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  /// 批量解析结果 - 显示复制字段选择菜单
  void _showBatchParseCopyFieldMenu(List<_BatchParseItem> successItems) {
    if (successItems.isEmpty) return;
    final fields = <_ParseCopyField>[
      _ParseCopyField('title', '标题', (v) => v.title),
      _ParseCopyField('author', '作者', (v) => v.author),
      _ParseCopyField('videoUrl', '视频直链', (v) => v.videoUrl ?? ''),
      _ParseCopyField('cover', '封面图', (v) => v.cover),
      _ParseCopyField('url', '原链接', (v) => v.url),
      if (successItems.any((i) => i.video?.isImage ?? false))
        _ParseCopyField('images', '图片链接', (v) => v.images?.join('\n') ?? ''),
    ];

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        final dividerColor = isDark ? Colors.grey.shade700 : Colors.grey.shade300;
        return StatefulBuilder(
          builder: (context, setModalState) {
            return DraggableScrollableSheet(
              initialChildSize: 0.55,
              maxChildSize: 0.8,
              minChildSize: 0.35,
              builder: (_, controller) => Container(
                decoration: BoxDecoration(
                  color: Theme.of(context).cardColor,
                  borderRadius:
                      const BorderRadius.vertical(top: Radius.circular(20)),
                ),
                child: Column(
                  children: [
                    const SizedBox(height: 12),
                    Center(
                      child: Container(
                        width: 40,
                        height: 4,
                        decoration: BoxDecoration(
                          color: dividerColor,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Row(
                        children: [
                          const Text(
                            '复制字段',
                            style: TextStyle(
                                fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                          const Spacer(),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: Colors.orange.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(
                              '${successItems.length} 条记录',
                              style: const TextStyle(
                                fontSize: 12,
                                color: Colors.orange,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 8),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Text(
                        '选择要复制的字段，每条一行',
                        style:
                            TextStyle(fontSize: 13, color: secondaryTextColor),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Divider(height: 1, color: dividerColor),
                    // 全部字段选项
                    InkWell(
                      onTap: () {
                        _batchCopyParseAllFields(successItems);
                        Navigator.pop(context);
                      },
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 14),
                        child: Row(
                          children: [
                            Container(
                              width: 36,
                              height: 36,
                              decoration: BoxDecoration(
                                color: Colors.blue.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: const Icon(Icons.copy_all,
                                  color: Colors.blue, size: 20),
                            ),
                            const SizedBox(width: 12),
                            const Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('全部字段',
                                      style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.w600)),
                                  SizedBox(height: 2),
                                  Text('复制每条记录的所有字段信息',
                                      style: TextStyle(fontSize: 12)),
                                ],
                              ),
                            ),
                            Icon(Icons.chevron_right,
                                color: secondaryTextColor, size: 18),
                          ],
                        ),
                      ),
                    ),
                    Divider(height: 1, color: dividerColor, indent: 68),
                    // 单字段列表
                    Expanded(
                      child: ListView.builder(
                        controller: controller,
                        shrinkWrap: true,
                        itemCount: fields.length,
                        itemBuilder: (context, index) {
                          final field = fields[index];
                          return InkWell(
                            onTap: () {
                              _batchCopyParseField(successItems, field);
                              Navigator.pop(context);
                            },
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 20, vertical: 13),
                              child: Row(
                                children: [
                                  Container(
                                    width: 36,
                                    height: 36,
                                    decoration: BoxDecoration(
                                      color: AppTheme.primaryColor
                                          .withOpacity(0.1),
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: Icon(Icons.text_fields,
                                        color: AppTheme.primaryColor,
                                        size: 18),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Text(
                                      field.label,
                                      style: const TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.w500),
                                    ),
                                  ),
                                  Icon(Icons.chevron_right,
                                      color: secondaryTextColor, size: 18),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  /// 批量解析 - 复制指定字段的所有值
  void _batchCopyParseField(
      List<_BatchParseItem> items, _ParseCopyField field) {
    final values = items
        .where((i) => i.video != null)
        .map((i) => field.getValue(i.video!))
        .where((v) => v.isNotEmpty)
        .toList();
    if (values.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('暂无可复制的内容')),
      );
      return;
    }
    Clipboard.setData(ClipboardData(text: values.join('\n')));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('已复制 ${values.length} 条${field.label}')),
    );
  }

  /// 批量解析 - 复制全部字段
  void _batchCopyParseAllFields(List<_BatchParseItem> items) {
    final lines = <String>[];
    for (final item in items) {
      final v = item.video;
      if (v == null) continue;
      lines.add('标题：${v.title}');
      lines.add('作者：${v.author}');
      lines.add('平台：${v.platformName}');
      if (v.videoUrl != null && v.videoUrl!.isNotEmpty) {
        lines.add('视频直链：${v.videoUrl}');
      }
      lines.add('封面：${v.cover}');
      lines.add('原链接：${v.url}');
      if (v.isImage && v.images != null && v.images!.isNotEmpty) {
        lines.add('图片链接：\n${v.images!.join('\n')}');
      }
      lines.add('---');
    }
    if (lines.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('暂无可复制的内容')),
      );
      return;
    }
    Clipboard.setData(ClipboardData(text: lines.join('\n')));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('已复制全部信息')),
    );
  }

  Widget _buildBatchResultItem(_BatchParseItem item) {
    final isSuccess = item.status == 'success';
    final video = item.video;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final successBg = isDark ? Colors.green.shade900.withOpacity(0.2) : Colors.green.shade50;
    final failBg = isDark ? Colors.red.shade900.withOpacity(0.2) : Colors.red.shade50;
    final successBorder = isDark ? Colors.green.shade700 : Colors.green.shade200;
    final failBorder = isDark ? Colors.red.shade700 : Colors.red.shade200;
    final successIcon = isDark ? Colors.green.shade300 : Colors.green;
    final failIcon = isDark ? Colors.red.shade300 : Colors.red;
    final textSecondary = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
    final textPrimary = isDark ? Colors.white : Colors.black87;
    final failErrorText = isDark ? Colors.red.shade300 : Colors.red.shade700;

    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: isSuccess ? successBg : failBg,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: isSuccess ? successBorder : failBorder,
        ),
      ),
      child: Row(
        children: [
          Icon(
            isSuccess ? Icons.check_circle : Icons.error_outline,
            color: isSuccess ? successIcon : failIcon,
            size: 18,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: isSuccess && video != null
                ? Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        video.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                          color: textPrimary,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Row(
                        children: [
                          PlatformBadge(platform: video.platform, size: 12),
                          const SizedBox(width: 4),
                          Text(
                            video.typeName,
                            style: TextStyle(fontSize: 10, color: textSecondary),
                          ),
                          const SizedBox(width: 6),
                          Text(
                            '作者：${video.author}',
                            style: TextStyle(fontSize: 10, color: textSecondary),
                          ),
                        ],
                      ),
                    ],
                  )
                : Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        item.originalUrl,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontSize: 12, color: textPrimary),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        item.error ?? '解析失败',
                        style: TextStyle(fontSize: 10, color: failErrorText),
                      ),
                    ],
                  ),
          ),
          if (isSuccess && video != null)
            IconButton(
              onPressed: () {
                if (video.isImage) {
                  _downloadImages(video);
                } else {
                  final settings = context.read<SettingsProvider>();
                  _downloadVideo(video, settings.defaultQuality);
                }
              },
              icon: const Icon(Icons.download, size: 18),
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
            ),
        ],
      ),
    );
  }

  /// 重试批量解析中失败的项
  Future<void> _retryFailedBatchItems() async {
    final failList = _batchResults.where((r) => r.status == 'failed').toList();
    final originalSuccessCount = _batchResults.where((r) => r.status == 'success').length;
    if (failList.isEmpty) return;

    final failedUrls = failList.map((r) => r.originalUrl).toList();

    setState(() {
      _parsing = true;
      _parsingAction = 'parse';
      _batchCurrent = 0;
      _batchTotal = failedUrls.length;
    });

    final results = <_BatchParseItem>[];
    // 先保留成功的项
    results.addAll(_batchResults.where((r) => r.status == 'success'));

    for (int i = 0; i < failedUrls.length; i++) {
      final url = failedUrls[i];
      setState(() {
        _batchCurrent = i + 1;
      });

      final extractedUrl = _parserService.extractUrl(url);

      if (extractedUrl == null) {
        results.add(_BatchParseItem(
          originalUrl: url,
          status: 'failed',
          error: '未找到有效的视频链接',
        ));
        continue;
      }

      if (_isAuthorProfileUrl(extractedUrl)) {
        results.add(_BatchParseItem(
          originalUrl: url,
          status: 'failed',
          error: '作者主页链接，请查看作者全部作品',
        ));
        continue;
      }

      try {
        final video = await _parserService.parse(extractedUrl);
        try {
          await context.read<HistoryProvider>().addVideo(video);
        } catch (_) {
          try {
            await context.read<HistoryService>().add(video);
          } catch (_) {}
        }
        results.add(_BatchParseItem(
          originalUrl: url,
          status: 'success',
          video: video,
        ));
      } catch (e) {
        results.add(_BatchParseItem(
          originalUrl: url,
          status: 'failed',
          error: e.toString().replaceAll('ParseException: ', ''),
        ));
      }
    }

    if (mounted) {
      setState(() {
        _batchResults = results;
        _parsing = false;
        _parsingAction = null;
      });

      final newSuccessCount =
          results.where((r) => r.status == 'success').length - originalSuccessCount;
      if (newSuccessCount > 0) {
        _showSuccessSnackBar('重试成功：新增 $newSuccessCount 条解析成功');
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('重试完成，仍有失败项')),
        );
      }
    }
  }

  /// 批量下载全部视频
  Future<void> _batchDownloadVideos() async {
    final downloadProvider = context.read<DownloadProvider>();
    final settings = context.read<SettingsProvider>();
    final quality = settings.defaultQuality;
    final hasPermission = await downloadProvider.checkPermission();
    if (!hasPermission) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('需要存储权限才能下载')),
      );
      return;
    }

    var count = 0;
    for (final item in _batchResults) {
      if (item.status == 'success' && item.video != null && item.video!.isVideo) {
        try {
          await downloadProvider.addDownload(item.video!, quality);
          count++;
        } catch (_) {}
      }
    }

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('已添加 $count 个视频到下载队列')),
      );
      setState(() {
        _currentIndex = 4; // 切换到下载页
      });
    }
  }

  /// 批量下载全部图片
  Future<void> _batchDownloadImages() async {
    final downloadProvider = context.read<DownloadProvider>();
    final hasPermission = await downloadProvider.checkPermission();
    if (!hasPermission) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('需要存储权限才能保存图片')),
      );
      return;
    }

    var count = 0;
    for (final item in _batchResults) {
      if (item.status == 'success' && item.video != null && item.video!.isImage) {
        final video = item.video!;
        final images = video.images;
        if (images != null && images.isNotEmpty) {
          for (int i = 0; i < images.length; i++) {
            final imageUrl = images[i];
            final imageTask = VideoInfo(
              id: '${video.id}_img_$i',
              url: imageUrl,
              platform: video.platform,
              title: '${video.title}_${i + 1}',
              author: video.author,
              cover: imageUrl,
              videoUrl: imageUrl,
              parsedAt: DateTime.now(),
              type: 'image',
            );
            try {
              await downloadProvider.addDownload(imageTask, 'original');
              count++;
            } catch (_) {}
          }
        }
      }
    }

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('已添加 $count 张图片到下载队列')),
      );
      setState(() {
        _currentIndex = 4; // 切换到下载页
      });
    }
  }

  /// 批量下载全部（视频+图片）
  Future<void> _batchDownloadAll() async {
    final downloadProvider = context.read<DownloadProvider>();
    final settings = context.read<SettingsProvider>();
    final quality = settings.defaultQuality;
    final hasPermission = await downloadProvider.checkPermission();
    if (!hasPermission) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('需要存储权限才能下载')),
      );
      return;
    }

    var videoCount = 0;
    var imageCount = 0;

    for (final item in _batchResults) {
      if (item.status != 'success' || item.video == null) continue;
      final video = item.video!;
      if (video.isVideo) {
        try {
          await downloadProvider.addDownload(video, quality);
          videoCount++;
        } catch (_) {}
      } else if (video.isImage) {
        final images = video.images;
        if (images != null && images.isNotEmpty) {
          for (int i = 0; i < images.length; i++) {
            final imageUrl = images[i];
            final imageTask = VideoInfo(
              id: '${video.id}_img_$i',
              url: imageUrl,
              platform: video.platform,
              title: '${video.title}_${i + 1}',
              author: video.author,
              cover: imageUrl,
              videoUrl: imageUrl,
              parsedAt: DateTime.now(),
              type: 'image',
            );
            try {
              await downloadProvider.addDownload(imageTask, 'original');
              imageCount++;
            } catch (_) {}
          }
        }
      }
    }

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('已添加 $videoCount 个视频、$imageCount 张图片到下载队列')),
      );
      setState(() {
        _currentIndex = 4; // 切换到下载页
      });
    }
  }
}

/// 批量解析条目
class _BatchParseItem {
  final String originalUrl;
  final String status; // 'success' | 'failed'
  final VideoInfo? video;
  final String? error;

  _BatchParseItem({
    required this.originalUrl,
    required this.status,
    this.video,
    this.error,
  });
}

/// 解析记录复制字段配置
class _ParseCopyField {
  final String key;
  final String label;
  final String Function(VideoInfo video) getValue;

  _ParseCopyField(this.key, this.label, this.getValue);
}

/// 底部导航项配置
class _NavItem {
  final IconData icon;
  final IconData activeIcon;
  final String label;

  const _NavItem({
    required this.icon,
    required this.activeIcon,
    required this.label,
  });
}

class _QuickActionItem {
  final IconData icon;
  final String label;
  final List<Color> gradient;
  final VoidCallback onTap;
  final VoidCallback? onLongPress;

  const _QuickActionItem({
    required this.icon,
    required this.label,
    required this.gradient,
    required this.onTap,
    this.onLongPress,
  });
}

/// 快捷菜单项
class _QuickMenuItem {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _QuickMenuItem({
    required this.icon,
    required this.label,
    required this.onTap,
  });
}

/// 资源看板网格项
class _StatGridItem {
  final IconData icon;
  final String label;
  final String value;
  final List<Color> gradient;

  const _StatGridItem({
    required this.icon,
    required this.label,
    required this.value,
    required this.gradient,
  });
}
