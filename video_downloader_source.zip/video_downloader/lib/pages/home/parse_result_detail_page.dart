import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:provider/provider.dart';
import '../../models/video_info.dart';
import '../../theme/app_theme.dart';
import '../../widgets/platform_badge.dart';
import '../../widgets/gradient_button.dart';
import '../../providers/history_provider.dart';
import '../../providers/download_provider.dart';
import '../../providers/settings_provider.dart';

/// 解析结果详情页
///
/// 集中展示完整的解析结果信息，包括封面、标题、作者、
/// 平台信息、图集图片、操作按钮等。
/// 支持左右滑动切换历史记录。
class ParseResultDetailPage extends StatefulWidget {
  final VideoInfo video;

  const ParseResultDetailPage({
    super.key,
    required this.video,
  });

  @override
  State<ParseResultDetailPage> createState() => _ParseResultDetailPageState();
}

class _ParseResultDetailPageState extends State<ParseResultDetailPage> {
  late PageController _pageController;
  int _currentIndex = 0;
  List<VideoInfo> _videos = [];
  bool _initialized = false;

  VideoInfo get video {
    if (_videos.isEmpty || _currentIndex >= _videos.length) {
      return widget.video;
    }
    return _videos[_currentIndex];
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _initPageView();
    });
  }

  void _initPageView() {
    final historyProvider = context.read<HistoryProvider>();
    final allVideos = historyProvider.videos;

    if (allVideos.isEmpty) {
      _videos = [widget.video];
      _currentIndex = 0;
    } else {
      // 找到当前 video 在历史记录中的位置
      final index = allVideos.indexWhere((v) => v.id == widget.video.id);
      if (index == -1) {
        // 如果不在历史记录中，把它放在第一个位置
        _videos = [widget.video, ...allVideos];
        _currentIndex = 0;
      } else {
        _videos = allVideos;
        _currentIndex = index;
      }
    }

    _pageController = PageController(initialPage: _currentIndex);
    setState(() {
      _initialized = true;
    });
  }

  @override
  void dispose() {
    if (_initialized) {
      _pageController.dispose();
    }
    super.dispose();
  }

  /// 格式化日期时间
  String _formatDateTime(DateTime dt) {
    final y = dt.year.toString().padLeft(4, '0');
    final m = dt.month.toString().padLeft(2, '0');
    final d = dt.day.toString().padLeft(2, '0');
    final h = dt.hour.toString().padLeft(2, '0');
    final min = dt.minute.toString().padLeft(2, '0');
    return '$y-$m-$d $h:$min';
  }

  /// 复制到剪贴板
  Future<void> _copyToClipboard(String text, String label) async {
    await Clipboard.setData(ClipboardData(text: text));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('$label已复制'),
          duration: const Duration(seconds: 2),
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  /// 在浏览器中打开
  Future<void> _openInBrowser(String? url) async {
    if (url == null || url.isEmpty) return;
    final uri = Uri.tryParse(url);
    if (uri != null && await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  /// 分享
  Future<void> _share() async {
    final text = '${video.title}\n${video.url}';
    await Share.share(text, subject: video.title);
  }

  /// 下载视频
  Future<void> _downloadVideo(String quality) async {
    final downloadProvider = context.read<DownloadProvider>();
    final hasPermission = await downloadProvider.checkPermission();
    if (!hasPermission) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('存储权限未授予，无法下载')),
        );
      }
      return;
    }
    await downloadProvider.addDownload(video, quality);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('已添加到下载队列'), behavior: SnackBarBehavior.floating),
      );
      Navigator.of(context).pop();
    }
  }

  /// 下载封面图
  Future<void> _downloadCover() async {
    final downloadProvider = context.read<DownloadProvider>();
    final hasPermission = await downloadProvider.checkPermission();
    if (!hasPermission) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('存储权限未授予，无法下载')),
        );
      }
      return;
    }
    // 创建一个特殊的封面下载任务
    final coverVideo = video.copyWith(
      videoUrl: video.cover,
      type: 'image',
      images: [video.cover],
      title: '${video.title}_封面',
    );
    await downloadProvider.addDownload(coverVideo, 'original');
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('封面下载已开始'), behavior: SnackBarBehavior.floating),
      );
      Navigator.of(context).pop();
    }
  }

  /// 下载音频
  Future<void> _downloadAudio(String quality) async {
    final downloadProvider = context.read<DownloadProvider>();
    final settings = context.read<SettingsProvider>();
    final hasPermission = await downloadProvider.checkPermission();
    if (!hasPermission) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('存储权限未授予，无法下载')),
        );
      }
      return;
    }
    await downloadProvider.addAudioDownload(
      video,
      quality,
      audioFormat: settings.defaultAudioFormat,
    );
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('已添加到下载队列'), behavior: SnackBarBehavior.floating),
      );
      Navigator.of(context).pop();
    }
  }

  /// 下载全部图片
  Future<void> _downloadImages() async {
    final downloadProvider = context.read<DownloadProvider>();
    final hasPermission = await downloadProvider.checkPermission();
    if (!hasPermission) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('存储权限未授予，无法下载')),
        );
      }
      return;
    }
    await downloadProvider.addDownload(video, 'original');
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('已添加到下载队列'), behavior: SnackBarBehavior.floating),
      );
      Navigator.of(context).pop();
    }
  }

  /// 切换收藏
  void _toggleFavorite() {
    final historyProvider = context.read<HistoryProvider>();
    historyProvider.toggleFavorite(video.id);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    if (!_initialized) {
      // 未初始化时显示加载状态
      return Scaffold(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        body: const Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    final isDark = AppTheme.isDark(context);
    final textPrimary = AppTheme.textPrimaryColor(context);
    final textSecondary = AppTheme.textSecondaryColor(context);
    final platformPrimary = AppTheme.platformPrimaryColor(video.platform);
    final platformGrad = AppTheme.platformGradient(video.platform);
    final isImage = video.isImage;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: PageView.builder(
        controller: _pageController,
        onPageChanged: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        itemCount: _videos.length,
        itemBuilder: (context, index) {
          final pageVideo = _videos[index];
          return _buildDetailPage(pageVideo, isDark, textPrimary, textSecondary);
        },
      ),
      // 底部操作栏
      bottomNavigationBar: _buildBottomActionBar(
          platformGrad, platformPrimary, textPrimary, textSecondary, isImage),
    );
  }

  /// 构建单个详情页内容
  Widget _buildDetailPage(
    VideoInfo pageVideo,
    bool isDark,
    Color textPrimary,
    Color textSecondary,
  ) {
    final platformPrimary = AppTheme.platformPrimaryColor(pageVideo.platform);
    final scrollController = ScrollController();

    return CustomScrollView(
      controller: scrollController,
      slivers: [
        // ===== 顶部封面图 + SliverAppBar =====
        SliverAppBar(
          expandedHeight: 280,
          pinned: true,
          stretch: true,
          backgroundColor: Theme.of(context).scaffoldBackgroundColor,
          systemOverlayStyle: isDark
              ? SystemUiOverlayStyle.light
              : SystemUiOverlayStyle.dark,
          leading: Padding(
            padding: const EdgeInsets.all(8),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.4),
                shape: BoxShape.circle,
              ),
              child: IconButton(
                icon: const Icon(Icons.arrow_back, color: Colors.white),
                onPressed: () => Navigator.of(context).pop(),
                iconSize: 22,
                padding: EdgeInsets.zero,
              ),
            ),
          ),
          actions: [
            Padding(
              padding: const EdgeInsets.all(8),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.4),
                  shape: BoxShape.circle,
                ),
                child: Consumer<HistoryProvider>(
                  builder: (context, historyProvider, child) {
                    final isFavorite = historyProvider.isFavorite(pageVideo.id);
                    return IconButton(
                      icon: Icon(
                        isFavorite ? Icons.favorite : Icons.favorite_border,
                        color: isFavorite ? Colors.red.shade400 : Colors.white,
                      ),
                      onPressed: () {
                        historyProvider.toggleFavorite(pageVideo.id);
                        setState(() {});
                      },
                      iconSize: 22,
                      padding: EdgeInsets.zero,
                    );
                  },
                ),
              ),
            ),
            const SizedBox(width: 4),
          ],
          flexibleSpace: FlexibleSpaceBar(
            stretchModes: const [
              StretchMode.zoomBackground,
              StretchMode.blurBackground,
            ],
            background: Stack(
              fit: StackFit.expand,
              children: [
                // 封面图
                pageVideo.cover.isNotEmpty
                    ? Image.network(
                        pageVideo.cover,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          color: platformPrimary.withOpacity(0.3),
                          child: Center(
                            child: PlatformBadge(platform: pageVideo.platform, size: 60),
                          ),
                        ),
                      )
                    : Container(
                        color: platformPrimary.withOpacity(0.3),
                        child: Center(
                          child: PlatformBadge(platform: pageVideo.platform, size: 60),
                        ),
                      ),
                // 渐变遮罩
                DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.black.withOpacity(0.3),
                        Colors.transparent,
                        Colors.black.withOpacity(0.6),
                      ],
                      stops: const [0.0, 0.4, 1.0],
                    ),
                  ),
                ),
                // 底部信息
                Positioned(
                  left: 20,
                  right: 20,
                  bottom: 20,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: platformPrimary.withOpacity(0.9),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.check_circle,
                                    color: Colors.white, size: 14),
                                const SizedBox(width: 4),
                                Text(
                                  '解析成功',
                                  style: TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w700,
                                    color: Colors.white,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              color: pageVideo.isImage
                                  ? Colors.purple.withOpacity(0.8)
                                  : Colors.blue.withOpacity(0.8),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  pageVideo.isImage ? Icons.image : Icons.ondemand_video,
                                  size: 11,
                                  color: Colors.white,
                                ),
                                const SizedBox(width: 3),
                                Text(
                                  pageVideo.isImage
                                      ? '${pageVideo.typeName} · ${pageVideo.imageCount}张'
                                      : pageVideo.typeName,
                                  style: TextStyle(
                                    fontSize: 10,
                                    color: Colors.white,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),

        // ===== 内容区域 =====
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 100),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // 标题
                Text(
                  pageVideo.title,
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    height: 1.3,
                    color: textPrimary,
                  ),
                ),
                const SizedBox(height: 16),

                // 作者信息卡片
                _buildAuthorCard(pageVideo, textPrimary, textSecondary),
                const SizedBox(height: 20),

                // 平台与时间信息
                _buildInfoRow(pageVideo, textPrimary, textSecondary),
                const SizedBox(height: 20),

                // 视频描述/文案
                _buildDescriptionSection(pageVideo, textPrimary, textSecondary),
                const SizedBox(height: 20),

                // 图集图片网格（图文类型）
                if (pageVideo.isImage && pageVideo.images != null && pageVideo.images!.isNotEmpty) ...[
                  _buildImagesGrid(pageVideo, textPrimary, textSecondary),
                  const SizedBox(height: 20),
                ],

                // 统计信息
                _buildStatsSection(pageVideo, textPrimary, textSecondary),
              ],
            ),
          ),
        ),
      ],
    );
  }

  /// 作者信息卡片
  Widget _buildAuthorCard(VideoInfo pageVideo, Color textPrimary, Color textSecondary) {
    final isDark = AppTheme.isDark(context);
    final borderColor = isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0);
    final cardBg = AppTheme.cardBg(context);

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderColor, width: 0.5),
        boxShadow: AppTheme.shadowSm,
      ),
      child: Row(
        children: [
          // 作者头像（首字母占位）
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              gradient: AppTheme.platformGradient(pageVideo.platform),
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                pageVideo.author.isNotEmpty ? pageVideo.author[0] : '?',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  pageVideo.author,
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: textPrimary,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  '${pageVideo.platformName} · 创作者',
                  style: TextStyle(
                    fontSize: 12,
                    color: textSecondary,
                  ),
                ),
              ],
            ),
          ),
          PlatformBadge(platform: pageVideo.platform, size: 24),
        ],
      ),
    );
  }

  /// 信息行：平台标签 + 解析时间
  Widget _buildInfoRow(VideoInfo pageVideo, Color textPrimary, Color textSecondary) {
    final isDark = AppTheme.isDark(context);
    final borderColor = isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0);
    final cardBg = AppTheme.cardBg(context);

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderColor, width: 0.5),
        boxShadow: AppTheme.shadowSm,
      ),
      child: Column(
        children: [
          _buildInfoItem(
            icon: Icons.label_outline,
            label: '来源平台',
            value: pageVideo.platformName,
            textPrimary: textPrimary,
            textSecondary: textSecondary,
            trailing: PlatformBadge(platform: pageVideo.platform, size: 20),
          ),
          const Divider(height: 16, thickness: 0.5),
          _buildInfoItem(
            icon: Icons.schedule,
            label: '解析时间',
            value: _formatDateTime(pageVideo.parsedAt),
            textPrimary: textPrimary,
            textSecondary: textSecondary,
          ),
          const Divider(height: 16, thickness: 0.5),
          _buildInfoItem(
            icon: Icons.link,
            label: '原始链接',
            value: pageVideo.url,
            textPrimary: textPrimary,
            textSecondary: textSecondary,
            maxLines: 1,
            onTap: () => _copyToClipboard(pageVideo.url, '链接'),
          ),
        ],
      ),
    );
  }

  /// 单个信息项
  Widget _buildInfoItem({
    required IconData icon,
    required String label,
    required String value,
    required Color textPrimary,
    required Color textSecondary,
    Widget? trailing,
    int maxLines = 1,
    VoidCallback? onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(
          children: [
            Icon(icon, size: 18, color: textSecondary),
            const SizedBox(width: 10),
            Text(
              label,
              style: TextStyle(
                fontSize: 13,
                color: textSecondary,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                value,
                maxLines: maxLines,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.right,
                style: TextStyle(
                  fontSize: 13,
                  color: textPrimary,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
            if (trailing != null) ...[
              const SizedBox(width: 8),
              trailing,
            ],
          ],
        ),
      ),
    );
  }

  /// 视频描述/文案部分
  Widget _buildDescriptionSection(VideoInfo pageVideo, Color textPrimary, Color textSecondary) {
    final isDark = AppTheme.isDark(context);
    final borderColor = isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0);
    final cardBg = AppTheme.cardBg(context);

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderColor, width: 0.5),
        boxShadow: AppTheme.shadowSm,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.article_outlined, size: 18, color: textSecondary),
              const SizedBox(width: 8),
              Text(
                '作品文案',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: textPrimary,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            pageVideo.title,
            style: TextStyle(
              fontSize: 14,
              height: 1.6,
              color: textPrimary,
            ),
          ),
        ],
      ),
    );
  }

  /// 图集图片网格
  Widget _buildImagesGrid(VideoInfo pageVideo, Color textPrimary, Color textSecondary) {
    final isDark = AppTheme.isDark(context);
    final borderColor = isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0);
    final cardBg = AppTheme.cardBg(context);
    final images = pageVideo.images!;

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderColor, width: 0.5),
        boxShadow: AppTheme.shadowSm,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.photo_library_outlined, size: 18, color: textSecondary),
              const SizedBox(width: 8),
              Text(
                '图集图片（共${images.length}张）',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: textPrimary,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              crossAxisSpacing: 8,
              mainAxisSpacing: 8,
              childAspectRatio: 1,
            ),
            itemCount: images.length,
            itemBuilder: (context, index) {
              final imgUrl = images[index];
              return ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: GestureDetector(
                  onTap: () => _openInBrowser(imgUrl),
                  child: Image.network(
                    imgUrl,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(
                      color: Colors.grey.shade300,
                      child: const Icon(Icons.broken_image,
                          color: Colors.grey, size: 30),
                    ),
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  /// 统计信息
  Widget _buildStatsSection(VideoInfo pageVideo, Color textPrimary, Color textSecondary) {
    final isDark = AppTheme.isDark(context);
    final borderColor = isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0);
    final cardBg = AppTheme.cardBg(context);
    final platformPrimary = AppTheme.platformPrimaryColor(pageVideo.platform);

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderColor, width: 0.5),
        boxShadow: AppTheme.shadowSm,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.bar_chart_outlined, size: 18, color: textSecondary),
              const SizedBox(width: 8),
              Text(
                '互动数据',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: textPrimary,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _buildStatItem(
                icon: Icons.thumb_up_outlined,
                label: '点赞',
                value: '-',
                color: platformPrimary,
              ),
              _buildStatItem(
                icon: Icons.chat_bubble_outline,
                label: '评论',
                value: '-',
                color: Colors.blue,
              ),
              _buildStatItem(
                icon: Icons.share_outlined,
                label: '分享',
                value: '-',
                color: Colors.green,
              ),
              _buildStatItem(
                icon: Icons.bookmark_border,
                label: '收藏',
                value: '-',
                color: Colors.orange,
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            '注：部分平台暂不支持获取详细互动数据',
            style: TextStyle(
              fontSize: 11,
              color: textSecondary.withOpacity(0.7),
            ),
          ),
        ],
      ),
    );
  }

  /// 单个统计项
  Widget _buildStatItem({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return Expanded(
      child: Column(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, size: 18, color: color),
          ),
          const SizedBox(height: 6),
          Text(
            value,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w700,
              color: color,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: TextStyle(
              fontSize: 11,
              color: AppTheme.textSecondaryColor(context),
            ),
          ),
        ],
      ),
    );
  }

  /// 底部操作栏
  Widget _buildBottomActionBar(
    LinearGradient platformGrad,
    Color platformPrimary,
    Color textPrimary,
    Color textSecondary,
    bool isImage,
  ) {
    final isDark = AppTheme.isDark(context);
    final borderColor = isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0);

    return Container(
      padding: EdgeInsets.fromLTRB(
        16,
        10,
        16,
        10 + MediaQuery.of(context).padding.bottom,
      ),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        border: Border(
          top: BorderSide(color: borderColor, width: 0.5),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 10,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Consumer<SettingsProvider>(
          builder: (context, settings, child) {
            final defaultQuality = settings.defaultQuality;
            final hasHd = video.videoUrlHd != null;
            final mainQuality =
                (defaultQuality == 'hd' && hasHd) ? 'hd' : 'original';
            final mainLabel = mainQuality == 'hd' ? '高清下载' : '原画下载';

            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // 主下载按钮
                SizedBox(
                  width: double.infinity,
                  child: GradientButton(
                    text: isImage ? '保存全部图片' : '$mainLabel · 保存到相册',
                    icon: Icons.download_for_offline,
                    height: 48,
                    gradient: platformGrad,
                    shadowColor: platformPrimary,
                    onPressed: () => isImage
                        ? _downloadImages()
                        : _downloadVideo(mainQuality),
                  ),
                ),
                const SizedBox(height: 10),
                // 次要操作按钮
                Row(
                  children: [
                    _buildActionButton(
                      icon: Icons.copy,
                      label: '复制链接',
                      color: textSecondary,
                      onTap: () => _copyToClipboard(
                        isImage
                            ? (video.images?.first ?? video.url)
                            : (video.videoUrl ?? video.url),
                        '链接',
                      ),
                    ),
                    _buildActionButton(
                      icon: Icons.share,
                      label: '分享',
                      color: textSecondary,
                      onTap: _share,
                    ),
                    _buildActionButton(
                      icon: Icons.open_in_new,
                      label: '浏览器打开',
                      color: textSecondary,
                      onTap: () => _openInBrowser(
                        isImage
                            ? (video.images?.first)
                            : video.videoUrl,
                      ),
                    ),
                    if (!isImage && video.cover.isNotEmpty)
                      _buildActionButton(
                        icon: Icons.image_outlined,
                        label: '下载封面',
                        color: textSecondary,
                        onTap: _downloadCover,
                      ),
                  ],
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  /// 底部操作按钮
  Widget _buildActionButton({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(8),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(icon, size: 20, color: color),
                const SizedBox(height: 4),
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 11,
                    color: color,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
