import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'dart:convert';
import 'dart:io';
import 'package:excel/excel.dart' as excel;
import 'package:intl/intl.dart';
import 'package:cross_file/cross_file.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:open_filex/open_filex.dart';
import 'package:file_picker/file_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../models/api_source.dart';
import '../../models/crawl_record.dart';
import '../../models/crawl_checkpoint.dart';
import '../../models/top10_works_result.dart';
import '../../providers/settings_provider.dart';
import '../../providers/crawl_history_provider.dart';
import '../../services/crawl_history_service.dart';
import '../../services/crawl_checkpoint_service.dart';
import '../../services/crawl_service.dart';
import '../../services/parser/parser_service.dart';
import '../../services/proxy_service.dart';
import '../../services/haptic_service.dart';
import '../../utils/platform_detector.dart';
import '../../theme/app_theme.dart';
import '../../widgets/gradient_button.dart';
import '../../widgets/link_input_card.dart';
import '../../widgets/platform_badge.dart';
import '../../widgets/empty_state.dart';
import '../../widgets/skeleton.dart';
import '../../widgets/slide_action_item.dart';

/// 抓取页面
class CrawlPage extends StatefulWidget {
  const CrawlPage({super.key});

  @override
  State<CrawlPage> createState() => _CrawlPageState();
}

class _CrawlPageState extends State<CrawlPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final TextEditingController _authorUrlController = TextEditingController();
  final TextEditingController _videoUrlController = TextEditingController();
  final TextEditingController _top10UrlController = TextEditingController();
  late final CrawlService _crawlService;

  CrawlRecord? _authorResult;
  CrawlRecord? _videoResult;
  String? _authorError;
  String? _videoError;
  bool _authorCrawling = false;
  bool _videoCrawling = false;

  /// 前10作品模式的结果
  Top10WorksResult? _top10Result;
  bool _top10Crawling = false;
  String? _top10Error;

  /// 前10作品抓取进度提示（来自 CrawlService 状态回调）
  String? _top10Status;

  /// 前10作品列表中展开的项
  final Set<String> _expandedTop10Works = {};

  /// 收藏动画状态（抓取结果卡片双击收藏动画）
  String? _favoriteAnimatingId;

  // 批量抓取结果（作者/视频各自独立，默认即支持批量解析）
  List<_BatchCrawlItem> _authorBatchResults = [];
  List<_BatchCrawlItem> _videoBatchResults = [];
  int _authorBatchCurrent = 0;
  int _videoBatchCurrent = 0;
  int _authorBatchTotal = 0;
  int _videoBatchTotal = 0;

  // 断点续传：未完成的批次进度（作者/视频各自独立）
  CrawlRecord? _authorBatchProgress;
  CrawlRecord? _videoBatchProgress;
  String? _currentBatchId;

  // 抓取速度和时间统计
  DateTime? _crawlStartTime;
  double _crawlSpeed = 0; // 条/秒
  int _crawlRemainingSeconds = 0; // 剩余秒数

  // 根据 tab 获取对应 controller/状态的辅助方法
  TextEditingController _urlControllerOf(bool isAuthor) =>
      isAuthor ? _authorUrlController : _videoUrlController;
  List<_BatchCrawlItem> _batchResultsOf(bool isAuthor) =>
      isAuthor ? _authorBatchResults : _videoBatchResults;
  int _batchCurrentOf(bool isAuthor) =>
      isAuthor ? _authorBatchCurrent : _videoBatchCurrent;
  int _batchTotalOf(bool isAuthor) =>
      isAuthor ? _authorBatchTotal : _videoBatchTotal;

  CrawlRecord? _batchProgressOf(bool isAuthor) =>
      isAuthor ? _authorBatchProgress : _videoBatchProgress;

  bool _hasIncompleteBatch(bool isAuthor) =>
      _batchProgressOf(isAuthor) != null &&
      _batchProgressOf(isAuthor)!.isBatchInProgress;

  // 单条结果/错误/加载状态的 tab 对应辅助方法
  CrawlRecord? _resultOf(bool isAuthor) =>
      isAuthor ? _authorResult : _videoResult;
  String? _errorOf(bool isAuthor) =>
      isAuthor ? _authorError : _videoError;
  bool _crawlingOf(bool isAuthor) =>
      isAuthor ? _authorCrawling : _videoCrawling;

  void _setResult(bool isAuthor, CrawlRecord? value) {
    if (isAuthor) {
      _authorResult = value;
    } else {
      _videoResult = value;
    }
  }

  void _setError(bool isAuthor, String? value) {
    if (isAuthor) {
      _authorError = value;
    } else {
      _videoError = value;
    }
  }

  void _setCrawling(bool isAuthor, bool value) {
    if (isAuthor) {
      _authorCrawling = value;
    } else {
      _videoCrawling = value;
    }
  }

  // 历史记录中展开的批次
  final Set<String> _expandedHistoryBatches = {};

  // 抓取源：'builtIn' 或 跟设置一致的第三方源
  bool _useBuiltIn = true;

  // ==================== 增量抓取与断点续传（作者视频） ====================

  /// 增量模式开关（作者抓取时使用）
  bool _incrementalMode = false;

  /// 当前输入链接对应的作者检查点（用于判断是否显示增量提示）
  CrawlCheckpoint? _currentAuthorCheckpoint;

  /// 增量抓取的视频结果列表
  List<CrawlRecord> _incrementalVideos = [];

  /// 增量抓取是否还有更多视频
  bool _incrementalHasMore = false;

  /// 增量抓取下一页游标
  String? _incrementalNextCursor;

  /// 是否正在加载更多增量视频
  bool _loadingMoreIncremental = false;

  // 选中的字段（按平台分别保存）
  String _selectedPlatform = 'douyin';
  final Map<String, Set<String>> _selectedAuthorFieldsByPlatform = {};
  final Map<String, Set<String>> _selectedVideoFieldsByPlatform = {};

  /// 获取当前平台的作者选中字段
  Set<String> get _currentAuthorFields =>
      _selectedAuthorFieldsByPlatform[_selectedPlatform] ??
      CrawlFieldConfigs.getDefaultSelectedKeys(_selectedPlatform, isAuthor: true);

  /// 获取当前平台的视频选中字段
  Set<String> get _currentVideoFields =>
      _selectedVideoFieldsByPlatform[_selectedPlatform] ??
      CrawlFieldConfigs.getDefaultSelectedKeys(_selectedPlatform, isAuthor: false);

  /// 支持的平台列表
  static const List<Map<String, String>> _platforms = [
    {'id': 'douyin', 'name': '抖音', 'icon': '🎵'},
    {'id': 'kuaishou', 'name': '快手', 'icon': '⚡'},
    {'id': 'xiaohongshu', 'name': '小红书', 'icon': '📕'},
  ];

  // ==================== 主题颜色辅助方法 ====================

  bool get _isDark => Theme.of(context).brightness == Brightness.dark;

  Color get _textColor => _isDark ? Colors.white : Colors.black87;
  Color get _secondaryTextColor =>
      _isDark ? Colors.grey.shade400 : Colors.grey.shade600;
  Color get _mutedTextColor =>
      _isDark ? Colors.grey.shade500 : Colors.grey.shade500;
  Color get _borderColor =>
      _isDark ? Colors.grey.shade700 : Colors.grey.shade300;
  Color get _fillColor =>
      _isDark ? const Color(0xFF0F172A) : Colors.grey.shade50;
  Color get _dividerColor =>
      _isDark ? Colors.grey.shade800 : Colors.grey.shade200;
  Color get _cardBgColor => Theme.of(context).cardColor;

  List<BoxShadow> get _cardShadow => _isDark
      ? const <BoxShadow>[]
      : [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    // 初始化各平台默认选中字段
    for (final p in _platforms) {
      final pid = p['id']!;
      _selectedAuthorFieldsByPlatform[pid] =
          CrawlFieldConfigs.getDefaultSelectedKeys(pid, isAuthor: true);
      _selectedVideoFieldsByPlatform[pid] =
          CrawlFieldConfigs.getDefaultSelectedKeys(pid, isAuthor: false);
    }
    WidgetsBinding.instance.addPostFrameCallback((_) {
      // 使用共享的 ParserService（已连接统计）初始化 CrawlService
      _crawlService = CrawlService(
        parserService: context.read<ParserService>(),
      );
      _syncCrawlService();
      // 设置代理服务
      _crawlService.setProxyService(context.read<ProxyService>());
      context.read<SettingsProvider>().addListener(_syncCrawlService);
      context.read<CrawlHistoryProvider>().loadHistory().then((_) {
        _loadBatchProgress();
      });
    });
  }

  /// 加载未完成的批次进度（用于断点续传）
  void _loadBatchProgress() {
    try {
      final service = context.read<CrawlHistoryService>();
      final authorProgress = service.getIncompleteAuthorBatchProgress();
      final videoProgress = service.getIncompleteVideoBatchProgress();
      if (mounted) {
        setState(() {
          _authorBatchProgress = authorProgress;
          _videoBatchProgress = videoProgress;
        });
      }
    } catch (_) {
      // 加载失败静默处理，不影响主流程
    }
  }

  @override
  void dispose() {
    _crawlService.onCrawlStatus = null;
    _tabController.dispose();
    _authorUrlController.dispose();
    _videoUrlController.dispose();
    _top10UrlController.dispose();
    try {
      context.read<SettingsProvider>().removeListener(_syncCrawlService);
    } catch (_) {}
    super.dispose();
  }

  /// 同步抓取服务的数据源 + UID 补全服务 + Cookie。
  /// 尊重用户在抓取页的源选择：选了内置解析器时，设置变化不覆盖该选择
  void _syncCrawlService() {
    final settings = context.read<SettingsProvider>();
    // 同步 UID 补全服务 URL
    _crawlService.setUidResolveService(settings.uidResolveServiceUrl);
    // 同步抖音 Cookie
    _crawlService.setDouyinCookies(settings.douyinCookies);
    // 同步抓取间隔和抖动
    _crawlService.setCrawlInterval(settings.crawlIntervalMs);
    _crawlService.setCrawlJitter(settings.crawlJitterMs);
    // 同步抓取重试次数
    _crawlService.setCrawlRetryCount(settings.crawlRetryCount);

    if (_useBuiltIn) {
      _crawlService.setApiSource(ApiSource.builtIn);
      return;
    }
    final source = ApiSource.fromId(settings.apiSourceId) ?? ApiSource.builtIn;
    _crawlService.setApiSource(
      source,
      apiKey: settings.getApiKey(source.id),
      customUrl: source.id == 'custom' ? settings.customApiUrl : null,
    );
  }

  ApiSource get _currentSettingSource {
    final settings = context.read<SettingsProvider>();
    return ApiSource.fromId(settings.apiSourceId) ?? ApiSource.builtIn;
  }

  bool get _hasThirdPartyConfigured => !_currentSettingSource.isBuiltIn;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // 顶部标题栏
        Container(
          decoration: BoxDecoration(gradient: AppTheme.primaryGradient),
          child: SafeArea(
            bottom: false,
            child: Column(
              children: [
                const SizedBox(height: 12),
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      Icon(Icons.search, color: Colors.white, size: 22),
                      SizedBox(width: 8),
                      Text(
                        '数据抓取',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                // 平台选择器
                _buildPlatformSelector(),
                const SizedBox(height: 8),
                TabBar(
                  controller: _tabController,
                  labelColor: Colors.white,
                  unselectedLabelColor: Colors.white60,
                  indicatorColor: Colors.white,
                  indicatorSize: TabBarIndicatorSize.label,
                  labelStyle:
                      const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
                  tabs: const [
                    Tab(text: '作者信息'),
                    Tab(text: '前10作品'),
                    Tab(text: '视频信息'),
                  ],
                ),
              ],
            ),
          ),
        ),
        Expanded(
          child: TabBarView(
            controller: _tabController,
            children: [
              _buildCrawlContent(isAuthor: true),
              _buildTop10Content(),
              _buildCrawlContent(isAuthor: false),
            ],
          ),
        ),
      ],
    );
  }

  // ==================== 平台选择器 ====================

  Widget _buildPlatformSelector() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: _platforms.map((p) {
          final isSelected = _selectedPlatform == p['id'];
          return Expanded(
            child: GestureDetector(
              onTap: () {
                setState(() {
                  _selectedPlatform = p['id']!;
                  // 切换平台时清空作者和视频两个Tab的结果
                  _setResult(true, null);
                  _setResult(false, null);
                  _setError(true, null);
                  _setError(false, null);
                });
              },
              child: Container(
                margin: EdgeInsets.only(
                  left: p['id'] == _platforms.first['id'] ? 0 : 4,
                  right: p['id'] == _platforms.last['id'] ? 0 : 4,
                ),
                padding: const EdgeInsets.symmetric(vertical: 8),
                decoration: BoxDecoration(
                  gradient: isSelected
                      ? const LinearGradient(
                          colors: [Colors.white, Colors.white70],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        )
                      : null,
                  color: isSelected ? null : Colors.white.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(p['icon']!, style: const TextStyle(fontSize: 14)),
                    const SizedBox(width: 4),
                    Text(
                      p['name']!,
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: isSelected
                            ? AppTheme.primaryColor
                            : Colors.white.withOpacity(0.8),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildCrawlContent({required bool isAuthor}) {
    final batchResults = _batchResultsOf(isAuthor);
    // 键盘适配：底部添加键盘高度间距，确保输入框不被遮挡
    final keyboardHeight = MediaQuery.of(context).viewInsets.bottom;
    return RefreshIndicator(
      onRefresh: () async {
        await context.read<CrawlHistoryProvider>().loadHistory();
        _loadBatchProgress();
      },
      child: SingleChildScrollView(
        padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + keyboardHeight),
        physics: const ClampingScrollPhysics(),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildSourceSelector(),
            const SizedBox(height: 12),
            _buildInputCard(isAuthor: isAuthor),
            const SizedBox(height: 16),
            // 有批量结果（多条）则显示批量结果卡片；否则按单条结果/错误展示
            if (batchResults.isNotEmpty) ...[
              _buildBatchResultCard(isAuthor: isAuthor),
            ] else ...[
              if (_errorOf(isAuthor) != null) _buildErrorCard(_errorOf(isAuthor)!),
              if (_resultOf(isAuthor) != null) _buildResultCard(_resultOf(isAuthor)!),
            ],
            const SizedBox(height: 20),
            _buildHistorySection(isAuthor: isAuthor),
          ],
        ),
      ),
    );
  }

  // ==================== 抓取源选择器 ====================

  Widget _buildSourceSelector() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: _cardBgColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _borderColor),
      ),
      child: Row(
        children: [
          Icon(Icons.power_outlined, size: 18, color: _secondaryTextColor),
          const SizedBox(width: 8),
          Text(
            '抓取源',
            style: TextStyle(fontSize: 13, color: _secondaryTextColor),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: PopupMenuButton<String>(
              onSelected: (val) {
                setState(() {
                  _useBuiltIn = val == 'builtIn';
                  // 切换抓取源时清空作者和视频两个Tab的结果
                  _setResult(true, null);
                  _setResult(false, null);
                  _setError(true, null);
                  _setError(false, null);
                });
                // 更新服务
                if (_useBuiltIn) {
                  _crawlService.setApiSource(ApiSource.builtIn);
                } else {
                  _syncCrawlService();
                }
              },
              itemBuilder: (context) => [
                PopupMenuItem(
                  value: 'builtIn',
                  child: Row(
                    children: [
                      const Icon(Icons.code, size: 18, color: Colors.blue),
                      const SizedBox(width: 8),
                      const Expanded(child: Text('内置解析器')),
                      Text('基础抓取',
                          style: TextStyle(fontSize: 11, color: _secondaryTextColor)),
                    ],
                  ),
                ),
                PopupMenuItem(
                  value: 'thirdParty',
                  enabled: _hasThirdPartyConfigured,
                  child: Row(
                    children: [
                      const Icon(Icons.cloud_outlined,
                          size: 18, color: Colors.green),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          _hasThirdPartyConfigured
                              ? _currentSettingSource.name
                              : '未配置第三方',
                        ),
                      ),
                      Text('完整数据',
                          style: TextStyle(fontSize: 11, color: _secondaryTextColor)),
                    ],
                  ),
                ),
              ],
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    _useBuiltIn ? '内置解析器' : _currentSettingSource.name,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: AppTheme.primaryColor,
                    ),
                  ),
                  const SizedBox(width: 4),
                  Icon(Icons.arrow_drop_down,
                      color: AppTheme.primaryColor, size: 20),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== 输入区域 ====================

  Widget _buildInputCard({required bool isAuthor}) {
    final controller = _urlControllerOf(isAuthor);
    final batchCurrent = _batchCurrentOf(isAuthor);
    final batchTotal = _batchTotalOf(isAuthor);
    return LinkInputCard(
      controller: controller,
      title: isAuthor ? '作者抓取' : '视频抓取',
      titleIcon: isAuthor ? Icons.person_search : Icons.video_library,
      hintText: '每行一条链接，支持批量抓取',
      showPasteButton: true,
      onChanged: isAuthor
          ? (text) {
              // 作者抓取时，输入单条链接时检测检查点
              final lines = text.split('\n').where((l) => l.trim().isNotEmpty).toList();
              if (lines.length == 1) {
                _checkAuthorCheckpoint(lines.first);
              } else {
                setState(() => _currentAuthorCheckpoint = null);
              }
            }
          : null,
      actions: [
        LinkInputAction(
          id: 'crawl',
          label: '开始抓取',
          icon: Icons.search,
          isPrimary: true,
          onTap: (urls) => _doCrawlSmart(isAuthor: isAuthor, urls: urls),
        ),
      ],
      loadingActionId: _crawlingOf(isAuthor) ? 'crawl' : null,
      loadingProgressText:
          _crawlingOf(isAuthor) && batchTotal > 1 ? '$batchCurrent/$batchTotal' : null,
      child: Column(
        children: [
          // 平台提示
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Row(
              children: [
                Icon(Icons.info_outline, size: 14, color: _mutedTextColor),
                const SizedBox(width: 6),
                Text(
                  '当前平台：${_platforms.firstWhere((p) => p['id'] == _selectedPlatform)['name']}，请输入对应平台的链接',
                  style: TextStyle(fontSize: 12, color: _mutedTextColor),
                ),
              ],
            ),
          ),
          _buildFieldSelector(isAuthor: isAuthor),
          // 作者抓取：增量模式开关 + 检查点提示
          if (isAuthor) ...[
            const SizedBox(height: 12),
            _buildIncrementalModeSwitch(),
            // 检查点提示：检测到该作者曾抓取过
            if (_currentAuthorCheckpoint != null && !_crawlingOf(isAuthor)) ...[
              const SizedBox(height: 10),
              _buildCheckpointHint(),
            ],
            // 断点续传：检查点有 cursor，说明上次没抓完
            if (_currentAuthorCheckpoint?.cursor != null &&
                _currentAuthorCheckpoint!.cursor!.isNotEmpty &&
                !_crawlingOf(isAuthor) &&
                _incrementalMode) ...[
              const SizedBox(height: 10),
              _buildCheckpointResumeButton(),
            ],
          ],
          // 断点续传：继续抓取按钮（批量抓取断点）
          if (_hasIncompleteBatch(isAuthor) && !_crawlingOf(isAuthor)) ...[
            const SizedBox(height: 12),
            _buildResumeButton(isAuthor: isAuthor),
          ],
        ],
      ),
    );
  }

  /// 增量模式开关
  Widget _buildIncrementalModeSwitch() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: _fillColor,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _borderColor),
      ),
      child: Row(
        children: [
          Icon(
            _incrementalMode ? Icons.new_releases_outlined : Icons.all_inclusive,
            size: 18,
            color: _incrementalMode ? AppTheme.primaryColor : _secondaryTextColor,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '增量模式',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: _textColor,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  _incrementalMode
                      ? '只抓取上次抓取后发布的新视频'
                      : '抓取作者全部视频（速度较慢）',
                  style: TextStyle(fontSize: 11, color: _secondaryTextColor),
                ),
              ],
            ),
          ),
          Switch(
            value: _incrementalMode,
            onChanged: _authorCrawling
                ? null
                : (value) {
                    setState(() => _incrementalMode = value);
                  },
            activeColor: AppTheme.primaryColor,
          ),
        ],
      ),
    );
  }

  /// 检查点提示卡片
  Widget _buildCheckpointHint() {
    final checkpoint = _currentAuthorCheckpoint!;
    final lastCrawlAt = _formatCheckpointTime(checkpoint.lastCrawlAt);
    final total = checkpoint.totalVideoCount;
    final hasUnfinished = checkpoint.cursor != null && checkpoint.cursor!.isNotEmpty;

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppTheme.primaryColor.withOpacity(_isDark ? 0.1 : 0.06),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: AppTheme.primaryColor.withOpacity(0.3),
        ),
      ),
      child: Row(
        children: [
          Icon(
            hasUnfinished ? Icons.pause_circle_outline : Icons.history,
            size: 18,
            color: AppTheme.primaryColor,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '检测到历史抓取记录',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.primaryColor,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  '上次抓取：$lastCrawlAt · 累计 $total 条视频${hasUnfinished ? '（未完成）' : ''}',
                  style: TextStyle(fontSize: 11, color: _secondaryTextColor),
                ),
              ],
            ),
          ),
          if (!_incrementalMode)
            TextButton(
              onPressed: _authorCrawling
                  ? null
                  : () {
                      setState(() => _incrementalMode = true);
                    },
              child: const Text('开启增量', style: TextStyle(fontSize: 12)),
            ),
        ],
      ),
    );
  }

  /// 基于检查点的断点续抓按钮
  Widget _buildCheckpointResumeButton() {
    final checkpoint = _currentAuthorCheckpoint!;
    final total = checkpoint.totalVideoCount;

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.orange.withOpacity(_isDark ? 0.15 : 0.08),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: Colors.orange.withOpacity(0.4),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(
                Icons.playlist_play,
                size: 18,
                color: Colors.orange,
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  '上次抓取未完成（已累计 $total 条）',
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: Colors.orange,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: _authorCrawling
                  ? null
                  : () {
                      // 继续上次抓取：开启增量模式，从 cursor 处继续
                      setState(() {
                        _incrementalMode = true;
                      });
                      // 直接开始抓取（会从检查点 cursor 继续）
                      _doCrawlSmart(isAuthor: true);
                    },
              icon: const Icon(Icons.play_arrow, size: 16),
              label: const Text('继续上次抓取'),
              style: OutlinedButton.styleFrom(
                foregroundColor: Colors.orange,
                side: const BorderSide(color: Colors.orange),
                padding: const EdgeInsets.symmetric(vertical: 8),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// 格式化检查点时间
  String _formatCheckpointTime(DateTime time) {
    final now = DateTime.now();
    final diff = now.difference(time);
    if (diff.inDays == 0) {
      return '今天 ${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';
    } else if (diff.inDays == 1) {
      return '昨天 ${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';
    } else if (diff.inDays < 7) {
      return '${diff.inDays} 天前';
    } else {
      return '${time.month}月${time.day}日';
    }
  }

  /// 构建继续抓取按钮（断点续传）
  Widget _buildResumeButton({required bool isAuthor}) {
    final progress = _batchProgressOf(isAuthor)!;
    final completed = progress.batchCompleted;
    final total = progress.batchTotal;
    final remaining = total - completed;
    final percent = total > 0 ? (completed / total * 100).toStringAsFixed(0) : '0';

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.primaryColor.withOpacity(_isDark ? 0.15 : 0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.primaryColor.withOpacity(0.4),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.pause_circle_filled,
                color: AppTheme.primaryColor,
                size: 20,
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  '检测到未完成的批次（$completed/$total 已完成）',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.primaryColor,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: total > 0 ? completed / total : 0,
              backgroundColor: _isDark ? Colors.grey.shade800 : Colors.grey.shade200,
              valueColor: AlwaysStoppedAnimation<Color>(AppTheme.primaryColor),
              minHeight: 6,
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => _discardBatchProgress(isAuthor: isAuthor),
                  icon: const Icon(Icons.delete_outline, size: 16),
                  label: const Text('放弃进度'),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                flex: 2,
                child: GradientButton(
                  text: '继续抓取（剩余 $remaining 条）',
                  icon: Icons.play_arrow,
                  onPressed: () => _resumeBatchCrawl(isAuthor: isAuthor),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  /// 放弃未完成的批次进度
  void _discardBatchProgress({required bool isAuthor}) async {
    final progress = _batchProgressOf(isAuthor);
    if (progress == null || progress.batchId == null) return;

    try {
      final service = context.read<CrawlHistoryService>();
      await service.clearBatchProgress(progress.batchId!);
    } catch (_) {}

    setState(() {
      if (isAuthor) {
        _authorBatchProgress = null;
      } else {
        _videoBatchProgress = null;
      }
    });
  }

  Widget _buildFieldSelector({required bool isAuthor}) {
    final fields = CrawlFieldConfigs.getFields(_selectedPlatform, isAuthor: isAuthor);
    final selected = isAuthor ? _currentAuthorFields : _currentVideoFields;

    return InkWell(
      onTap: () => _showFieldPicker(isAuthor: isAuthor),
      borderRadius: BorderRadius.circular(10),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: _fillColor,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: _borderColor),
        ),
        child: Row(
          children: [
            Icon(Icons.filter_list_outlined,
                size: 18, color: _secondaryTextColor),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                '抓取字段（已选 ${selected.length}/${fields.length}）',
                style: TextStyle(fontSize: 13, color: _secondaryTextColor),
              ),
            ),
            Icon(Icons.chevron_right,
                size: 18, color: _mutedTextColor),
          ],
        ),
      ),
    );
  }

  void _showFieldPicker({required bool isAuthor}) {
    final fields = CrawlFieldConfigs.getFields(_selectedPlatform, isAuthor: isAuthor);
    // 创建本地可变集合用于弹窗内的选择操作
    final selected = <String>{...(isAuthor ? _currentAuthorFields : _currentVideoFields)};

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => StatefulBuilder(
        builder: (context, setSheetState) => DraggableScrollableSheet(
          initialChildSize: 0.6,
          maxChildSize: 0.85,
          minChildSize: 0.4,
          builder: (_, controller) => Container(
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              borderRadius:
                  BorderRadius.vertical(top: Radius.circular(20)),
            ),
            child: Column(
              children: [
                const SizedBox(height: 12),
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.grey.shade700
                          : Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
                  child: Row(
                    children: [
                      const Text(
                        '选择抓取字段',
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                      const Spacer(),
                      TextButton(
                        onPressed: () {
                          setSheetState(() {
                            selected.clear();
                            selected.addAll(
                                fields.where((f) => f.defaultSelected).map((f) => f.key));
                          });
                        },
                        child: const Text('重置'),
                      ),
                      TextButton(
                        onPressed: () {
                          setSheetState(() {
                            if (selected.length == fields.length) {
                              // 全部已选中，点击后全部取消
                              selected.clear();
                            } else {
                              // 未全部选中，点击后全选
                              selected.clear();
                              selected.addAll(fields.map((f) => f.key));
                            }
                          });
                        },
                        child: Text(selected.length == fields.length ? '反选' : '全选'),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: ListView.builder(
                    controller: controller,
                    itemCount: fields.length,
                    itemBuilder: (_, i) {
                      final field = fields[i];
                      final isSelected = selected.contains(field.key);
                      return CheckboxListTile(
                        value: isSelected,
                        onChanged: (val) {
                          setSheetState(() {
                            if (val == true) {
                              selected.add(field.key);
                            } else {
                              selected.remove(field.key);
                            }
                          });
                        },
                        title: Text(field.label,
                            style: const TextStyle(fontSize: 14)),
                        controlAffinity: ListTileControlAffinity.leading,
                        dense: true,
                      );
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: SizedBox(
                    width: double.infinity,
                    child: GradientButton(
                      text: '确定',
                      icon: Icons.check,
                      onPressed: () {
                        // 保存到当前平台的字段选择
                        setState(() {
                          if (isAuthor) {
                            _selectedAuthorFieldsByPlatform[_selectedPlatform] =
                                Set<String>.from(selected);
                          } else {
                            _selectedVideoFieldsByPlatform[_selectedPlatform] =
                                Set<String>.from(selected);
                          }
                        });
                        Navigator.pop(context);
                      },
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ==================== 历史记录区域 ====================

  Widget _buildHistorySection({required bool isAuthor}) {
    return Consumer<CrawlHistoryProvider>(
      builder: (context, provider, child) {
        final records = isAuthor ? provider.authorRecords : provider.videoRecords;
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor =
            isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        final fillColor =
            isDark ? const Color(0xFF0F172A) : Colors.grey.shade50;
        // 获取未完成的批次
        final incompleteBatches = provider.getIncompleteBatchesByType(isAuthor);
        final hasIncomplete = incompleteBatches.isNotEmpty && !_crawlingOf(isAuthor);
        return Container(
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            borderRadius: BorderRadius.circular(16),
            boxShadow: isDark
                ? const <BoxShadow>[]
                : [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 10,
                      offset: const Offset(0, 2),
                    ),
                  ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 14, 8, 10),
                child: Row(
                  children: [
                    Icon(Icons.history, size: 18, color: secondaryTextColor),
                    const SizedBox(width: 8),
                    Text(
                      '${isAuthor ? '作者' : '视频'}抓取历史',
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 1),
                      decoration: BoxDecoration(
                        color: fillColor,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        '${records.length}',
                        style: TextStyle(
                          fontSize: 11,
                          color: secondaryTextColor,
                        ),
                      ),
                    ),
                    const Spacer(),
                    if (records.isNotEmpty) ...[
                      // 复制字段
                      _buildCompactIconButton(
                        icon: Icons.content_copy,
                        label: '复制字段',
                        color: AppTheme.primaryColor,
                        onTap: () => _showHistoryCopyFieldMenu(records, isAuthor: isAuthor),
                      ),
                      const SizedBox(width: 2),
                      // 导出
                      _buildCompactIconButton(
                        icon: Icons.file_download_outlined,
                        label: '导出',
                        color: AppTheme.primaryColor,
                        onTap: () => _exportHistory(isAuthor: isAuthor),
                      ),
                      const SizedBox(width: 2),
                      // 清空
                      _buildCompactIconButton(
                        icon: Icons.delete_outline,
                        label: '清空',
                        color: secondaryTextColor,
                        onTap: () => _clearHistory(isAuthor: isAuthor),
                      ),
                    ],
                  ],
                ),
              ),
              // 一键恢复全部中断任务按钮
              if (hasIncomplete) ...[
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: InkWell(
                    onTap: () => _resumeAllInterruptedBatches(isAuthor: isAuthor),
                    borderRadius: BorderRadius.circular(10),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                      decoration: BoxDecoration(
                        color: Colors.orange.withOpacity(isDark ? 0.15 : 0.08),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: Colors.orange.withOpacity(0.4),
                        ),
                      ),
                      child: Row(
                        children: [
                          const Icon(
                            Icons.playlist_play,
                            size: 18,
                            color: Colors.orange,
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              '检测到 ${incompleteBatches.length} 个未完成的批次',
                              style: const TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: Colors.orange,
                              ),
                            ),
                          ),
                          const Text(
                            '一键恢复',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: Colors.orange,
                            ),
                          ),
                          const SizedBox(width: 2),
                          const Icon(
                            Icons.arrow_forward_ios,
                            size: 12,
                            color: Colors.orange,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 8),
              ],
              const Divider(height: 1),
              if (provider.loading)
                Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    children: List.generate(
                      5,
                      (index) => const Padding(
                        padding: EdgeInsets.only(bottom: 10),
                        child: ListItemSkeleton(),
                      ),
                    ),
                  ),
                )
              else if (records.isEmpty)
                Container(
                  constraints: const BoxConstraints(minHeight: 200),
                  child: EmptyState.noCrawlHistory(),
                )
              else
                _buildGroupedHistoryList(records, isAuthor: isAuthor),
              if (records.length > 20)
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                  child: Center(
                    child: Text(
                      '仅显示最近 20 条，共 ${records.length} 条',
                      style:
                          TextStyle(fontSize: 11, color: secondaryTextColor),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildGroupedHistoryList(List<CrawlRecord> records, {required bool isAuthor}) {
    // 按 batchId 分组
    final batchMap = <String, List<CrawlRecord>>{};
    final singleRecords = <CrawlRecord>[];

    for (final record in records) {
      if (record.batchId != null && record.batchId!.isNotEmpty) {
        batchMap.putIfAbsent(record.batchId!, () => []).add(record);
      } else {
        singleRecords.add(record);
      }
    }

    // 构建显示项列表
    final items = <dynamic>[];
    for (final r in singleRecords) {
      items.add(_HistorySingleItem(r));
    }
    batchMap.forEach((batchId, batchRecords) {
      items.add(_HistoryBatchItem(batchId, batchRecords));
    });

    // 按时间倒序
    items.sort((a, b) {
      DateTime timeA = a is _HistorySingleItem
          ? a.record.crawledAt
          : (a as _HistoryBatchItem).records.first.crawledAt;
      DateTime timeB = b is _HistorySingleItem
          ? b.record.crawledAt
          : (b as _HistoryBatchItem).records.first.crawledAt;
      return timeB.compareTo(timeA);
    });

    // 限制显示数量（批次算 1 条，但展开后会显示更多）
    final displayItems = items.length > 20 ? items.sublist(0, 20) : items;

    return Column(
      children: [
        for (var i = 0; i < displayItems.length; i++) ...[
          if (i > 0) const Divider(height: 1, indent: 72, endIndent: 16),
          _buildHistoryDisplayItem(displayItems[i], isAuthor: isAuthor),
        ],
      ],
    );
  }

  Widget _buildHistoryDisplayItem(dynamic item, {required bool isAuthor}) {
    if (item is _HistorySingleItem) {
      return _buildHistoryItem(item.record, isAuthor: isAuthor);
    } else if (item is _HistoryBatchItem) {
      final batch = item;
      final isExpanded = _expandedHistoryBatches.contains(batch.batchId);
      final latestTime = batch.records.first.crawledAt;
      // 获取批次进度
      final batchProgress = context.read<CrawlHistoryProvider>().getBatchProgress(batch.batchId);
      final hasProgress = batchProgress != null && batchProgress.batchTotal > 0;
      final isInProgress = batchProgress?.isBatchInProgress ?? false;
      final isInterrupted = batchProgress?.isBatchInterrupted ?? false;

      return Column(
        children: [
          InkWell(
            onTap: () {
              setState(() {
                if (isExpanded) {
                  _expandedHistoryBatches.remove(batch.batchId);
                } else {
                  _expandedHistoryBatches.add(batch.batchId);
                }
              });
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              child: Row(
                children: [
                  Container(
                    width: 56,
                    height: 56,
                    decoration: BoxDecoration(
                      color: isInterrupted
                          ? Colors.red.withOpacity(_isDark ? 0.2 : 0.1)
                          : isInProgress
                              ? Colors.orange.withOpacity(_isDark ? 0.2 : 0.1)
                              : Colors.orange.withOpacity(_isDark ? 0.2 : 0.1),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(
                      isInterrupted
                          ? Icons.pause_circle_filled
                          : isInProgress
                              ? Icons.play_circle_filled
                              : Icons.playlist_add_check,
                      color: isInterrupted
                          ? Colors.red
                          : isInProgress
                              ? Colors.orange
                              : Colors.orange,
                      size: 24,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                '批量抓取 - ${batch.records.length} 条',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                            // 状态标识
                            if (isInProgress) ...[
                              const SizedBox(width: 6),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(
                                  color: isInterrupted
                                      ? Colors.red.withOpacity(0.15)
                                      : Colors.orange.withOpacity(0.15),
                                  borderRadius: BorderRadius.circular(4),
                                ),
                                child: Text(
                                  batchProgress!.batchStatusText,
                                  style: TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.w600,
                                    color: isInterrupted ? Colors.red : Colors.orange,
                                  ),
                                ),
                              ),
                            ],
                          ],
                        ),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            PlatformBadge(platform: batch.records.first.platform, size: 11),
                            const SizedBox(width: 6),
                            Expanded(
                              child: Text(
                                batch.records.first.typeLabel,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontSize: 11,
                                  color: _secondaryTextColor,
                                ),
                              ),
                            ),
                            const SizedBox(width: 6),
                            Text(
                              _formatHistoryTime(latestTime),
                              style: TextStyle(
                                fontSize: 10,
                                color: _mutedTextColor,
                              ),
                            ),
                          ],
                        ),
                        // 进度条和进度文字
                        if (hasProgress) ...[
                          const SizedBox(height: 6),
                          Row(
                            children: [
                              Expanded(
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(3),
                                  child: LinearProgressIndicator(
                                    value: batchProgress!.batchProgressPercent / 100,
                                    backgroundColor: _isDark ? Colors.grey.shade800 : Colors.grey.shade200,
                                    valueColor: AlwaysStoppedAnimation<Color>(
                                      isInterrupted ? Colors.red : AppTheme.primaryColor,
                                    ),
                                    minHeight: 4,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Text(
                                '${batchProgress.batchProgressText} (${batchProgress.batchProgressCountText})',
                                style: TextStyle(
                                  fontSize: 10,
                                  color: _mutedTextColor,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                          // 继续按钮
                          if (isInProgress && !_crawlingOf(isAuthor)) ...[
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                const Spacer(),
                                SizedBox(
                                  height: 28,
                                  child: OutlinedButton.icon(
                                    onPressed: () {
                                      _resumeBatchFromHistory(batchProgress, isAuthor: isAuthor);
                                    },
                                    icon: const Icon(Icons.play_arrow, size: 14),
                                    label: Text(
                                      isInterrupted ? '继续抓取' : '继续',
                                      style: const TextStyle(fontSize: 11),
                                    ),
                                    style: OutlinedButton.styleFrom(
                                      foregroundColor: isInterrupted ? Colors.red : AppTheme.primaryColor,
                                      side: BorderSide(
                                        color: isInterrupted ? Colors.red.withOpacity(0.5) : AppTheme.primaryColor.withOpacity(0.5),
                                      ),
                                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 0),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(6),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(width: 4),
                  // 复制字段按钮
                  InkWell(
                    onTap: () {
                      _showHistoryCopyFieldMenu(batch.records, isAuthor: isAuthor);
                    },
                    borderRadius: BorderRadius.circular(6),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: AppTheme.primaryColor.withOpacity(_isDark ? 0.18 : 0.1),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(
                          color: AppTheme.primaryColor.withOpacity(0.4),
                          width: 0.8,
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.content_copy,
                              size: 12, color: AppTheme.primaryColor),
                          const SizedBox(width: 3),
                          Text(
                            '复制字段',
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w500,
                              color: _isDark
                                  ? AppTheme.primaryColor.withOpacity(0.95)
                                  : AppTheme.primaryColorDark,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 4),
                  Icon(
                    isExpanded ? Icons.expand_less : Icons.expand_more,
                    color: _mutedTextColor,
                    size: 20,
                  ),
                ],
              ),
            ),
          ),
          if (isExpanded)
            Padding(
              padding: const EdgeInsets.only(left: 40),
              child: Column(
                children: [
                  const Divider(height: 1, indent: 32, endIndent: 16),
                  ...batch.records.map((record) => InkWell(
                        onTap: () => _showHistoryDetail(record),
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
                          child: Row(
                            children: [
                              SizedBox(
                                width: 40,
                                height: 40,
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: _recordThumbUrl(record) != null
                                      ? Image.network(
                                          _recordThumbUrl(record)!,
                                          fit: BoxFit.cover,
                                          errorBuilder: (_, __, ___) =>
                                              _buildHistoryIcon(isAuthor),
                                        )
                                      : _buildHistoryIcon(isAuthor),
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      record.displayTitle,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      record.displaySubtitle,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        fontSize: 10,
                                        color: _secondaryTextColor,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Icon(Icons.chevron_right,
                                  color: _mutedTextColor, size: 16),
                            ],
                          ),
                        ),
                      )),
                ],
              ),
            ),
        ],
      );
    }
    return const SizedBox.shrink();
  }

  Widget _buildHistoryItem(CrawlRecord record, {required bool isAuthor}) {
    final thumbUrl = _recordThumbUrl(record);
    final batchProgress = record.batchId != null
        ? context.read<CrawlHistoryProvider>().getBatchProgress(record.batchId!)
        : null;
    final isIncompleteBatch = batchProgress?.isBatchInProgress ?? false;

    // 构造左滑操作
    final actions = <SlideAction>[];

    // 分享操作
    actions.add(
      SlideAction(
        icon: Icons.share,
        label: '分享',
        color: Colors.blue,
        onTap: () => _shareHistoryItem(record),
      ),
    );

    // 删除操作
    actions.add(
      SlideAction(
        icon: Icons.delete,
        label: '删除',
        color: Colors.red,
        onTap: () => _deleteHistoryItem(record),
      ),
    );

    return SlideActionItem(
      actions: actions,
      actionWidth: 72,
      child: InkWell(
        onTap: () => _showHistoryDetail(record),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          child: Row(
            children: [
              SizedBox(
                width: 56,
                height: 56,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: thumbUrl != null && thumbUrl.isNotEmpty
                      ? Image.network(
                          thumbUrl,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) =>
                              _buildHistoryIcon(isAuthor),
                        )
                      : _buildHistoryIcon(isAuthor),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            record.displayTitle,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                        // 未完成批次标识
                        if (isIncompleteBatch) ...[
                          const SizedBox(width: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 5, vertical: 1),
                            decoration: BoxDecoration(
                              color: batchProgress!.isBatchInterrupted
                                  ? Colors.red.withOpacity(0.15)
                                  : Colors.orange.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(3),
                            ),
                            child: Text(
                              batchProgress.batchStatusText,
                              style: TextStyle(
                                fontSize: 9,
                                fontWeight: FontWeight.w600,
                                color: batchProgress.isBatchInterrupted
                                    ? Colors.red
                                    : Colors.orange,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        PlatformBadge(platform: record.platform, size: 11),
                        const SizedBox(width: 6),
                        Expanded(
                          child: Text(
                            record.displaySubtitle,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 11,
                              color: _secondaryTextColor,
                            ),
                          ),
                        ),
                        const SizedBox(width: 6),
                        Text(
                          _formatHistoryTime(record.crawledAt),
                          style: TextStyle(
                            fontSize: 10,
                            color: _mutedTextColor,
                          ),
                        ),
                      ],
                    ),
                    // 进度条（未完成的批次）
                    if (isIncompleteBatch && batchProgress!.batchTotal > 0) ...[
                      const SizedBox(height: 6),
                      Row(
                        children: [
                          Expanded(
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(2),
                              child: LinearProgressIndicator(
                                value: batchProgress.batchProgressPercent / 100,
                                backgroundColor:
                                    _isDark ? Colors.grey.shade800 : Colors.grey.shade200,
                                valueColor: AlwaysStoppedAnimation<Color>(
                                  batchProgress.isBatchInterrupted
                                      ? Colors.red
                                      : AppTheme.primaryColor,
                                ),
                                minHeight: 3,
                              ),
                            ),
                          ),
                          const SizedBox(width: 6),
                          Text(
                            '${batchProgress.batchProgressText} (${batchProgress.batchProgressCountText})',
                            style: TextStyle(
                              fontSize: 9,
                              color: _mutedTextColor,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(width: 4),
              Icon(Icons.chevron_right, color: _mutedTextColor, size: 18),
            ],
          ),
        ),
      ),
    );
  }

  /// 分享历史记录
  void _shareHistoryItem(CrawlRecord record) {
    final text = '${record.displayTitle}\n${record.url}';
    Share.share(text);
  }

  /// 删除历史记录（带撤销提示）
  void _deleteHistoryItem(CrawlRecord record) async {
    final provider = context.read<CrawlHistoryProvider>();
    await provider.removeRecord(record.id);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('已删除记录'),
          action: SnackBarAction(
            label: '撤销',
            onPressed: () {
              // 撤销：重新添加记录
              provider.addRecord(record);
            },
          ),
          duration: const Duration(seconds: 3),
        ),
      );
    }
  }

  void _showHistoryDetail(CrawlRecord record) {
    final isAuthor = record.isAuthor;
    // 检查是否属于未完成的批次
    final isBatchRecord = record.batchId != null && record.batchId!.isNotEmpty;
    CrawlRecord? batchProgress;
    if (isBatchRecord) {
      batchProgress = context.read<CrawlHistoryProvider>().getBatchProgress(record.batchId!);
    }
    final isIncompleteBatch = batchProgress != null && batchProgress.isBatchInProgress;
    final isInterrupted = batchProgress?.isBatchInterrupted ?? false;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        maxChildSize: 0.95,
        minChildSize: 0.5,
        builder: (_, controller) => Container(
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
          ),
          child: ListView(
            controller: controller,
            padding: const EdgeInsets.all(20),
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Theme.of(context).brightness == Brightness.dark
                        ? Colors.grey.shade700
                        : Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: isAuthor
                          ? Colors.purple.withOpacity(_isDark ? 0.2 : 0.1)
                          : Colors.blue.withOpacity(_isDark ? 0.2 : 0.1),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      record.typeLabel,
                      style: TextStyle(
                        fontSize: 12,
                        color: isAuthor ? Colors.purple : Colors.blue,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  PlatformBadge(platform: record.platform, size: 12),
                  // 批次状态标识
                  if (isIncompleteBatch) ...[
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: isInterrupted
                            ? Colors.red.withOpacity(0.15)
                            : Colors.orange.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        batchProgress!.batchStatusText,
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: isInterrupted ? Colors.red : Colors.orange,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
              const SizedBox(height: 12),
              // 预览图 + 标题信息（紧凑布局）
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (_recordThumbUrl(record) != null)
                    ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: Image.network(
                        _recordThumbUrl(record)!,
                        width: 100,
                        height: 140,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                      ),
                    ),
                  if (_recordThumbUrl(record) != null)
                    const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          record.displayTitle,
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          '抓取时间：${_formatDateTime(record.crawledAt)}',
                          style: TextStyle(fontSize: 12, color: _secondaryTextColor),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '数据字段：${record.fields.length} 项',
                          style: TextStyle(fontSize: 12, color: _secondaryTextColor),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              const Divider(height: 1),
              const SizedBox(height: 12),
              ...record.fields.map((f) => Padding(
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    child: _buildDetailRow(f.key, f.value),
                  )),
              const SizedBox(height: 16),
              // 继续抓取按钮（未完成的批次）
              if (isIncompleteBatch && batchProgress != null) ...[
                SizedBox(
                  width: double.infinity,
                  child: GradientButton(
                    text: isInterrupted ? '继续抓取' : '继续抓取',
                    icon: Icons.play_arrow,
                    onPressed: () {
                      Navigator.pop(context);
                      _resumeBatchFromHistory(batchProgress!, isAuthor: isAuthor);
                    },
                  ),
                ),
                const SizedBox(height: 10),
              ],
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () {
                        final text = record.fields
                            .map((f) => '${f.key}：${f.value}')
                            .join('\n');
                        Clipboard.setData(ClipboardData(text: text));
                        Navigator.pop(context);
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('已复制全部信息')),
                        );
                      },
                      icon: const Icon(Icons.copy, size: 16),
                      label: const Text('复制全部'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () {
                        context
                            .read<CrawlHistoryProvider>()
                            .removeRecord(record.id);
                        Navigator.pop(context);
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('已删除记录')),
                        );
                      },
                      icon: const Icon(Icons.delete_outline, size: 16),
                      label: const Text('删除'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.red,
                        side: BorderSide(color: Colors.red.shade300),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _clearHistory({required bool isAuthor}) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('确认清空'),
        content: Text('确定要清空所有${isAuthor ? '作者' : '视频'}抓取记录吗？'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              if (isAuthor) {
                await context.read<CrawlHistoryProvider>().clearAuthorHistory();
              } else {
                await context.read<CrawlHistoryProvider>().clearVideoHistory();
              }
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('已清空')),
                );
              }
            },
            child: const Text('确定', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  Future<void> _exportHistory({required bool isAuthor}) async {
    final provider = context.read<CrawlHistoryProvider>();
    final records = isAuthor ? provider.authorRecords : provider.videoRecords;

    if (records.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('没有可导出的记录')),
      );
      return;
    }

    try {
      // 收集所有字段（确保所有记录的字段都被包含）
      final allKeys = <String>{};
      for (final record in records) {
        allKeys.addAll(record.data.keys);
      }
      final keyList = allKeys.toList();

      // 创建 Excel
      final book = excel.Excel.createExcel();
      final sheetName = isAuthor ? '作者抓取记录' : '视频抓取记录';
      // excel 4.x 默认有 Sheet1，删除并重建
      if (book.sheets.containsKey('Sheet1')) {
        book.delete('Sheet1');
      }
      book.setDefaultSheet(sheetName);
      final sheet = book[sheetName];

      // 表头
      final headers = ['序号', '平台', '抓取时间', '原始链接', ...keyList.map((k) => _fieldLabel(k))];
      for (int i = 0; i < headers.length; i++) {
        sheet.cell(excel.CellIndex.indexByColumnRow(columnIndex: i, rowIndex: 0)).value =
            excel.TextCellValue(headers[i]);
      }

      // 数据行
      for (int i = 0; i < records.length; i++) {
        final record = records[i];
        final row = <dynamic>[
          i + 1,
          record.platformName,
          DateFormat('yyyy-MM-dd HH:mm:ss').format(record.crawledAt),
          record.url,
          ...keyList.map((k) => record.data[k]?.toString() ?? ''),
        ];
        for (int j = 0; j < row.length; j++) {
          sheet.cell(excel.CellIndex.indexByColumnRow(columnIndex: j, rowIndex: i + 1)).value =
              excel.TextCellValue(row[j].toString());
        }
      }

      // 保存到临时目录
      final bytes = book.save();
      if (bytes == null) {
        throw Exception('导出失败：无法生成文件');
      }

      final tempDir = await getTemporaryDirectory();
      final fileName = '${isAuthor ? '作者' : '视频'}_抓取记录_${DateFormat('yyyyMMdd_HHmmss').format(DateTime.now())}.xlsx';
      final filePath = '${tempDir.path}/$fileName';
      final file = File(filePath);
      await file.writeAsBytes(bytes);

      // 分享文件
      await Share.shareXFiles(
        [XFile(filePath, mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')],
        text: '${isAuthor ? '作者' : '视频'}抓取记录（共${records.length}条）',
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('已导出 ${records.length} 条记录')),
        );
      }
    } catch (e) {
      debugPrint('导出失败: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('导出失败：${e.toString()}')),
        );
      }
    }
  }

  String _fieldLabel(String key) {
    const labels = {
      'uid': '作者UID',
      'uniqueId': '抖音号',
      'nickname': '昵称',
      'authorName': '作者名称',
      'avatar': '头像',
      'signature': '简介',
      'description': '描述',
      'followerCount': '粉丝数',
      'fansCount': '粉丝数',
      'followingCount': '关注数',
      'followCount': '关注数',
      'totalFavorited': '获赞数',
      'likeCountTotal': '总获赞',
      'awemeCount': '作品数',
      'videoCount': '作品数',
      'favoriteCount': '收藏数',
      'videoId': '视频ID',
      'awemeId': '作品ID',
      'title': '标题',
      'desc': '描述',
      'cover': '封面',
      'shareUrl': '分享链接',
      'createTime': '发布时间',
      'publishTime': '发布时间',
      'duration': '时长(秒)',
      'durationSeconds': '时长(秒)',
      'diggCount': '点赞数',
      'likeCount': '点赞数',
      'commentCount': '评论数',
      'shareCount': '分享数',
      'collectCount': '收藏数',
      'playCount': '播放数',
      'downloadCount': '下载数',
      'authorUid': '作者UID',
      'authorUniqueId': '作者抖音号',
      'authorNickname': '作者昵称',
      'authorAvatar': '作者头像',
    };
    return labels[key] ?? key;
  }

  Widget _buildDetailRow(String label, String value) {
    final isImageUrl = _isImageUrlField(label) &&
        value.isNotEmpty &&
        (value.startsWith('http://') || value.startsWith('https://'));
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: InkWell(
        onTap: value.isEmpty
            ? null
            : () {
                Clipboard.setData(ClipboardData(text: value));
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('已复制 $label'),
                    duration: const Duration(seconds: 1),
                  ),
                );
              },
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 80,
              child: Text(
                label,
                style: TextStyle(fontSize: 13, color: _secondaryTextColor),
              ),
            ),
            Expanded(
              child: isImageUrl
                  ? Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(6),
                          child: Image.network(
                            value,
                            width: 60,
                            height: 60,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) =>
                                const SizedBox.shrink(),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            value,
                            style: TextStyle(
                              fontSize: 11,
                              color: _secondaryTextColor,
                            ),
                            maxLines: 3,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    )
                  : Text(
                      value.isEmpty ? '-' : value,
                      style: TextStyle(fontSize: 13, color: _textColor),
                    ),
            ),
            const SizedBox(width: 4),
            Icon(
              Icons.copy,
              size: 14,
              color: value.isEmpty ? Colors.transparent : _mutedTextColor,
            ),
          ],
        ),
      ),
    );
  }

  bool _isImageUrlField(String label) {
    const imageFields = {'头像', '封面图', '作者头像', '封面'};
    return imageFields.contains(label);
  }

  String _formatHistoryTime(DateTime dt) {
    final now = DateTime.now();
    final diff = now.difference(dt);
    if (diff.inMinutes < 1) return '刚刚';
    if (diff.inMinutes < 60) return '${diff.inMinutes}分钟前';
    if (diff.inHours < 24) return '${diff.inHours}小时前';
    if (diff.inDays < 7) return '${diff.inDays}天前';
    return '${dt.month}/${dt.day}';
  }

  /// 紧凑图标按钮（防溢出）
  Widget _buildCompactIconButton({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Flexible(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(6),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 14, color: color),
              const SizedBox(width: 3),
              Flexible(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 11,
                    color: color,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _formatDateTime(DateTime dt) {
    return '${dt.year}-${dt.month.toString().padLeft(2, '0')}-${dt.day.toString().padLeft(2, '0')} '
        '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
  }

  /// 格式化剩余时间
  String _formatRemainingTime(int seconds) {
    if (seconds <= 0) return '计算中';
    if (seconds < 60) return '${seconds}秒';
    if (seconds < 3600) {
      final min = seconds ~/ 60;
      final sec = seconds % 60;
      return '${min}分${sec}秒';
    }
    final hour = seconds ~/ 3600;
    final min = (seconds % 3600) ~/ 60;
    return '${hour}时${min}分';
  }

  /// 获取记录的预览图 URL（视频用封面，作者用头像）
  /// 优先从 rawData（完整原始数据）取，不受用户字段选择影响；
  /// rawData 为空时回退到 data（过滤后的数据）。
  String? _recordThumbUrl(CrawlRecord record) {
    final rawData = record.rawData;
    final data = record.data;
    // 视频：封面优先（从 rawData 取）
    if (record.isVideo) {
      final cover = rawData?['cover'] ?? data['cover'];
      if (cover is String && cover.isNotEmpty) return cover;
    }
    // 作者：头像（从 rawData 取）
    if (record.isAuthor) {
      final avatar = rawData?['avatar'] ?? data['avatar'];
      if (avatar is String && avatar.isNotEmpty) return avatar;
    }
    // 视频记录里的作者头像兜底（从 rawData 取）
    final authorAvatar = rawData?['authorAvatar'] ?? data['authorAvatar'];
    if (authorAvatar is String && authorAvatar.isNotEmpty) return authorAvatar;
    return null;
  }

  /// 历史记录图标兜底（无图时显示）
  Widget _buildHistoryIcon(bool isAuthor) {
    return Container(
      decoration: BoxDecoration(
        color: isAuthor
            ? Colors.purple.withOpacity(_isDark ? 0.2 : 0.1)
            : Colors.blue.withOpacity(_isDark ? 0.2 : 0.1),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Icon(
        isAuthor ? Icons.person_outline : Icons.play_circle_outline,
        color: isAuthor ? Colors.purple : Colors.blue,
        size: 24,
      ),
    );
  }

  // ==================== 操作方法 ====================

  void _clearInput({required bool isAuthor}) {
    setState(() {
      _urlControllerOf(isAuthor).clear();
      _setError(isAuthor, null);
      _setResult(isAuthor, null);
    });
  }

  /// 统一抓取入口：根据输入框中的链接数量自动选择单条/批量解析
  Future<void> _doCrawlSmart({required bool isAuthor, List<String>? urls}) async {
    final text = _urlControllerOf(isAuthor).text.trim();

    // 优先使用传入的 urls 参数，否则从 controller 解析
    final List<String> urlList = urls ??
        text
            .split('\n')
            .map((e) => e.trim())
            .where((e) => e.isNotEmpty)
            .toList();

    if (urlList.isEmpty) {
      setState(() => _setError(isAuthor, '请输入链接'));
      return;
    }

    // 平台验证：检查链接是否属于当前选中平台
    final mismatchedUrls = <String>[];
    for (final url in urlList) {
      final detected = PlatformDetector.detectPlatformId(url);
      if (detected != 'unknown' && detected != _selectedPlatform) {
        mismatchedUrls.add(url);
      }
    }
    if (mismatchedUrls.isNotEmpty) {
      final platformName = _platforms.firstWhere(
        (p) => p['id'] == _selectedPlatform,
        orElse: () => {'name': '未知'},
      )['name'];
      final detectedName = _platforms.firstWhere(
        (p) => p['id'] == PlatformDetector.detectPlatformId(mismatchedUrls.first),
        orElse: () => {'name': '其他平台'},
      )['name'];
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('当前选中平台为「$platformName」，但检测到 $detectedName 链接，可能导致抓取失败'),
          backgroundColor: Colors.orange,
          duration: const Duration(seconds: 3),
        ),
      );
    }

    if (urlList.length == 1) {
      // 单条解析：清空批量结果与计数，确保按单条方式展示与计数
      setState(() {
        if (isAuthor) {
          _authorBatchResults = [];
          _authorBatchCurrent = 0;
          _authorBatchTotal = 0;
        } else {
          _videoBatchResults = [];
          _videoBatchCurrent = 0;
          _videoBatchTotal = 0;
        }
      });
      await _doCrawl(isAuthor: isAuthor);
    } else {
      // 批量解析
      await _doBatchCrawl(isAuthor: isAuthor);
    }
  }

  Future<void> _doCrawl({required bool isAuthor}) async {
    final url = _urlControllerOf(isAuthor).text.trim();
    if (url.isEmpty) {
      setState(() => _setError(isAuthor, '请输入链接'));
      return;
    }

    setState(() {
      _setCrawling(isAuthor, true);
      _setError(isAuthor, null);
      _setResult(isAuthor, null);
      // 作者增量抓取：重置增量视频列表状态
      if (isAuthor && _incrementalMode) {
        _incrementalVideos = [];
        _incrementalHasMore = false;
        _incrementalNextCursor = null;
      }
    });

    try {
      CrawlRecord record;
      final fields = isAuthor
          ? _currentAuthorFields.toList()
          : _currentVideoFields.toList();

      if (isAuthor) {
        if (_incrementalMode) {
          // 增量模式：从检查点获取上次抓取的位置
          final checkpoint = _currentAuthorCheckpoint;
          record = await _crawlService.crawlAuthor(
            url,
            fields: fields,
            incremental: true,
            lastVideoPublishTime: checkpoint?.lastVideoPublishTime,
            lastVideoId: checkpoint?.lastVideoId,
            cursor: checkpoint?.cursor,
          );
          // 提取增量视频结果
          final rawData = record.rawData;
          if (rawData != null) {
            final videos = rawData['incrementalVideos'] as List<CrawlRecord>?;
            if (videos != null) {
              _incrementalVideos = videos;
              _incrementalHasMore = rawData['hasMoreVideos'] == true;
              _incrementalNextCursor = rawData['nextCursor'] as String?;
            }
          }
          // 保存增量检查点
          await _saveIncrementalCheckpoint(record);
          // 将增量视频写入历史
          for (final video in _incrementalVideos) {
            try {
              await context.read<CrawlHistoryService>().addRecord(video);
            } catch (_) {}
          }
          // 刷新历史
          if (mounted) {
            context.read<CrawlHistoryProvider>().loadHistory();
          }
        } else {
          // 普通模式：只抓取作者信息
          record = await _crawlService.crawlAuthor(url, fields: fields);
          // 保存基础检查点（只更新抓取时间）
          await _saveAuthorCheckpoint(record);
        }
      } else {
        record = await _crawlService.crawlVideo(url, fields: fields);
      }

      // 写入历史（不依赖 mounted，确保数据持久化不丢失）
      try {
        await context.read<CrawlHistoryProvider>().addRecord(record);
      } catch (_) {
        try {
          await context.read<CrawlHistoryService>().addRecord(record);
        } catch (_) {
          // 双重兜底：忽略历史写入失败，不影响主流程
        }
      }

      if (mounted) {
        setState(() => _setResult(isAuthor, record));
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _setError(isAuthor, e.toString().replaceAll('CrawlException: ', ''));
        });
      }
    } finally {
      if (mounted) {
        setState(() => _setCrawling(isAuthor, false));
      }
    }
  }

  /// 保存作者基础检查点（非增量模式，只记录抓取时间）
  Future<void> _saveAuthorCheckpoint(CrawlRecord record) async {
    try {
      final checkpointService = context.read<CrawlCheckpointService>();
      final authorId = record.data['authorUid']?.toString() ??
          record.data['authorSecUid']?.toString() ??
          record.data['secUid']?.toString() ??
          record.data['uid']?.toString() ??
          '';
      if (authorId.isNotEmpty) {
        final nickname = record.data['nickname']?.toString();
        await checkpointService.updateCheckpoint(
          record.platform,
          authorId,
          lastCrawlAt: DateTime.now(),
          nickname: nickname,
        );
        // 更新当前检查点缓存
        _currentAuthorCheckpoint = checkpointService.getCheckpoint(record.platform, authorId);
      }
    } catch (_) {
      // 检查点保存失败不影响主流程
    }
  }

  /// 保存增量检查点（增量模式下更新完整检查点信息）
  Future<void> _saveIncrementalCheckpoint(CrawlRecord record) async {
    try {
      final rawData = record.rawData;
      if (rawData == null) return;

      final checkpointService = context.read<CrawlCheckpointService>();
      final authorId = rawData['authorIdForCheckpoint']?.toString() ??
          record.data['authorUid']?.toString() ??
          record.data['uid']?.toString() ??
          '';
      if (authorId.isEmpty) return;

      final nickname = rawData['nicknameForCheckpoint']?.toString() ??
          record.data['nickname']?.toString();
      final latestPublishTime = rawData['latestPublishTime'] as DateTime?;
      final latestVideoId = rawData['latestVideoId']?.toString();
      final nextCursor = rawData['nextCursor'] as String?;
      final hasMore = rawData['hasMoreVideos'] == true;

      // 获取旧检查点的累计数量
      final oldCheckpoint = checkpointService.getCheckpoint(record.platform, authorId);
      final oldTotal = oldCheckpoint?.totalVideoCount ?? 0;
      final newVideosCount = (rawData['incrementalVideos'] as List?)?.length ?? 0;

      await checkpointService.updateCheckpoint(
        record.platform,
        authorId,
        lastCrawlAt: DateTime.now(),
        nickname: nickname,
        lastVideoPublishTime: latestPublishTime ?? oldCheckpoint?.lastVideoPublishTime,
        lastVideoId: latestVideoId ?? oldCheckpoint?.lastVideoId,
        totalVideoCount: oldTotal + newVideosCount,
        // 还有更多时保留 cursor，全部抓完则清空
        cursor: hasMore ? nextCursor : null,
      );

      // 更新当前检查点缓存
      _currentAuthorCheckpoint = checkpointService.getCheckpoint(record.platform, authorId);
    } catch (_) {
      // 检查点保存失败不影响主流程
    }
  }

  /// 从 URL 中检测作者检查点（用于决定是否显示增量提示）
  Future<void> _checkAuthorCheckpoint(String url) async {
    try {
      final cleanUrl = CrawlService.extractUrl(url) ?? url.trim();
      if (cleanUrl.isEmpty) {
        setState(() => _currentAuthorCheckpoint = null);
        return;
      }
      final platform = PlatformDetector.detectPlatformId(cleanUrl);
      if (platform == 'unknown') {
        setState(() => _currentAuthorCheckpoint = null);
        return;
      }
      // 尝试从 URL 提取作者 ID
      String? authorId;
      if (platform == 'douyin') {
        authorId = CrawlService.extractSecUid(cleanUrl);
      }
      // 其他平台暂不支持预检测

      if (authorId != null && authorId.isNotEmpty) {
        final checkpointService = context.read<CrawlCheckpointService>();
        final checkpoint = checkpointService.getCheckpoint(platform, authorId);
        if (mounted) {
          setState(() => _currentAuthorCheckpoint = checkpoint);
        }
      } else {
        if (mounted) {
          setState(() => _currentAuthorCheckpoint = null);
        }
      }
    } catch (_) {
      // 检测失败静默处理
    }
  }

  /// 加载更多增量视频（分页续抓）
  Future<void> _loadMoreIncrementalVideos(String url, List<String> fields) async {
    if (_loadingMoreIncremental || !_incrementalHasMore) return;
    if (_incrementalNextCursor == null || _incrementalNextCursor!.isEmpty) return;

    setState(() => _loadingMoreIncremental = true);

    try {
      final result = await _crawlService.crawlAuthorVideos(
        url,
        fields: fields,
        cursor: _incrementalNextCursor,
        count: 20,
        incremental: true,
        lastVideoPublishTime: _currentAuthorCheckpoint?.lastVideoPublishTime,
        lastVideoId: _currentAuthorCheckpoint?.lastVideoId,
      );

      // 添加新视频到列表
      setState(() {
        _incrementalVideos.addAll(result.videos);
        _incrementalHasMore = result.hasMore;
        _incrementalNextCursor = result.nextCursor;
      });

      // 更新检查点 cursor
      try {
        final checkpointService = context.read<CrawlCheckpointService>();
        final authorId = result.authorId;
        if (authorId.isNotEmpty) {
          final oldCheckpoint = checkpointService.getCheckpoint(_selectedPlatform, authorId);
          final oldTotal = oldCheckpoint?.totalVideoCount ?? 0;
          await checkpointService.updateCheckpoint(
            _selectedPlatform,
            authorId,
            totalVideoCount: oldTotal + result.videos.length,
            cursor: result.hasMore ? result.nextCursor : null,
          );
          _currentAuthorCheckpoint = checkpointService.getCheckpoint(_selectedPlatform, authorId);
        }
      } catch (_) {}

      // 写入历史
      for (final video in result.videos) {
        try {
          await context.read<CrawlHistoryService>().addRecord(video);
        } catch (_) {}
      }
      if (mounted) {
        context.read<CrawlHistoryProvider>().loadHistory();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('加载更多失败：${e.toString().replaceAll('CrawlException: ', '')}')),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _loadingMoreIncremental = false);
      }
    }
  }

  // ==================== 批量抓取 ====================

  Future<void> _doBatchCrawl({required bool isAuthor}) async {
    final text = _urlControllerOf(isAuthor).text.trim();
    if (text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('请输入链接')),
      );
      return;
    }

    // 按行分割，过滤空行
    final urls = text
        .split('\n')
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();

    if (urls.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('请输入至少一个有效链接')),
      );
      return;
    }

    // 清除该类型之前未完成的批次进度（开启新批次时废弃旧进度）
    final oldProgress = _batchProgressOf(isAuthor);
    if (oldProgress?.batchId != null) {
      try {
        final service = context.read<CrawlHistoryService>();
        await service.clearBatchProgress(oldProgress!.batchId!);
      } catch (_) {}
    }

    final batchId = DateTime.now().millisecondsSinceEpoch.toString();
    final fields = isAuthor
        ? _currentAuthorFields.toList()
        : _currentVideoFields.toList();

    // 创建并保存批次进度（断点续传）
    final progress = CrawlService.createBatchProgressRecord(
      batchId: batchId,
      urls: urls,
      fields: fields,
      isAuthor: isAuthor,
    );
    try {
      final service = context.read<CrawlHistoryService>();
      await service.saveBatchProgress(progress);
    } catch (_) {}

    setState(() {
      _setCrawling(isAuthor, true);
      _currentBatchId = batchId;
      if (isAuthor) {
        _authorBatchResults = [];
        _authorBatchCurrent = 0;
        _authorBatchTotal = urls.length;
        _authorBatchProgress = progress;
      } else {
        _videoBatchResults = [];
        _videoBatchCurrent = 0;
        _videoBatchTotal = urls.length;
        _videoBatchProgress = progress;
      }
    });

    final successRecords = <CrawlRecord>[];
    _crawlStartTime = DateTime.now();

    for (var i = 0; i < urls.length; i++) {
      if (!mounted) break;

      final url = urls[i];
      
      // 计算速度和剩余时间
      final elapsed = DateTime.now().difference(_crawlStartTime!).inMilliseconds;
      if (elapsed > 0 && i > 0) {
        final speed = (i * 1000) / elapsed; // 条/秒
        final remaining = ((urls.length - i) / speed).round();
        if (mounted) {
          setState(() {
            _crawlSpeed = speed;
            _crawlRemainingSeconds = remaining;
          });
        }
      }

      setState(() {
        if (isAuthor) {
          _authorBatchCurrent = i + 1;
        } else {
          _videoBatchCurrent = i + 1;
        }
      });

      try {
        CrawlRecord record;
        if (isAuthor) {
          record = await _crawlService.crawlAuthor(url, fields: fields);
        } else {
          record = await _crawlService.crawlVideo(url, fields: fields);
        }
        // 注入 batchId
        final recordWithBatch = CrawlRecord(
          id: record.id,
          url: record.url,
          platform: record.platform,
          crawlType: record.crawlType,
          crawledAt: record.crawledAt,
          data: record.data,
          rawData: record.rawData,
          batchId: batchId,
        );
        successRecords.add(recordWithBatch);
        if (mounted) {
          setState(() {
            if (isAuthor) {
              _authorBatchResults.add(_BatchCrawlItem(url: url, record: recordWithBatch));
            } else {
              _videoBatchResults.add(_BatchCrawlItem(url: url, record: recordWithBatch));
            }
          });
        }
      } catch (e) {
        if (mounted) {
          setState(() {
            if (isAuthor) {
              _authorBatchResults.add(_BatchCrawlItem(
                url: url,
                error: e.toString().replaceAll('CrawlException: ', ''),
              ));
            } else {
              _videoBatchResults.add(_BatchCrawlItem(
                url: url,
                error: e.toString().replaceAll('CrawlException: ', ''),
              ));
            }
          });
        }
      }

      // 更新批次进度（断点续传）
      try {
        final service = context.read<CrawlHistoryService>();
        await service.updateBatchProgress(
          batchId: batchId,
          currentIndex: i + 1,
          completed: successRecords.length,
        );
        // 更新内存中的进度状态
        if (isAuthor) {
          _authorBatchProgress = _authorBatchProgress?.copyWith(
            batchCurrentIndex: i + 1,
            batchCompleted: successRecords.length,
          );
        } else {
          _videoBatchProgress = _videoBatchProgress?.copyWith(
            batchCurrentIndex: i + 1,
            batchCompleted: successRecords.length,
          );
        }
      } catch (_) {}
    }

    // 批量保存到历史（不依赖 mounted，确保数据持久化不丢失）
    if (successRecords.isNotEmpty) {
      try {
        final provider = context.read<CrawlHistoryProvider>();
        for (final record in successRecords) {
          await provider.addRecord(record);
        }
      } catch (_) {
        try {
          final service = context.read<CrawlHistoryService>();
          for (final record in successRecords) {
            await service.addRecord(record);
          }
        } catch (_) {
          // 双重兜底：忽略历史写入失败，不影响主流程
        }
      }
    }

    // 标记批次为已完成并清除进度（断点续传）
    try {
      final service = context.read<CrawlHistoryService>();
      await service.markBatchCompleted(batchId);
      // 完成后清除进度记录
      await service.clearBatchProgress(batchId);
    } catch (_) {}

    if (mounted) {
      setState(() {
        _setCrawling(isAuthor, false);
        _currentBatchId = null;
        if (isAuthor) {
          _authorBatchProgress = null;
        } else {
          _videoBatchProgress = null;
        }
      });
    }
  }

  // ==================== 断点续传：继续抓取 ====================

  /// 继续抓取（从上次中断的位置恢复）
  Future<void> _resumeBatchCrawl({required bool isAuthor}) async {
    final progress = _batchProgressOf(isAuthor);
    if (progress == null ||
        progress.batchId == null ||
        progress.batchUrls == null) {
      return;
    }

    final batchId = progress.batchId!;
    final urls = progress.batchUrls!;
    final fields = progress.batchFields;
    final startIndex = progress.batchCurrentIndex;
    final isAuthorType = progress.batchIsAuthor ?? false;

    // 恢复之前已完成的结果到 UI（从历史记录中加载）
    final previousResults = <_BatchCrawlItem>[];
    try {
      final service = context.read<CrawlHistoryService>();
      final historyRecords = service.getAll();
      final batchRecords = historyRecords
          .where((r) => r.batchId == batchId)
          .toList();
      for (final record in batchRecords) {
        previousResults.add(_BatchCrawlItem(url: record.url, record: record));
      }
    } catch (_) {}

    setState(() {
      _setCrawling(isAuthor, true);
      _currentBatchId = batchId;
      if (isAuthor) {
        _authorBatchResults = previousResults;
        _authorBatchCurrent = startIndex;
        _authorBatchTotal = urls.length;
      } else {
        _videoBatchResults = previousResults;
        _videoBatchCurrent = startIndex;
        _videoBatchTotal = urls.length;
      }
    });

    // 同步字段选择（恢复时保持一致）
    if (fields != null) {
      setState(() {
        // 切换到记录对应的平台
        if (progress.platform.isNotEmpty) {
          _selectedPlatform = progress.platform;
        }
        // 恢复字段选择到对应平台
        final platform = progress.platform.isEmpty ? _selectedPlatform : progress.platform;
        if (isAuthorType) {
          _selectedAuthorFieldsByPlatform[platform] = fields.toSet();
        } else {
          _selectedVideoFieldsByPlatform[platform] = fields.toSet();
        }
      });
    }

    // 把 URL 列表填回输入框
    _urlControllerOf(isAuthor).text = urls.join('\n');

    final successRecords = <CrawlRecord>[];
    var completedCount = previousResults.where((r) => r.isSuccess).length;
    _crawlStartTime = DateTime.now();

    // 从中断位置继续抓取
    for (var i = startIndex; i < urls.length; i++) {
      if (!mounted) break;

      final url = urls[i];

      // 计算速度和剩余时间
      final elapsed = DateTime.now().difference(_crawlStartTime!).inMilliseconds;
      final processed = i - startIndex;
      if (elapsed > 0 && processed > 0) {
        final speed = (processed * 1000) / elapsed; // 条/秒
        final remaining = ((urls.length - i) / speed).round();
        if (mounted) {
          setState(() {
            _crawlSpeed = speed;
            _crawlRemainingSeconds = remaining;
          });
        }
      }

      if (mounted) {
        setState(() {
          if (isAuthor) {
            _authorBatchCurrent = i + 1;
          } else {
            _videoBatchCurrent = i + 1;
          }
        });
      }

      try {
        CrawlRecord record;
        if (isAuthorType) {
          record = await _crawlService.crawlAuthor(url, fields: fields);
        } else {
          record = await _crawlService.crawlVideo(url, fields: fields);
        }
        final recordWithBatch = record.copyWith(batchId: batchId);
        successRecords.add(recordWithBatch);
        completedCount++;
        if (mounted) {
          setState(() {
            if (isAuthor) {
              _authorBatchResults.add(_BatchCrawlItem(url: url, record: recordWithBatch));
            } else {
              _videoBatchResults.add(_BatchCrawlItem(url: url, record: recordWithBatch));
            }
          });
        }
      } catch (e) {
        if (mounted) {
          setState(() {
            if (isAuthor) {
              _authorBatchResults.add(_BatchCrawlItem(
                url: url,
                error: e.toString().replaceAll('CrawlException: ', ''),
              ));
            } else {
              _videoBatchResults.add(_BatchCrawlItem(
                url: url,
                error: e.toString().replaceAll('CrawlException: ', ''),
              ));
            }
          });
        }
      }

      // 更新批次进度（断点续传）
      try {
        final service = context.read<CrawlHistoryService>();
        await service.updateBatchProgress(
          batchId: batchId,
          currentIndex: i + 1,
          completed: completedCount,
        );
        if (isAuthor) {
          _authorBatchProgress = _authorBatchProgress?.copyWith(
            batchCurrentIndex: i + 1,
            batchCompleted: completedCount,
          );
        } else {
          _videoBatchProgress = _videoBatchProgress?.copyWith(
            batchCurrentIndex: i + 1,
            batchCompleted: completedCount,
          );
        }
      } catch (_) {}
    }

    // 保存新的成功记录到历史
    if (successRecords.isNotEmpty) {
      try {
        final provider = context.read<CrawlHistoryProvider>();
        for (final record in successRecords) {
          await provider.addRecord(record);
        }
      } catch (_) {
        try {
          final service = context.read<CrawlHistoryService>();
          for (final record in successRecords) {
            await service.addRecord(record);
          }
        } catch (_) {
          // 双重兜底：忽略历史写入失败，不影响主流程
        }
      }
    }

    // 标记批次为已完成并清除进度
    try {
      final service = context.read<CrawlHistoryService>();
      await service.markBatchCompleted(batchId);
      await service.clearBatchProgress(batchId);
    } catch (_) {}

    if (mounted) {
      setState(() {
        _setCrawling(isAuthor, false);
        _currentBatchId = null;
        if (isAuthor) {
          _authorBatchProgress = null;
        } else {
          _videoBatchProgress = null;
        }
      });
    }
  }

  /// 从历史记录中恢复指定批次
  void _resumeBatchFromHistory(CrawlRecord progress, {required bool isAuthor}) {
    if (_crawlingOf(isAuthor)) return;

    setState(() {
      if (isAuthor) {
        _authorBatchProgress = progress;
      } else {
        _videoBatchProgress = progress;
      }
    });

    // 切换到对应的 tab
    _tabController.animateTo(isAuthor ? 0 : 2);

    // 调用恢复方法
    _resumeBatchCrawl(isAuthor: isAuthor);
  }

  /// 一键恢复全部中断的批次
  Future<void> _resumeAllInterruptedBatches({required bool isAuthor}) async {
    if (_crawlingOf(isAuthor)) return;

    final provider = context.read<CrawlHistoryProvider>();
    final batches = provider.getIncompleteBatchesByType(isAuthor);
    if (batches.isEmpty) return;

    // 切换到对应的 tab
    _tabController.animateTo(isAuthor ? 0 : 2);

    // 恢复第一个批次（因为当前只能同时运行一个抓取任务）
    final firstBatch = batches.first;
    _resumeBatchFromHistory(firstBatch, isAuthor: isAuthor);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('已恢复 1 个批次，剩余 ${batches.length - 1} 个批次待处理'),
          duration: const Duration(seconds: 3),
        ),
      );
    }
  }

  // ==================== 批量结果展示 ====================

  Widget _buildBatchResultCard({required bool isAuthor}) {
    final batchResults = _batchResultsOf(isAuthor);
    final batchCurrent = _batchCurrentOf(isAuthor);
    final batchTotal = _batchTotalOf(isAuthor);
    final successCount = batchResults.where((r) => r.isSuccess).length;
    final failCount = batchResults.where((r) => !r.isSuccess).length;
    final isDone = !_crawlingOf(isAuthor);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _cardBgColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.primaryColor.withOpacity(0.3)),
        boxShadow: _cardShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                isDone ? Icons.check_circle : Icons.hourglass_bottom,
                color: isDone ? AppTheme.successColor : AppTheme.primaryColor,
                size: 20,
              ),
              const SizedBox(width: 8),
              Text(
                isDone ? '批量抓取完成' : '批量抓取中...',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: isDone ? AppTheme.successColor : AppTheme.primaryColor,
                ),
              ),
              const Spacer(),
              if (isDone) ...[
                // 右上角：复制字段
                _buildResultCopyFieldButton(isAuthor),
                const SizedBox(width: 4),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: Colors.green.withOpacity(_isDark ? 0.2 : 0.1),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    '成功 $successCount',
                    style: TextStyle(
                        fontSize: 11,
                        color: _isDark
                            ? Colors.green.shade400
                            : Colors.green.shade700),
                  ),
                ),
                const SizedBox(width: 6),
                if (failCount > 0)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.red.withOpacity(_isDark ? 0.2 : 0.1),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Text(
                      '失败 $failCount',
                      style: TextStyle(
                          fontSize: 11,
                          color: _isDark
                              ? Colors.red.shade400
                              : Colors.red.shade700),
                    ),
                  ),
              ] else
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      '$batchCurrent / $batchTotal',
                      style: TextStyle(fontSize: 12, color: _secondaryTextColor),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${_crawlSpeed.toStringAsFixed(1)} 条/秒 · 剩余${_formatRemainingTime(_crawlRemainingSeconds)}',
                      style: TextStyle(fontSize: 10, color: _mutedTextColor),
                    ),
                  ],
                ),
            ],
          ),
          const SizedBox(height: 12),
          const Divider(height: 1),
          const SizedBox(height: 8),
          SizedBox(
            height: 300,
            child: ListView.separated(
              physics: const ClampingScrollPhysics(),
              padding: const EdgeInsets.symmetric(vertical: 4),
              itemCount: batchResults.length,
              separatorBuilder: (_, __) => const Divider(height: 1, indent: 56, endIndent: 8),
              itemBuilder: (context, index) {
                final item = batchResults[index];
                return _buildBatchResultItem(item, isAuthor: isAuthor);
              },
            ),
          ),
          if (isDone && successCount > 0) ...[
            const SizedBox(height: 12),
            const Divider(height: 1),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _exportBatchCsv(isAuthor: isAuthor),
                    icon: const Icon(Icons.table_chart_outlined, size: 16),
                    label: const Text('导出CSV'),
                    style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 10)),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _exportBatchXlsx(isAuthor: isAuthor),
                    icon: const Icon(Icons.file_download_outlined, size: 16),
                    label: const Text('导出Excel'),
                    style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 10)),
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  /// 批量结果卡右上角的"复制字段"按钮
  Widget _buildResultCopyFieldButton(bool isAuthor) {
    final batchResults = _batchResultsOf(isAuthor);
    final successCount = batchResults.where((i) => i.isSuccess).length;
    if (successCount == 0) return const SizedBox.shrink();
    return InkWell(
      onTap: () => _copyBatchResultsFields(isAuthor),
      borderRadius: BorderRadius.circular(4),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
        decoration: BoxDecoration(
          color: AppTheme.primaryColor.withOpacity(_isDark ? 0.2 : 0.1),
          borderRadius: BorderRadius.circular(4),
          border: Border.all(color: AppTheme.primaryColor.withOpacity(0.4)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.content_copy, size: 11, color: AppTheme.primaryColor),
            const SizedBox(width: 3),
            Text(
              '复制字段',
              style: TextStyle(
                fontSize: 11,
                color: _isDark
                    ? AppTheme.primaryColor.withOpacity(0.9)
                    : AppTheme.primaryColorDark,
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// 批量复制结果卡中所有成功记录的某个字段
  void _copyBatchResultsFields(bool isAuthor) {
    final batchResults = _batchResultsOf(isAuthor);
    final successRecords = batchResults
        .where((i) => i.isSuccess && i.record != null)
        .map((i) => i.record!)
        .toList();
    if (successRecords.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('暂无可复制的记录')),
      );
      return;
    }
    _showHistoryCopyFieldMenu(successRecords, isAuthor: isAuthor);
  }

  Widget _buildBatchResultItem(_BatchCrawlItem item, {required bool isAuthor}) {
    if (item.isSuccess) {
      final record = item.record!;
      final thumbUrl = _recordThumbUrl(record);
      return InkWell(
        onTap: () => _showHistoryDetail(record),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
          child: Row(
            children: [
              SizedBox(
                width: 44,
                height: 44,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: thumbUrl != null && thumbUrl.isNotEmpty
                      ? Image.network(
                          thumbUrl,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) =>
                              _buildBatchResultIcon(isAuthor, true),
                        )
                      : _buildBatchResultIcon(isAuthor, true),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      record.displayTitle,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      record.displaySubtitle,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 11,
                        color: _secondaryTextColor,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Icon(Icons.check_circle, color: Colors.green.shade500, size: 18),
              const SizedBox(width: 4),
              Icon(Icons.chevron_right, color: _mutedTextColor, size: 16),
            ],
          ),
        ),
      );
    } else {
      return InkWell(
        onTap: () {
          showDialog(
            context: context,
            builder: (context) => AlertDialog(
              title: const Text('抓取失败'),
              content: Text(item.error ?? '未知错误'),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('确定'),
                ),
              ],
            ),
          );
        },
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
          child: Row(
            children: [
              SizedBox(
                width: 44,
                height: 44,
                child: _buildBatchResultIcon(isAuthor, false),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '抓取失败',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                        color: _isDark
                            ? Colors.red.shade400
                            : Colors.red.shade700,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      item.error ?? '未知错误',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 11,
                        color: _isDark
                            ? Colors.red.shade300
                            : Colors.red.shade500,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Icon(Icons.error_outline, color: Colors.red.shade500, size: 18),
            ],
          ),
        ),
      );
    }
  }

  Widget _buildBatchResultIcon(bool isAuthor, bool success) {
    return Container(
      decoration: BoxDecoration(
        color: success
            ? (isAuthor
                ? Colors.purple.withOpacity(_isDark ? 0.2 : 0.1)
                : Colors.blue.withOpacity(_isDark ? 0.2 : 0.1))
            : Colors.red.withOpacity(_isDark ? 0.2 : 0.1),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Icon(
        success
            ? (isAuthor ? Icons.person_outline : Icons.play_circle_outline)
            : Icons.close,
        color: success
            ? (isAuthor ? Colors.purple : Colors.blue)
            : Colors.red.shade400,
        size: 20,
      ),
    );
  }

  /// 批量导出 CSV 文件（UTF-8 BOM，Excel 可直接打开）
  Future<void> _exportBatchCsv({required bool isAuthor}) async {
    final batchResults = _batchResultsOf(isAuthor);
    final successItems = batchResults.where((r) => r.isSuccess).toList();
    if (successItems.isEmpty) return;

    // 获取字段配置（用于表头）- 从记录中获取平台
    final recordPlatform = successItems.first.record!.platform;
    final fieldConfigs = CrawlFieldConfigs.getFields(
      recordPlatform.isEmpty ? _selectedPlatform : recordPlatform,
      isAuthor: isAuthor,
    );
    final labelMap = {
      for (final f in fieldConfigs) f.key: f.label,
    };

    // 收集所有出现过的字段 key（按配置顺序）
    final allKeys = <String>[];
    for (final item in successItems) {
      for (final key in item.record!.data.keys) {
        if (!allKeys.contains(key)) {
          allKeys.add(key);
        }
      }
    }

    // 构建 CSV
    final buffer = StringBuffer();
    // UTF-8 BOM：保证 Excel / WPS 直接打开时中文不乱码
    buffer.write('\uFEFF');
    // 表头
    buffer.writeln(allKeys.map((k) => '"${labelMap[k] ?? k}"').join(','));
    // 数据行
    for (final item in successItems) {
      final row = allKeys.map((k) {
        final value = item.record!.data[k]?.toString() ?? '';
        return '"${value.replaceAll('"', '""').replaceAll('\n', ' ')}"';
      }).join(',');
      buffer.writeln(row);
    }

    await _saveAndShowExportedFile(
      fileName: _exportFileName(
          isAuthor ? 'author_batch${successItems.length}' : 'video_batch${successItems.length}',
          'csv'),
      bytes: utf8.encode(buffer.toString()),
      mimeType: 'text/csv',
    );
  }

  Future<void> _exportBatchXlsx({required bool isAuthor}) async {
    final batchResults = _batchResultsOf(isAuthor);
    final successItems = batchResults.where((r) => r.isSuccess).toList();
    if (successItems.isEmpty) return;

    // 获取字段配置映射 - 从记录中获取平台
    final recordPlatform = successItems.first.record!.platform;
    final fieldConfigs = CrawlFieldConfigs.getFields(
      recordPlatform.isEmpty ? _selectedPlatform : recordPlatform,
      isAuthor: isAuthor,
    );
    final labelMap = {
      for (final f in fieldConfigs) f.key: f.label,
    };

    // 收集所有出现过的字段 key
    final allKeys = <String>[];
    for (final item in successItems) {
      for (final key in item.record!.data.keys) {
        if (!allKeys.contains(key)) {
          allKeys.add(key);
        }
      }
    }

    // 构建表头
    final headers = allKeys.map((k) => labelMap[k] ?? k).toList();

    // 创建 Excel 工作簿
    final book = excel.Excel.createExcel();
    const defaultSheetName = 'Sheet1';
    final sheetName = isAuthor ? '作者信息' : '视频信息';
    book.rename(defaultSheetName, sheetName);
    final sheet = book[sheetName];

    // 表头样式
    final headerStyle = excel.CellStyle(
      bold: true,
      horizontalAlign: excel.HorizontalAlign.Center,
      verticalAlign: excel.VerticalAlign.Center,
    );

    // 写入表头
    for (var i = 0; i < headers.length; i++) {
      final cell = sheet.cell(
          excel.CellIndex.indexByColumnRow(columnIndex: i, rowIndex: 0));
      cell.value = excel.TextCellValue(headers[i]);
      cell.cellStyle = headerStyle;
    }

    // 数据样式
    final dataStyle = excel.CellStyle(
      verticalAlign: excel.VerticalAlign.Center,
      textWrapping: excel.TextWrapping.WrapText,
    );

    // 写入数据行
    for (var rowIdx = 0; rowIdx < successItems.length; rowIdx++) {
      final record = successItems[rowIdx].record!;
      for (var colIdx = 0; colIdx < allKeys.length; colIdx++) {
        final cell = sheet.cell(
            excel.CellIndex.indexByColumnRow(columnIndex: colIdx, rowIndex: rowIdx + 1));
        final value = record.data[allKeys[colIdx]]?.toString() ?? '';
        cell.value = excel.TextCellValue(value);
        cell.cellStyle = dataStyle;
      }
    }

    // 设置列宽
    try {
      for (var i = 0; i < headers.length; i++) {
        final colWidth =
            (headers[i].length * 2.0 + 4).clamp(10.0, 40.0);
        sheet.setColumnWidth(i, colWidth);
      }
    } catch (_) {}

    // 生成文件
    try {
      final bytes = book.save();
      if (bytes == null) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('生成 Excel 文件失败')),
          );
        }
        return;
      }

      await _saveAndShowExportedFile(
        fileName: _exportFileName(
            isAuthor
                ? 'author_batch${successItems.length}'
                : 'video_batch${successItems.length}',
            'xlsx'),
        bytes: bytes,
        mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('导出失败：${e.toString().replaceAll('Exception: ', '')}')),
        );
      }
    }
  }

  // ==================== 错误展示 ====================

  Widget _buildErrorCard(String error) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.red.withOpacity(_isDark ? 0.15 : 0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
            color: _isDark ? Colors.red.shade800 : Colors.red.shade200),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.error_outline,
              color: _isDark ? Colors.red.shade400 : Colors.red.shade600,
              size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              error,
              style: TextStyle(
                  color:
                      _isDark ? Colors.red.shade300 : Colors.red.shade700,
                  fontSize: 12,
                  height: 1.4),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== 结果展示 ====================

  Widget _buildResultCard(CrawlRecord record) {
    final isAuthor = record.isAuthor;

    return Consumer<CrawlHistoryProvider>(
      builder: (context, provider, child) {
        final isFavorite = provider.isFavorite(record.id);
        final showAnim = _favoriteAnimatingId == record.id;

        return GestureDetector(
          onLongPress: () => _showCrawlResultActionMenu(record),
          onDoubleTap: () => _toggleCrawlResultFavorite(record),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: _cardBgColor,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppTheme.primaryColor.withOpacity(0.3)),
              boxShadow: _cardShadow,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.check_circle, color: AppTheme.successColor, size: 20),
                    const SizedBox(width: 8),
                    Text(
                      '抓取成功',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: AppTheme.successColor,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      padding:
                          const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: isAuthor
                            ? Colors.purple.withOpacity(_isDark ? 0.2 : 0.1)
                            : Colors.blue.withOpacity(_isDark ? 0.2 : 0.1),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        record.typeLabel,
                        style: TextStyle(
                          fontSize: 11,
                          color: isAuthor ? Colors.purple : Colors.blue,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    const Spacer(),
                    // 收藏按钮（带动画）
                    AnimatedScale(
                      scale: showAnim ? 1.3 : 1.0,
                      duration: const Duration(milliseconds: 200),
                      curve: Curves.easeOutBack,
                      child: IconButton(
                        icon: Icon(
                          isFavorite ? Icons.favorite : Icons.favorite_border,
                          color: isFavorite ? Colors.red.shade400 : Colors.grey.shade400,
                          size: 20,
                        ),
                        onPressed: () => _toggleCrawlResultFavorite(record),
                        padding: EdgeInsets.zero,
                        constraints: const BoxConstraints(),
                        splashRadius: 18,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      record.platformName,
                      style: TextStyle(fontSize: 11, color: _secondaryTextColor),
                    ),
                  ],
                ),
          const SizedBox(height: 14),
          const Divider(height: 1),
          const SizedBox(height: 12),
          ...record.fields.map((f) => _buildDataRow(f.key, f.value)),
          // 抖音平台已停止对外公开播放量，避免用户误以为抓取故障
          if (!isAuthor && record.platform == 'douyin')
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.info_outline,
                      size: 12,
                      color: _isDark
                          ? Colors.orange.shade400
                          : Colors.orange.shade600),
                  const SizedBox(width: 4),
                  Expanded(
                    child: Text(
                      '抖音平台已停止对外公开播放量（仅作者本人可见），播放数无法获取时显示为 —；点赞/评论/分享/收藏不受影响',
                      style: TextStyle(
                          fontSize: 10,
                          color: _isDark
                              ? Colors.orange.shade300
                              : Colors.orange.shade700,
                          height: 1.4),
                    ),
                  ),
                ],
              ),
            ),
          const SizedBox(height: 14),
          const Divider(height: 1),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => _copyAllResult(record),
                  icon: const Icon(Icons.copy, size: 16),
                  label: const Text('复制全部'),
                  style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 10)),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => _showExportOptions(record),
                  icon: const Icon(Icons.file_download_outlined, size: 16),
                  label: const Text('导出文件'),
                  style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 10)),
                ),
              ),
            ],
          ),
        ],
      ),
          ),
        );
      },
    );
  }

  /// 抓取结果卡片 - 显示长按操作菜单
  void _showCrawlResultActionMenu(CrawlRecord record) {
    final isFav = context.read<CrawlHistoryProvider>().isFavorite(record.id);
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 12),
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: _isDark ? Colors.grey.shade700 : Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 8),
            ListTile(
              leading: const Icon(Icons.link, color: Colors.blue),
              title: const Text('复制链接'),
              onTap: () {
                Navigator.pop(context);
                Clipboard.setData(ClipboardData(text: record.url));
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('链接已复制')),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.share, color: Colors.green),
              title: const Text('分享'),
              onTap: () {
                Navigator.pop(context);
                Share.share(record.url);
              },
            ),
            ListTile(
              leading: Icon(
                isFav ? Icons.favorite : Icons.favorite_border,
                color: isFav ? Colors.red : Colors.grey,
              ),
              title: Text(isFav ? '取消收藏' : '收藏'),
              onTap: () {
                Navigator.pop(context);
                _toggleCrawlResultFavorite(record);
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete_outline, color: Colors.red),
              title: const Text('删除', style: TextStyle(color: Colors.red)),
              onTap: () async {
                Navigator.pop(context);
                final confirm = await showDialog<bool>(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: const Text('删除记录'),
                    content: const Text('确定要删除这条抓取记录吗？'),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context, false),
                        child: const Text('取消'),
                      ),
                      TextButton(
                        onPressed: () => Navigator.pop(context, true),
                        child: const Text('删除', style: TextStyle(color: Colors.red)),
                      ),
                    ],
                  ),
                );
                if (confirm == true && mounted) {
                  await context.read<CrawlHistoryProvider>().removeRecord(record.id);
                  if (mounted) {
                    setState(() {
                      _setResult(record.isAuthor, null);
                    });
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('已删除')),
                    );
                  }
                }
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  /// 抓取结果卡片 - 切换收藏状态（带动画）
  Future<void> _toggleCrawlResultFavorite(CrawlRecord record) async {
    HapticService.lightImpact();
    setState(() {
      _favoriteAnimatingId = record.id;
    });

    await context.read<CrawlHistoryProvider>().toggleFavorite(record.id);

    // 动画结束后清除状态
    Future.delayed(const Duration(milliseconds: 600), () {
      if (mounted) {
        setState(() {
          if (_favoriteAnimatingId == record.id) {
            _favoriteAnimatingId = null;
          }
        });
      }
    });
  }

  Widget _buildDataRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: InkWell(
        onTap: () {
          Clipboard.setData(ClipboardData(text: value));
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
                content: Text('已复制 $label'),
                duration: const Duration(seconds: 1)),
          );
        },
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 90,
              child: Text(
                label,
                style: TextStyle(fontSize: 12, color: _secondaryTextColor),
              ),
            ),
            Expanded(
              child: Text(
                value.isEmpty ? '-' : value,
                style: TextStyle(fontSize: 12, color: _textColor),
              ),
            ),
            const SizedBox(width: 4),
            Icon(Icons.copy, size: 12, color: _mutedTextColor),
          ],
        ),
      ),
    );
  }

  void _copyAllResult(CrawlRecord record) {
    final text =
        record.fields.map((f) => '${f.key}：${f.value}').join('\n');
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('已复制全部信息')),
    );
  }

  void _showExportOptions(CrawlRecord record) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 12),
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.grey.shade700
                      : Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              '导出格式',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 8),
            ListTile(
              leading:
                  const Icon(Icons.table_chart_outlined, color: Colors.green),
              title: const Text('导出 CSV 文件'),
              subtitle: Text(
                '保存为 .csv 文件（Download 目录），Excel / WPS 可直接打开',
                style: TextStyle(fontSize: 11, color: _secondaryTextColor),
              ),
              onTap: () {
                Navigator.pop(context);
                _exportCsv(record);
              },
            ),
            ListTile(
              leading:
                  const Icon(Icons.grid_on_outlined, color: Colors.teal),
              title: const Text('导出 Excel (.xlsx)'),
              subtitle: Text(
                '保存为标准 Excel 文件（Download 目录），支持打开和分享',
                style: TextStyle(fontSize: 11, color: _secondaryTextColor),
              ),
              onTap: () {
                Navigator.pop(context);
                _exportXlsx(record);
              },
            ),
            ListTile(
              leading:
                  const Icon(Icons.description_outlined, color: Colors.blue),
              title: const Text('导出 TXT 文本'),
              subtitle: Text(
                '保存为 .txt 文本文件（Download 目录），每行一个字段',
                style: TextStyle(fontSize: 11, color: _secondaryTextColor),
              ),
              onTap: () {
                Navigator.pop(context);
                _exportTxt(record);
              },
            ),
            ListTile(
              leading: const Icon(Icons.copy, color: Colors.purple),
              title: const Text('复制全部内容'),
              subtitle: Text(
                '直接复制到剪贴板，方便粘贴使用',
                style: TextStyle(fontSize: 11, color: _secondaryTextColor),
              ),
              onTap: () {
                Navigator.pop(context);
                _copyAllResult(record);
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  // ==================== 文件导出 ====================

  /// 生成带时间戳的导出文件名：前缀_20260815_215959.ext
  String _exportFileName(String prefix, String ext) {
    final now = DateTime.now();
    String two(int n) => n.toString().padLeft(2, '0');
    final stamp =
        '${now.year}${two(now.month)}${two(now.day)}_${two(now.hour)}${two(now.minute)}${two(now.second)}';
    return '${prefix}_$stamp.$ext';
  }

  /// 保存导出文件：公共 Download 目录 → 应用外部目录 → 临时目录 逐级兜底，
  /// 成功后弹窗展示保存位置，并提供 分享/打开 操作。
  ///
  /// 说明：不再依赖系统分享面板作为"导出成功"的判定，
  /// 文件先落盘再由用户选择是否分享，彻底解决"导出失败"和"导出变复制"问题。
  Future<void> _saveAndShowExportedFile({
    required String fileName,
    required List<int> bytes,
    required String mimeType,
  }) async {
    String? savedPath;
    String? savedDesc;

    // 1. 公共 Download 目录（文件管理器直接可见）
    if (Platform.isAndroid) {
      try {
        // Android 9 及以下需要运行时请求写权限；
        // Android 10 靠 legacy 存储 + 声明的旧权限；
        // Android 11+ 该权限自动跳过（granted），靠下面 SAF 兜底
        try {
          final ps = await Permission.storage.status;
          if (!ps.isGranted) {
            await Permission.storage.request();
          }
        } catch (_) {}

        final dir = Directory('/storage/emulated/0/Download');
        if (await dir.exists()) {
          final file = File('${dir.path}/$fileName');
          await file.writeAsBytes(bytes);
          // 写入后校验，防止部分 ROM 静默失败
          if (await file.exists() && await file.length() == bytes.length) {
            savedPath = file.path;
            savedDesc = 'Download/$fileName';
          }
        }
      } catch (_) {
        // 公共目录无权限（Android 11+ 受限存储），继续 SAF 兜底
      }
    }

    // 2. Android 11+：SAF 系统保存对话框（无需任何权限，
    //    用户自选保存位置，官方推荐的受限存储导出方式）
    if (savedPath == null && Platform.isAndroid) {
      try {
        final pickedPath = await FilePicker.platform.saveFile(
          fileName: fileName,
          bytes: Uint8List.fromList(bytes),
        );
        if (pickedPath != null && pickedPath.isNotEmpty) {
          savedPath = pickedPath;
          savedDesc = pickedPath;
        }
        // 用户取消 SAF 对话框：pickedPath 为 null，继续回退应用目录
      } catch (_) {
        // SAF 不可用（部分 ROM 精简），继续回退
      }
    }

    // 3. 应用外部文件目录（Android/data/包名/files），
    //    桌面平台（Windows/macOS/Linux）也走这里
    if (savedPath == null) {
      try {
        final Directory? dir = Platform.isAndroid
            ? await getExternalStorageDirectory()
            : await getApplicationDocumentsDirectory();
        if (dir != null) {
          if (!await dir.exists()) {
            await dir.create(recursive: true);
          }
          final file = File('${dir.path}/$fileName');
          await file.writeAsBytes(bytes);
          if (await file.exists() && await file.length() == bytes.length) {
            savedPath = file.path;
            savedDesc = file.path;
          }
        }
      } catch (_) {}
    }

    // 4. 临时目录最终兜底
    if (savedPath == null) {
      try {
        final dir = await getTemporaryDirectory();
        final file = File('${dir.path}/$fileName');
        await file.writeAsBytes(bytes);
        savedPath = file.path;
        savedDesc = file.path;
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
                content: Text('导出失败：文件写入异常（${e.toString()}）')),
          );
        }
        return;
      }
    }

    if (!mounted) return;
    _showExportedDialog(
      fileName: fileName,
      savedPath: savedPath,
      savedDesc: savedDesc ?? savedPath,
      mimeType: mimeType,
    );
  }

  /// 导出成功弹窗：显示保存路径 + 分享/打开 操作
  void _showExportedDialog({
    required String fileName,
    required String savedPath,
    required String savedDesc,
    required String mimeType,
  }) {
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.check_circle, color: Colors.green, size: 22),
            SizedBox(width: 8),
            Text('导出成功', style: TextStyle(fontSize: 17)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('文件已保存到：', style: TextStyle(fontSize: 13)),
            const SizedBox(height: 8),
            Container(
              width: double.maxFinite,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: _fillColor,
                borderRadius: BorderRadius.circular(8),
              ),
              child: SelectableText(
                savedDesc,
                style: TextStyle(
                    fontSize: 12,
                    color: _secondaryTextColor,
                    height: 1.4),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('关闭'),
          ),
          TextButton(
            onPressed: () async {
              try {
                final result = await OpenFilex.open(savedPath);
                if (result.type != ResultType.done && dialogContext.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                        content:
                            Text('打开失败：${result.message}（可用WPS/Excel手动打开）')),
                  );
                }
              } catch (e) {
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('打开失败：$e')),
                  );
                }
              }
            },
            child: const Text('打开'),
          ),
          FilledButton(
            onPressed: () async {
              try {
                // Android 上分享文件必须通过 FileProvider，
                // 先把文件复制到应用 cache 目录（FileProvider 一定授权），
                // 避免 Download/外部目录因路径不在授权范围内而分享失败
                String sharePath = savedPath;
                if (Platform.isAndroid) {
                  try {
                    final cacheDir = await getTemporaryDirectory();
                    final shareFile = File('${cacheDir.path}/$fileName');
                    if (!shareFile.path.startsWith(savedPath)) {
                      await File(savedPath).copy(shareFile.path);
                      sharePath = shareFile.path;
                    }
                  } catch (_) {
                    // 复制失败时用原路径尝试
                  }
                }
                // 使用 shareFiles（旧版稳定 API），shareXFiles 在 share_plus 4.x 上
                // 存在 MissingPluginException 兼容性问题
                await Share.shareFiles(
                  [sharePath],
                  text: fileName,
                  mimeTypes: [mimeType],
                );
              } catch (e) {
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                        content: Text('分享失败：$e（文件已保存，可手动发送）')),
                  );
                }
              }
            },
            child: const Text('分享'),
          ),
        ],
      ),
    );
  }

  Future<void> _exportCsv(CrawlRecord record) async {
    final buffer = StringBuffer();
    // UTF-8 BOM：保证 Excel / WPS 直接打开时中文不乱码
    buffer.write('\uFEFF');
    buffer.writeln('字段名,值');
    for (final f in record.fields) {
      final value = f.value.replaceAll('"', '""').replaceAll('\n', ' ');
      buffer.writeln('"${f.key}","$value"');
    }
    await _saveAndShowExportedFile(
      fileName:
          _exportFileName(record.isAuthor ? 'author_info' : 'video_info', 'csv'),
      bytes: utf8.encode(buffer.toString()),
      mimeType: 'text/csv',
    );
  }

  Future<void> _exportTxt(CrawlRecord record) async {
    final text = record.fields.map((f) => '${f.key}：${f.value}').join('\n');
    await _saveAndShowExportedFile(
      fileName:
          _exportFileName(record.isAuthor ? 'author_info' : 'video_info', 'txt'),
      bytes: utf8.encode(text),
      mimeType: 'text/plain',
    );
  }

  // ==================== Excel 导出 ====================

  Future<void> _exportXlsx(CrawlRecord record) async {
    final isAuthor = record.isAuthor;

    // 获取字段配置映射（key -> label）- 从记录中获取平台
    final recordPlatform = record.platform;
    final fieldConfigs = CrawlFieldConfigs.getFields(
      recordPlatform.isEmpty ? _selectedPlatform : recordPlatform,
      isAuthor: isAuthor,
    );
    final labelMap = {
      for (final f in fieldConfigs) f.key: f.label,
    };

    // 构建表头和数据行
    final headers = <String>[];
    final values = <String>[];

    record.data.forEach((key, value) {
      final label = labelMap[key] ?? key;
      headers.add(label);
      values.add(value?.toString() ?? '');
    });

    // 创建 Excel 工作簿
    final book = excel.Excel.createExcel();
    const defaultSheetName = 'Sheet1';
    final sheetName = isAuthor ? '作者信息' : '视频信息';

    // 重命名默认 Sheet
    book.rename(defaultSheetName, sheetName);

    // 获取 Sheet 对象
    final sheet = book[sheetName];

    // 写入表头（第一行）
    final headerStyle = excel.CellStyle(
      bold: true,
      horizontalAlign: excel.HorizontalAlign.Center,
      verticalAlign: excel.VerticalAlign.Center,
    );

    for (var i = 0; i < headers.length; i++) {
      final cell = sheet.cell(
          excel.CellIndex.indexByColumnRow(columnIndex: i, rowIndex: 0));
      cell.value = excel.TextCellValue(headers[i]);
      cell.cellStyle = headerStyle;
    }

    // 写入数据行（第二行）
    final dataStyle = excel.CellStyle(
      verticalAlign: excel.VerticalAlign.Center,
      textWrapping: excel.TextWrapping.WrapText,
    );

    for (var i = 0; i < values.length; i++) {
      final cell = sheet.cell(
          excel.CellIndex.indexByColumnRow(columnIndex: i, rowIndex: 1));
      cell.value = excel.TextCellValue(values[i]);
      cell.cellStyle = dataStyle;
    }

    // 设置列宽（自适应简单处理）
    try {
      for (var i = 0; i < headers.length; i++) {
        final colWidth =
            (headers[i].length * 2.0 + 4).clamp(10.0, 40.0);
        sheet.setColumnWidth(i, colWidth);
      }
    } catch (_) {
      // 忽略列宽设置错误
    }

    // 生成文件
    try {
      final bytes = book.save();
      if (bytes == null) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('生成 Excel 文件失败')),
          );
        }
        return;
      }

      await _saveAndShowExportedFile(
        fileName: _exportFileName(isAuthor ? 'author_info' : 'video_info', 'xlsx'),
        bytes: bytes,
        mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('导出失败：${e.toString().replaceAll('Exception: ', '')}')),
        );
      }
    }
  }

  // ==================== 前10作品模式 ====================

  Widget _buildTop10Content() {
    final keyboardHeight = MediaQuery.of(context).viewInsets.bottom;
    return RefreshIndicator(
      onRefresh: () async {
        await context.read<CrawlHistoryProvider>().loadHistory();
      },
      child: SingleChildScrollView(
        padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + keyboardHeight),
        physics: const ClampingScrollPhysics(),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildSourceSelector(),
            const SizedBox(height: 12),
            _buildTop10InputCard(),
            const SizedBox(height: 16),
            if (_top10Crawling && _top10Status != null) _buildTop10StatusCard(),
            if (_top10Error != null) _buildTop10ErrorCard(),
            if (_top10Result != null) _buildTop10ResultCard(),
            const SizedBox(height: 20),
            _buildTop10HistorySection(),
          ],
        ),
      ),
    );
  }

  Widget _buildTop10InputCard() {
    return LinkInputCard(
      controller: _top10UrlController,
      title: '前10作品',
      titleIcon: Icons.trending_up,
      hintText: '输入作者主页链接，抓取最近10条作品数据',
      showPasteButton: true,
      actions: [
        LinkInputAction(
          id: 'crawl',
          label: '开始抓取',
          icon: Icons.auto_graph,
          isPrimary: true,
          onTap: (urls) => _doCrawlTop10(),
        ),
      ],
      loadingActionId: _top10Crawling ? 'crawl' : null,
      child: Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Row(
          children: [
            Icon(Icons.info_outline, size: 14, color: _mutedTextColor),
            const SizedBox(width: 6),
            Expanded(
              child: Text(
                '当前平台：${_platforms.firstWhere((p) => p['id'] == _selectedPlatform)['name']}，抓取最近发布的10条作品并统计点赞/收藏/评论数据',
                style: TextStyle(fontSize: 12, color: _mutedTextColor),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _doCrawlTop10() async {
    final url = _top10UrlController.text.trim();
    if (url.isEmpty) {
      setState(() => _top10Error = '请输入作者主页链接');
      return;
    }

    // 平台验证
    final detected = PlatformDetector.detectPlatformId(url);
    if (detected != 'unknown' && detected != _selectedPlatform) {
      final platformName = _platforms.firstWhere(
        (p) => p['id'] == _selectedPlatform,
        orElse: () => {'name': '未知'},
      )['name'];
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('当前选中平台为「$platformName」，链接可能不匹配，可能导致抓取失败'),
          backgroundColor: Colors.orange,
          duration: const Duration(seconds: 3),
        ),
      );
    }

    setState(() {
      _top10Crawling = true;
      _top10Error = null;
      _top10Result = null;
      _top10Status = null;
      _expandedTop10Works.clear();
    });

    // 接入抓取状态回调（展示 WebView 抓取进度等提示）
    _crawlService.onCrawlStatus = (message) {
      if (!mounted) return;
      setState(() => _top10Status = message.isEmpty ? null : message);
    };

    try {
      final result = await _crawlService.crawlTop10Works(
        url,
        platform: _selectedPlatform,
      );
      if (mounted) {
        setState(() {
          _top10Result = result;
          _top10Crawling = false;
          _top10Status = null;
        });
        // 保存到历史记录
        try {
          await context.read<CrawlHistoryService>().addTop10Record(result);
          // ignore: empty_catches
        } catch (_) {}
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _top10Error = e.toString().replaceAll('CrawlException: ', '');
          _top10Crawling = false;
          _top10Status = null;
        });
      }
    } finally {
      _crawlService.onCrawlStatus = null;
    }
  }

  /// 抓取进度状态卡片（展示 WebView 抓取等阶段的实时提示）
  Widget _buildTop10StatusCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _cardBgColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.primaryColor.withOpacity(0.3)),
        boxShadow: _cardShadow,
      ),
      child: Row(
        children: [
          const SizedBox(
            width: 18,
            height: 18,
            child: CircularProgressIndicator(strokeWidth: 2.2),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              _top10Status ?? '正在抓取…',
              style: const TextStyle(fontSize: 13, height: 1.4),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTop10ErrorCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _cardBgColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.red.withOpacity(0.3)),
        boxShadow: _cardShadow,
      ),
      child: Row(
        children: [
          Icon(Icons.error_outline, color: Colors.red.shade400, size: 24),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              _top10Error ?? '抓取失败',
              style: TextStyle(color: Colors.red.shade400, fontSize: 14),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTop10ResultCard() {
    final result = _top10Result!;
    return Column(
      children: [
        // 作者信息条
        _buildTop10AuthorBar(result),
        const SizedBox(height: 12),
        // 统计卡片区域
        _buildTop10StatsCards(result),
        const SizedBox(height: 12),
        // 柱状图
        _buildTop10BarChart(result),
        const SizedBox(height: 12),
        // 作品列表
        _buildTop10WorksList(result),
        const SizedBox(height: 12),
        // 操作按钮
        _buildTop10ActionButtons(result),
      ],
    );
  }

  Widget _buildTop10AuthorBar(Top10WorksResult result) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: AppTheme.primaryGradient,
        borderRadius: BorderRadius.circular(16),
        boxShadow: _cardShadow,
      ),
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white.withOpacity(0.5), width: 2),
              color: Colors.white.withOpacity(0.2),
            ),
            child: result.authorAvatar != null && result.authorAvatar!.isNotEmpty
                ? ClipOval(
                    child: Image.network(
                      result.authorAvatar!,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => const Icon(
                        Icons.person,
                        color: Colors.white,
                        size: 28,
                      ),
                    ),
                  )
                : const Icon(Icons.person, color: Colors.white, size: 28),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  result.authorName,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        result.platformName,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      '共 ${result.workCount} 条作品',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.85),
                        fontSize: 12,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      '跨度 ${result.publishSpanDays} 天',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.85),
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              const Text(
                '抓取成功',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                _formatDateTime(result.crawledAt),
                style: TextStyle(
                  color: Colors.white.withOpacity(0.75),
                  fontSize: 11,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTop10StatsCards(Top10WorksResult result) {
    return Column(
      children: [
        Row(
          children: [
            Expanded(child: _buildStatCard(
              icon: Icons.favorite,
              label: '点赞',
              total: result.totalLikes,
              avg: result.avgLikes,
              median: result.medianLikes,
              color: const Color(0xFFFE2C55),
              gradient: const LinearGradient(
                colors: [Color(0xFFFF6B6B), Color(0xFFFE2C55)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            )),
            const SizedBox(width: 10),
            Expanded(child: _buildStatCard(
              icon: Icons.bookmark,
              label: '收藏',
              total: result.totalCollects,
              avg: result.avgCollects,
              median: result.medianCollects,
              color: const Color(0xFFF59E0B),
              gradient: const LinearGradient(
                colors: [Color(0xFFFBBF24), Color(0xFFF59E0B)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            )),
            const SizedBox(width: 10),
            Expanded(child: _buildStatCard(
              icon: Icons.comment,
              label: '评论',
              total: result.totalComments,
              avg: result.avgComments,
              median: result.medianComments,
              color: const Color(0xFF3B82F6),
              gradient: const LinearGradient(
                colors: [Color(0xFF60A5FA), Color(0xFF3B82F6)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            )),
          ],
        ),
      ],
    );
  }

  Widget _buildStatCard({
    required IconData icon,
    required String label,
    required int total,
    required double avg,
    required double median,
    required Color color,
    required Gradient gradient,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _cardBgColor,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _borderColor),
        boxShadow: _cardShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  gradient: gradient,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(icon, color: Colors.white, size: 16),
              ),
              const SizedBox(width: 6),
              Text(
                label,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: _textColor,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            Top10WorksResult.formatCount(total),
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w700,
              color: _textColor,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            '总数',
            style: TextStyle(fontSize: 11, color: _mutedTextColor),
          ),
          const SizedBox(height: 8),
          const Divider(height: 1),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      Top10WorksResult.formatDouble(avg),
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: _textColor,
                      ),
                    ),
                    const SizedBox(height: 1),
                    Text(
                      '平均',
                      style: TextStyle(fontSize: 10, color: _mutedTextColor),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      Top10WorksResult.formatDouble(median),
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: _textColor,
                      ),
                    ),
                    const SizedBox(height: 1),
                    Text(
                      '中位',
                      style: TextStyle(fontSize: 10, color: _mutedTextColor),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTop10BarChart(Top10WorksResult result) {
    final works = result.works;
    if (works.isEmpty) return const SizedBox.shrink();

    final maxLikes = works.map((w) => w.likeCount).reduce((a, b) => a > b ? a : b);
    final maxVal = maxLikes > 0 ? maxLikes : 1;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _cardBgColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _borderColor),
        boxShadow: _cardShadow,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.bar_chart, size: 18, color: AppTheme.primaryColor),
              const SizedBox(width: 6),
              Text(
                '点赞数对比',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: _textColor,
                ),
              ),
              const Spacer(),
              Text(
                '单位：${maxLikes >= 10000 ? '万' : '个'}',
                style: TextStyle(fontSize: 11, color: _mutedTextColor),
              ),
            ],
          ),
          const SizedBox(height: 14),
          SizedBox(
            height: 140,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: works.asMap().entries.map((entry) {
                final index = entry.key;
                final work = entry.value;
                final ratio = work.likeCount / maxVal;
                final barHeight = 100.0 * ratio;
                final isEven = index % 2 == 0;

                return Expanded(
                  child: Padding(
                    padding: EdgeInsets.symmetric(
                      horizontal: works.length <= 5 ? 4 : 2,
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        // 数值标签
                        Text(
                          _shortCount(work.likeCount),
                          style: TextStyle(
                            fontSize: 9,
                            fontWeight: FontWeight.w600,
                            color: _secondaryTextColor,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 4),
                        // 柱子
                        Container(
                          height: barHeight > 2 ? barHeight : 2,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: isEven
                                  ? [AppTheme.primaryColor, AppTheme.secondaryColor]
                                  : [const Color(0xFF60A5FA), const Color(0xFF3B82F6)],
                              begin: Alignment.bottomCenter,
                              end: Alignment.topCenter,
                            ),
                            borderRadius: const BorderRadius.vertical(
                              top: Radius.circular(4),
                            ),
                          ),
                        ),
                        const SizedBox(height: 4),
                        // 序号
                        Container(
                          width: 18,
                          height: 18,
                          decoration: BoxDecoration(
                            color: index == 0
                                ? AppTheme.accentColor
                                : _fillColor,
                            shape: BoxShape.circle,
                          ),
                          alignment: Alignment.center,
                          child: Text(
                            '${index + 1}',
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.w600,
                              color: index == 0 ? Colors.white : _secondaryTextColor,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  String _shortCount(int count) {
    if (count >= 10000) {
      return '${(count / 10000).toStringAsFixed(1)}w';
    }
    return count.toString();
  }

  Widget _buildTop10WorksList(Top10WorksResult result) {
    return Container(
      decoration: BoxDecoration(
        color: _cardBgColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _borderColor),
        boxShadow: _cardShadow,
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
            child: Row(
              children: [
                Icon(Icons.view_list, size: 18, color: AppTheme.primaryColor),
                const SizedBox(width: 6),
                Text(
                  '作品列表',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: _textColor,
                  ),
                ),
                const Spacer(),
                Text(
                  '共 ${result.workCount} 条',
                  style: TextStyle(fontSize: 12, color: _mutedTextColor),
                ),
              ],
            ),
          ),
          const Divider(height: 1, indent: 16, endIndent: 16),
          ...result.works.asMap().entries.map((entry) {
            final index = entry.key;
            final work = entry.value;
            final isExpanded = _expandedTop10Works.contains(work.videoId);
            return Column(
              children: [
                InkWell(
                  onTap: () {
                    setState(() {
                      if (isExpanded) {
                        _expandedTop10Works.remove(work.videoId);
                      } else {
                        _expandedTop10Works.add(work.videoId);
                      }
                    });
                  },
                  onLongPress: () => _showTop10WorkActionMenu(work, result),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    child: Row(
                      children: [
                        // 序号
                        Container(
                          width: 24,
                          height: 24,
                          decoration: BoxDecoration(
                            color: index == 0
                                ? AppTheme.accentColor
                                : index < 3
                                    ? AppTheme.primaryColor.withOpacity(0.15)
                                    : _fillColor,
                            borderRadius: BorderRadius.circular(6),
                          ),
                          alignment: Alignment.center,
                          child: Text(
                            '${index + 1}',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              color: index == 0
                                  ? Colors.white
                                  : index < 3
                                      ? AppTheme.primaryColor
                                      : _secondaryTextColor,
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        // 封面
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: work.cover.isNotEmpty
                              ? Image.network(
                                  work.cover,
                                  width: 48,
                                  height: 64,
                                  fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) => Container(
                                    width: 48,
                                    height: 64,
                                    color: _fillColor,
                                    child: Icon(Icons.video_library,
                                        size: 20, color: _mutedTextColor),
                                  ),
                                )
                              : Container(
                                  width: 48,
                                  height: 64,
                                  color: _fillColor,
                                  child: Icon(Icons.video_library,
                                      size: 20, color: _mutedTextColor),
                                ),
                        ),
                        const SizedBox(width: 10),
                        // 标题和数据
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                work.title.isEmpty ? '无标题' : work.title,
                                style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w500,
                                  color: _textColor,
                                ),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                              const SizedBox(height: 6),
                              Row(
                                children: [
                                  Icon(Icons.favorite,
                                      size: 12, color: Colors.red.shade400),
                                  const SizedBox(width: 2),
                                  Text(
                                    _shortCount(work.likeCount),
                                    style: TextStyle(
                                      fontSize: 11,
                                      color: _secondaryTextColor,
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Icon(Icons.bookmark,
                                      size: 12, color: Colors.orange.shade400),
                                  const SizedBox(width: 2),
                                  Text(
                                    _shortCount(work.collectCount),
                                    style: TextStyle(
                                      fontSize: 11,
                                      color: _secondaryTextColor,
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Icon(Icons.comment,
                                      size: 12, color: Colors.blue.shade400),
                                  const SizedBox(width: 2),
                                  Text(
                                    _shortCount(work.commentCount),
                                    style: TextStyle(
                                      fontSize: 11,
                                      color: _secondaryTextColor,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 8),
                        // 展开箭头
                        Icon(
                          isExpanded
                              ? Icons.expand_less
                              : Icons.expand_more,
                          size: 20,
                          color: _mutedTextColor,
                        ),
                      ],
                    ),
                  ),
                ),
                // 展开详情
                if (isExpanded)
                  Container(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                    color: _fillColor.withOpacity(_isDark ? 0.3 : 0.5),
                    child: Column(
                      children: [
                        const SizedBox(height: 8),
                        _buildTop10DetailRow(
                            '发布时间', _formatDateTime(work.publishTime)),
                        _buildTop10DetailRow(
                            '点赞数', Top10WorksResult.formatCount(work.likeCount)),
                        _buildTop10DetailRow(
                            '收藏数', Top10WorksResult.formatCount(work.collectCount)),
                        _buildTop10DetailRow(
                            '评论数', Top10WorksResult.formatCount(work.commentCount)),
                        if (work.shareCount != null)
                          _buildTop10DetailRow(
                              '分享数', Top10WorksResult.formatCount(work.shareCount!)),
                        if (work.playCount != null && work.playCount! > 0)
                          _buildTop10DetailRow(
                              '播放数', Top10WorksResult.formatCount(work.playCount!)),
                        _buildTop10DetailRow('作品ID', work.videoId),
                      ],
                    ),
                  ),
                if (index < result.works.length - 1)
                  const Divider(height: 1, indent: 50, endIndent: 16),
              ],
            );
          }).toList(),
        ],
      ),
    );
  }

  Widget _buildTop10DetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 70,
            child: Text(
              label,
              style: TextStyle(fontSize: 12, color: _mutedTextColor),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(fontSize: 12, color: _textColor),
            ),
          ),
        ],
      ),
    );
  }

  /// Top10作品长按快捷菜单
  void _showTop10WorkActionMenu(Top10Work work, Top10WorksResult result) {
    HapticService.mediumImpact();
    final workShareUrl = _buildWorkShareUrl(work.videoId, result.platform);
    final authorUrl = result.url;
    final isFav = false; // Top10 作品收藏状态后续可扩展

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 12),
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: _isDark ? Colors.grey.shade700 : Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 8),
            // 作品信息预览
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              child: Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: work.cover.isNotEmpty
                        ? Image.network(
                            work.cover,
                            width: 48,
                            height: 64,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Container(
                              width: 48,
                              height: 64,
                              color: _fillColor,
                              child: Icon(Icons.video_library, size: 20, color: _mutedTextColor),
                            ),
                          )
                        : Container(
                            width: 48,
                            height: 64,
                            color: _fillColor,
                            child: Icon(Icons.video_library, size: 20, color: _mutedTextColor),
                          ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          work.title.isEmpty ? '无标题' : work.title,
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: _textColor,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '${result.authorName} · ${Top10WorksResult.formatCount(work.likeCount)}赞',
                          style: TextStyle(fontSize: 12, color: _secondaryTextColor),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const Divider(height: 1, indent: 16, endIndent: 16),
            ListTile(
              leading: const Icon(Icons.title, color: Colors.blue),
              title: const Text('复制标题'),
              onTap: () {
                Navigator.pop(context);
                Clipboard.setData(ClipboardData(text: work.title));
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('标题已复制')),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.link, color: Colors.purple),
              title: const Text('复制作品链接'),
              onTap: () {
                Navigator.pop(context);
                Clipboard.setData(ClipboardData(text: workShareUrl));
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('作品链接已复制')),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.person_outline, color: Colors.teal),
              title: const Text('复制作者链接'),
              onTap: () {
                Navigator.pop(context);
                Clipboard.setData(ClipboardData(text: authorUrl));
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('作者链接已复制')),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.download_outlined, color: Colors.green),
              title: const Text('下载作品'),
              onTap: () {
                Navigator.pop(context);
                // 跳转到下载页或发起下载
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('请先解析作品链接后下载')),
                );
              },
            ),
            ListTile(
              leading: Icon(
                isFav ? Icons.favorite : Icons.favorite_border,
                color: isFav ? Colors.red : Colors.grey,
              ),
              title: Text(isFav ? '取消收藏' : '收藏作品'),
              onTap: () async {
                Navigator.pop(context);
                // 将 Top10 作品转为 CrawlRecord 并收藏
                await _favoriteTop10Work(work, result);
              },
            ),
            ListTile(
              leading: const Icon(Icons.share, color: Colors.orange),
              title: const Text('分享'),
              onTap: () {
                Navigator.pop(context);
                Share.share('${work.title}\n$workShareUrl');
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  /// 构造作品分享链接
  String _buildWorkShareUrl(String videoId, String platform) {
    switch (platform) {
      case 'douyin':
        return 'https://www.douyin.com/video/$videoId';
      case 'kuaishou':
        return 'https://www.kuaishou.com/short-video/$videoId';
      case 'xiaohongshu':
      case 'xhs':
        return 'https://www.xiaohongshu.com/discovery/item/$videoId';
      default:
        return videoId;
    }
  }

  /// 收藏 Top10 作品
  Future<void> _favoriteTop10Work(Top10Work work, Top10WorksResult result) async {
    try {
      final record = CrawlRecord(
        id: 'top10_${result.id}_${work.videoId}',
        url: _buildWorkShareUrl(work.videoId, result.platform),
        platform: result.platform,
        crawlType: 'video',
        crawledAt: DateTime.now(),
        data: {
          'videoId': work.videoId,
          'title': work.title,
          'cover': work.cover,
          'likeCount': work.likeCount,
          'collectCount': work.collectCount,
          'commentCount': work.commentCount,
          'authorUid': result.authorId,
          'authorNickname': result.authorName,
          'authorAvatar': result.authorAvatar,
          'publishTime': work.publishTime.toIso8601String(),
        },
        rawData: {
          'cover': work.cover,
          'authorAvatar': result.authorAvatar,
        },
        isFavorite: true,
        favoritedAt: DateTime.now(),
      );
      await context.read<CrawlHistoryProvider>().addRecord(record);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('已收藏')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('收藏失败：$e')),
        );
      }
    }
  }

  Widget _buildTop10ActionButtons(Top10WorksResult result) {
    return Row(
      children: [
        Expanded(
          child: OutlinedButton.icon(
            onPressed: () => _showCopyFieldMenu(result),
            icon: const Icon(Icons.content_copy, size: 18),
            label: const Text('复制字段'),
            style: OutlinedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 12),
            ),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: OutlinedButton.icon(
            onPressed: () => _exportTop10AsText(result),
            icon: const Icon(Icons.text_snippet_outlined, size: 18),
            label: const Text('导出文本'),
            style: OutlinedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 12),
            ),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: ElevatedButton.icon(
            onPressed: () => _shareTop10(result),
            icon: const Icon(Icons.share, size: 18),
            label: const Text('分享数据'),
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 12),
            ),
          ),
        ),
      ],
    );
  }

  /// 显示复制字段选项菜单
  void _showCopyFieldMenu(Top10WorksResult result) {
    final fields = <_CopyFieldOption>[
      _CopyFieldOption(label: '作品标题', icon: Icons.title, getValue: (w) => w.title.isEmpty ? '无标题' : w.title),
      _CopyFieldOption(label: '作品ID', icon: Icons.videocam, getValue: (w) => w.videoId),
      _CopyFieldOption(label: '点赞数', icon: Icons.favorite, getValue: (w) => Top10WorksResult.formatCount(w.likeCount)),
      _CopyFieldOption(label: '收藏数', icon: Icons.bookmark, getValue: (w) => Top10WorksResult.formatCount(w.collectCount)),
      _CopyFieldOption(label: '评论数', icon: Icons.comment, getValue: (w) => Top10WorksResult.formatCount(w.commentCount)),
      _CopyFieldOption(label: '发布时间', icon: Icons.schedule, getValue: (w) => _formatDateTime(w.publishTime)),
      if (result.works.any((w) => w.shareCount != null))
        _CopyFieldOption(label: '分享数', icon: Icons.share, getValue: (w) => w.shareCount != null ? Top10WorksResult.formatCount(w.shareCount!) : '-'),
      if (result.works.any((w) => w.playCount != null && w.playCount! > 0))
        _CopyFieldOption(label: '播放数', icon: Icons.play_circle, getValue: (w) => w.playCount != null ? Top10WorksResult.formatCount(w.playCount!) : '-'),
    ];

    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 12),
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 16),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                children: [
                  Icon(Icons.content_copy, size: 20),
                  SizedBox(width: 8),
                  Text(
                    '选择要复制的字段',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            ...fields.map((field) => ListTile(
                  leading: Icon(field.icon, size: 22),
                  title: Text(field.label),
                  trailing: const Icon(Icons.chevron_right, size: 20),
                  onTap: () {
                    Navigator.pop(context);
                    _copyFieldValues(result, field);
                  },
                )),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  /// 复制指定字段的所有值
  void _copyFieldValues(Top10WorksResult result, _CopyFieldOption field) {
    final values = result.works.map((w) => field.getValue(w)).toList();
    final text = values.join('\n');
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('已复制 ${values.length} 条${field.label}')),
    );
  }

  // ==================== 历史记录批量复制字段 ====================

  /// 根据字段键获取对应图标
  IconData _getIconForField(String fieldKey) {
    const iconMap = {
      // 作者相关
      'uid': Icons.perm_identity,
      'uniqueId': Icons.alternate_email,
      'nickname': Icons.person,
      'authorName': Icons.person,
      'avatar': Icons.face,
      'signature': Icons.edit_note,
      'description': Icons.description,
      'followerCount': Icons.people,
      'fansCount': Icons.people,
      'followingCount': Icons.person_add,
      'followCount': Icons.person_add,
      'totalFavorited': Icons.favorite,
      'likeCountTotal': Icons.favorite,
      'awemeCount': Icons.video_library,
      'videoCount': Icons.video_library,
      'favoriteCount': Icons.bookmark,
      // 视频相关
      'videoId': Icons.videocam,
      'awemeId': Icons.movie,
      'title': Icons.title,
      'desc': Icons.description,
      'cover': Icons.image,
      'shareUrl': Icons.link,
      'createTime': Icons.schedule,
      'publishTime': Icons.schedule,
      'duration': Icons.timer,
      'durationSeconds': Icons.timer,
      'diggCount': Icons.favorite,
      'likeCount': Icons.favorite,
      'commentCount': Icons.comment,
      'shareCount': Icons.share,
      'collectCount': Icons.bookmark,
      'playCount': Icons.play_circle,
      'downloadCount': Icons.download,
      // 作者信息（视频里的）
      'authorUid': Icons.perm_identity,
      'authorUniqueId': Icons.alternate_email,
      'authorNickname': Icons.person,
      'authorAvatar': Icons.face,
    };
    return iconMap[fieldKey] ?? Icons.text_fields;
  }

  /// 显示历史记录复制字段选项菜单
  void _showHistoryCopyFieldMenu(List<CrawlRecord> records, {required bool isAuthor}) {
    // 收集所有记录中出现的字段键（保持顺序）
    final fieldKeys = <String>[];
    final seenKeys = <String>{};
    for (final record in records) {
      record.data.keys.forEach((key) {
        if (seenKeys.add(key)) {
          fieldKeys.add(key);
        }
      });
    }

    if (fieldKeys.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('暂无可复制的字段')),
      );
      return;
    }

    final fields = fieldKeys
        .map((key) => _HistoryCopyFieldOption(
              fieldKey: key,
              label: CrawlRecord.getFieldLabel(key),
              icon: _getIconForField(key),
            ))
        .toList();

    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 12),
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                children: [
                  const Icon(Icons.content_copy, size: 20),
                  const SizedBox(width: 8),
                  const Text(
                    '选择要复制的字段',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                  const Spacer(),
                  Text(
                    '共 ${records.length} 条记录',
                    style: TextStyle(fontSize: 12, color: _secondaryTextColor),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Flexible(
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: fields.length,
                itemBuilder: (context, index) {
                  final field = fields[index];
                  return ListTile(
                    leading: Icon(field.icon, size: 22),
                    title: Text(field.label),
                    trailing: const Icon(Icons.chevron_right, size: 20),
                    onTap: () {
                      Navigator.pop(context);
                      _copyHistoryFieldValues(records, field);
                    },
                  );
                },
              ),
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  /// 复制历史记录中指定字段的所有值
  void _copyHistoryFieldValues(List<CrawlRecord> records, _HistoryCopyFieldOption field) {
    final values = <String>[];
    for (final record in records) {
      final value = record.data[field.fieldKey];
      values.add(value?.toString() ?? '-');
    }
    final text = values.join('\n');
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('已复制 ${values.length} 条${field.label}')),
    );
  }

  String _generateTop10Report(Top10WorksResult result) {
    final buf = StringBuffer();
    buf.writeln('【前10作品数据分析】');
    buf.writeln('作者：${result.authorName}');
    buf.writeln('平台：${result.platformName}');
    buf.writeln('抓取时间：${_formatDateTime(result.crawledAt)}');
    buf.writeln('作品数量：${result.workCount} 条');
    buf.writeln('发布跨度：${result.publishSpanDays} 天');
    buf.writeln('');
    buf.writeln('--- 统计数据 ---');
    buf.writeln('点赞总数：${Top10WorksResult.formatCount(result.totalLikes)}');
    buf.writeln('点赞平均：${Top10WorksResult.formatDouble(result.avgLikes)}');
    buf.writeln('点赞中位：${Top10WorksResult.formatDouble(result.medianLikes)}');
    buf.writeln('');
    buf.writeln('收藏总数：${Top10WorksResult.formatCount(result.totalCollects)}');
    buf.writeln('收藏平均：${Top10WorksResult.formatDouble(result.avgCollects)}');
    buf.writeln('收藏中位：${Top10WorksResult.formatDouble(result.medianCollects)}');
    buf.writeln('');
    buf.writeln('评论总数：${Top10WorksResult.formatCount(result.totalComments)}');
    buf.writeln('评论平均：${Top10WorksResult.formatDouble(result.avgComments)}');
    buf.writeln('评论中位：${Top10WorksResult.formatDouble(result.medianComments)}');
    buf.writeln('');
    buf.writeln('--- 作品列表 ---');
    for (var i = 0; i < result.works.length; i++) {
      final w = result.works[i];
      buf.writeln('${i + 1}. ${w.title.isEmpty ? "无标题" : w.title}');
      buf.writeln('   点赞：${Top10WorksResult.formatCount(w.likeCount)} | '
          '收藏：${Top10WorksResult.formatCount(w.collectCount)} | '
          '评论：${Top10WorksResult.formatCount(w.commentCount)}');
      buf.writeln('   发布：${_formatDateTime(w.publishTime)}');
    }
    return buf.toString();
  }

  Future<void> _exportTop10AsText(Top10WorksResult result) async {
    try {
      final text = _generateTop10Report(result);
      await Clipboard.setData(ClipboardData(text: text));
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('已复制到剪贴板')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('导出失败：$e')),
        );
      }
    }
  }

  Future<void> _shareTop10(Top10WorksResult result) async {
    try {
      final text = _generateTop10Report(result);
      await Share.share(text, subject: '${result.authorName} - 前10作品数据分析');
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('分享失败：$e')),
        );
      }
    }
  }

  Widget _buildTop10HistorySection() {
    // 前10作品历史记录：从 CrawlHistoryService 中获取 top10 类型的记录
    final provider = context.watch<CrawlHistoryProvider>();
    final top10Records = provider.records
        .where((r) => r.crawlType == 'top10')
        .toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(Icons.history, size: 18, color: _secondaryTextColor),
            const SizedBox(width: 6),
            Text(
              '抓取历史',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: _secondaryTextColor,
              ),
            ),
            const Spacer(),
            if (top10Records.isNotEmpty)
              TextButton(
                onPressed: () => _clearTop10History(),
                child: const Text('清空', style: TextStyle(fontSize: 12)),
              ),
          ],
        ),
        const SizedBox(height: 8),
        if (top10Records.isEmpty)
          EmptyState(
            iconData: Icons.history,
            title: '暂无历史记录',
            subtitle: '抓取的前10作品数据会保存在这里',
          )
        else
          ...top10Records.take(5).map((record) => _buildTop10HistoryItem(record)),
      ],
    );
  }

  Widget _buildTop10HistoryItem(CrawlRecord record) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: _cardBgColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _borderColor),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              gradient: AppTheme.primaryGradient,
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(Icons.trending_up, color: Colors.white, size: 16),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  record.data['authorName']?.toString() ?? '前10作品',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: _textColor,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 2),
                Text(
                  '${record.data['workCount'] ?? 0} 条作品 · ${_formatDateTime(record.crawledAt)}',
                  style: TextStyle(fontSize: 11, color: _mutedTextColor),
                ),
              ],
            ),
          ),
          Icon(Icons.chevron_right, size: 18, color: _mutedTextColor),
        ],
      ),
    );
  }

  void _clearTop10History() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('确认清空'),
        content: const Text('确定要清空所有前10作品抓取记录吗？'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              await context.read<CrawlHistoryProvider>().clearTop10History();
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('已清空')),
                );
              }
            },
            child: const Text('确定', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }
}

/// 批量抓取单条结果（用于 UI 展示）
class _BatchCrawlItem {
  final String url;
  final CrawlRecord? record;
  final String? error;

  _BatchCrawlItem({
    required this.url,
    this.record,
    this.error,
  });

  bool get isSuccess => record != null && error == null;
}

/// 历史记录单条显示项
class _HistorySingleItem {
  final CrawlRecord record;
  _HistorySingleItem(this.record);
}

/// 历史记录批次显示项
class _HistoryBatchItem {
  final String batchId;
  final List<CrawlRecord> records;
  _HistoryBatchItem(this.batchId, this.records);
}

/// 复制字段选项（Top10作品用）
class _CopyFieldOption {
  final String label;
  final IconData icon;
  final String Function(Top10Work work) getValue;

  const _CopyFieldOption({
    required this.label,
    required this.icon,
    required this.getValue,
  });
}

/// 历史记录复制字段选项
class _HistoryCopyFieldOption {
  final String fieldKey;
  final String label;
  final IconData icon;

  const _HistoryCopyFieldOption({
    required this.fieldKey,
    required this.label,
    required this.icon,
  });
}
