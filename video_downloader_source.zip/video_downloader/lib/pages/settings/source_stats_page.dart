import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/source_stats.dart';
import '../../providers/source_stats_provider.dart';
import '../../theme/app_theme.dart';
import '../../widgets/confirm_dialog.dart';

/// 解析源质量看板页面
class SourceStatsPage extends StatefulWidget {
  const SourceStatsPage({super.key});

  @override
  State<SourceStatsPage> createState() => _SourceStatsPageState();
}

class _SourceStatsPageState extends State<SourceStatsPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('解析源质量看板'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              context.read<SourceStatsProvider>().refresh();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('已刷新统计数据')),
              );
            },
            tooltip: '刷新',
          ),
          IconButton(
            icon: const Icon(Icons.delete_sweep_outlined),
            onPressed: () => _handleResetAll(context),
            tooltip: '重置统计',
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: '成功率'),
            Tab(text: '耗时'),
            Tab(text: '失败原因'),
          ],
        ),
      ),
      body: Consumer<SourceStatsProvider>(
        builder: (context, provider, child) {
          return Column(
            children: [
              _buildOverallStats(context, provider),
              Expanded(
                child: TabBarView(
                  controller: _tabController,
                  children: [
                    _buildSuccessRateTab(context, provider),
                    _buildDurationTab(context, provider),
                    _buildFailureReasonsTab(context, provider),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  // ==================== 总体统计 ====================

  Widget _buildOverallStats(BuildContext context, SourceStatsProvider provider) {
    final isDark = AppTheme.isDark(context);
    final rate = provider.overallSuccessRate;

    return Container(
      margin: const EdgeInsets.fromLTRB(20, 12, 20, 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: AppTheme.primaryGradient,
        borderRadius: BorderRadius.circular(AppTheme.radiusLg),
        boxShadow: AppTheme.shadowMd,
      ),
      child: Row(
        children: [
          // 大圆环
          SizedBox(
            width: 64,
            height: 64,
            child: Stack(
              alignment: Alignment.center,
              children: [
                SizedBox(
                  width: 64,
                  height: 64,
                  child: CircularProgressIndicator(
                    value: rate,
                    strokeWidth: 6,
                    backgroundColor: Colors.white.withOpacity(0.2),
                    valueColor: const AlwaysStoppedAnimation(Colors.white),
                  ),
                ),
                Text(
                  '${(rate * 100).toStringAsFixed(0)}%',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  '整体成功率',
                  style: TextStyle(
                    fontSize: 13,
                    color: Colors.white70,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '${provider.totalRequests} 次请求',
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Text(
                      '成功 ${provider.totalSuccess}',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.green.shade100,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      '失败 ${provider.totalRequests - provider.totalSuccess}',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.red.shade100,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ==================== 成功率 Tab ====================

  Widget _buildSuccessRateTab(BuildContext context, SourceStatsProvider provider) {
    final ranking = provider.successRanking;
    if (ranking.isEmpty) {
      return _buildEmptyStats(context, '暂无解析记录', '开始使用后这里会显示各源的成功率');
    }

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
      itemCount: ranking.length,
      itemBuilder: (context, index) {
        final stats = ranking[index];
        return Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: _buildSuccessRateCard(context, stats, index + 1),
        );
      },
    );
  }

  Widget _buildSuccessRateCard(BuildContext context, SourceStats stats, int rank) {
    final isDark = AppTheme.isDark(context);
    final rate = stats.successRate;
    Color barColor;
    if (rate >= 0.8) {
      barColor = AppTheme.successColor;
    } else if (rate >= 0.5) {
      barColor = AppTheme.warningColor;
    } else {
      barColor = AppTheme.errorColor;
    }

    return Container(
      decoration: BoxDecoration(
        color: AppTheme.cardBg(context),
        borderRadius: BorderRadius.circular(AppTheme.radiusLg),
        border: Border.all(
          color: isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
          width: 0.5,
        ),
        boxShadow: AppTheme.shadowSm,
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                // 排名
                Container(
                  width: 28,
                  height: 28,
                  decoration: BoxDecoration(
                    gradient: rank <= 3 ? AppTheme.primaryGradient : null,
                    color: rank <= 3 ? null : AppTheme.surfaceBg(context),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    '$rank',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: rank <= 3 ? Colors.white : AppTheme.textTertiaryColor(context),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    stats.sourceName,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      color: AppTheme.textPrimaryColor(context),
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                Text(
                  stats.successRateText,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: barColor,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            // 进度条
            ClipRRect(
              borderRadius: BorderRadius.circular(AppTheme.radiusFull),
              child: LinearProgressIndicator(
                value: rate,
                backgroundColor: AppTheme.surfaceBg(context),
                valueColor: AlwaysStoppedAnimation(barColor),
                minHeight: 8,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Text(
                  '共 ${stats.totalRequests} 次',
                  style: TextStyle(
                    fontSize: 12,
                    color: AppTheme.textTertiaryColor(context),
                  ),
                ),
                const SizedBox(width: 12),
                Text(
                  '成功 ${stats.successCount}',
                  style: TextStyle(
                    fontSize: 12,
                    color: AppTheme.successColor,
                  ),
                ),
                const SizedBox(width: 12),
                Text(
                  '失败 ${stats.failureCount}',
                  style: TextStyle(
                    fontSize: 12,
                    color: AppTheme.errorColor,
                  ),
                ),
                const Spacer(),
                Text(
                  '平均 ${stats.avgDurationText}',
                  style: TextStyle(
                    fontSize: 12,
                    color: AppTheme.textTertiaryColor(context),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ==================== 耗时 Tab ====================

  Widget _buildDurationTab(BuildContext context, SourceStatsProvider provider) {
    final ranking = provider.speedRanking;
    if (ranking.isEmpty) {
      return _buildEmptyStats(context, '暂无数据', '开始使用后这里会显示各源的耗时对比');
    }

    // 找出最长耗时用于比例计算
    final maxDuration = ranking.fold<double>(
      0,
      (max, s) => s.avgDurationMs > max ? s.avgDurationMs : max,
    );

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
      itemCount: ranking.length,
      itemBuilder: (context, index) {
        final stats = ranking[index];
        return Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: _buildDurationCard(context, stats, index + 1, maxDuration),
        );
      },
    );
  }

  Widget _buildDurationCard(
    BuildContext context,
    SourceStats stats,
    int rank,
    double maxDuration,
  ) {
    final isDark = AppTheme.isDark(context);
    final ratio = maxDuration > 0 ? stats.avgDurationMs / maxDuration : 0;

    return Container(
      decoration: BoxDecoration(
        color: AppTheme.cardBg(context),
        borderRadius: BorderRadius.circular(AppTheme.radiusLg),
        border: Border.all(
          color: isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
          width: 0.5,
        ),
        boxShadow: AppTheme.shadowSm,
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 28,
                  height: 28,
                  decoration: BoxDecoration(
                    gradient: rank <= 3 ? AppTheme.primaryGradient : null,
                    color: rank <= 3 ? null : AppTheme.surfaceBg(context),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  alignment: Alignment.center,
                  child: Icon(
                    rank == 1
                        ? Icons.flash_on
                        : (rank == 2 ? Icons.bolt : Icons.speed),
                    size: 16,
                    color: rank <= 3 ? Colors.white : AppTheme.textTertiaryColor(context),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    stats.sourceName,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      color: AppTheme.textPrimaryColor(context),
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                Text(
                  stats.avgDurationText,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: ratio < 0.5
                        ? AppTheme.successColor
                        : (ratio < 0.8 ? AppTheme.warningColor : AppTheme.errorColor),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            // 横向柱状图（从左到右，越短越快）
            Row(
              children: [
                Expanded(
                  child: LayoutBuilder(
                    builder: (context, constraints) {
                      final barWidth = constraints.maxWidth * ratio.clamp(0.1, 1.0);
                      return Stack(
                        children: [
                          Container(
                            height: 24,
                            decoration: BoxDecoration(
                              color: AppTheme.surfaceBg(context),
                              borderRadius: BorderRadius.circular(AppTheme.radiusSm),
                            ),
                          ),
                          Container(
                            width: barWidth,
                            height: 24,
                            decoration: BoxDecoration(
                              gradient: AppTheme.primaryGradientHorizontal,
                              borderRadius: BorderRadius.circular(AppTheme.radiusSm),
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Text(
                  '共 ${stats.totalRequests} 次请求',
                  style: TextStyle(
                    fontSize: 12,
                    color: AppTheme.textTertiaryColor(context),
                  ),
                ),
                const Spacer(),
                if (stats.recentDurations.isNotEmpty)
                  Text(
                    '最近平均 ${stats.recentAvgDurationMs.toStringAsFixed(0)}ms',
                    style: TextStyle(
                      fontSize: 12,
                      color: AppTheme.textSecondaryColor(context),
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ==================== 失败原因 Tab ====================

  Widget _buildFailureReasonsTab(BuildContext context, SourceStatsProvider provider) {
    final reasons = provider.allFailureReasons;
    final allStats = provider.allStats;

    if (reasons.isEmpty) {
      return _buildEmptyStats(context, '暂无失败记录', '当解析失败时，这里会统计失败原因');
    }

    final totalFailures = reasons.values.fold(0, (sum, v) => sum + v);

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
      children: [
        // 总览
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppTheme.cardBg(context),
            borderRadius: BorderRadius.circular(AppTheme.radiusLg),
            border: Border.all(
              color: AppTheme.isDark(context)
                  ? const Color(0xFF334155)
                  : const Color(0xFFE2E8F0),
              width: 0.5,
            ),
            boxShadow: AppTheme.shadowSm,
          ),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: AppTheme.errorColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(AppTheme.radiusMd),
                ),
                child: const Icon(Icons.error_outline, color: AppTheme.errorColor),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '总失败次数',
                      style: TextStyle(
                        fontSize: 12,
                        color: AppTheme.textTertiaryColor(context),
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '$totalFailures 次',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.errorColor,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        // 失败原因排行
        ...reasons.entries.map((entry) {
          final ratio = totalFailures > 0 ? entry.value / totalFailures : 0.0;
          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: _buildFailureReasonItem(
              context,
              entry.key,
              entry.value,
              ratio,
            ),
          );
        }).toList(),
        const SizedBox(height: 16),
        // 各源失败详情
        _buildSectionTitle(context, '各源失败统计'),
        const SizedBox(height: 8),
        ...allStats.where((s) => s.failureCount > 0).map((stats) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: _buildSourceFailureItem(context, stats),
          );
        }).toList(),
      ],
    );
  }

  Widget _buildFailureReasonItem(
    BuildContext context,
    String reason,
    int count,
    double ratio,
  ) {
    final isDark = AppTheme.isDark(context);
    // 简化原因显示
    final displayReason = reason.length > 50
        ? '${reason.substring(0, 50)}...'
        : reason;

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppTheme.cardBg(context),
        borderRadius: BorderRadius.circular(AppTheme.radiusMd),
        border: Border.all(
          color: isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
          width: 0.5,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  displayReason,
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                    color: AppTheme.textPrimaryColor(context),
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Text(
                '$count 次',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.errorColor,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(AppTheme.radiusFull),
            child: LinearProgressIndicator(
              value: ratio,
              backgroundColor: AppTheme.surfaceBg(context),
              valueColor: const AlwaysStoppedAnimation(AppTheme.errorColor),
              minHeight: 6,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            '占比 ${(ratio * 100).toStringAsFixed(1)}%',
            style: TextStyle(
              fontSize: 11,
              color: AppTheme.textTertiaryColor(context),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSourceFailureItem(BuildContext context, SourceStats stats) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: AppTheme.surfaceBg(context),
        borderRadius: BorderRadius.circular(AppTheme.radiusMd),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              stats.sourceName,
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: AppTheme.textPrimaryColor(context),
              ),
            ),
          ),
          Text(
            '${stats.failureCount} 次失败',
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: AppTheme.errorColor,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(BuildContext context, String title) {
    return Row(
      children: [
        Container(
          width: 3,
          height: 14,
          decoration: BoxDecoration(
            gradient: AppTheme.primaryGradient,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 8),
        Text(
          title,
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w700,
            color: AppTheme.textSecondaryColor(context),
          ),
        ),
      ],
    );
  }

  // ==================== 空状态 ====================

  Widget _buildEmptyStateWidget(
    BuildContext context,
    IconData icon,
    String title,
    String subtitle,
  ) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            size: 64,
            color: AppTheme.textMuted,
          ),
          const SizedBox(height: 16),
          Text(
            title,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: AppTheme.textSecondaryColor(context),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            subtitle,
            style: TextStyle(
              fontSize: 13,
              color: AppTheme.textTertiaryColor(context),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyStats(BuildContext context, String title, String subtitle) {
    return _buildEmptyStateWidget(
      context,
      Icons.bar_chart_outlined,
      title,
      subtitle,
    );
  }

  // ==================== 操作 ====================

  Future<void> _handleResetAll(BuildContext context) async {
    final confirmed = await showConfirmDialog(
      context,
      title: '重置统计数据',
      content: '确定要重置所有解析源的统计数据吗？重置后将无法恢复。',
      confirmText: '重置',
      isDestructive: true,
    );
    if (confirmed == true && context.mounted) {
      await context.read<SourceStatsProvider>().resetAll();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('统计数据已重置')),
      );
    }
  }
}
