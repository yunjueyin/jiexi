import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/settings_provider.dart';
import '../../theme/app_theme.dart';
import '../../widgets/frosted_app_bar.dart';

/// 手势设置页面
///
/// 合并了「双指手势」「摇一摇解析」「重压快捷」「重置手势提示」
/// 四个设置项，方便用户在同一页面统一管理手势相关功能。
class GestureSettingsPage extends StatefulWidget {
  const GestureSettingsPage({super.key});

  @override
  State<GestureSettingsPage> createState() => _GestureSettingsPageState();
}

class _GestureSettingsPageState extends State<GestureSettingsPage> {
  @override
  Widget build(BuildContext context) {
    final isDark = AppTheme.isDark(context);
    final borderColor = isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0);

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: const FrostedAppBar(
        title: '手势设置',
      ),
      body: ListView(
        padding: EdgeInsets.fromLTRB(20, MediaQuery.of(context).padding.top + kToolbarHeight + 16, 20, 32),
        children: [
          _buildSectionTitle('手势操作'),
          const SizedBox(height: 8),
          _buildSettingsGroup([
            _buildTwoFingerGestureTile(),
            _buildShakeToParseTile(),
            _buildForceTouchTile(),
          ]),
          const SizedBox(height: 24),
          _buildSectionTitle('其他'),
          const SizedBox(height: 8),
          _buildSettingsGroup([
            _buildResetGestureHintsTile(),
          ]),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 0, 4, 0),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w600,
          color: AppTheme.textSecondaryColor(context),
        ),
      ),
    );
  }

  Widget _buildSettingsGroup(List<Widget> children) {
    final isDark = AppTheme.isDark(context);
    final borderColor = isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0);

    return Container(
      decoration: BoxDecoration(
        color: AppTheme.cardBg(context),
        borderRadius: BorderRadius.circular(AppTheme.radiusLg),
        border: Border.all(color: borderColor, width: 0.5),
        boxShadow: AppTheme.shadowSm,
      ),
      clipBehavior: Clip.antiAlias,
      child: IconTheme(
        data: IconThemeData(
          size: 22,
          color: AppTheme.primaryColor,
        ),
        child: Column(
          children: List.generate(children.length * 2 - 1, (index) {
            if (index.isEven) {
              return children[index ~/ 2];
            } else {
              return Divider(
                height: 0.5,
                thickness: 0.5,
                indent: 56,
                endIndent: 16,
                color: borderColor,
              );
            }
          }),
        ),
      ),
    );
  }

  /// 双指手势
  Widget _buildTwoFingerGestureTile() {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        return SwitchListTile(
          secondary: const Icon(Icons.pan_tool_outlined),
          title: const Text('双指手势'),
          subtitle: const Text('双指缩放切换布局密度，双指下滑进入搜索'),
          value: settings.twoFingerGestureEnabled,
          onChanged: (value) => settings.setTwoFingerGestureEnabled(value),
        );
      },
    );
  }

  /// 摇一摇解析
  Widget _buildShakeToParseTile() {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        return SwitchListTile(
          secondary: const Icon(Icons.screen_rotation_outlined),
          title: const Text('摇一摇解析'),
          subtitle: const Text('在首页摇一摇手机，自动读取剪贴板并解析'),
          value: settings.shakeToParseEnabled,
          onChanged: (value) => settings.setShakeToParseEnabled(value),
        );
      },
    );
  }

  /// 重压快捷菜单
  Widget _buildForceTouchTile() {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        return SwitchListTile(
          secondary: const Icon(Icons.touch_app_outlined),
          title: const Text('重压快捷菜单'),
          subtitle: const Text('长按列表项和结果卡片弹出快捷操作菜单'),
          value: settings.forceTouchEnabled,
          onChanged: (value) => settings.setForceTouchEnabled(value),
        );
      },
    );
  }

  /// 重置手势提示
  Widget _buildResetGestureHintsTile() {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        return ListTile(
          leading: const Icon(Icons.tips_and_updates_outlined),
          title: const Text('重置手势提示'),
          subtitle: const Text('重新显示所有页面的手势操作提示'),
          trailing: const Icon(Icons.refresh),
          onTap: () async {
            await settings.resetGestureHints();
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('手势提示已重置，下次进入页面时会重新显示'),
                  duration: Duration(seconds: 2),
                ),
              );
            }
          },
        );
      },
    );
  }
}
