import 'dart:io';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:file_picker/file_picker.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'package:cross_file/cross_file.dart';
import '../../providers/settings_provider.dart';
import '../../providers/download_provider.dart';
import '../../providers/cookie_provider.dart';
import '../../providers/custom_source_provider.dart';
import '../../providers/source_stats_provider.dart';
import '../../providers/crawl_history_provider.dart';
import '../../theme/app_theme.dart';
import '../../theme/app_colors.dart';
import '../../widgets/frosted_app_bar.dart';
import '../../models/api_source.dart';
import 'webview_cookie_page.dart';
import 'cookie_manager_page.dart';
import 'custom_sources_page.dart';
import 'source_stats_page.dart';
import 'bottom_nav_management_page.dart';
import 'storage_rules_page.dart';
import 'gesture_settings_page.dart';
import 'nav_quick_actions_page.dart';
import '../lock/lock_page.dart';
import '../../providers/privacy_lock_provider.dart';
import '../../utils/page_route.dart';
import '../../services/proxy_service.dart';
import '../../services/data_backup_service.dart';
import '../../services/crawl_history_service.dart';
import '../../services/history_service.dart';
import '../../services/custom_source_service.dart';
import '../../services/settings_service.dart';
import '../../services/quick_actions_service.dart';
import '../../services/search_history_service.dart';
import '../guide/guide_page.dart';
import 'about_page.dart';

class SettingsPage extends StatefulWidget {
  /// 初始滚动到的设置项 key（用于从其他页面跳转定位）
  final String? initialSection;

  const SettingsPage({super.key, this.initialSection});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  static const String _appVersion = '2.1.0';

  /// 预览卡片是否展开
  bool _previewCardExpanded = true;

  /// 搜索控制器
  final TextEditingController _searchController = TextEditingController();

  /// 搜索框焦点节点
  final FocusNode _searchFocusNode = FocusNode();

  /// 当前搜索词
  String _searchQuery = '';

  /// 搜索历史服务
  final SearchHistoryService _searchHistoryService = SearchHistoryService();

  /// 搜索历史列表
  List<String> _searchHistory = [];

  /// 是否显示搜索历史
  bool _showSearchHistory = false;

  /// 搜索历史服务是否已初始化
  bool _searchHistoryInited = false;

  /// 滚动控制器
  final ScrollController _scrollController = ScrollController();

  /// 常用设置点击次数（本地缓存，用于排序）
  Map<String, int> _quickSettingClickCounts = {};

  /// 各设置项的 GlobalKey，用于滚动定位
  final Map<String, GlobalKey> _sectionKeys = {
    'api_source': GlobalKey(),
    'download_path': GlobalKey(),
    'download_concurrency': GlobalKey(),
    'dark_mode': GlobalKey(),
    'privacy_lock': GlobalKey(),
    'proxy': GlobalKey(),
  };

  /// 是否为桌面端平台
  bool get _isDesktop {
    if (kIsWeb) return true;
    return Platform.isLinux || Platform.isWindows || Platform.isMacOS;
  }

  @override
  void initState() {
    super.initState();
    // 初始化搜索历史服务
    _initSearchHistory();
    // 监听搜索框焦点变化
    _searchFocusNode.addListener(_onSearchFocusChanged);
    // 延迟初始化控制器（等待 Provider 可用）
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final settings = context.read<SettingsProvider>();
      _proxyHostController.text = settings.proxyHost;
      _proxyPortController.text = settings.proxyPort.toString();
      _proxyUserController.text = settings.proxyUsername ?? '';
      _proxyPassController.text = settings.proxyPassword ?? '';

      // 加载常用设置点击次数
      _quickSettingClickCounts = Map.from(settings.quickSettingClickCounts);

      // 如果指定了初始 section，滚动到对应位置
      if (widget.initialSection != null) {
        _scrollToSection(widget.initialSection!);
      }
    });
  }

  /// 初始化搜索历史服务
  Future<void> _initSearchHistory() async {
    await _searchHistoryService.init();
    if (mounted) {
      setState(() {
        _searchHistory = _searchHistoryService.history;
        _searchHistoryInited = true;
      });
    }
  }

  /// 搜索框焦点变化回调
  void _onSearchFocusChanged() {
    if (_searchFocusNode.hasFocus && _searchQuery.isEmpty && _searchHistory.isNotEmpty) {
      setState(() {
        _showSearchHistory = true;
      });
    } else {
      setState(() {
        _showSearchHistory = false;
      });
    }
  }

  /// 执行搜索
  void _performSearch(String query) {
    final trimmed = query.trim();
    if (trimmed.isNotEmpty) {
      _searchHistoryService.addHistory(trimmed).then((_) {
        if (mounted) {
          setState(() {
            _searchHistory = _searchHistoryService.history;
          });
        }
      });
    }
    setState(() {
      _searchQuery = trimmed;
      _showSearchHistory = false;
    });
    _searchFocusNode.unfocus();
  }

  /// 点击历史记录项
  void _onHistoryItemTap(String keyword) {
    _searchController.text = keyword;
    _searchController.selection = TextSelection.fromPosition(
      TextPosition(offset: keyword.length),
    );
    _performSearch(keyword);
  }

  /// 删除单条历史记录
  Future<void> _deleteHistoryItem(String keyword) async {
    await _searchHistoryService.removeHistory(keyword);
    if (mounted) {
      setState(() {
        _searchHistory = _searchHistoryService.history;
        if (_searchHistory.isEmpty) {
          _showSearchHistory = false;
        }
      });
    }
  }

  /// 清空所有搜索历史
  Future<void> _clearAllHistory() async {
    await _searchHistoryService.clearHistory();
    if (mounted) {
      setState(() {
        _searchHistory = [];
        _showSearchHistory = false;
      });
    }
  }

  /// 滚动到指定设置项
  void _scrollToSection(String key) {
    final sectionKey = _sectionKeys[key];
    if (sectionKey == null) return;
    final context = sectionKey.currentContext;
    if (context == null) {
      // 可能还没渲染完成，延迟再试（最多重试 5 次）
      _retryScrollCount++;
      if (_retryScrollCount <= 5) {
        Future.delayed(const Duration(milliseconds: 100), () {
          _scrollToSection(key);
        });
      } else {
        _retryScrollCount = 0;
      }
      return;
    }
    _retryScrollCount = 0;

    // 优先通过 Scrollable.ensureVisible 滚动
    Scrollable.ensureVisible(
      context,
      duration: const Duration(milliseconds: 500),
      curve: Curves.easeOutCubic,
      alignment: 0.1,
    ).then((_) {
      // 滚动完成后添加短暂高亮效果
      _highlightSection(key);
    });
  }

  int _retryScrollCount = 0;

  /// 高亮指定设置项（短暂显示高亮背景）
  void _highlightSection(String key) {
    // 这里可以扩展：添加临时高亮背景动画
    // 目前通过滚动定位本身就足够引导用户注意力
  }

  @override
  void dispose() {
    _searchController.dispose();
    _searchFocusNode.removeListener(_onSearchFocusChanged);
    _searchFocusNode.dispose();
    _scrollController.dispose();
    _proxyHostController.dispose();
    _proxyPortController.dispose();
    _proxyUserController.dispose();
    _proxyPassController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isSearching = _searchQuery.isNotEmpty;
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: const FrostedAppBar(
        title: '设置',
      ),
      body: Column(
        children: [
          // 搜索栏
          _buildSearchBar(),
          // 搜索历史列表
          if (_showSearchHistory && _searchHistory.isNotEmpty) _buildSearchHistoryList(),
          // 列表内容
          Expanded(
            child: isSearching
                ? _buildSearchResults()
                : _buildSettingsList(),
          ),
        ],
      ),
    );
  }

  /// 懒加载设置列表
  Widget _buildSettingsList() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
      child: CustomScrollView(
        controller: _scrollController,
        cacheExtent: 80,
        slivers: _buildSlivers(),
      ),
    );
  }

  /// 构建设置页 slivers（逐项懒加载 + RepaintBoundary 隔离重绘）
  List<Widget> _buildSlivers() {
    final isDesktop = _isDesktop;
    final slivers = <Widget>[];

    void spacer(double h) {
      slivers.add(SliverToBoxAdapter(child: SizedBox(height: h)));
    }

    void item(Widget w) {
      slivers.add(SliverToBoxAdapter(child: RepaintBoundary(child: w)));
    }

    void header(IconData icon, String title, List<Color> gradient) {
      slivers.add(
        SliverToBoxAdapter(
          child: RepaintBoundary(
            child: _buildSectionHeader(icon: icon, title: title, gradient: gradient),
          ),
        ),
      );
    }

    void group(List<Widget> children) {
      for (var i = 0; i < children.length; i++) {
        item(children[i]);
        if (i < children.length - 1) {
          item(const Divider(height: 1, thickness: 0.5, indent: 56, endIndent: 16));
        }
      }
    }

    // 常用设置快速入口
    spacer(4);
    item(Padding(padding: const EdgeInsets.only(bottom: 4), child: _buildQuickSettingsCard()));

    // 通用设置
    spacer(20);
    header(Icons.settings_outlined, '通用设置', [AppTheme.primaryColor, AppTheme.secondaryColor]);
    group([
      SizedBox(key: _sectionKeys['api_source'], child: _buildApiSourceSetting(context)),
      _buildCustomSourcesEntry(context),
      _buildSourceStatsEntry(context),
      _buildClipboardSettingsEntry(context),
      _buildRetrySettingsEntry(context),
      _buildCrawlTimingEntry(context),
      _buildAutoRetrySetting(context),
      if (!isDesktop) _buildHapticFeedbackSetting(context),
    ]);
    spacer(12);
    item(SizedBox(key: _sectionKeys['proxy'], child: _buildProxySetting(context)));

    // 下载设置
    spacer(20);
    header(Icons.download_outlined, '下载设置', [AppTheme.infoColor, const Color(0xFF0EA5E9)]);
    group([
      _buildQualitySetting(context),
      SizedBox(key: _sectionKeys['download_path'], child: _buildDownloadPathSetting(context)),
      _buildStorageRulesEntry(context),
      _buildWifiOnlySetting(context),
      _buildSmartDownloadEntry(context),
      SizedBox(key: _sectionKeys['download_concurrency'], child: _buildDownloadConcurrencySetting(context)),
      _buildDownloadReminderEntry(context),
      _buildAutoSaveToGallerySetting(context),
      _buildDefaultAudioFormatSetting(context),
      _buildAutoCleanDownloadsSetting(context),
    ]);

    // 设置实时预览卡片
    spacer(24);
    item(_buildSettingsPreviewCard(context));

    // 外观显示
    spacer(24);
    header(Icons.palette_outlined, '外观显示', [const Color(0xFF6366F1), const Color(0xFF8B5CF6)]);
    group([
      _buildUiDensityEntry(context),
      _buildFontSettingsEntry(context),
      SizedBox(key: _sectionKeys['theme_color'], child: _buildThemeColorSetting(context)),
      SizedBox(key: _sectionKeys['dark_mode'], child: _buildDarkModeSetting(context)),
      _buildParallaxSetting(context),
      if (!isDesktop) _buildGestureSettingsEntry(context),
      if (!isDesktop) _buildNavQuickActionsEntry(context),
    ]);

    // 隐私安全
    spacer(24);
    header(Icons.security_outlined, '隐私安全', [Colors.orange, Colors.deepOrange]);
    group([
      _buildDouyinAdvancedSection(context),
      _buildCookieManagerEntry(context),
      SizedBox(key: _sectionKeys['privacy_lock'], child: _buildPrivacyLockSetting(context)),
    ]);

    // 数据管理
    spacer(24);
    header(Icons.backup_outlined, '数据管理', [const Color(0xFF8B5CF6), const Color(0xFF6366F1)]);
    group([
      _buildExportDataTile(context),
      _buildImportDataTile(context),
      _buildClearAllDataTile(context),
    ]);

    // 关于
    spacer(24);
    header(Icons.info_outline, '关于', [AppTheme.successColor, const Color(0xFF059669)]);
    group([
      _buildViewGuideTile(context),
      _buildClearCacheTile(context),
      _buildAboutTile(context),
    ]);

    return slivers;
  }

  // ============================================================
  // 搜索功能
  // ============================================================

  /// 搜索关键词映射：设置项标识 -> 关键词列表
  Map<String, List<String>> get _settingSearchKeys => {
        'api_source': ['解析源', 'API', '接口', '第三方'],
        'custom_sources': ['自定义源', '自定义解析', '添加源'],
        'source_stats': ['统计', '看板', '成功率', '数据源'],
        'clipboard_settings': ['剪贴板', '自动解析', '粘贴', '检测', '提示'],
        'auto_parse_clipboard': ['剪贴板', '自动解析', '粘贴'],
        'clipboard_detection': ['剪贴板', '检测', '提示'],
        'retry_settings': ['重试', '解析重试', '抓取重试', '失败重试'],
        'parse_retry': ['重试', '解析失败', '失败重试'],
        'crawl_retry': ['抓取重试', '失败重试', '抓取'],
        'crawl_timing': ['抓取间隔', '抓取抖动', '间隔', '延迟', '随机'],
        'crawl_interval': ['抓取间隔', '间隔', '延迟'],
        'crawl_jitter': ['抖动', '随机', '间隔'],
        'auto_retry': ['自动重试', '下载重试', '失败重试'],
        'haptic_feedback': ['震动', '触觉', '反馈', '振动'],
        'download_quality': ['画质', '清晰度', '质量'],
        'download_path': ['下载路径', '保存位置', '目录', '文件夹'],
        'storage_rules': ['存储规则', '分类存储', '命名规则', '文件夹', '文件名'],
        'storage_mode': ['分类存储', '智能分类', '文件夹'],
        'storage_naming': ['命名规则', '文件名', '命名'],
        'wifi_only': ['仅WiFi', '流量', '移动网络'],
        'smart_download': ['智能下载', '自动下载', '分享', '自动粘贴'],
        'auto_download_share': ['自动下载', '分享', '自动'],
        'auto_paste_download': ['自动粘贴', '一键下载', '粘贴'],
        'download_concurrency': ['并发', '同时下载', '多线程'],
        'download_reminder': ['下载提醒', '提示音', '通知', '下载完成', '完成动作'],
        'download_sound': ['提示音', '声音', '完成音'],
        'download_complete_action': ['完成动作', '下载完成', '自动打开'],
        'download_notification': ['通知', '状态栏', '提示'],
        'default_audio_format': ['音频格式', 'mp3', 'm4a', '音频'],
        'proxy': ['代理', 'proxy', '网络代理', 'HTTP'],
        'ui_density_entry': ['界面密度', '密度', '紧凑', '宽松', 'UI', '紧凑列表'],
        'ui_density': ['密度', '紧凑', '宽松', 'UI'],
        'font_settings': ['字体设置', '字体大小', '大字体', '字号', '文字'],
        'font_size': ['字体', '字号', '大小', '文字'],
        'dark_mode': ['深色模式', '夜间模式', '主题', 'OLED'],
        'theme_color': ['主题色', '颜色', '配色', '色调', '主题颜色'],
        'parallax': ['视差', '滚动', '动画'],
        'gesture_settings': ['手势设置', '双指', '摇一摇', '重按', '3D Touch', '手势提示'],
        'two_finger_gesture': ['双指', '手势', '快捷'],
        'shake_to_parse': ['摇一摇', '摇动', '摇一摇解析'],
        'force_touch': ['重按', '3D Touch', '重压', '快捷菜单'],
        'nav_quick_actions': ['导航', '快捷方式', '底部导航', '桌面快捷', '导航管理'],
        'bottom_nav_manage': ['底部导航', '导航管理', '自定义导航'],
        'bottom_nav_management': ['底部导航', '导航栏', '管理'],
        'reset_gesture_hints': ['重置提示', '手势提示', '引导'],
        'douyin_cookie': ['Cookie', '抖音', '登录', 'cookies'],
        'cookie_manager': ['Cookie管理', 'cookies', '配置'],
        'privacy_lock': ['隐私锁', '密码', '生物识别', '加密'],
        'guide': ['新手引导', '引导', '使用说明', '教程'],
      };

  /// 构建搜索栏
  Widget _buildSearchBar() {
    final isDark = AppTheme.isDark(context);
    return Container(
      padding: EdgeInsets.fromLTRB(20, MediaQuery.of(context).padding.top + kToolbarHeight + 8, 20, 12),
      decoration: BoxDecoration(
        color: AppTheme.cardBg(context),
        border: Border(
          bottom: BorderSide(
            color: AppTheme.borderColor(context),
            width: 0.5,
          ),
        ),
      ),
      child: Container(
        height: 40,
        decoration: BoxDecoration(
          color: isDark ? const Color(0xFF1E293B) : const Color(0xFFF1F5F9),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          children: [
            const SizedBox(width: 12),
            Icon(
              Icons.search,
              size: 20,
              color: AppTheme.textTertiaryColor(context),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: TextField(
                controller: _searchController,
                focusNode: _searchFocusNode,
                textInputAction: TextInputAction.search,
                onChanged: (value) {
                  setState(() {
                    _searchQuery = value.trim();
                  });
                  // 输入时隐藏历史记录
                  if (_showSearchHistory && value.trim().isNotEmpty) {
                    setState(() {
                      _showSearchHistory = false;
                    });
                  }
                },
                onSubmitted: (value) {
                  _performSearch(value);
                },
                decoration: InputDecoration(
                  hintText: '搜索设置...',
                  hintStyle: TextStyle(
                    color: AppTheme.textTertiaryColor(context),
                    fontSize: 14,
                  ),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(vertical: 10),
                ),
                style: TextStyle(
                  fontSize: 14,
                  color: AppTheme.textPrimaryColor(context),
                ),
              ),
            ),
            if (_searchQuery.isNotEmpty)
              GestureDetector(
                onTap: _clearSearch,
                child: Padding(
                  padding: const EdgeInsets.only(right: 12),
                  child: Icon(
                    Icons.cancel,
                    size: 18,
                    color: AppTheme.textTertiaryColor(context),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  /// 清除搜索
  void _clearSearch() {
    _searchController.clear();
    setState(() {
      _searchQuery = '';
    });
    // 清空后如果搜索框有焦点且有历史记录，显示历史记录
    if (_searchFocusNode.hasFocus && _searchHistory.isNotEmpty) {
      setState(() {
        _showSearchHistory = true;
      });
    }
  }

  /// 构建搜索历史列表
  Widget _buildSearchHistoryList() {
    final isDark = AppTheme.isDark(context);
    return Container(
      constraints: const BoxConstraints(maxHeight: 300),
      decoration: BoxDecoration(
        color: AppTheme.cardBg(context),
        border: Border(
          bottom: BorderSide(
            color: AppTheme.borderColor(context),
            width: 0.5,
          ),
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // 标题行
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 12, 12, 8),
            child: Row(
              children: [
                Icon(
                  Icons.history,
                  size: 16,
                  color: AppTheme.textTertiaryColor(context),
                ),
                const SizedBox(width: 8),
                Text(
                  '搜索历史',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                    color: AppTheme.textSecondaryColor(context),
                  ),
                ),
                const Spacer(),
                TextButton(
                  onPressed: _clearAllHistory,
                  style: TextButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    minimumSize: Size.zero,
                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  ),
                  child: Text(
                    '清空',
                    style: TextStyle(
                      fontSize: 12,
                      color: AppTheme.textTertiaryColor(context),
                    ),
                  ),
                ),
              ],
            ),
          ),
          // 历史记录列表
          Flexible(
            child: ListView.builder(
              shrinkWrap: true,
              padding: const EdgeInsets.symmetric(horizontal: 8),
              itemCount: _searchHistory.length,
              itemBuilder: (context, index) {
                final keyword = _searchHistory[index];
                return _buildHistoryItem(keyword, isDark);
              },
            ),
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }

  /// 构建单条历史记录项
  Widget _buildHistoryItem(String keyword, bool isDark) {
    return InkWell(
      onTap: () => _onHistoryItemTap(keyword),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        child: Row(
          children: [
            Icon(
              Icons.history,
              size: 16,
              color: AppTheme.textTertiaryColor(context),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                keyword,
                style: TextStyle(
                  fontSize: 14,
                  color: AppTheme.textPrimaryColor(context),
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            GestureDetector(
              onTap: () => _deleteHistoryItem(keyword),
              child: Padding(
                padding: const EdgeInsets.all(4),
                child: Icon(
                  Icons.close,
                  size: 16,
                  color: AppTheme.textTertiaryColor(context),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  //  常用设置快速入口
  // ============================================================

  /// 常用设置快速入口卡片
  Widget _buildQuickSettingsCard() {
    final isDark = AppTheme.isDark(context);
    final settings = context.read<SettingsProvider>();

    // 定义常用设置项
    final items = <_QuickSettingItem>[
      _QuickSettingItem(
        icon: Icons.public_outlined,
        label: '解析源',
        gradient: [AppTheme.primaryColor, AppTheme.secondaryColor],
        sectionKey: 'api_source',
        onTap: () => _showApiSourceDialog(context),
      ),
      _QuickSettingItem(
        icon: Icons.folder_outlined,
        label: '下载路径',
        gradient: [AppTheme.infoColor, const Color(0xFF0EA5E9)],
        sectionKey: 'download_path',
        onTap: () => _showDownloadPathDialog(context),
      ),
      _QuickSettingItem(
        icon: Icons.speed_outlined,
        label: '并发数',
        gradient: [const Color(0xFF8B5CF6), const Color(0xFF6366F1)],
        sectionKey: 'download_concurrency',
        onTap: () => _scrollToSection('download_concurrency'),
      ),
      _QuickSettingItem(
        icon: Icons.dark_mode_outlined,
        label: '深色模式',
        gradient: [const Color(0xFF6366F1), const Color(0xFF4F46E5)],
        sectionKey: 'dark_mode',
        onTap: () => _showThemeModeDialog(context),
      ),
      if (!_isDesktop)
        _QuickSettingItem(
          icon: Icons.lock_outlined,
          label: '隐私锁',
          gradient: [Colors.orange, Colors.deepOrange],
          sectionKey: 'privacy_lock',
          onTap: () => _scrollToSection('privacy_lock'),
        ),
      _QuickSettingItem(
        icon: Icons.cloud_outlined,
        label: '代理设置',
        gradient: [const Color(0xFF14B8A6), const Color(0xFF0D9488)],
        sectionKey: 'proxy',
        onTap: () => _scrollToSection('proxy'),
      ),
    ];

    // 按点击次数排序（降序），点击次数相同则保持原顺序
    items.sort((a, b) {
      final countA = _quickSettingClickCounts[a.sectionKey] ?? 0;
      final countB = _quickSettingClickCounts[b.sectionKey] ?? 0;
      return countB.compareTo(countA);
    });

    // 包装 onTap，增加点击统计
    final wrappedItems = items.map((item) {
      return _QuickSettingItem(
        icon: item.icon,
        label: item.label,
        gradient: item.gradient,
        sectionKey: item.sectionKey,
        onTap: () async {
          // 更新本地点击计数并刷新 UI
          setState(() {
            _quickSettingClickCounts[item.sectionKey] =
                (_quickSettingClickCounts[item.sectionKey] ?? 0) + 1;
          });
          // 异步持久化到存储
          settings.incrementQuickSettingClick(item.sectionKey);
          // 执行原始操作
          item.onTap();
        },
      );
    }).toList();

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.cardBg(context),
        borderRadius: BorderRadius.circular(AppTheme.radiusLg),
        border: Border.all(
          color: isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
          width: 0.5,
        ),
        boxShadow: AppTheme.shadowSm,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 4,
                height: 16,
                decoration: BoxDecoration(
                  gradient: AppTheme.primaryGradient,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(width: 8),
              const Text(
                '常用设置',
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(width: 8),
              Text(
                '按使用频率排序',
                style: TextStyle(
                  fontSize: 11,
                  color: AppTheme.textSecondaryColor(context),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: wrappedItems.map((item) => _buildQuickSettingItem(item)).toList(),
          ),
        ],
      ),
    );
  }

  /// 构建单个常用设置项
  Widget _buildQuickSettingItem(_QuickSettingItem item) {
    return Expanded(
      child: InkWell(
        onTap: item.onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: item.gradient,
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: item.gradient.first.withOpacity(0.3),
                      blurRadius: 8,
                      spreadRadius: 1,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Icon(
                  item.icon,
                  color: Colors.white,
                  size: 24,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                item.label,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                  color: AppTheme.textSecondaryColor(context),
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// 构建搜索结果列表
  Widget _buildSearchResults() {
    final filteredKeys = _getFilteredSettingKeys();

    if (filteredKeys.isEmpty) {
      return _buildEmptySearchResult();
    }

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
      children: [
        _buildSettingsGroup(
          filteredKeys.map((key) => _buildSearchResultItem(key)).toList(),
        ),
      ],
    );
  }

  /// 桌面端不支持的设置项 key 集合
  Set<String> get _desktopExcludedKeys => {
        'haptic_feedback',
        'two_finger_gesture',
        'shake_to_parse',
        'force_touch',
        'bottom_nav_manage',
        'bottom_nav_management',
        'reset_gesture_hints',
        'gesture_settings',
        'nav_quick_actions',
      };

  /// 获取过滤后的设置项 key 列表
  List<String> _getFilteredSettingKeys() {
    final query = _searchQuery.toLowerCase();
    final keys = <String>[];

    _settingSearchKeys.forEach((key, keywords) {
      // 桌面端跳过移动端专属设置
      if (_isDesktop && _desktopExcludedKeys.contains(key)) return;

      final title = _getSettingTitle(key);
      final subtitle = _getSettingSubtitleStatic(key) ?? '';
      final matchesTitle = title.toLowerCase().contains(query);
      final matchesSubtitle = subtitle.toLowerCase().contains(query);
      final matchesKeyword = keywords.any((k) => k.toLowerCase().contains(query));

      if (matchesTitle || matchesSubtitle || matchesKeyword) {
        keys.add(key);
      }
    });

    return keys;
  }

  /// 构建空搜索结果状态
  Widget _buildEmptySearchResult() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.search_off_outlined,
            size: 64,
            color: AppTheme.textTertiaryColor(context),
          ),
          const SizedBox(height: 16),
          Text(
            '未找到匹配的设置',
            style: TextStyle(
              fontSize: 16,
              color: AppTheme.textSecondaryColor(context),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            '试试其他关键词',
            style: TextStyle(
              fontSize: 13,
              color: AppTheme.textTertiaryColor(context),
            ),
          ),
        ],
      ),
    );
  }

  /// 高亮匹配文字
  Widget _highlightMatch(String text, String query) {
    if (query.isEmpty) return Text(text);

    final lowerText = text.toLowerCase();
    final lowerQuery = query.toLowerCase();
    final index = lowerText.indexOf(lowerQuery);

    if (index == -1) return Text(text);

    final beforeMatch = text.substring(0, index);
    final matchText = text.substring(index, index + query.length);
    final afterMatch = text.substring(index + query.length);

    return Text.rich(
      TextSpan(
        children: [
          TextSpan(text: beforeMatch),
          TextSpan(
            text: matchText,
            style: const TextStyle(
              backgroundColor: Color(0xFFFFF59D),
              color: Color(0xFFF57F17),
              fontWeight: FontWeight.w600,
            ),
          ),
          TextSpan(text: afterMatch),
        ],
      ),
    );
  }

  /// 获取设置项标题
  String _getSettingTitle(String key) {
    switch (key) {
      case 'api_source':
        return '解析API源';
      case 'custom_sources':
        return '自定义解析源';
      case 'source_stats':
        return '解析源质量看板';
      case 'clipboard_settings':
        return '剪贴板设置';
      case 'auto_parse_clipboard':
        return '自动解析剪贴板';
      case 'clipboard_detection':
        return '剪贴板检测';
      case 'retry_settings':
        return '重试设置';
      case 'parse_retry':
        return '解析重试次数';
      case 'crawl_retry':
        return '抓取重试次数';
      case 'crawl_timing':
        return '抓取时序';
      case 'crawl_interval':
        return '抓取间隔';
      case 'crawl_jitter':
        return '抓取抖动';
      case 'auto_retry':
        return '下载失败自动重试';
      case 'haptic_feedback':
        return '触觉反馈';
      case 'download_quality':
        return '下载画质';
      case 'download_path':
        return '下载路径';
      case 'storage_rules':
        return '存储规则';
      case 'storage_mode':
        return '分类存储';
      case 'storage_naming':
        return '命名规则';
      case 'wifi_only':
        return '仅WiFi下载';
      case 'smart_download':
        return '智能下载';
      case 'auto_download_share':
        return '分享自动下载';
      case 'auto_paste_download':
        return '自动粘贴下载';
      case 'download_concurrency':
        return '并发下载数';
      case 'download_reminder':
        return '下载完成提醒';
      case 'download_sound':
        return '下载提示音';
      case 'download_complete_action':
        return '下载完成动作';
      case 'download_notification':
        return '下载通知';
      case 'default_audio_format':
        return '默认音频格式';
      case 'proxy':
        return '网络代理';
      case 'ui_density_entry':
        return '界面密度';
      case 'ui_density':
        return '布局密度';
      case 'font_settings':
        return '字体设置';
      case 'font_size':
        return '字体大小';
      case 'dark_mode':
        return '主题模式';
      case 'theme_color':
        return '主题色';
      case 'parallax':
        return '视差效果';
      case 'gesture_settings':
        return '手势设置';
      case 'two_finger_gesture':
        return '双指手势';
      case 'shake_to_parse':
        return '摇一摇解析';
      case 'force_touch':
        return '重按快捷';
      case 'nav_quick_actions':
        return '导航与快捷方式';
      case 'bottom_nav_manage':
      case 'bottom_nav_management':
        return '底部导航管理';
      case 'reset_gesture_hints':
        return '重置手势提示';
      case 'douyin_cookie':
        return '抖音高级设置';
      case 'cookie_manager':
        return 'Cookie 管理面板';
      case 'privacy_lock':
        return '隐私锁';
      case 'guide':
        return '新手引导';
      default:
        return '';
    }
  }

  /// 获取设置项静态副标题（用于搜索匹配）
  String? _getSettingSubtitleStatic(String key) {
    switch (key) {
      case 'custom_sources':
        return '添加你自己的 API 解析服务';
      case 'source_stats':
        return '查看各解析源成功率与耗时统计';
      case 'clipboard_settings':
        return '管理剪贴板自动解析与检测提示';
      case 'retry_settings':
        return '设置解析与抓取失败后的重试次数';
      case 'crawl_timing':
        return '设置抓取间隔时间与随机抖动范围';
      case 'auto_retry':
        return '网络异常时自动重试下载';
      case 'haptic_feedback':
        return '操作时提供震动反馈';
      case 'download_quality':
        return '选择下载视频清晰度';
      case 'storage_rules':
        return '文件存储组织方式与命名规则';
      case 'storage_mode':
        return '按平台和日期智能分类';
      case 'storage_naming':
        return '自定义文件命名规则';
      case 'smart_download':
        return '分享链接与剪贴板自动下载';
      case 'download_reminder':
        return '下载完成时的提示音、通知与后续动作';
      case 'download_sound':
        return '下载完成时播放提示音';
      case 'download_complete_action':
        return '下载完成后执行的动作';
      case 'download_notification':
        return '在状态栏显示下载通知';
      case 'default_audio_format':
        return '选择音频下载格式';
      case 'ui_density_entry':
        return '调整界面密度与列表紧凑度';
      case 'ui_density':
        return '调整界面紧凑程度';
      case 'font_settings':
        return '字体大小与大字体模式设置';
      case 'font_size':
        return '调整界面文字大小';
      case 'dark_mode':
        return '浅色/深色/跟随系统';
      case 'parallax':
        return '滚动时的视差动画效果';
      case 'gesture_settings':
        return '双指手势、摇一摇、重按快捷等设置';
      case 'two_finger_gesture':
        return '双指下滑关闭当前页面';
      case 'shake_to_parse':
        return '摇动手机触发解析';
      case 'force_touch':
        return '重按条目弹出快捷菜单';
      case 'nav_quick_actions':
        return '底部导航栏与桌面快捷方式管理';
      case 'bottom_nav_manage':
      case 'bottom_nav_management':
        return '自定义底部导航栏顺序和显隐';
      case 'reset_gesture_hints':
        return '重新显示所有页面的手势操作提示';
      case 'douyin_cookie':
        return 'UID 补全 / Cookie 管理 / 登录获取';
      case 'cookie_manager':
        return '管理各平台 Cookie，支持多账号切换';
      case 'privacy_lock':
        return '保护你的隐私数据';
      default:
        return null;
    }
  }

  /// 获取设置项图标
  IconData _getSettingIcon(String key) {
    switch (key) {
      case 'api_source':
        return Icons.api_outlined;
      case 'custom_sources':
        return Icons.link_outlined;
      case 'source_stats':
        return Icons.bar_chart_outlined;
      case 'clipboard_settings':
        return Icons.paste_outlined;
      case 'auto_parse_clipboard':
        return Icons.paste_outlined;
      case 'clipboard_detection':
        return Icons.content_paste_go_outlined;
      case 'retry_settings':
        return Icons.refresh_outlined;
      case 'parse_retry':
        return Icons.refresh_outlined;
      case 'crawl_retry':
        return Icons.autorenew_outlined;
      case 'crawl_timing':
        return Icons.timer_outlined;
      case 'crawl_interval':
        return Icons.timer_outlined;
      case 'crawl_jitter':
        return Icons.shuffle_outlined;
      case 'auto_retry':
        return Icons.autorenew_outlined;
      case 'haptic_feedback':
        return Icons.vibration_outlined;
      case 'download_quality':
        return Icons.hd_outlined;
      case 'download_path':
        return Icons.folder_outlined;
      case 'storage_rules':
        return Icons.folder_special_outlined;
      case 'storage_mode':
        return Icons.create_new_folder_outlined;
      case 'storage_naming':
        return Icons.drive_file_rename_outline_outlined;
      case 'wifi_only':
        return Icons.wifi_outlined;
      case 'smart_download':
        return Icons.auto_awesome_outlined;
      case 'auto_download_share':
        return Icons.share_outlined;
      case 'auto_paste_download':
        return Icons.content_paste_go_outlined;
      case 'download_concurrency':
        return Icons.download_outlined;
      case 'download_reminder':
        return Icons.notifications_active_outlined;
      case 'download_sound':
        return Icons.volume_up_outlined;
      case 'download_complete_action':
        return Icons.download_done_outlined;
      case 'download_notification':
        return Icons.notifications_outlined;
      case 'default_audio_format':
        return Icons.audiotrack_outlined;
      case 'proxy':
        return Icons.vpn_lock_outlined;
      case 'ui_density_entry':
        return Icons.aspect_ratio_outlined;
      case 'ui_density':
        return Icons.density_small_outlined;
      case 'font_settings':
        return Icons.text_fields_outlined;
      case 'font_size':
        return Icons.text_fields_outlined;
      case 'dark_mode':
        return Icons.dark_mode_outlined;
      case 'theme_color':
        return Icons.color_lens_outlined;
      case 'parallax':
        return Icons.view_in_ar_outlined;
      case 'gesture_settings':
        return Icons.pan_tool_outlined;
      case 'two_finger_gesture':
        return Icons.pan_tool_outlined;
      case 'shake_to_parse':
        return Icons.screen_rotation_outlined;
      case 'force_touch':
        return Icons.touch_app_outlined;
      case 'nav_quick_actions':
        return Icons.view_column_outlined;
      case 'bottom_nav_manage':
      case 'bottom_nav_management':
        return Icons.view_column_outlined;
      case 'reset_gesture_hints':
        return Icons.tips_and_updates_outlined;
      case 'douyin_cookie':
        return Icons.tune_outlined;
      case 'cookie_manager':
        return Icons.cookie_outlined;
      case 'privacy_lock':
        return Icons.lock_outlined;
      case 'guide':
        return Icons.school_outlined;
      default:
        return Icons.settings_outlined;
    }
  }

  /// 构建搜索结果项
  Widget _buildSearchResultItem(String key) {
    switch (key) {
      // ---- 导航/弹窗型设置 ----
      case 'api_source':
        return Consumer<SettingsProvider>(
          builder: (context, settings, child) {
            final currentSource = ApiSource.fromId(settings.apiSourceId);
            return ListTile(
              leading: Icon(_getSettingIcon(key)),
              title: _highlightMatch(_getSettingTitle(key), _searchQuery),
              subtitle: Text(
                currentSource?.name ?? '内置解析器',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => _showApiSourceDialog(context),
            );
          },
        );
      case 'custom_sources':
        return _buildNavigateResult(key, () {
          Navigator.push(context, AppPageRoute.slideRight(const CustomSourcesPage()));
        });
      case 'source_stats':
        return _buildNavigateResult(key, () {
          Navigator.push(context, AppPageRoute.slideRight(const SourceStatsPage()));
        });
      case 'clipboard_settings':
        return _buildNavigateResult(key, () => _showClipboardSettingsBottomSheet(context));
      case 'retry_settings':
        return _buildNavigateResult(key, () => _showRetrySettingsBottomSheet(context));
      case 'crawl_timing':
        return _buildNavigateResult(key, () => _showCrawlTimingBottomSheet(context));
      case 'download_path':
        return Consumer<SettingsProvider>(
          builder: (context, settings, child) {
            return ListTile(
              leading: Icon(_getSettingIcon(key)),
              title: _highlightMatch(_getSettingTitle(key), _searchQuery),
              subtitle: Text(
                settings.downloadPath,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 12, fontFamily: 'monospace'),
              ),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => _showDownloadPathDialog(context),
            );
          },
        );
      case 'storage_rules':
        return _buildNavigateResult(key, () {
          Navigator.push(context, AppPageRoute.slideRight(const StorageRulesPage()));
        });
      case 'storage_mode':
        return Consumer<SettingsProvider>(
          builder: (context, settings, child) {
            final label = settings.organizeByPlatform ? '按平台分类' : '不分类';
            return ListTile(
              leading: Icon(_getSettingIcon(key)),
              title: _highlightMatch(_getSettingTitle(key), _searchQuery),
              subtitle: Text(label),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => _showStorageOrganizeModeDialog(context),
            );
          },
        );
      case 'storage_naming':
        return Consumer<SettingsProvider>(
          builder: (context, settings, child) {
            return ListTile(
              leading: Icon(_getSettingIcon(key)),
              title: _highlightMatch(_getSettingTitle(key), _searchQuery),
              subtitle: Text(settings.storageNamingRule),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => _showStorageNamingRuleDialog(context),
            );
          },
        );
      case 'dark_mode':
        return Consumer<SettingsProvider>(
          builder: (context, settings, child) {
            return ListTile(
              leading: Icon(_getSettingIcon(key)),
              title: _highlightMatch(_getSettingTitle(key), _searchQuery),
              subtitle: Text(_themeModeLabel(settings.themeMode)),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => _showThemeModeDialog(context),
            );
          },
        );
      case 'theme_color':
        return Consumer<SettingsProvider>(
          builder: (context, settings, child) {
            return ListTile(
              leading: Icon(_getSettingIcon(key)),
              title: _highlightMatch(_getSettingTitle(key), _searchQuery),
              subtitle: Text(_themeColorLabel(settings.themeColor)),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => _showThemeColorDialog(context),
            );
          },
        );
      case 'ui_density_entry':
        return _buildNavigateResult(key, () => _showUiDensityBottomSheet(context));
      case 'ui_density':
        return Consumer<SettingsProvider>(
          builder: (context, settings, child) {
            return ListTile(
              leading: Icon(_getSettingIcon(key)),
              title: _highlightMatch(_getSettingTitle(key), _searchQuery),
              subtitle: Text(_densityLabel(settings.uiDensity)),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => _showUiDensityDialog(context),
            );
          },
        );
      case 'font_settings':
        return _buildNavigateResult(key, () => _showFontSettingsBottomSheet(context));
      case 'font_size':
        return Consumer<SettingsProvider>(
          builder: (context, settings, child) {
            return ListTile(
              leading: Icon(_getSettingIcon(key)),
              title: _highlightMatch(_getSettingTitle(key), _searchQuery),
              subtitle: Text(_fontSizeLabel(settings.fontSizeScale)),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => _showFontSizeDialog(context),
            );
          },
        );
      case 'download_quality':
        return Consumer<SettingsProvider>(
          builder: (context, settings, child) {
            final qualityLabel = _qualityLabel(settings.defaultQuality);
            return ListTile(
              leading: Icon(_getSettingIcon(key)),
              title: _highlightMatch(_getSettingTitle(key), _searchQuery),
              subtitle: Text(qualityLabel),
              trailing: const Icon(Icons.chevron_right),
              onTap: null,
            );
          },
        );
      case 'download_complete_action':
        return Consumer<SettingsProvider>(
          builder: (context, settings, child) {
            return ListTile(
              leading: Icon(_getSettingIcon(key)),
              title: _highlightMatch(_getSettingTitle(key), _searchQuery),
              subtitle: Text(_completeActionLabel(settings.downloadCompleteAction)),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => _showCompleteActionDialog(context),
            );
          },
        );
      case 'default_audio_format':
        return Consumer<SettingsProvider>(
          builder: (context, settings, child) {
            return ListTile(
              leading: Icon(_getSettingIcon(key)),
              title: _highlightMatch(_getSettingTitle(key), _searchQuery),
              subtitle: Text(settings.defaultAudioFormat.toUpperCase()),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => _showAudioFormatDialog(context),
            );
          },
        );
      case 'download_concurrency':
        return Consumer<SettingsProvider>(
          builder: (context, settings, child) {
            return ListTile(
              leading: Icon(_getSettingIcon(key)),
              title: _highlightMatch(_getSettingTitle(key), _searchQuery),
              subtitle: Text('同时下载 ${settings.downloadConcurrency} 个任务'),
              trailing: const Icon(Icons.chevron_right),
              onTap: null,
            );
          },
        );
      case 'crawl_interval':
        return Consumer<SettingsProvider>(
          builder: (context, settings, child) {
            return ListTile(
              leading: Icon(_getSettingIcon(key)),
              title: _highlightMatch(_getSettingTitle(key), _searchQuery),
              subtitle: Text('${settings.crawlIntervalMs} 毫秒'),
              trailing: const Icon(Icons.chevron_right),
              onTap: null,
            );
          },
        );
      case 'crawl_jitter':
        return Consumer<SettingsProvider>(
          builder: (context, settings, child) {
            return ListTile(
              leading: Icon(_getSettingIcon(key)),
              title: _highlightMatch(_getSettingTitle(key), _searchQuery),
              subtitle: Text('±${settings.crawlJitterMs} 毫秒'),
              trailing: const Icon(Icons.chevron_right),
              onTap: null,
            );
          },
        );
      case 'crawl_retry':
        return Consumer<SettingsProvider>(
          builder: (context, settings, child) {
            return ListTile(
              leading: Icon(_getSettingIcon(key)),
              title: _highlightMatch(_getSettingTitle(key), _searchQuery),
              subtitle: Text('最多 ${settings.crawlRetryCount} 次'),
              trailing: const Icon(Icons.chevron_right),
              onTap: null,
            );
          },
        );
      case 'parse_retry':
        return Consumer<SettingsProvider>(
          builder: (context, settings, child) {
            return ListTile(
              leading: Icon(_getSettingIcon(key)),
              title: _highlightMatch(_getSettingTitle(key), _searchQuery),
              subtitle: Text('失败后重试 ${settings.parseRetryCount} 次'),
              trailing: const Icon(Icons.chevron_right),
              onTap: null,
            );
          },
        );
      case 'download_sound':
        return Consumer<SettingsProvider>(
          builder: (context, settings, child) {
            return SwitchListTile(
              secondary: Icon(_getSettingIcon(key)),
              title: _highlightMatch(_getSettingTitle(key), _searchQuery),
              subtitle: Text(_soundTypeLabel(settings.downloadSoundType)),
              value: settings.downloadSoundEnabled,
              onChanged: (v) => settings.setDownloadSoundEnabled(v),
            );
          },
        );

      // ---- 开关型设置 ----
      case 'wifi_only':
        return _buildSwitchResult(
          key,
          (s) => s.wifiOnly,
          (s, v) => s.setWifiOnly(v),
        );
      case 'auto_parse_clipboard':
        return _buildSwitchResult(
          key,
          (s) => s.autoParseClipboard,
          (s, v) => s.setAutoParseClipboard(v, mutualExclusion: false),
        );
      case 'clipboard_detection':
        return _buildSwitchResult(
          key,
          (s) => s.clipboardDetectionEnabled,
          (s, v) => s.setClipboardDetectionEnabled(v),
        );
      case 'auto_download_share':
        return _buildSwitchResult(
          key,
          (s) => s.autoDownloadOnShare,
          (s, v) => s.setAutoDownloadOnShare(v),
        );
      case 'smart_download':
        return _buildNavigateResult(key, () => _showSmartDownloadBottomSheet(context));
      case 'auto_paste_download':
        return _buildSwitchResult(
          key,
          (s) => s.autoPasteAndDownload,
          (s, v) => s.setAutoPasteAndDownload(v, mutualExclusion: false),
        );
      case 'haptic_feedback':
        return _buildSwitchResult(
          key,
          (s) => s.hapticFeedbackEnabled,
          (s, v) => s.setHapticFeedbackEnabled(v),
        );
      case 'download_reminder':
        return _buildNavigateResult(key, () => _showDownloadReminderBottomSheet(context));
      case 'download_notification':
        return _buildSwitchResult(
          key,
          (s) => s.downloadNotificationEnabled,
          (s, v) => s.setDownloadNotificationEnabled(v),
        );
      case 'parallax':
        return _buildSwitchResult(
          key,
          (s) => s.parallaxEnabled,
          (s, v) => s.setParallaxEnabled(v),
        );
      case 'gesture_settings':
        return _buildNavigateResult(key, () {
          Navigator.push(context, AppPageRoute.slideRight(const GestureSettingsPage()));
        });
      case 'two_finger_gesture':
        return _buildSwitchResult(
          key,
          (s) => s.twoFingerGestureEnabled,
          (s, v) => s.setTwoFingerGestureEnabled(v),
        );
      case 'shake_to_parse':
        return _buildSwitchResult(
          key,
          (s) => s.shakeToParseEnabled,
          (s, v) => s.setShakeToParseEnabled(v),
        );
      case 'force_touch':
        return _buildSwitchResult(
          key,
          (s) => s.forceTouchEnabled,
          (s, v) => s.setForceTouchEnabled(v),
        );

      // ---- 复杂/特殊设置 ----
      case 'proxy':
        return Consumer<SettingsProvider>(
          builder: (context, settings, child) {
            final enabled = settings.proxyEnabled;
            return ListTile(
              leading: Icon(_getSettingIcon(key)),
              title: _highlightMatch(_getSettingTitle(key), _searchQuery),
              subtitle: Text(
                enabled
                    ? (settings.proxyHost.isNotEmpty
                        ? '${settings.proxyType}://${settings.proxyHost}:${settings.proxyPort}'
                        : '已启用，未配置地址')
                    : '未启用',
                style: const TextStyle(fontSize: 12),
              ),
              trailing: const Icon(Icons.chevron_right),
              onTap: null,
            );
          },
        );
      case 'douyin_cookie':
        return _buildNavigateResult(key, null);
      case 'cookie_manager':
        return Consumer<CookieProvider>(
          builder: (context, provider, child) {
            return ListTile(
              leading: Icon(_getSettingIcon(key)),
              title: _highlightMatch(_getSettingTitle(key), _searchQuery),
              subtitle: Text(
                provider.totalCount > 0
                    ? '共 ${provider.totalCount} 个，有效 ${provider.activeCount} 个'
                    : '管理各平台 Cookie，支持多账号切换',
              ),
              trailing: const Icon(Icons.chevron_right),
              onTap: () {
                Navigator.push(context, AppPageRoute.slideRight(const CookieManagerPage()));
              },
            );
          },
        );
      case 'nav_quick_actions':
        return _buildNavigateResult(key, () {
          Navigator.push(context, AppPageRoute.slideRight(const NavQuickActionsPage()));
        });
      case 'bottom_nav_manage':
      case 'bottom_nav_management':
        return Consumer<SettingsProvider>(
          builder: (context, settings, child) {
            final configJson = settings.bottomNavConfigJson;
            int visibleCount = 5;
            if (configJson.isNotEmpty) {
              try {
                final config = settings.bottomNavConfig;
                visibleCount = (config['visibleTabs'] as List?)?.length ?? 5;
              } catch (_) {}
            }
            return ListTile(
              leading: Icon(_getSettingIcon(key)),
              title: _highlightMatch(_getSettingTitle(key), _searchQuery),
              subtitle: Text('已显示 $visibleCount 个 Tab，可自定义顺序和显隐'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () {
                Navigator.push(
                  context,
                  AppPageRoute.slideRight(const BottomNavManagementPage()),
                );
              },
            );
          },
        );
      case 'reset_gesture_hints':
        return Consumer<SettingsProvider>(
          builder: (context, settings, child) {
            return ListTile(
              leading: Icon(_getSettingIcon(key)),
              title: _highlightMatch(_getSettingTitle(key), _searchQuery),
              subtitle: Text(_getSettingSubtitleStatic(key) ?? ''),
              trailing: const Icon(Icons.refresh),
              onTap: () async {
                await settings.resetGestureHints();
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('手势提示已重置，下次进入页面时会重新显示'),
                      duration: Duration(seconds: 2),
                    ),
                  );
                }
              },
            );
          },
        );
      case 'privacy_lock':
        return Consumer<SettingsProvider>(
          builder: (context, settings, child) {
            return ListTile(
              leading: Icon(_getSettingIcon(key)),
              title: _highlightMatch(_getSettingTitle(key), _searchQuery),
              subtitle: Text(
                settings.privacyLockEnabled ? '已启用' : '未启用',
              ),
              trailing: const Icon(Icons.chevron_right),
              onTap: null,
            );
          },
        );
      case 'guide':
        return _buildNavigateResult(key, () {
          Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => const GuidePage()),
          );
        });
      default:
        return _buildNavigateResult(key, null);
    }
  }

  /// 构建导航型搜索结果
  Widget _buildNavigateResult(String key, VoidCallback? onTap) {
    final subtitle = _getSettingSubtitleStatic(key);
    return ListTile(
      leading: Icon(_getSettingIcon(key)),
      title: _highlightMatch(_getSettingTitle(key), _searchQuery),
      subtitle: subtitle != null ? Text(subtitle) : null,
      trailing: const Icon(Icons.chevron_right),
      onTap: onTap,
    );
  }

  /// 构建开关型搜索结果
  Widget _buildSwitchResult(
    String key,
    bool Function(SettingsProvider) getValue,
    void Function(SettingsProvider, bool) onChanged,
  ) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        final subtitle = _getSettingSubtitleStatic(key);
        return SwitchListTile(
          secondary: Icon(_getSettingIcon(key)),
          title: _highlightMatch(_getSettingTitle(key), _searchQuery),
          subtitle: subtitle != null ? Text(subtitle) : null,
          value: getValue(settings),
          onChanged: (v) => onChanged(settings, v),
        );
      },
    );
  }

  /// 画质标签
  String _qualityLabel(String quality) {
    switch (quality) {
      case 'original':
        return '原画';
      case 'hd':
        return '高清';
      default:
        return quality;
    }
  }

  /// 密度标签
  String _densityLabel(String density) {
    switch (density) {
      case 'compact':
        return '紧凑';
      case 'comfortable':
        return '宽松';
      case 'normal':
      default:
        return '标准';
    }
  }

  /// 字体大小标签
  String _fontSizeLabel(String scale) {
    switch (scale) {
      case 'small':
        return '小';
      case 'large':
        return '大';
      case 'xlarge':
        return '特大';
      case 'normal':
      default:
        return '标准';
    }
  }

  /// 提示音类型标签
  String _soundTypeLabel(String type) {
    switch (type) {
      case 'ding':
        return '叮咚';
      case 'chime':
        return '风铃';
      case 'pop':
        return '气泡';
      default:
        return '默认';
    }
  }

  /// 完成动作标签
  String _completeActionLabel(String action) {
    switch (action) {
      case 'notify':
        return '仅通知';
      case 'open':
        return '自动打开';
      case 'share':
        return '自动分享';
      case 'none':
        return '无操作';
      default:
        return action;
    }
  }

  // ============================================================
  // 设置实时预览卡片
  // ============================================================

  /// 设置实时预览卡片
  ///
  /// 在设置页顶部展示一个迷你结果卡片预览，
  /// 调整布局密度、主题模式、字体大小等设置时实时变化。
  Widget _buildSettingsPreviewCard(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        final density = DensityLevelX.fromString(settings.uiDensity);
        final textScale = density.textScale * _fontSizeScaleFactor(settings.fontSizeScale);

        return Container(
          decoration: BoxDecoration(
            color: AppTheme.cardBg(context),
            borderRadius: BorderRadius.circular(AppTheme.radiusLg),
            border: Border.all(
              color: AppTheme.borderColor(context),
              width: 0.5,
            ),
            boxShadow: AppTheme.shadowSm,
          ),
          clipBehavior: Clip.antiAlias,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // 标题栏（可点击折叠）
              InkWell(
                onTap: () {
                  setState(() {
                    _previewCardExpanded = !_previewCardExpanded;
                  });
                },
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  child: Row(
                    children: [
                      Container(
                        width: 28,
                        height: 28,
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [Color(0xFF6366F1), Color(0xFF8B5CF6)],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Icon(
                          Icons.preview_outlined,
                          color: Colors.white,
                          size: 16,
                        ),
                      ),
                      const SizedBox(width: 10),
                      const Expanded(
                        child: Text(
                          '实时预览',
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      Text(
                        '调整外观设置后查看效果',
                        style: TextStyle(
                          fontSize: 12,
                          color: AppTheme.textTertiaryColor(context),
                        ),
                      ),
                      const SizedBox(width: 8),
                      AnimatedRotation(
                        duration: const Duration(milliseconds: 250),
                        turns: _previewCardExpanded ? 0 : -0.25,
                        child: Icon(
                          Icons.keyboard_arrow_down_rounded,
                          color: AppTheme.textTertiaryColor(context),
                          size: 20,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              // 分割线
              if (_previewCardExpanded)
                Divider(
                  height: 1,
                  thickness: 0.5,
                  color: AppTheme.borderColor(context),
                ),
              // 预览内容
              AnimatedCrossFade(
                duration: const Duration(milliseconds: 300),
                crossFadeState: _previewCardExpanded
                    ? CrossFadeState.showFirst
                    : CrossFadeState.showSecond,
                firstChild: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
                  child: _buildMiniPreviewCard(context, textScale),
                ),
                secondChild: const SizedBox.shrink(),
              ),
            ],
          ),
        );
      },
    );
  }

  /// 构建迷你预览卡片
  Widget _buildMiniPreviewCard(BuildContext context, double textScale) {
    final isDark = AppTheme.isDark(context);
    final primaryColor = Theme.of(context).primaryColor;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeOutCubic,
      padding: EdgeInsets.all(10 * textScale),
      decoration: BoxDecoration(
        color: AppTheme.cardBg(context),
        borderRadius: BorderRadius.circular(AppTheme.radiusMd * textScale),
        border: Border.all(
          color: isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
          width: 0.5,
        ),
        boxShadow: AppTheme.shadowSm,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 封面占位
          Container(
            width: 64 * textScale,
            height: 52 * textScale,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(AppTheme.radiusSm * textScale),
              color: isDark ? const Color(0xFF0F172A) : const Color(0xFFF1F5F9),
            ),
            child: Icon(
              Icons.play_circle_outline,
              size: 20 * textScale,
              color: isDark ? Colors.grey.shade600 : Colors.grey.shade400,
            ),
          ),
          SizedBox(width: 10 * textScale),
          // 文字信息
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  '示例视频标题文字',
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 12 * textScale,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.textPrimaryColor(context),
                    height: 1.35,
                  ),
                ),
                SizedBox(height: 4 * textScale),
                Row(
                  children: [
                    Container(
                      padding: EdgeInsets.symmetric(
                        horizontal: 6 * textScale,
                        vertical: 2 * textScale,
                      ),
                      decoration: BoxDecoration(
                        color: primaryColor.withOpacity(isDark ? 0.15 : 0.08),
                        borderRadius: BorderRadius.circular(4 * textScale),
                      ),
                      child: Text(
                        '抖音',
                        style: TextStyle(
                          fontSize: 10 * textScale,
                          fontWeight: FontWeight.w600,
                          color: primaryColor,
                          height: 1.2,
                        ),
                      ),
                    ),
                    SizedBox(width: 6 * textScale),
                    Icon(
                      Icons.person_outline,
                      size: 10 * textScale,
                      color: AppTheme.textTertiaryColor(context),
                    ),
                    SizedBox(width: 2 * textScale),
                    Expanded(
                      child: Text(
                        '作者昵称',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 10 * textScale,
                          color: AppTheme.textTertiaryColor(context),
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          // 下载按钮
          SizedBox(width: 6 * textScale),
          Container(
            width: 32 * textScale,
            height: 32 * textScale,
            decoration: BoxDecoration(
              gradient: AppTheme.primaryGradient,
              borderRadius: BorderRadius.circular(AppTheme.radiusSm * textScale),
              boxShadow: [
                BoxShadow(
                  color: primaryColor.withOpacity(0.3),
                  blurRadius: 6,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Icon(
              Icons.download_outlined,
              color: Colors.white,
              size: 16 * textScale,
            ),
          ),
        ],
      ),
    );
  }

  /// 字体大小缩放因子
  double _fontSizeScaleFactor(String scale) {
    switch (scale) {
      case 'small':
        return 0.9;
      case 'large':
        return 1.15;
      case 'xlarge':
        return 1.3;
      case 'medium':
      default:
        return 1.0;
    }
  }

  /// 分组标题：渐变图标背景 + 标题文字
  Widget _buildSectionHeader({
    required IconData icon,
    required String title,
    required List<Color> gradient,
  }) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(2, 24, 4, 12),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: gradient,
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(
                  color: gradient.first.withOpacity(0.3),
                  blurRadius: 6,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Icon(
              icon,
              color: Colors.white,
              size: 18,
            ),
          ),
          const SizedBox(width: 12),
          Text(
            title,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: AppTheme.textPrimaryColor(context),
              letterSpacing: 0.2,
            ),
          ),
        ],
      ),
    );
  }

  /// 设置分组容器：一个圆角卡片包含多个设置项，项之间用细分割线
  Widget _buildSettingsGroup(List<Widget> children) {
    final isDark = AppTheme.isDark(context);
    final borderColor = isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0);
    
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.cardBg(context),
        borderRadius: BorderRadius.circular(AppTheme.radiusLg),
        border: Border.all(color: borderColor, width: 0.5),
        boxShadow: AppTheme.shadowSm,
      ),
      clipBehavior: Clip.antiAlias,
      child: IconTheme(
        data: IconThemeData(
          size: 22,
          color: AppTheme.primaryColor,
        ),
        child: Column(
          children: List.generate(children.length * 2 - 1, (index) {
            if (index.isEven) {
              return children[index ~/ 2];
            } else {
              return Divider(
                height: 0.5,
                thickness: 0.5,
                indent: 56,
                endIndent: 16,
                color: borderColor,
              );
            }
          }),
        ),
      ),
    );
  }

  // ============================================================
  //  合并设置入口 & BottomSheet
  // ============================================================

  // ----------------------------------------------------------
  // 剪贴板设置（合并自动解析剪贴板 + 剪贴板检测）
  // ----------------------------------------------------------
  Widget _buildClipboardSettingsEntry(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        final enabledCount = (settings.autoParseClipboard ? 1 : 0) + (settings.clipboardDetectionEnabled ? 1 : 0);
        return ListTile(
          leading: const Icon(Icons.paste_outlined),
          title: const Text('剪贴板设置'),
          subtitle: Text(
            '已开启 $enabledCount 项',
            style: TextStyle(color: secondaryTextColor, fontSize: 13),
          ),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _showClipboardSettingsBottomSheet(context),
        );
      },
    );
  }

  Future<void> _showClipboardSettingsBottomSheet(BuildContext context) async {
    final settings = context.read<SettingsProvider>();
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textPrimary = isDark ? Colors.white : Colors.grey.shade900;
    final borderColor = isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0);

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Container(
                        width: 40,
                        height: 4,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade300,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      '剪贴板设置',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: textPrimary,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      decoration: BoxDecoration(
                        color: isDark ? const Color(0xFF1E293B) : const Color(0xFFF8FAFC),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: borderColor, width: 0.5),
                      ),
                      child: Column(
                        children: [
                          SwitchListTile(
                            title: const Text('自动解析剪贴板'),
                            subtitle: const Text('打开应用时自动检测剪贴板中的视频链接'),
                            value: settings.autoParseClipboard,
                            onChanged: (value) {
                              settings.setAutoParseClipboard(value);
                              setModalState(() {});
                            },
                          ),
                          Divider(height: 0.5, thickness: 0.5, indent: 16, endIndent: 16, color: borderColor),
                          SwitchListTile(
                            title: const Text('剪贴板检测'),
                            subtitle: const Text('首页显示剪贴板链接提示，点击快速填充'),
                            value: settings.clipboardDetectionEnabled,
                            onChanged: (value) {
                              settings.setClipboardDetectionEnabled(value);
                              setModalState(() {});
                            },
                          ),
                          Divider(height: 0.5, thickness: 0.5, indent: 16, endIndent: 16, color: borderColor),
                          SwitchListTile(
                            title: const Text('智能粘贴'),
                            subtitle: const Text('粘贴内容与已有不同则追加到下方，相同则覆盖'),
                            value: settings.smartPasteAppendMode,
                            onChanged: (value) {
                              settings.setSmartPasteAppendMode(value);
                              setModalState(() {});
                            },
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  // ----------------------------------------------------------
  // 重试设置（合并解析重试 + 抓取重试）
  // ----------------------------------------------------------
  Widget _buildRetrySettingsEntry(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        return ListTile(
          leading: const Icon(Icons.refresh_outlined),
          title: const Text('重试设置'),
          subtitle: Text(
            '解析 ${settings.parseRetryCount} 次 · 抓取 ${settings.crawlRetryCount} 次',
            style: TextStyle(color: secondaryTextColor, fontSize: 13),
          ),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _showRetrySettingsBottomSheet(context),
        );
      },
    );
  }

  Future<void> _showRetrySettingsBottomSheet(BuildContext context) async {
    final settings = context.read<SettingsProvider>();
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textPrimary = isDark ? Colors.white : Colors.grey.shade900;
    final textSecondary = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
    final borderColor = isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0);

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Container(
                        width: 40,
                        height: 4,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade300,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      '重试设置',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: textPrimary,
                      ),
                    ),
                    const SizedBox(height: 16),
                    // 解析重试
                    Container(
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                      decoration: BoxDecoration(
                        color: isDark ? const Color(0xFF1E293B) : const Color(0xFFF8FAFC),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: borderColor, width: 0.5),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.refresh_outlined, size: 18, color: textSecondary),
                              const SizedBox(width: 8),
                              Text(
                                '解析重试次数',
                                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: textPrimary),
                              ),
                              const Spacer(),
                              Text(
                                '${settings.parseRetryCount} 次',
                                style: TextStyle(color: AppTheme.primaryColor, fontWeight: FontWeight.w600),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Text(
                            '失败后自动重试（多源 fallback 内有效）',
                            style: TextStyle(color: textSecondary, fontSize: 12),
                          ),
                          Slider(
                            value: settings.parseRetryCount.toDouble(),
                            min: 0,
                            max: 5,
                            divisions: 5,
                            label: '${settings.parseRetryCount} 次',
                            onChanged: (value) {
                              settings.setParseRetryCount(value.round());
                              setModalState(() {});
                            },
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    // 抓取重试
                    Container(
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                      decoration: BoxDecoration(
                        color: isDark ? const Color(0xFF1E293B) : const Color(0xFFF8FAFC),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: borderColor, width: 0.5),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.autorenew_outlined, size: 18, color: textSecondary),
                              const SizedBox(width: 8),
                              Text(
                                '抓取重试次数',
                                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: textPrimary),
                              ),
                              const Spacer(),
                              Text(
                                '${settings.crawlRetryCount} 次',
                                style: TextStyle(color: AppTheme.primaryColor, fontWeight: FontWeight.w600),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Text(
                            '单条抓取失败后自动重试',
                            style: TextStyle(color: textSecondary, fontSize: 12),
                          ),
                          Slider(
                            value: settings.crawlRetryCount.toDouble(),
                            min: 0,
                            max: 5,
                            divisions: 5,
                            label: '${settings.crawlRetryCount} 次',
                            onChanged: (value) {
                              settings.setCrawlRetryCount(value.round());
                              setModalState(() {});
                            },
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  // ----------------------------------------------------------
  // 抓取时序（合并抓取间隔 + 抓取抖动）
  // ----------------------------------------------------------
  Widget _buildCrawlTimingEntry(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        final intervalSec = (settings.crawlIntervalMs / 1000).toStringAsFixed(1);
        final jitterSec = (settings.crawlJitterMs / 1000).toStringAsFixed(1);
        return ListTile(
          leading: const Icon(Icons.timer_outlined),
          title: const Text('抓取时序'),
          subtitle: Text(
            '间隔 ${intervalSec}s · 抖动 ±${jitterSec}s',
            style: TextStyle(color: secondaryTextColor, fontSize: 13),
          ),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _showCrawlTimingBottomSheet(context),
        );
      },
    );
  }

  Future<void> _showCrawlTimingBottomSheet(BuildContext context) async {
    final settings = context.read<SettingsProvider>();
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textPrimary = isDark ? Colors.white : Colors.grey.shade900;
    final textSecondary = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
    final borderColor = isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0);

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            final intervalSec = (settings.crawlIntervalMs / 1000).toStringAsFixed(1);
            final jitterSec = (settings.crawlJitterMs / 1000).toStringAsFixed(1);
            return SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Container(
                        width: 40,
                        height: 4,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade300,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      '抓取时序',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: textPrimary,
                      ),
                    ),
                    const SizedBox(height: 16),
                    // 抓取间隔
                    Container(
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                      decoration: BoxDecoration(
                        color: isDark ? const Color(0xFF1E293B) : const Color(0xFFF8FAFC),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: borderColor, width: 0.5),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.timer_outlined, size: 18, color: textSecondary),
                              const SizedBox(width: 8),
                              Text(
                                '抓取间隔',
                                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: textPrimary),
                              ),
                              const Spacer(),
                              Text(
                                '$intervalSec 秒 / 条',
                                style: TextStyle(color: AppTheme.primaryColor, fontWeight: FontWeight.w600),
                              ),
                            ],
                          ),
                          Slider(
                            value: settings.crawlIntervalMs.toDouble(),
                            min: 0,
                            max: 5000,
                            divisions: 50,
                            label: '${intervalSec}秒',
                            onChanged: (value) {
                              settings.setCrawlIntervalMs(value.round());
                              setModalState(() {});
                            },
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    // 抓取抖动
                    Container(
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                      decoration: BoxDecoration(
                        color: isDark ? const Color(0xFF1E293B) : const Color(0xFFF8FAFC),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: borderColor, width: 0.5),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.shuffle, size: 18, color: textSecondary),
                              const SizedBox(width: 8),
                              Text(
                                '随机抖动',
                                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: textPrimary),
                              ),
                              const Spacer(),
                              Text(
                                '±$jitterSec 秒',
                                style: TextStyle(color: AppTheme.primaryColor, fontWeight: FontWeight.w600),
                              ),
                            ],
                          ),
                          Text(
                            '避免规律请求被风控',
                            style: TextStyle(color: textSecondary, fontSize: 12),
                          ),
                          Slider(
                            value: settings.crawlJitterMs.toDouble(),
                            min: 0,
                            max: 3000,
                            divisions: 30,
                            label: '±${jitterSec}秒',
                            onChanged: (value) {
                              settings.setCrawlJitterMs(value.round());
                              setModalState(() {});
                            },
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  // ----------------------------------------------------------
  // 存储规则入口（导航到子页面）
  // ----------------------------------------------------------
  Widget _buildStorageRulesEntry(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        return ListTile(
          leading: const Icon(Icons.folder_special_outlined),
          title: const Text('存储规则'),
          subtitle: Text(
            '${_organizeModeShortName(settings.storageOrganizeMode)} · ${_namingRuleName(settings.storageNamingRule)}',
            style: TextStyle(color: secondaryTextColor, fontSize: 13),
          ),
          trailing: const Icon(Icons.chevron_right),
          onTap: () {
            Navigator.push(context, AppPageRoute.slideRight(const StorageRulesPage()));
          },
        );
      },
    );
  }

  String _organizeModeShortName(String mode) {
    switch (mode) {
      case 'flat': return '平铺';
      case 'platform': return '按平台';
      case 'author': return '按作者';
      case 'date': return '按日期';
      case 'platform_author': return '平台+作者';
      default: return '平铺';
    }
  }

  // ----------------------------------------------------------
  // 智能下载（合并分享自动下载 + 自动粘贴下载）
  // ----------------------------------------------------------
  Widget _buildSmartDownloadEntry(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        final enabledCount = (settings.autoDownloadOnShare ? 1 : 0) + (settings.autoPasteAndDownload ? 1 : 0);
        return ListTile(
          leading: const Icon(Icons.auto_awesome_outlined),
          title: const Text('智能下载'),
          subtitle: Text(
            '已开启 $enabledCount 项自动下载',
            style: TextStyle(color: secondaryTextColor, fontSize: 13),
          ),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _showSmartDownloadBottomSheet(context),
        );
      },
    );
  }

  Future<void> _showSmartDownloadBottomSheet(BuildContext context) async {
    final settings = context.read<SettingsProvider>();
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textPrimary = isDark ? Colors.white : Colors.grey.shade900;
    final borderColor = isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0);

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Container(
                        width: 40,
                        height: 4,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade300,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      '智能下载',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: textPrimary,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      decoration: BoxDecoration(
                        color: isDark ? const Color(0xFF1E293B) : const Color(0xFFF8FAFC),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: borderColor, width: 0.5),
                      ),
                      child: Column(
                        children: [
                          SwitchListTile(
                            title: const Text('分享后自动下载'),
                            subtitle: const Text('从其他应用分享链接时自动开始下载'),
                            value: settings.autoDownloadOnShare,
                            onChanged: (value) {
                              settings.setAutoDownloadOnShare(value);
                              setModalState(() {});
                            },
                          ),
                          Divider(height: 0.5, thickness: 0.5, indent: 16, endIndent: 16, color: borderColor),
                          SwitchListTile(
                            title: const Text('自动粘贴解析下载'),
                            subtitle: const Text('打开应用时自动粘贴剪贴板链接并解析下载'),
                            value: settings.autoPasteAndDownload,
                            onChanged: (value) {
                              settings.setAutoPasteAndDownload(value);
                              setModalState(() {});
                            },
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  // ----------------------------------------------------------
  // 下载完成提醒（合并提示音 + 通知 + 完成动作）
  // ----------------------------------------------------------
  Widget _buildDownloadReminderEntry(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        final enabledCount = (settings.downloadSoundEnabled ? 1 : 0) + (settings.downloadNotificationEnabled ? 1 : 0);
        return ListTile(
          leading: const Icon(Icons.notifications_active_outlined),
          title: const Text('下载完成提醒'),
          subtitle: Text(
            '已开启 $enabledCount 种提醒方式',
            style: TextStyle(color: secondaryTextColor, fontSize: 13),
          ),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _showDownloadReminderBottomSheet(context),
        );
      },
    );
  }

  Future<void> _showDownloadReminderBottomSheet(BuildContext context) async {
    final settings = context.read<SettingsProvider>();
    final downloadProvider = context.read<DownloadProvider>();
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textPrimary = isDark ? Colors.white : Colors.grey.shade900;
    final textSecondary = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
    final borderColor = isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0);

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Container(
                        width: 40,
                        height: 4,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade300,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      '下载完成提醒',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: textPrimary,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      decoration: BoxDecoration(
                        color: isDark ? const Color(0xFF1E293B) : const Color(0xFFF8FAFC),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: borderColor, width: 0.5),
                      ),
                      child: Column(
                        children: [
                          // 下载提示音
                          SwitchListTile(
                            title: const Text('下载提示音'),
                            subtitle: const Text('下载完成时播放提示音'),
                            value: settings.downloadSoundEnabled,
                            onChanged: (value) {
                              settings.setDownloadSoundEnabled(value);
                              setModalState(() {});
                            },
                          ),
                          if (settings.downloadSoundEnabled)
                            Padding(
                              padding: const EdgeInsets.fromLTRB(16, 0, 16, 0),
                              child: Row(
                                children: [
                                  const SizedBox(width: 40),
                                  Expanded(
                                    child: Text(
                                      '音效：${_soundTypeName(settings.downloadSoundType)}',
                                      style: TextStyle(color: textSecondary, fontSize: 13),
                                    ),
                                  ),
                                  TextButton(
                                    onPressed: () {
                                      Navigator.pop(context);
                                      _showSoundTypeDialog(context);
                                    },
                                    child: const Text('选择'),
                                  ),
                                ],
                              ),
                            ),
                          Divider(height: 0.5, thickness: 0.5, indent: 16, endIndent: 16, color: borderColor),
                          // 下载通知
                          SwitchListTile(
                            title: const Text('下载通知'),
                            subtitle: const Text('在状态栏显示下载通知'),
                            value: settings.downloadNotificationEnabled,
                            onChanged: (value) async {
                              await settings.setDownloadNotificationEnabled(value);
                              downloadProvider.manager.downloadNotificationEnabled = value;
                              setModalState(() {});
                            },
                          ),
                          Divider(height: 0.5, thickness: 0.5, indent: 16, endIndent: 16, color: borderColor),
                          // 下载完成动作
                          ListTile(
                            title: const Text('下载完成后'),
                            subtitle: Text(
                              _completeActionName(settings.downloadCompleteAction),
                              style: TextStyle(color: textSecondary, fontSize: 13),
                            ),
                            trailing: const Icon(Icons.chevron_right),
                            onTap: () {
                              Navigator.pop(context);
                              _showCompleteActionDialog(context);
                            },
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  // ----------------------------------------------------------
  // 界面密度（合并 UI 密度 + 紧凑列表模式）
  // ----------------------------------------------------------
  Widget _buildUiDensityEntry(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        final currentDensity = DensityLevelX.fromString(settings.uiDensity);
        final compactSuffix = settings.compactListMode ? ' · 紧凑列表' : '';
        return ListTile(
          leading: const Icon(Icons.aspect_ratio_outlined),
          title: const Text('界面密度'),
          subtitle: Text(
            '${currentDensity.label}$compactSuffix',
            style: TextStyle(color: secondaryTextColor, fontSize: 13),
          ),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _showUiDensityBottomSheet(context),
        );
      },
    );
  }

  Future<void> _showUiDensityBottomSheet(BuildContext context) async {
    final settings = context.read<SettingsProvider>();
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textPrimary = isDark ? Colors.white : Colors.grey.shade900;
    final textSecondary = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
    final borderColor = isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0);
    final currentDensity = DensityLevelX.fromString(settings.uiDensity);
    final levels = DensityLevel.values;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Container(
                        width: 40,
                        height: 4,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade300,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      '界面密度',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: textPrimary,
                      ),
                    ),
                    const SizedBox(height: 16),
                    // 密度选择
                    Container(
                      decoration: BoxDecoration(
                        color: isDark ? const Color(0xFF1E293B) : const Color(0xFFF8FAFC),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: borderColor, width: 0.5),
                      ),
                      child: Column(
                        children: levels.map((level) {
                          final isSelected = level == currentDensity;
                          return Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              if (level != levels.first)
                                Divider(height: 0.5, thickness: 0.5, indent: 16, endIndent: 16, color: borderColor),
                              ListTile(
                                leading: Icon(
                                  level == DensityLevel.compact
                                      ? Icons.density_small
                                      : level == DensityLevel.standard
                                          ? Icons.density_medium
                                          : Icons.density_large,
                                  color: isSelected ? AppTheme.primaryColor : textSecondary,
                                ),
                                title: Text(level.label),
                                subtitle: Text(
                                  level.description,
                                  style: TextStyle(fontSize: 12, color: textSecondary),
                                ),
                                trailing: isSelected
                                    ? Icon(Icons.check_circle, color: AppTheme.primaryColor)
                                    : null,
                                onTap: () {
                                  settings.setUiDensity(level.storageValue);
                                  setModalState(() {});
                                },
                              ),
                            ],
                          );
                        }).toList(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    // 紧凑列表模式
                    Container(
                      decoration: BoxDecoration(
                        color: isDark ? const Color(0xFF1E293B) : const Color(0xFFF8FAFC),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: borderColor, width: 0.5),
                      ),
                      child: SwitchListTile(
                        title: const Text('列表紧凑模式'),
                        subtitle: const Text('缩小列表行高，一屏显示更多内容'),
                        value: settings.compactListMode,
                        onChanged: (value) {
                          settings.setCompactListMode(value);
                          setModalState(() {});
                        },
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  // ----------------------------------------------------------
  // 字体设置（合并字体大小 + 大字体模式）
  // ----------------------------------------------------------
  Widget _buildFontSettingsEntry(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        final suffix = settings.largeFontMode ? ' · 大字体模式' : '';
        return ListTile(
          leading: const Icon(Icons.text_fields_outlined),
          title: const Text('字体设置'),
          subtitle: Text(
            '${_fontSizeLabel(settings.fontSizeScale)}$suffix',
            style: TextStyle(color: secondaryTextColor, fontSize: 13),
          ),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _showFontSettingsBottomSheet(context),
        );
      },
    );
  }

  Future<void> _showFontSettingsBottomSheet(BuildContext context) async {
    final settings = context.read<SettingsProvider>();
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textPrimary = isDark ? Colors.white : Colors.grey.shade900;
    final textSecondary = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
    final borderColor = isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0);
    final currentScale = settings.fontSizeScale;
    final options = [
      ('small', '小', '适合一屏展示更多内容', Icons.text_decrease),
      ('medium', '标准', '默认大小，推荐使用', Icons.text_fields),
      ('large', '大', '更大的文字，更易阅读', Icons.text_increase),
      ('xlarge', '特大', '超大字体，适合视力不佳', Icons.text_rotate_up),
    ];

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Container(
                        width: 40,
                        height: 4,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade300,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      '字体设置',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: textPrimary,
                      ),
                    ),
                    const SizedBox(height: 16),
                    // 字体大小选择
                    Container(
                      decoration: BoxDecoration(
                        color: isDark ? const Color(0xFF1E293B) : const Color(0xFFF8FAFC),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: borderColor, width: 0.5),
                      ),
                      child: Column(
                        children: options.map((opt) {
                          final isSelected = currentScale == opt.$1;
                          return Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              if (opt != options.first)
                                Divider(height: 0.5, thickness: 0.5, indent: 16, endIndent: 16, color: borderColor),
                              ListTile(
                                leading: Icon(opt.$4, color: isSelected ? AppTheme.primaryColor : textSecondary),
                                title: Text(opt.$2),
                                subtitle: Text(
                                  opt.$3,
                                  style: TextStyle(fontSize: 12, color: textSecondary),
                                ),
                                trailing: isSelected
                                    ? Icon(Icons.check_circle, color: AppTheme.primaryColor)
                                    : null,
                                onTap: () {
                                  settings.setFontSizeScale(opt.$1);
                                  setModalState(() {});
                                },
                              ),
                            ],
                          );
                        }).toList(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    // 大字体模式
                    Container(
                      decoration: BoxDecoration(
                        color: isDark ? const Color(0xFF1E293B) : const Color(0xFFF8FAFC),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: borderColor, width: 0.5),
                      ),
                      child: SwitchListTile(
                        title: const Text('大字体模式'),
                        subtitle: const Text('全局字体放大 15%，按钮和交互元素也相应放大'),
                        value: settings.largeFontMode,
                        onChanged: (value) async {
                          await settings.setLargeFontMode(value);
                          setModalState(() {});
                        },
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  // ----------------------------------------------------------
  // 手势设置入口（导航到子页面）
  // ----------------------------------------------------------
  Widget _buildGestureSettingsEntry(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        final enabledCount = (settings.twoFingerGestureEnabled ? 1 : 0)
            + (settings.shakeToParseEnabled ? 1 : 0)
            + (settings.forceTouchEnabled ? 1 : 0);
        return ListTile(
          leading: const Icon(Icons.pan_tool_outlined),
          title: const Text('手势设置'),
          subtitle: Text(
            '已开启 $enabledCount 项手势功能',
            style: TextStyle(color: secondaryTextColor, fontSize: 13),
          ),
          trailing: const Icon(Icons.chevron_right),
          onTap: () {
            Navigator.push(context, AppPageRoute.slideRight(const GestureSettingsPage()));
          },
        );
      },
    );
  }

  // ----------------------------------------------------------
  // 导航与快捷方式入口（导航到子页面）
  // ----------------------------------------------------------
  Widget _buildNavQuickActionsEntry(BuildContext context) {
    return ListTile(
      leading: const Icon(Icons.view_column_outlined),
      title: const Text('导航与快捷方式'),
      subtitle: const Text(
        '底部导航管理、桌面快捷方式',
        style: TextStyle(fontSize: 13),
      ),
      trailing: const Icon(Icons.chevron_right),
      onTap: () {
        Navigator.push(context, AppPageRoute.slideRight(const NavQuickActionsPage()));
      },
    );
  }

  Widget _buildQualitySetting(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            RadioListTile<String>(
              title: const Text('原画'),
              subtitle: const Text('最高画质，文件较大'),
              value: 'original',
              groupValue: settings.defaultQuality,
              onChanged: (value) {
                if (value != null) settings.setDefaultQuality(value);
              },
            ),
            const Divider(height: 0.5, thickness: 0.5, indent: 56, endIndent: 16),
            RadioListTile<String>(
              title: const Text('高清'),
              subtitle: const Text('画质较好，文件适中'),
              value: 'hd',
              groupValue: settings.defaultQuality,
              onChanged: (value) {
                if (value != null) settings.setDefaultQuality(value);
              },
            ),
          ],
        );
      },
    );
  }

  // ======================================================
  // 下载路径：显示完整路径 + 可复制 + 选择目录修复
  // ======================================================
  Widget _buildDownloadPathSetting(BuildContext context) {
    return Consumer2<SettingsProvider, DownloadProvider>(
      builder: (context, settings, downloadProvider, child) {
        final path = downloadProvider.downloadPath;
        final isCustom = downloadProvider.useCustomPath;
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade700;
        final borderColor = isDark ? Colors.grey.shade700 : Colors.grey.shade300;
        final blueColor = isDark ? Colors.blue.shade400 : Colors.blue.shade600;
        final orangeColor = isDark ? Colors.orange.shade400 : Colors.orange.shade700;
        return Card(
          child: Column(
            children: [
              ListTile(
                leading: const Icon(Icons.folder_outlined),
                title: const Text('下载路径'),
                subtitle: Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        path,
                        style: TextStyle(
                          fontSize: 12,
                          color: secondaryTextColor,
                          fontFamily: 'monospace',
                          height: 1.3,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 6),
                      Row(
                        children: [
                          Icon(Icons.copy,
                              size: 12, color: blueColor),
                          const SizedBox(width: 4),
                          Text(
                            '点击复制路径',
                            style: TextStyle(
                              fontSize: 11,
                              color: blueColor,
                              decoration: TextDecoration.underline,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                isThreeLine: true,
                trailing: const Icon(Icons.chevron_right),
                onTap: () {
                  // 点击复制路径
                  Clipboard.setData(ClipboardData(text: path));
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                        content: Text('路径已复制到剪贴板'),
                        duration: Duration(seconds: 1)),
                  );
                },
                onLongPress: () => _showDownloadPathDialog(context),
              ),
              // 更改路径按钮
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                child: SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: () => _showDownloadPathDialog(context),
                    icon: const Icon(Icons.edit_outlined, size: 16),
                    label: const Text('更改下载路径'),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      side: BorderSide(color: borderColor),
                    ),
                  ),
                ),
              ),
              if (isCustom)
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                  child: Row(
                    children: [
                      Icon(Icons.info_outline,
                          size: 14, color: orangeColor),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          '自定义目录需要存储权限，使用默认目录无需权限',
                          style: TextStyle(
                            fontSize: 11,
                            color: orangeColor,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              // 按平台分类保存
              Consumer<SettingsProvider>(
                builder: (context, settings, child) {
                  return SwitchListTile(
                    secondary: const Icon(Icons.folder_special_outlined),
                    title: const Text('按平台分类保存'),
                    subtitle: Text(
                      '在下载目录下创建平台子文件夹（抖音、快手等）',
                      style: TextStyle(fontSize: 12, color: secondaryTextColor),
                    ),
                    value: settings.organizeByPlatform,
                    onChanged: (value) async {
                      await settings.setOrganizeByPlatform(value);
                      // 同步到下载管理器
                      if (context.mounted) {
                        context.read<DownloadProvider>().manager.organizeByPlatform = value;
                      }
                    },
                  );
                },
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildWifiOnlySetting(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        return SwitchListTile(
          secondary: const Icon(Icons.wifi_outlined),
          title: const Text('仅 WiFi 下载'),
          subtitle: const Text('移动网络下不自动下载'),
          value: settings.wifiOnly,
          onChanged: (value) => settings.setWifiOnly(value),
        );
      },
    );
  }

  Widget _buildAutoDownloadOnShareSetting(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        return SwitchListTile(
            secondary: const Icon(Icons.share_outlined),
            title: const Text('分享后自动下载'),
            subtitle: const Text('从其他应用分享链接时自动开始下载'),
            value: settings.autoDownloadOnShare,
            onChanged: (value) => settings.setAutoDownloadOnShare(value),
        );
      },
    );
  }

  Widget _buildAutoPasteAndDownloadSetting(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        return SwitchListTile(
            secondary: const Icon(Icons.auto_awesome_outlined),
            title: const Text('自动粘贴解析下载'),
            subtitle: const Text('打开应用时自动粘贴剪贴板链接并解析下载'),
            value: settings.autoPasteAndDownload,
            onChanged: (value) {
              settings.setAutoPasteAndDownload(value);
            },
        );
      },
    );
  }

  Widget _buildDownloadConcurrencySetting(BuildContext context) {
    return Consumer2<SettingsProvider, DownloadProvider>(
      builder: (context, settings, downloadProvider, child) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        final concurrency = settings.downloadConcurrency;
        return Card(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 8, 8),
            child: Row(
              children: [
                Icon(Icons.download_outlined, color: secondaryTextColor),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        '并发下载数',
                        style: TextStyle(fontSize: 15),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        '同时下载 $concurrency 个任务',
                        style: TextStyle(color: secondaryTextColor, fontSize: 12),
                      ),
                      Slider(
                        value: concurrency.toDouble(),
                        min: 1,
                        max: 5,
                        divisions: 4,
                        label: '$concurrency 个',
                        onChanged: (value) {
                          final v = value.round();
                          settings.setDownloadConcurrency(v);
                          downloadProvider.manager.setMaxConcurrency(v);
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildDownloadSoundSetting(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        return Card(
          child: Column(
            children: [
              SwitchListTile(
                secondary: const Icon(Icons.volume_up_outlined),
                title: const Text('下载完成音效'),
                subtitle: const Text('下载完成时播放提示音'),
                value: settings.downloadSoundEnabled,
                onChanged: (value) => settings.setDownloadSoundEnabled(value),
              ),
              if (settings.downloadSoundEnabled) ...[
                const Divider(height: 1, indent: 72),
                ListTile(
                  leading: const SizedBox.shrink(),
                  title: const Text('音效选择'),
                  subtitle: Text(
                    _soundTypeName(settings.downloadSoundType),
                    style: TextStyle(color: secondaryTextColor, fontSize: 13),
                  ),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => _showSoundTypeDialog(context),
                ),
              ],
            ],
          ),
        );
      },
    );
  }

  Widget _buildDownloadCompleteActionSetting(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        return ListTile(
            leading: const Icon(Icons.play_circle_outline),
            title: const Text('下载完成后'),
            subtitle: Text(
              _completeActionName(settings.downloadCompleteAction),
              style: TextStyle(color: secondaryTextColor, fontSize: 13),
            ),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _showCompleteActionDialog(context),
        );
      },
    );
  }

  Widget _buildDownloadNotificationSetting(BuildContext context) {
    return Consumer2<SettingsProvider, DownloadProvider>(
      builder: (context, settings, downloadProvider, child) {
        return SwitchListTile(
            secondary: const Icon(Icons.notifications_active_outlined),
            title: const Text('下载完成通知'),
            subtitle: const Text('下载完成时发送系统通知'),
            value: settings.downloadNotificationEnabled,
            onChanged: (value) async {
              await settings.setDownloadNotificationEnabled(value);
              downloadProvider.manager.downloadNotificationEnabled = value;
            },
        );
      },
    );
  }

  Widget _buildAutoSaveToGallerySetting(BuildContext context) {
    return Consumer2<SettingsProvider, DownloadProvider>(
      builder: (context, settings, downloadProvider, child) {
        return SwitchListTile(
          secondary: const Icon(Icons.photo_library_outlined),
          title: const Text('下载完成自动保存到相册'),
          subtitle: const Text('默认开启，视频和图片下载完成后自动添加到系统相册（音频除外）'),
          value: settings.autoSaveToGallery,
          onChanged: (value) async {
            await settings.setAutoSaveToGallery(value);
            downloadProvider.manager.autoSaveToGallery = value;
          },
        );
      },
    );
  }

  // ======================================================
  // 代理设置
  // ======================================================

  Widget _buildProxySetting(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        final borderColor = isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0);
        final enabled = settings.proxyEnabled;

        return Container(
          decoration: BoxDecoration(
            color: AppTheme.cardBg(context),
            borderRadius: BorderRadius.circular(AppTheme.radiusLg),
            border: Border.all(color: borderColor, width: 0.5),
            boxShadow: AppTheme.shadowSm,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SwitchListTile(
                secondary: const Icon(Icons.vpn_lock_outlined),
                title: const Text('网络代理'),
                subtitle: Text(
                  enabled ? settings.proxyHost.isNotEmpty ? '${settings.proxyType}://${settings.proxyHost}:${settings.proxyPort}' : '已启用，未配置地址' : '未启用',
                  style: TextStyle(fontSize: 12, color: secondaryTextColor),
                ),
                value: enabled,
                onChanged: (value) async {
                  await settings.setProxyEnabled(value);
                  // 通知 ProxyService 更新（通过 SettingsProvider 的 notifyListeners，ProxyService 由 main.dart 中监听）
                },
              ),
              if (enabled) ...[
                const Divider(height: 0.5, thickness: 0.5, indent: 16, endIndent: 16),
                const SizedBox(height: 8),
                // 代理类型
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 80,
                        child: Text('代理类型', style: TextStyle(fontSize: 14, color: secondaryTextColor)),
                      ),
                      Expanded(
                        child: SegmentedButton<String>(
                          segments: const [
                            ButtonSegment(value: 'http', label: Text('HTTP')),
                            ButtonSegment(value: 'https', label: Text('HTTPS')),
                            ButtonSegment(value: 'socks5', label: Text('SOCKS5')),
                          ],
                          selected: {settings.proxyType},
                          onSelectionChanged: (Set<String> s) {
                            settings.setProxyType(s.first);
                          },
                          style: ButtonStyle(
                            visualDensity: VisualDensity.compact,
                            textStyle: WidgetStateProperty.all(const TextStyle(fontSize: 12)),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                // 代理地址和端口
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 80,
                        child: Text('代理地址', style: TextStyle(fontSize: 14, color: secondaryTextColor)),
                      ),
                      Expanded(
                        child: TextField(
                          controller: _proxyHostController,
                          decoration: InputDecoration(
                            hintText: '127.0.0.1',
                            isDense: true,
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                            contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                          ),
                          onChanged: (value) => settings.setProxyHost(value.trim()),
                        ),
                      ),
                      const SizedBox(width: 12),
                      SizedBox(
                        width: 60,
                        child: TextField(
                          controller: _proxyPortController,
                          keyboardType: TextInputType.number,
                          decoration: InputDecoration(
                            hintText: '8080',
                            isDense: true,
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                            contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                          ),
                          onChanged: (value) {
                            final port = int.tryParse(value.trim()) ?? 8080;
                            settings.setProxyPort(port);
                          },
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                // 用户名和密码
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 80,
                        child: Text('用户名', style: TextStyle(fontSize: 14, color: secondaryTextColor)),
                      ),
                      Expanded(
                        child: TextField(
                          controller: _proxyUserController,
                          decoration: InputDecoration(
                            hintText: '可选',
                            isDense: true,
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                            contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                          ),
                          onChanged: (value) => settings.setProxyUsername(value.trim().isEmpty ? null : value.trim()),
                        ),
                      ),
                      const SizedBox(width: 12),
                      SizedBox(
                        width: 80,
                        child: Text('密码', style: TextStyle(fontSize: 14, color: secondaryTextColor)),
                      ),
                      Expanded(
                        child: TextField(
                          controller: _proxyPassController,
                          obscureText: !_proxyPasswordVisible,
                          decoration: InputDecoration(
                            hintText: '可选',
                            isDense: true,
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                            contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                            suffixIcon: IconButton(
                              icon: Icon(
                                _proxyPasswordVisible ? Icons.visibility_off : Icons.visibility,
                                size: 18,
                              ),
                              onPressed: () {
                                setState(() {
                                  _proxyPasswordVisible = !_proxyPasswordVisible;
                                });
                              },
                              padding: EdgeInsets.zero,
                              constraints: const BoxConstraints(),
                            ),
                          ),
                          onChanged: (value) => settings.setProxyPassword(value.trim().isEmpty ? null : value.trim()),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                // 测试按钮 + 绕过域名
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 80,
                        child: Text('连通性测试', style: TextStyle(fontSize: 14, color: secondaryTextColor)),
                      ),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: _proxyTesting ? null : () => _testProxyConnection(context),
                          icon: _proxyTesting
                              ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2))
                              : const Icon(Icons.network_check, size: 16),
                          label: Text(_proxyTesting ? '测试中...' : '测试代理连通性'),
                          style: OutlinedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(vertical: 8),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                if (_proxyTestResult != null) ...[
                  const SizedBox(height: 6),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Row(
                      children: [
                        const SizedBox(width: 80),
                        Expanded(
                          child: Row(
                            children: [
                              Icon(
                                _proxyTestResult!.$1 ? Icons.check_circle : Icons.error_outline,
                                size: 16,
                                color: _proxyTestResult!.$1 ? Colors.green : Colors.red,
                              ),
                              const SizedBox(width: 6),
                              Expanded(
                                child: Text(
                                  _proxyTestResult!.$1
                                      ? '连接成功（${_proxyTestResult!.$2}ms）'
                                      : '连接失败：${_proxyTestResult!.$3 ?? '未知错误'}',
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: _proxyTestResult!.$1 ? Colors.green : Colors.red,
                                  ),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
                const SizedBox(height: 8),
                // 绕过代理的域名
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: 80,
                        child: Padding(
                          padding: const EdgeInsets.only(top: 10),
                          child: Text('绕过域名', style: TextStyle(fontSize: 14, color: secondaryTextColor)),
                        ),
                      ),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Wrap(
                              spacing: 6,
                              runSpacing: 6,
                              children: [
                                ...settings.proxyBypassDomains.asMap().entries.map((entry) {
                                  return Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: isDark ? Colors.grey.shade800 : Colors.grey.shade100,
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Text(entry.value, style: const TextStyle(fontSize: 12)),
                                        const SizedBox(width: 4),
                                        GestureDetector(
                                          onTap: () {
                                            final newList = List<String>.from(settings.proxyBypassDomains);
                                            newList.removeAt(entry.key);
                                            settings.setProxyBypassDomains(newList);
                                          },
                                          child: Icon(Icons.close, size: 14, color: secondaryTextColor),
                                        ),
                                      ],
                                    ),
                                  );
                                }),
                                GestureDetector(
                                  onTap: () => _addProxyBypassDomain(context),
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                    decoration: BoxDecoration(
                                      border: Border.all(color: borderColor, width: 1),
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Icon(Icons.add, size: 14, color: secondaryTextColor),
                                        const SizedBox(width: 2),
                                        Text('添加', style: TextStyle(fontSize: 12, color: secondaryTextColor)),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 4),
                            Text(
                              '匹配域名及其子域名，直接连接不走代理',
                              style: TextStyle(fontSize: 11, color: secondaryTextColor),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
              ],
            ],
          ),
        );
      },
    );
  }

  bool _proxyTesting = false;
  (bool, int, String?)? _proxyTestResult;
  bool _proxyPasswordVisible = false;
  final TextEditingController _proxyHostController = TextEditingController();
  final TextEditingController _proxyPortController = TextEditingController();
  final TextEditingController _proxyUserController = TextEditingController();
  final TextEditingController _proxyPassController = TextEditingController();

  Future<void> _testProxyConnection(BuildContext context) async {
    setState(() {
      _proxyTesting = true;
      _proxyTestResult = null;
    });

    // 使用 ProxyService 测试（通过 Provider 获取）
    try {
      // 直接用 settings 中的配置临时测试
      final settings = context.read<SettingsProvider>();
      final proxyService = ProxyService();
      proxyService.updateConfig(
        enabled: settings.proxyEnabled,
        type: settings.proxyType,
        host: settings.proxyHost,
        port: settings.proxyPort,
        username: settings.proxyUsername,
        password: settings.proxyPassword,
        bypassDomains: settings.proxyBypassDomains,
      );
      final result = await proxyService.testConnection();
      if (mounted) {
        setState(() {
          _proxyTesting = false;
          _proxyTestResult = result;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _proxyTesting = false;
          _proxyTestResult = (false, 0, e.toString());
        });
      }
    }
  }

  Future<void> _addProxyBypassDomain(BuildContext context) async {
    final settings = context.read<SettingsProvider>();
    final controller = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('添加绕过域名'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(
            hintText: '例如：example.com',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () {
              final domain = controller.text.trim().toLowerCase();
              if (domain.isNotEmpty) {
                final newList = List<String>.from(settings.proxyBypassDomains);
                if (!newList.contains(domain)) {
                  newList.add(domain);
                  settings.setProxyBypassDomains(newList);
                }
              }
              Navigator.pop(context);
            },
            child: const Text('添加'),
          ),
        ],
      ),
    ).then((_) => controller.dispose());
  }

  // ======================================================
  // 智能分类存储
  // ======================================================

  Widget _buildStorageOrganizeModeSetting(BuildContext context) {
    return Consumer2<SettingsProvider, DownloadProvider>(
      builder: (context, settings, downloadProvider, child) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        return ListTile(
          leading: const Icon(Icons.folder_special_outlined),
          title: const Text('存储组织模式'),
          subtitle: Text(
            _organizeModeName(settings.storageOrganizeMode),
            style: TextStyle(color: secondaryTextColor, fontSize: 13),
          ),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _showStorageOrganizeModeDialog(context),
        );
      },
    );
  }

  Widget _buildStorageNamingRuleSetting(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        return ListTile(
          leading: const Icon(Icons.text_fields),
          title: const Text('文件命名规则'),
          subtitle: Text(
            _namingRuleName(settings.storageNamingRule),
            style: TextStyle(color: secondaryTextColor, fontSize: 13),
          ),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _showStorageNamingRuleDialog(context),
        );
      },
    );
  }

  String _organizeModeName(String mode) {
    switch (mode) {
      case 'flat': return '平铺（所有文件在同一目录）';
      case 'platform': return '按平台分类（抖音/快手/小红书）';
      case 'author': return '按作者分类';
      case 'date': return '按日期分类';
      case 'platform_author': return '平台 + 作者（两级目录）';
      default: return '平铺';
    }
  }

  String _namingRuleName(String rule) {
    switch (rule) {
      case 'title': return '标题';
      case 'platform_title': return '平台_标题';
      case 'date_title': return '日期_标题';
      case 'id_title': return 'ID_标题';
      default: return '标题';
    }
  }

  Future<void> _showStorageOrganizeModeDialog(BuildContext context) async {
    final settings = context.read<SettingsProvider>();
    final downloadProvider = context.read<DownloadProvider>();
    final currentMode = settings.storageOrganizeMode;
    final currentDateFormat = settings.storageDateFormat;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade500;

    final modes = [
      ('flat', '平铺', '所有文件保存在同一目录', Icons.folder_outlined),
      ('platform', '按平台', '抖音/快手/小红书 子文件夹', Icons.language_outlined),
      ('author', '按作者', '以作者名创建子文件夹', Icons.person_outline),
      ('date', '按日期', '以日期创建子文件夹', Icons.calendar_today_outlined),
      ('platform_author', '平台+作者', '两级目录：平台/作者', Icons.account_tree_outlined),
    ];

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('存储组织模式'),
        content: StatefulBuilder(
          builder: (context, setState) {
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ...modes.map((m) {
                  final isSelected = m.$1 == currentMode;
                  return ListTile(
                    leading: Icon(m.$4, color: isSelected ? AppTheme.primaryColor : secondaryTextColor),
                    title: Text(m.$2),
                    subtitle: Text(m.$3, style: TextStyle(fontSize: 12, color: secondaryTextColor)),
                    trailing: isSelected
                        ? Icon(Icons.check_circle, color: AppTheme.primaryColor)
                        : const SizedBox.shrink(),
                    onTap: () {
                      settings.setStorageOrganizeMode(m.$1);
                      // 同步到下载管理器
                      downloadProvider.manager.storageOrganizeMode = m.$1;
                      Navigator.pop(context);
                    },
                  );
                }).toList(),
                if (currentMode == 'date') ...[
                  const Divider(height: 1),
                  const SizedBox(height: 8),
                  const Text('日期格式', style: TextStyle(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 4),
                  Wrap(
                    spacing: 8,
                    children: [
                      _buildDateFormatChip('yyyyMMdd', currentDateFormat, secondaryTextColor, (val) {
                        settings.setStorageDateFormat(val);
                        downloadProvider.manager.storageDateFormat = val;
                      }),
                      _buildDateFormatChip('yyyy-MM', currentDateFormat, secondaryTextColor, (val) {
                        settings.setStorageDateFormat(val);
                        downloadProvider.manager.storageDateFormat = val;
                      }),
                      _buildDateFormatChip('yyyy-MM-dd', currentDateFormat, secondaryTextColor, (val) {
                        settings.setStorageDateFormat(val);
                        downloadProvider.manager.storageDateFormat = val;
                      }),
                    ],
                  ),
                ],
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildDateFormatChip(
    String format,
    String current,
    Color secondaryColor,
    void Function(String) onTap,
  ) {
    final isSelected = format == current;
    return GestureDetector(
      onTap: () => onTap(format),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: isSelected ? AppTheme.primaryColor.withOpacity(0.1) : Colors.transparent,
          border: Border.all(
            color: isSelected ? AppTheme.primaryColor : secondaryColor,
            width: isSelected ? 1.5 : 1,
          ),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Text(
          format,
          style: TextStyle(
            fontSize: 12,
            color: isSelected ? AppTheme.primaryColor : secondaryColor,
            fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
          ),
        ),
      ),
    );
  }

  Future<void> _showStorageNamingRuleDialog(BuildContext context) async {
    final settings = context.read<SettingsProvider>();
    final downloadProvider = context.read<DownloadProvider>();
    final currentRule = settings.storageNamingRule;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade500;

    final rules = [
      ('title', '标题', '作品标题.mp4'),
      ('platform_title', '平台_标题', '抖音_作品标题.mp4'),
      ('date_title', '日期_标题', '20240101_作品标题.mp4'),
      ('id_title', 'ID_标题', 'abc123_作品标题.mp4'),
    ];

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('文件命名规则'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: rules.map((r) {
            final isSelected = r.$1 == currentRule;
            return ListTile(
              title: Text(r.$2),
              subtitle: Text(r.$3, style: TextStyle(fontSize: 12, color: secondaryTextColor, fontFamily: 'monospace')),
              trailing: isSelected
                  ? Icon(Icons.check_circle, color: AppTheme.primaryColor)
                  : const SizedBox.shrink(),
              onTap: () {
                settings.setStorageNamingRule(r.$1);
                downloadProvider.manager.storageNamingRule = r.$1;
                Navigator.pop(context);
              },
            );
          }).toList(),
        ),
      ),
    );
  }

  Widget _buildDefaultAudioFormatSetting(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        return ListTile(
          leading: const Icon(Icons.audiotrack_outlined),
          title: const Text('默认音频格式'),
          subtitle: Text(
            _audioFormatName(settings.defaultAudioFormat),
            style: TextStyle(color: secondaryTextColor, fontSize: 13),
          ),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _showAudioFormatDialog(context),
        );
      },
    );
  }

  /// 自动清理下载记录设置
  Widget _buildAutoRetrySetting(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        final downloadProvider = context.read<DownloadProvider>();
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        final maxRetry = settings.maxRetryCount;
        return Column(
          children: [
            SwitchListTile(
              secondary: const Icon(Icons.refresh_outlined),
              title: const Text('下载失败自动重试'),
              subtitle: Text(
                '网络异常时自动重试下载',
                style: TextStyle(color: secondaryTextColor, fontSize: 12),
              ),
              value: settings.autoRetryOnFailure,
              onChanged: (value) {
                settings.setAutoRetryOnFailure(value);
                downloadProvider.manager.setAutoRetryOnFailure(value);
              },
            ),
            if (settings.autoRetryOnFailure) ...[
              const Divider(height: 1, indent: 72),
              Padding(
                padding: const EdgeInsets.fromLTRB(72, 8, 16, 8),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            '最大重试次数',
                            style: TextStyle(fontSize: 14),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            '最多重试 $maxRetry 次',
                            style: TextStyle(color: secondaryTextColor, fontSize: 12),
                          ),
                          Slider(
                            value: maxRetry.toDouble(),
                            min: 1,
                            max: 5,
                            divisions: 4,
                            label: '$maxRetry 次',
                            onChanged: (value) {
                              final v = value.round();
                              settings.setMaxRetryCount(v);
                              downloadProvider.manager.setMaxRetryCount(v);
                            },
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        );
      },
    );
  }

  Widget _buildAutoCleanDownloadsSetting(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        final downloadProvider = context.read<DownloadProvider>();
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        return Column(
          children: [
            SwitchListTile(
              secondary: const Icon(Icons.cleaning_services_outlined),
              title: const Text('自动清理已完成任务'),
              subtitle: Text(
                '下载完成后自动清理超出限制的记录',
                style: TextStyle(color: secondaryTextColor, fontSize: 12),
              ),
              value: settings.autoCleanDownloadsEnabled,
              onChanged: (value) {
                settings.setAutoCleanDownloadsEnabled(value);
                downloadProvider.manager.autoCleanDownloadsEnabled = value;
              },
            ),
            if (settings.autoCleanDownloadsEnabled) ...[
              const Divider(height: 1, indent: 72),
              // 清理策略
              ListTile(
                leading: const SizedBox.shrink(),
                title: const Text('清理策略'),
                subtitle: Text(
                  settings.autoCleanMode == 'days'
                      ? '按保留天数：${settings.autoCleanDays} 天'
                      : '按保留数量：最多 ${settings.autoCleanMaxCount} 条',
                  style: TextStyle(color: secondaryTextColor, fontSize: 13),
                ),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _showAutoCleanStrategyDialog(context),
              ),
              const Divider(height: 1, indent: 72),
              // 清理范围
              SwitchListTile(
                secondary: const SizedBox.shrink(),
                title: const Text('同时删除本地文件'),
                subtitle: Text(
                  settings.autoCleanDeleteFiles ? '清理记录并删除下载的文件' : '仅清理记录，保留文件',
                  style: TextStyle(color: secondaryTextColor, fontSize: 12),
                ),
                value: settings.autoCleanDeleteFiles,
                onChanged: (value) {
                  settings.setAutoCleanDeleteFiles(value);
                  downloadProvider.manager.autoCleanDeleteFiles = value;
                },
              ),
            ],
          ],
        );
      },
    );
  }

  /// 显示自动清理策略选择对话框
  Future<void> _showAutoCleanStrategyDialog(BuildContext context) async {
    final settings = context.read<SettingsProvider>();
    final downloadProvider = context.read<DownloadProvider>();
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textPrimary = isDark ? Colors.white : Colors.grey.shade900;
    final textSecondary = isDark ? Colors.grey.shade400 : Colors.grey.shade600;

    final dayOptions = [7, 15, 30, 90];
    final countOptions = [50, 100, 200, 500];

    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Container(
                        width: 40,
                        height: 4,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade300,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      '清理策略',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: textPrimary,
                      ),
                    ),
                    const SizedBox(height: 16),
                    // 模式选择
                    Row(
                      children: [
                        Expanded(
                          child: GestureDetector(
                            onTap: () {
                              setModalState(() {});
                              settings.setAutoCleanMode('days');
                              downloadProvider.manager.autoCleanMode = 'days';
                            },
                            child: Container(
                              padding: const EdgeInsets.symmetric(vertical: 10),
                              decoration: BoxDecoration(
                                color: settings.autoCleanMode == 'days'
                                    ? AppTheme.primaryColor.withOpacity(0.1)
                                    : Colors.transparent,
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                  color: settings.autoCleanMode == 'days'
                                      ? AppTheme.primaryColor
                                      : (isDark ? Colors.grey.shade700 : Colors.grey.shade300),
                                  width: 1.5,
                                ),
                              ),
                              child: Center(
                                child: Text(
                                  '按保留天数',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    color: settings.autoCleanMode == 'days'
                                        ? AppTheme.primaryColor
                                        : textPrimary,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: GestureDetector(
                            onTap: () {
                              setModalState(() {});
                              settings.setAutoCleanMode('count');
                              downloadProvider.manager.autoCleanMode = 'count';
                            },
                            child: Container(
                              padding: const EdgeInsets.symmetric(vertical: 10),
                              decoration: BoxDecoration(
                                color: settings.autoCleanMode == 'count'
                                    ? AppTheme.primaryColor.withOpacity(0.1)
                                    : Colors.transparent,
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                  color: settings.autoCleanMode == 'count'
                                      ? AppTheme.primaryColor
                                      : (isDark ? Colors.grey.shade700 : Colors.grey.shade300),
                                  width: 1.5,
                                ),
                              ),
                              child: Center(
                                child: Text(
                                  '按保留数量',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    color: settings.autoCleanMode == 'count'
                                        ? AppTheme.primaryColor
                                        : textPrimary,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    // 选项列表
                    if (settings.autoCleanMode == 'days') ...[
                      Text(
                        '保留天数',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: textSecondary,
                        ),
                      ),
                      const SizedBox(height: 8),
                      ...dayOptions.map((days) => RadioListTile<int>(
                        value: days,
                        groupValue: settings.autoCleanDays,
                        onChanged: (v) {
                          if (v != null) {
                            settings.setAutoCleanDays(v);
                            downloadProvider.manager.autoCleanDays = v;
                            setModalState(() {});
                          }
                        },
                        title: Text('保留 $days 天'),
                        dense: true,
                        contentPadding: EdgeInsets.zero,
                      )),
                    ] else ...[
                      Text(
                        '保留数量',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: textSecondary,
                        ),
                      ),
                      const SizedBox(height: 8),
                      ...countOptions.map((count) => RadioListTile<int>(
                        value: count,
                        groupValue: settings.autoCleanMaxCount,
                        onChanged: (v) {
                          if (v != null) {
                            settings.setAutoCleanMaxCount(v);
                            downloadProvider.manager.autoCleanMaxCount = v;
                            setModalState(() {});
                          }
                        },
                        title: Text('最多保留 $count 条'),
                        dense: true,
                        contentPadding: EdgeInsets.zero,
                      )),
                    ],
                    const SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () => Navigator.pop(context),
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          backgroundColor: AppTheme.primaryColor,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: const Text(
                          '确定',
                          style: TextStyle(fontWeight: FontWeight.w600),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  String _soundTypeName(String type) {
    switch (type) {
      case 'ding': return '叮咚';
      case 'chime': return '风铃';
      case 'success': return '成功';
      case 'pop': return '气泡';
      default: return '叮咚';
    }
  }

  String _completeActionName(String action) {
    switch (action) {
      case 'none': return '无操作';
      case 'open': return '自动打开文件';
      case 'share': return '自动分享文件';
      default: return '无操作';
    }
  }

  String _audioFormatName(String format) {
    switch (format) {
      case 'aac': return 'AAC';
      case 'm4a': return 'M4A';
      case 'mp3':
      default: return 'MP3';
    }
  }

  String _hapticLevelName(String level) {
    switch (level) {
      case 'light': return '轻微';
      case 'heavy': return '强烈';
      case 'medium': return '中等';
      default: return '中等';
    }
  }

  Future<void> _showSoundTypeDialog(BuildContext context) async {
    final settings = context.read<SettingsProvider>();
    final currentType = settings.downloadSoundType;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade500;
    final soundTypes = [
      ('ding', '叮咚', '清脆的提示音'),
      ('chime', '风铃', '柔和的风铃声'),
      ('success', '成功', '欢快的成功音'),
      ('pop', '气泡', '轻松的气泡音'),
    ];

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('选择音效'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: soundTypes.map((s) {
            final isSelected = s.$1 == currentType;
            return ListTile(
              title: Text(s.$2),
              subtitle: Text(s.$3, style: TextStyle(fontSize: 12, color: secondaryTextColor)),
              trailing: isSelected
                  ? Icon(Icons.check_circle, color: AppTheme.primaryColor)
                  : const SizedBox.shrink(),
              onTap: () {
                settings.setDownloadSoundType(s.$1);
                Navigator.pop(context);
              },
            );
          }).toList(),
        ),
      ),
    );
  }

  Future<void> _showCompleteActionDialog(BuildContext context) async {
    final settings = context.read<SettingsProvider>();
    final currentAction = settings.downloadCompleteAction;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade500;
    final actions = [
      ('none', '无操作', '下载完成后仅通知，不自动操作'),
      ('open', '自动打开文件', '下载完成后自动打开视频/图片'),
      ('share', '自动分享文件', '下载完成后自动弹出分享面板'),
    ];

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('下载完成后'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: actions.map((a) {
            final isSelected = a.$1 == currentAction;
            return ListTile(
              title: Text(a.$2),
              subtitle: Text(a.$3, style: TextStyle(fontSize: 12, color: secondaryTextColor)),
              trailing: isSelected
                  ? Icon(Icons.check_circle, color: AppTheme.primaryColor)
                  : const SizedBox.shrink(),
              onTap: () {
                settings.setDownloadCompleteAction(a.$1);
                Navigator.pop(context);
              },
            );
          }).toList(),
        ),
      ),
    );
  }

  Future<void> _showAudioFormatDialog(BuildContext context) async {
    final settings = context.read<SettingsProvider>();
    final currentFormat = settings.defaultAudioFormat;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade500;
    final formats = [
      ('mp3', 'MP3', '兼容性最好，文件体积适中'),
      ('aac', 'AAC', '音质更好，文件体积更小'),
      ('m4a', 'M4A', '苹果设备推荐格式'),
    ];

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('默认音频格式'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: formats.map((f) {
            final isSelected = f.$1 == currentFormat;
            return ListTile(
              title: Text(f.$2),
              subtitle: Text(f.$3, style: TextStyle(fontSize: 12, color: secondaryTextColor)),
              trailing: isSelected
                  ? Icon(Icons.check_circle, color: AppTheme.primaryColor)
                  : const SizedBox.shrink(),
              onTap: () {
                settings.setDefaultAudioFormat(f.$1);
                Navigator.pop(context);
              },
            );
          }).toList(),
        ),
      ),
    );
  }

  Future<void> _showHapticLevelDialog(BuildContext context) async {
    final settings = context.read<SettingsProvider>();
    final currentLevel = settings.hapticFeedbackLevel;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade500;
    final levels = [
      ('light', '轻微', '轻柔的震动反馈'),
      ('medium', '中等', '适中的震动反馈'),
      ('heavy', '强烈', '较强的震动反馈'),
    ];

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('触觉反馈强度'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: levels.map((l) {
            final isSelected = l.$1 == currentLevel;
            return ListTile(
              title: Text(l.$2),
              subtitle: Text(l.$3, style: TextStyle(fontSize: 12, color: secondaryTextColor)),
              trailing: isSelected
                  ? Icon(Icons.check_circle, color: AppTheme.primaryColor)
                  : const SizedBox.shrink(),
              onTap: () {
                settings.setHapticFeedbackLevel(l.$1);
                // 立即触发一次反馈，让用户感受强度
                switch (l.$1) {
                  case 'light':
                    HapticFeedback.lightImpact();
                    break;
                  case 'heavy':
                    HapticFeedback.heavyImpact();
                    break;
                  case 'medium':
                  default:
                    HapticFeedback.mediumImpact();
                    break;
                }
                Navigator.pop(context);
              },
            );
          }).toList(),
        ),
      ),
    );
  }

  // ======================================================
  // 自定义解析源入口
  // ======================================================
  Widget _buildCustomSourcesEntry(BuildContext context) {
    return Consumer<CustomSourceProvider>(
      builder: (context, provider, child) {
        return ListTile(
          leading: const Icon(Icons.link_outlined),
          title: const Text('自定义解析源'),
          subtitle: Text(
            provider.totalCount > 0
                ? '已添加 ${provider.totalCount} 个，启用 ${provider.enabledCount} 个'
                : '添加你自己的 API 解析服务',
          ),
          trailing: const Icon(Icons.chevron_right),
          onTap: () {
            Navigator.push(context, AppPageRoute.slideRight(const CustomSourcesPage()));
          },
        );
      },
    );
  }

  // ======================================================
  // 解析源质量看板入口
  // ======================================================
  Widget _buildSourceStatsEntry(BuildContext context) {
    return Consumer<SourceStatsProvider>(
      builder: (context, provider, child) {
        final hasData = provider.totalRequests > 0;
        return ListTile(
          leading: const Icon(Icons.bar_chart_outlined),
          title: const Text('解析源质量看板'),
          subtitle: Text(
            hasData
                ? '总请求 ${provider.totalRequests} 次，成功率 ${(provider.overallSuccessRate * 100).toStringAsFixed(1)}%'
                : '查看各解析源成功率与耗时统计',
          ),
          trailing: const Icon(Icons.chevron_right),
          onTap: () {
            Navigator.push(context, AppPageRoute.slideRight(const SourceStatsPage()));
          },
        );
      },
    );
  }

  // ======================================================
  // Cookie 管理面板入口
  // ======================================================
  Widget _buildCookieManagerEntry(BuildContext context) {
    return Consumer<CookieProvider>(
      builder: (context, provider, child) {
        return ListTile(
          leading: const Icon(Icons.cookie_outlined),
          title: const Text('Cookie 管理面板'),
          subtitle: Text(
            provider.totalCount > 0
                ? '共 ${provider.totalCount} 个，有效 ${provider.activeCount} 个'
                : '管理各平台 Cookie，支持多账号切换',
          ),
          trailing: const Icon(Icons.chevron_right),
          onTap: () {
            Navigator.push(context, AppPageRoute.slideRight(const CookieManagerPage()));
          },
        );
      },
    );
  }

  // ======================================================
  // 解析 API 源
  // ======================================================
  Widget _buildApiSourceSetting(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        final currentSource = ApiSource.fromId(settings.apiSourceId);
        return ListTile(
            leading: const Icon(Icons.api_outlined),
            title: const Text('解析API源'),
            subtitle: Text(
              currentSource?.name ?? '内置解析器',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _showApiSourceDialog(context),
        );
      },
    );
  }

  // ======================================================
  // 抖音高级设置：UID补全服务 + Cookie管理（折叠式专区）
  // ======================================================
  Widget _buildDouyinAdvancedSection(BuildContext context) {
    return ExpansionTile(
      clipBehavior: Clip.antiAlias,
      leading: const Icon(Icons.tune_outlined),
        title: const Text(
          '抖音高级设置',
          style: TextStyle(fontWeight: FontWeight.w600, fontSize: 15),
        ),
        subtitle: Consumer<SettingsProvider>(
          builder: (context, settings, child) {
            final hasCookie = settings.douyinCookies.isNotEmpty;
            final hasUid = settings.uidResolveServiceUrl?.isNotEmpty ?? false;
            final items = <String>[];
            if (hasUid) items.add('UID服务已配');
            if (hasCookie) items.add('Cookie已获取');
            return Text(
              items.isEmpty ? 'UID 补全 / Cookie 管理 / 登录获取' : items.join(' · '),
              style: const TextStyle(fontSize: 12),
            );
          },
        ),
        childrenPadding: const EdgeInsets.fromLTRB(8, 4, 8, 12),
        children: [
          const SizedBox(height: 4),
          _buildUidResolveServiceTile(context),
          const Divider(height: 1, indent: 16, endIndent: 16),
          _buildCookieManagementTile(context),
        ],
    );
  }

  /// UID 补全服务子项
  Widget _buildUidResolveServiceTile(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        final url = settings.uidResolveServiceUrl;
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final hintColor = isDark ? Colors.grey.shade600 : Colors.grey.shade500;
        final textColor = isDark ? Colors.grey.shade400 : Colors.grey.shade700;
        return ListTile(
          leading: const Icon(Icons.link_outlined, size: 22),
          title: const Text('UID 补全服务', style: TextStyle(fontSize: 14)),
          subtitle: Text(
            url != null && url.isNotEmpty
                ? url
                : '未配置（抖音不公开数字UID，需服务端中转获取）',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 12,
              color: url != null && url.isNotEmpty ? textColor : hintColor,
            ),
          ),
          trailing: const Icon(Icons.chevron_right, size: 20),
          onTap: () => _showUidResolveServiceDialog(context),
        );
      },
    );
  }

  /// Cookie 管理（内嵌折叠面板）
  Widget _buildCookieManagementTile(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        final cookieCount = settings.douyinCookies.length;
        final hasCookie = cookieCount > 0;
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final greenColor = isDark ? Colors.green.shade400 : Colors.green.shade700;
        return ExpansionTile(
          leading: Icon(
            Icons.cookie_outlined,
            size: 22,
            color: hasCookie ? greenColor : null,
          ),
          title: const Text('Cookie 管理', style: TextStyle(fontSize: 14)),
          subtitle: Text(
            hasCookie ? '已获取 $cookieCount 个关键 Cookie' : '未配置',
            style: TextStyle(
              fontSize: 12,
              color: hasCookie ? greenColor : (isDark ? Colors.grey.shade500 : Colors.grey.shade600),
            ),
          ),
          tilePadding: const EdgeInsets.symmetric(horizontal: 16),
          childrenPadding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
          children: [
            const SizedBox(height: 4),
            // Cookie 状态详情
            if (hasCookie) _buildCookieStatusDetail(context),
            if (hasCookie) const SizedBox(height: 12),
            // 操作按钮网格
            _buildCookieActionGrid(context),
          ],
        );
      },
    );
  }

  /// Cookie 状态详情
  Widget _buildCookieStatusDetail(BuildContext context) {
    final settings = context.watch<SettingsProvider>();
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final borderColor = isDark ? Colors.grey.shade700 : Colors.grey.shade300;
    final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
    final greenColor = isDark ? Colors.green.shade400 : Colors.green;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: greenColor.withOpacity(isDark ? 0.08 : 0.04),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: greenColor.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.check_circle, size: 16, color: greenColor),
              const SizedBox(width: 6),
              Text(
                '当前有效 Cookie：${settings.douyinCookies.length} 个',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: greenColor,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          ...settings.douyinCookies.entries.map((entry) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 3),
              child: Row(
                children: [
                  SizedBox(
                    width: 110,
                    child: Text(
                      entry.key,
                      style: TextStyle(
                        fontSize: 11,
                        fontFamily: 'monospace',
                        color: secondaryTextColor,
                      ),
                    ),
                  ),
                  Expanded(
                    child: Text(
                      _maskCookieValue(entry.value),
                      style: const TextStyle(
                        fontSize: 11,
                        fontFamily: 'monospace',
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            );
          }).toList(),
        ],
      ),
    );
  }

  /// Cookie 操作按钮网格
  Widget _buildCookieActionGrid(BuildContext context) {
    final settings = context.watch<SettingsProvider>();
    final hasCookie = settings.douyinCookies.isNotEmpty;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final borderColor = isDark ? Colors.grey.shade700 : Colors.grey.shade300;
    final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
    final primaryColor = AppTheme.primaryColor;

    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: _buildCookieActionButton(
                context,
                icon: Icons.login_outlined,
                label: '登录获取',
                subLabel: '内置浏览器',
                color: primaryColor,
                onTap: () {
                  Navigator.push(
                    context,
                    AppPageRoute.slideRight(const WebviewCookiePage()),
                  );
                },
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _buildCookieActionButton(
                context,
                icon: Icons.edit_note_outlined,
                label: '手动输入',
                subLabel: '粘贴 Cookie',
                color: Colors.blue,
                onTap: () => _showManualCookieInputDialog(context),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: _buildCookieActionButton(
                context,
                icon: Icons.restore_outlined,
                label: '恢复备份',
                subLabel: '从备份恢复',
                color: Colors.orange,
                onTap: hasCookie ? null : () => _handleRestoreCookies(context),
                enabled: !hasCookie,
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _buildCookieActionButton(
                context,
                icon: Icons.delete_outline,
                label: '清除 Cookie',
                subLabel: '先自动备份',
                color: Colors.red,
                onTap: hasCookie ? () => _handleClearCookies(context) : null,
                enabled: hasCookie,
              ),
            ),
          ],
        ),
      ],
    );
  }

  /// 单个 Cookie 操作按钮
  Widget _buildCookieActionButton(
    BuildContext context, {
    required IconData icon,
    required String label,
    required String subLabel,
    required Color color,
    required VoidCallback? onTap,
    bool enabled = true,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final borderColor = isDark ? Colors.grey.shade700 : Colors.grey.shade300;
    final disabledColor = isDark ? Colors.grey.shade800 : Colors.grey.shade100;
    final disabledTextColor = isDark ? Colors.grey.shade600 : Colors.grey.shade400;

    final effectiveColor = enabled ? color : disabledTextColor;
    final bgColor = enabled
        ? color.withOpacity(isDark ? 0.08 : 0.04)
        : disabledColor;

    return Material(
      color: bgColor,
      borderRadius: BorderRadius.circular(10),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: enabled ? color.withOpacity(0.3) : borderColor,
              width: 1,
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 22, color: effectiveColor),
              const SizedBox(height: 4),
              Text(
                label,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: effectiveColor,
                ),
              ),
              const SizedBox(height: 1),
              Text(
                subLabel,
                style: TextStyle(
                  fontSize: 10,
                  color: enabled
                      ? (isDark ? Colors.grey.shade500 : Colors.grey.shade500)
                      : disabledTextColor,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// 脱敏 Cookie 值
  String _maskCookieValue(String value) {
    if (value.length <= 6) return '***';
    if (value.length <= 12) {
      return '${value.substring(0, 3)}***${value.substring(value.length - 2)}';
    }
    return '${value.substring(0, 5)}***${value.substring(value.length - 4)}';
  }

  /// 处理清除 Cookie
  Future<void> _handleClearCookies(BuildContext context) async {
    final settings = context.read<SettingsProvider>();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('清除 Cookie'),
        content: const Text('确定要清除当前的抖音 Cookie 吗？\n\n清除前会自动备份，之后可通过「恢复备份」找回。'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('确定清除', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirmed == true && context.mounted) {
      // 先备份
      await settings.backupDouyinCookies();
      // 再清除
      await settings.clearDouyinCookies();
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Cookie 已清除（已自动备份）')),
        );
      }
    }
  }

  /// 处理恢复 Cookie
  Future<void> _handleRestoreCookies(BuildContext context) async {
    final settings = context.read<SettingsProvider>();
    final hasBackup = await settings.hasDouyinCookiesBackup();
    if (!hasBackup && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('没有找到备份的 Cookie')),
      );
      return;
    }

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('恢复 Cookie'),
        content: const Text('确定要从备份中恢复 Cookie 吗？'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('恢复'),
          ),
        ],
      ),
    );

    if (confirmed == true && context.mounted) {
      final success = await settings.restoreDouyinCookies();
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(success ? 'Cookie 已恢复' : '恢复失败，备份数据无效'),
          ),
        );
      }
    }
  }

  /// 手动输入 Cookie 弹窗
  Future<void> _showManualCookieInputDialog(BuildContext context) async {
    final controller = TextEditingController();
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
    final hintTextColor = isDark ? Colors.grey.shade600 : Colors.grey.shade400;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('手动输入 Cookie'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '粘贴完整的 Cookie 字符串，格式：key1=value1; key2=value2',
              style: TextStyle(fontSize: 12, color: secondaryTextColor),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: controller,
              maxLines: 4,
              minLines: 3,
              decoration: InputDecoration(
                hintText: 'sessionid=xxx; ttwid=xxx; sid_guard=xxx',
                hintStyle: TextStyle(color: hintTextColor, fontSize: 12),
                border: const OutlineInputBorder(),
                isDense: true,
              ),
              style: const TextStyle(fontSize: 12, fontFamily: 'monospace'),
            ),
            const SizedBox(height: 8),
            Text(
              '提示：也支持粘贴 JSON 格式的 Cookie',
              style: TextStyle(fontSize: 11, color: hintTextColor),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: () async {
              final input = controller.text.trim();
              if (input.isEmpty) {
                Navigator.pop(context);
                return;
              }
              final success = await context
                  .read<SettingsProvider>()
                  .importDouyinCookiesFromString(input);
              if (context.mounted) {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      success ? 'Cookie 导入成功' : 'Cookie 格式不正确，导入失败',
                    ),
                  ),
                );
              }
            },
            child: const Text('导入'),
          ),
        ],
      ),
    ).then((_) => controller.dispose());
  }

  Widget _buildAutoParseClipboardSetting(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        return SwitchListTile(
            secondary: const Icon(Icons.content_paste_outlined),
            title: const Text('自动解析剪贴板'),
            subtitle: const Text('打开应用时自动检测剪贴板中的视频链接'),
            value: settings.autoParseClipboard,
            onChanged: (value) {
              settings.setAutoParseClipboard(value);
            },
        );
      },
    );
  }

  Widget _buildClipboardDetectionSetting(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        return SwitchListTile(
          secondary: const Icon(Icons.paste_rounded),
          title: const Text('剪贴板检测'),
          subtitle: const Text('首页显示剪贴板链接提示，点击快速填充'),
          value: settings.clipboardDetectionEnabled,
          onChanged: (value) {
            settings.setClipboardDetectionEnabled(value);
          },
        );
      },
    );
  }

  Widget _buildUiDensitySetting(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        final currentDensity = DensityLevelX.fromString(settings.uiDensity);
        return ListTile(
          leading: const Icon(Icons.aspect_ratio_outlined),
          title: const Text('界面大小'),
          subtitle: Text(
            '${currentDensity.label} · ${currentDensity.description}',
            style: TextStyle(
              fontSize: 12,
              color: Theme.of(context).textTheme.bodySmall?.color,
            ),
          ),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _showUiDensityDialog(context),
        );
      },
    );
  }

  Future<void> _showUiDensityDialog(BuildContext context) async {
    final settings = context.read<SettingsProvider>();
    final currentDensity = DensityLevelX.fromString(settings.uiDensity);
    final levels = DensityLevel.values;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('界面大小'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: levels.map((level) {
            final isSelected = level == currentDensity;
            return ListTile(
              leading: Icon(
                level == DensityLevel.compact
                    ? Icons.density_small
                    : level == DensityLevel.standard
                        ? Icons.density_medium
                        : Icons.density_large,
                color: isSelected ? AppTheme.primaryColor : null,
              ),
              title: Text(level.label),
              subtitle: Text(
                level.description,
                style: const TextStyle(fontSize: 12),
              ),
              trailing: isSelected
                  ? Icon(Icons.check_circle, color: AppTheme.primaryColor)
                  : const SizedBox.shrink(),
              onTap: () {
                settings.setUiDensity(level.storageValue);
                Navigator.pop(context);
              },
            );
          }).toList(),
        ),
      ),
    );
  }

  Widget _buildCompactListModeSetting(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        return SwitchListTile(
          secondary: const Icon(Icons.density_small_outlined),
          title: const Text('列表紧凑模式'),
          subtitle: const Text('缩小列表行高，一屏显示更多内容'),
          value: settings.compactListMode,
          onChanged: (value) => settings.setCompactListMode(value),
        );
      },
    );
  }

  Widget _buildThemeColorSetting(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        final colorData = AppThemeColorX.fromKey(settings.themeColor).data;
        return ListTile(
          leading: const Icon(Icons.color_lens_outlined),
          title: const Text('主题色'),
          subtitle: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 14,
                height: 14,
                decoration: BoxDecoration(
                  color: colorData.primary,
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 6),
              Text(
                _themeColorLabel(settings.themeColor),
                style: TextStyle(
                  fontSize: 12,
                  color: Theme.of(context).textTheme.bodySmall?.color,
                ),
              ),
            ],
          ),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _showThemeColorDialog(context),
        );
      },
    );
  }

  String _themeColorLabel(String colorKey) {
    return AppThemeColorX.fromKey(colorKey).data.name;
  }

  Future<void> _showThemeColorDialog(BuildContext context) async {
    final settings = context.read<SettingsProvider>();
    final colors = AppThemeColorX.allPresets;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('主题色'),
        contentPadding: const EdgeInsets.fromLTRB(8, 12, 8, 8),
        content: SizedBox(
          width: 300,
          child: GridView.builder(
            shrinkWrap: true,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              mainAxisSpacing: 16,
              crossAxisSpacing: 16,
              childAspectRatio: 1.0,
            ),
            itemCount: colors.length,
            itemBuilder: (context, index) {
              final color = colors[index];
              final isSelected = settings.themeColor == color.key;
              return GestureDetector(
                onTap: () {
                  settings.setThemeColor(color.key);
                  Navigator.of(context).pop();
                },
                child: Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: [color.primary, color.secondary],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    border: isSelected
                        ? Border.all(
                            color: Theme.of(context).primaryColor,
                            width: 3,
                          )
                        : null,
                    boxShadow: [
                      BoxShadow(
                        color: color.primary.withOpacity(0.3),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: isSelected
                      ? const Icon(
                          Icons.check,
                          color: Colors.white,
                          size: 28,
                        )
                      : null,
                ),
              );
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('取消'),
          ),
        ],
      ),
    );
  }

  Widget _buildDarkModeSetting(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        return ListTile(
          leading: const Icon(Icons.dark_mode_outlined),
          title: const Text('主题模式'),
          subtitle: Text(
            _themeModeLabel(settings.themeMode),
            style: TextStyle(
              fontSize: 12,
              color: Theme.of(context).textTheme.bodySmall?.color,
            ),
          ),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _showThemeModeDialog(context),
        );
      },
    );
  }

  String _themeModeLabel(String mode) {
    switch (mode) {
      case 'dark': return '深色模式';
      case 'oled': return 'OLED 纯黑';
      case 'system': return '跟随系统';
      case 'scheduled': return '自动（按时间）';
      case 'light':
      default: return '浅色模式';
    }
  }

  Future<void> _showThemeModeDialog(BuildContext context) async {
    final settings = context.read<SettingsProvider>();
    String selectedMode = settings.themeMode;
    String sunsetTime = settings.themeSunsetTime;
    String sunriseTime = settings.themeSunriseTime;

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) {
          return AlertDialog(
            title: const Text('主题模式'),
            contentPadding: const EdgeInsets.symmetric(vertical: 8),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  ..._buildThemeModeOptions(
                    selectedMode,
                    (value) {
                      setDialogState(() {
                        selectedMode = value;
                      });
                      settings.setThemeMode(value);
                    },
                  ),
                  if (selectedMode == 'scheduled') ...[
                    const Divider(height: 1),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                      child: Row(
                        children: [
                          const Icon(Icons.nightlight_round, size: 18, color: Colors.orange),
                          const SizedBox(width: 8),
                          const Text(
                            '夜间时段设置',
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 4),
                    // 开始时间（日落）
                    ListTile(
                      leading: const Icon(Icons.bedtime_outlined, size: 20),
                      title: const Text('开始时间', style: TextStyle(fontSize: 14)),
                      trailing: TextButton(
                        onPressed: () async {
                          final picked = await showTimePicker(
                            context: context,
                            initialTime: _parseTimeOfDay(sunsetTime),
                          );
                          if (picked != null) {
                            final timeStr = _formatTimeOfDay(picked);
                            setDialogState(() {
                              sunsetTime = timeStr;
                            });
                            settings.setThemeSunsetTime(timeStr);
                          }
                        },
                        child: Text(sunsetTime),
                      ),
                    ),
                    // 结束时间（日出）
                    ListTile(
                      leading: const Icon(Icons.wb_sunny_outlined, size: 20),
                      title: const Text('结束时间', style: TextStyle(fontSize: 14)),
                      trailing: TextButton(
                        onPressed: () async {
                          final picked = await showTimePicker(
                            context: context,
                            initialTime: _parseTimeOfDay(sunriseTime),
                          );
                          if (picked != null) {
                            final timeStr = _formatTimeOfDay(picked);
                            setDialogState(() {
                              sunriseTime = timeStr;
                            });
                            settings.setThemeSunriseTime(timeStr);
                          }
                        },
                        child: Text(sunriseTime),
                      ),
                    ),
                    const SizedBox(height: 8),
                  ],
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('完成'),
              ),
            ],
          );
        },
      ),
    );
  }

  List<Widget> _buildThemeModeOptions(String selectedMode, ValueChanged<String> onChanged) {
    final modes = [
      ('light', '浅色模式', '明亮清爽，适合白天使用', Icons.wb_sunny_outlined),
      ('dark', '深色模式', '护眼省电，适合夜间使用', Icons.dark_mode_outlined),
      ('oled', 'OLED 纯黑', '纯黑背景，OLED 屏幕更省电', Icons.brightness_1_outlined),
      ('system', '跟随系统', '自动跟随系统主题变化', Icons.brightness_auto_outlined),
      ('scheduled', '自动（按时间）', '设定时段内自动切换深色模式', Icons.schedule_outlined),
    ];

    return modes.map((mode) {
      final isSelected = selectedMode == mode.$1;
      return RadioListTile<String>(
        value: mode.$1,
        groupValue: selectedMode,
        onChanged: (value) {
          if (value != null) {
            onChanged(value);
          }
        },
        secondary: Icon(mode.$4, color: isSelected ? Theme.of(context).primaryColor : null),
        title: Text(mode.$2),
        subtitle: Text(
          mode.$3,
          style: const TextStyle(fontSize: 12),
        ),
        activeColor: Theme.of(context).primaryColor,
      );
    }).toList();
  }

  TimeOfDay _parseTimeOfDay(String timeStr) {
    final parts = timeStr.split(':');
    return TimeOfDay(
      hour: int.parse(parts[0]),
      minute: int.parse(parts[1]),
    );
  }

  String _formatTimeOfDay(TimeOfDay time) {
    return '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';
  }

  Widget _buildCrawlIntervalSetting(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        final intervalSec = settings.crawlIntervalMs / 1000;
        return Card(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 8, 8),
            child: Row(
              children: [
                Icon(Icons.timer_outlined, color: secondaryTextColor),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        '抓取间隔',
                        style: TextStyle(fontSize: 15),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        '${intervalSec.toStringAsFixed(1)} 秒 / 条',
                        style: TextStyle(color: secondaryTextColor, fontSize: 12),
                      ),
                      Slider(
                        value: settings.crawlIntervalMs.toDouble(),
                        min: 0,
                        max: 5000,
                        divisions: 50,
                        label: '${intervalSec.toStringAsFixed(1)}秒',
                        onChanged: (value) {
                          settings.setCrawlIntervalMs(value.round());
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildCrawlJitterSetting(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        final jitterSec = settings.crawlJitterMs / 1000;
        return Card(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 8, 8),
            child: Row(
              children: [
                Icon(Icons.shuffle, color: secondaryTextColor),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        '随机抖动',
                        style: TextStyle(fontSize: 15),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        '±${jitterSec.toStringAsFixed(1)} 秒（避免规律请求被风控）',
                        style: TextStyle(color: secondaryTextColor, fontSize: 12),
                      ),
                      Slider(
                        value: settings.crawlJitterMs.toDouble(),
                        min: 0,
                        max: 3000,
                        divisions: 30,
                        label: '±${jitterSec.toStringAsFixed(1)}秒',
                        onChanged: (value) {
                          settings.setCrawlJitterMs(value.round());
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildParseRetrySetting(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        final retryCount = settings.parseRetryCount;
        return Card(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 8, 8),
            child: Row(
              children: [
                Icon(Icons.refresh_outlined, color: secondaryTextColor),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        '解析重试次数',
                        style: TextStyle(fontSize: 15),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        '失败后自动重试 $retryCount 次（多源 fallback 内有效）',
                        style: TextStyle(color: secondaryTextColor, fontSize: 12),
                      ),
                      Slider(
                        value: retryCount.toDouble(),
                        min: 0,
                        max: 5,
                        divisions: 5,
                        label: '$retryCount 次',
                        onChanged: (value) {
                          settings.setParseRetryCount(value.round());
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildCrawlRetrySetting(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        final retryCount = settings.crawlRetryCount;
        return Card(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 8, 8),
            child: Row(
              children: [
                Icon(Icons.autorenew_outlined, color: secondaryTextColor),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        '抓取重试次数',
                        style: TextStyle(fontSize: 15),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        '单条抓取失败后自动重试 $retryCount 次',
                        style: TextStyle(color: secondaryTextColor, fontSize: 12),
                      ),
                      Slider(
                        value: retryCount.toDouble(),
                        min: 0,
                        max: 5,
                        divisions: 5,
                        label: '$retryCount 次',
                        onChanged: (value) {
                          settings.setCrawlRetryCount(value.round());
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildHapticFeedbackSetting(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        return Card(
          child: Column(
            children: [
              SwitchListTile(
                secondary: const Icon(Icons.vibration_outlined),
                title: const Text('触觉反馈'),
                subtitle: const Text('操作时提供震动反馈'),
                value: settings.hapticFeedbackEnabled,
                onChanged: (value) => settings.setHapticFeedbackEnabled(value),
              ),
              if (settings.hapticFeedbackEnabled) ...[
                const Divider(height: 1, indent: 72),
                ListTile(
                  leading: const SizedBox.shrink(),
                  title: const Text('反馈强度'),
                  subtitle: Text(
                    _hapticLevelName(settings.hapticFeedbackLevel),
                    style: TextStyle(color: secondaryTextColor, fontSize: 13),
                  ),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => _showHapticLevelDialog(context),
                ),
              ],
            ],
          ),
        );
      },
    );
  }

  // ======================================================
  // 数据管理
  // ======================================================

  Widget _buildExportDataTile(BuildContext context) {
    return ListTile(
      leading: const Icon(Icons.file_upload_outlined, color: Colors.green),
      title: const Text('导出全部数据'),
      subtitle: const Text('导出为 JSON 文件，包含历史记录、收藏、设置等'),
      trailing: const Icon(Icons.chevron_right),
      onTap: () => _handleExportData(context),
    );
  }

  Widget _buildImportDataTile(BuildContext context) {
    return ListTile(
      leading: const Icon(Icons.file_download_outlined, color: Colors.blue),
      title: const Text('导入数据'),
      subtitle: const Text('从 JSON 文件恢复数据，支持合并或覆盖'),
      trailing: const Icon(Icons.chevron_right),
      onTap: () => _handleImportData(context),
    );
  }

  Widget _buildClearAllDataTile(BuildContext context) {
    return ListTile(
      leading: const Icon(Icons.delete_sweep_outlined, color: Colors.red),
      title: const Text('清除所有数据', style: TextStyle(color: Colors.red)),
      subtitle: const Text('清除所有历史记录和收藏（设置保留）'),
      trailing: const Icon(Icons.chevron_right),
      onTap: () => _handleClearAllData(context),
    );
  }

  Future<void> _handleExportData(BuildContext context) async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => const Center(
        child: CircularProgressIndicator(),
      ),
    );

    try {
      final backupService = DataBackupService(
        crawlHistoryService: context.read<CrawlHistoryService>(),
        historyService: context.read<HistoryService>(),
        customSourceService: context.read<CustomSourceService>(),
        settingsService: context.read<SettingsService>(),
      );
      final filePath = await backupService.exportAllData();
      if (context.mounted) {
        Navigator.pop(context); // 关闭加载弹窗

        // 分享文件
        final fileName = filePath.split('/').last;
        await Share.shareXFiles(
          [XFile(filePath, mimeType: 'application/json')],
          text: '视频下载器数据备份（$fileName）',
        );

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('数据导出成功')),
        );
      }
    } catch (e) {
      if (context.mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('导出失败：$e')),
        );
      }
    }
  }

  Future<void> _handleImportData(BuildContext context) async {
    // 选择导入模式
    final mode = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('选择导入模式'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('请选择数据导入方式：'),
            const SizedBox(height: 12),
            _buildImportModeOption(
              icon: Icons.merge_type,
              title: '合并导入',
              desc: '保留现有数据，只添加新的记录（推荐）',
              color: Colors.blue,
              onTap: () => Navigator.pop(context, 'merge'),
            ),
            const SizedBox(height: 8),
            _buildImportModeOption(
              icon: Icons.restore,
              title: '覆盖导入',
              desc: '清空现有数据后再导入（谨慎使用）',
              color: Colors.orange,
              onTap: () => Navigator.pop(context, 'overwrite'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消'),
          ),
        ],
      ),
    );

    if (mode == null || !context.mounted) return;

    // 选择文件
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['json'],
    );

    if (result == null || result.files.single.path == null) return;
    if (!context.mounted) return;

    final filePath = result.files.single.path!;

    // 显示导入进度
    // ignore: use_build_context_synchronously
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => _ImportProgressDialog(
        filePath: filePath,
        mode: mode,
      ),
    );
  }

  Widget _buildImportModeOption({
    required IconData icon,
    required String title,
    required String desc,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          border: Border.all(color: color.withOpacity(0.3)),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          children: [
            Icon(icon, color: color),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    desc,
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey.shade600,
                    ),
                  ),
                ],
              ),
            ),
            Icon(Icons.chevron_right, color: Colors.grey.shade400),
          ],
        ),
      ),
    );
  }

  Future<void> _handleClearAllData(BuildContext context) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('确认清除所有数据'),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('此操作将清除以下数据：'),
            SizedBox(height: 8),
            Text('• 所有解析历史记录'),
            Text('• 所有抓取历史记录'),
            Text('• 所有收藏'),
            Text('• 所有自定义解析源'),
            SizedBox(height: 8),
            Text('设置项将会保留。', style: TextStyle(color: Colors.orange)),
            SizedBox(height: 8),
            Text('此操作不可恢复，请谨慎操作！',
                style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('确认清除', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirm != true || !context.mounted) return;

    // 二次确认
    final confirm2 = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('再次确认'),
        content: const Text('数据清除后将无法恢复，确定要继续吗？'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('确定', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirm2 != true || !context.mounted) return;

    // 执行清除
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => const Center(
        child: CircularProgressIndicator(),
      ),
    );

    try {
      final backupService = DataBackupService(
        crawlHistoryService: context.read<CrawlHistoryService>(),
        historyService: context.read<HistoryService>(),
        customSourceService: context.read<CustomSourceService>(),
        settingsService: context.read<SettingsService>(),
      );
      await backupService.clearAllData();

      // 刷新 providers
      if (context.mounted) {
        await context.read<CrawlHistoryProvider>().refresh();
      }

      if (context.mounted) {
        Navigator.pop(context); // 关闭加载弹窗
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('所有数据已清除')),
        );
      }
    } catch (e) {
      if (context.mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('清除失败：$e')),
        );
      }
    }
  }

  Widget _buildClearCacheTile(BuildContext context) {
    return ListTile(
        leading: const Icon(Icons.cleaning_services_outlined),
        title: const Text('清理缓存'),
        subtitle: const Text('清除临时缓存文件'),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => _showClearCacheDialog(context),
    );
  }

  Widget _buildViewGuideTile(BuildContext context) {
    return ListTile(
      leading: const Icon(Icons.school_outlined),
      title: const Text('新手引导'),
      subtitle: const Text('重新查看功能介绍'),
      trailing: const Icon(Icons.chevron_right),
      onTap: () {
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => const GuidePage(),
          ),
        );
      },
    );
  }

  Widget _buildAboutTile(BuildContext context) {
    return ListTile(
        leading: const Icon(Icons.info_outline),
        title: const Text('关于'),
        subtitle: Text('版本 $_appVersion'),
        trailing: const Icon(Icons.chevron_right),
        onTap: () {
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => const AboutPage(),
            ),
          );
        },
    );
  }

  // ======================================================
  // 解析源选择弹窗 + 即时配置
  // ======================================================
  void _showApiSourceDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => const _ApiSourceDialog(),
    );
  }

  Future<void> _launchUrl(String url) async {
    try {
      final uri = Uri.parse(url);
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      }
    } catch (_) {}
  }

  // ======================================================
  // 下载路径选择弹窗
  // ======================================================
  void _showDownloadPathDialog(BuildContext context) {
    final settings = context.read<SettingsProvider>();
    final downloadProvider = context.read<DownloadProvider>();
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('下载路径'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '选择视频保存位置',
              style: TextStyle(fontSize: 12, color: secondaryTextColor),
            ),
            const SizedBox(height: 12),
            _buildPathOption(
              context,
              icon: Icons.download_outlined,
              title: '默认下载目录',
              subtitle:
                  '${downloadProvider.useCustomPath ? '' : '（当前）'}Android 10+ 无需存储权限，系统 Download 目录',
              isSelected: !downloadProvider.useCustomPath,
              onTap: () {
                downloadProvider.setDownloadPath(null);
                settings.setDownloadPath('');
                Navigator.of(context).pop();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('已切换到默认下载目录')),
                );
              },
            ),
            const SizedBox(height: 8),
            _buildPathOption(
              context,
              icon: Icons.folder_open_outlined,
              title: '自定义目录',
              subtitle: downloadProvider.useCustomPath
                  ? '（当前）${downloadProvider.downloadPath}'
                  : '点击选择文件夹\nAndroid 11+ 走系统文件选择器，无需额外权限',
              isSelected: downloadProvider.useCustomPath,
              onTap: () async {
                Navigator.of(context).pop();
                final path = await downloadProvider.pickDirectory();
                if (path != null && path.isNotEmpty) {
                  downloadProvider.setDownloadPath(path);
                  settings.setDownloadPath(path);
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('下载路径已更新')),
                    );
                  }
                } else {
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('已取消选择')),
                    );
                  }
                }
              },
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('取消'),
          ),
        ],
      ),
    );
  }

  Widget _buildPathOption(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String subtitle,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final fillColor = isSelected
        ? AppTheme.primaryColor.withOpacity(isDark ? 0.15 : 0.08)
        : (isDark ? const Color(0xFF1E293B) : Colors.grey.shade50);
    final borderColor = isSelected
        ? AppTheme.primaryColor
        : (isDark ? Colors.grey.shade700 : Colors.grey.shade200);
    final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
    final iconGradient = isSelected
        ? AppTheme.primaryGradient
        : LinearGradient(
            colors: isDark
                ? [Colors.grey.shade600, Colors.grey.shade700]
                : [Colors.grey.shade400, Colors.grey.shade500]);
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: fillColor,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: borderColor,
            width: isSelected ? 1.5 : 1,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                gradient: iconGradient,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, color: Colors.white, size: 18),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 14,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontSize: 11,
                      color: secondaryTextColor,
                      height: 1.3,
                    ),
                    maxLines: 3,
                  ),
                ],
              ),
            ),
            if (isSelected)
              const Icon(
                Icons.check_circle,
                color: AppTheme.primaryColor,
                size: 20,
              ),
          ],
        ),
      ),
    );
  }

  // ======================================================
  // UID 补全服务配置弹窗
  // ======================================================
  void _showUidResolveServiceDialog(BuildContext context) {
    final controller = TextEditingController(
      text: context.read<SettingsProvider>().uidResolveServiceUrl ?? '',
    );
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey;
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('UID补全服务'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '抖音网页端不公开数字UID，配置服务端中转接口后可自动补全。',
              style: TextStyle(fontSize: 13, color: secondaryTextColor),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: controller,
              decoration: const InputDecoration(
                labelText: '服务 URL',
                hintText: 'https://xxx.supabase.co/functions/v1/douyin-uid',
                border: OutlineInputBorder(),
                isDense: true,
              ),
              keyboardType: TextInputType.url,
              maxLines: 1,
            ),
            const SizedBox(height: 8),
            Text(
              '协议：GET ?sec_uid=xxx → 返回 {"uid":"123"} 或纯文本',
              style: TextStyle(fontSize: 11, color: secondaryTextColor),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () {
              context.read<SettingsProvider>().setUidResolveServiceUrl(null);
              Navigator.pop(context);
            },
            child: const Text('清除'),
          ),
          FilledButton(
            onPressed: () {
              final url = controller.text.trim();
              context
                  .read<SettingsProvider>()
                  .setUidResolveServiceUrl(url.isEmpty ? null : url);
              Navigator.pop(context);
            },
            child: const Text('保存'),
          ),
        ],
      ),
    ).then((_) => controller.dispose());
  }

  void _showClearCacheDialog(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final redColor = isDark ? Colors.red.shade400 : Colors.red;
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('清理缓存'),
        content: const Text('确定要清理所有缓存文件吗？'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('缓存已清理')),
              );
            },
            child: Text('确定', style: TextStyle(color: redColor)),
          ),
        ],
      ),
    );
  }

  void _showAboutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AboutDialog(
        applicationName: '无水印下载',
        applicationVersion: _appVersion,
        applicationIcon: Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            gradient: AppTheme.primaryGradient,
            borderRadius: BorderRadius.circular(12),
          ),
          child: const Icon(Icons.download, color: Colors.white),
        ),
        children: const [
          SizedBox(height: 12),
          Text('支持抖音、快手视频/图文无水印解析下载。'),
          SizedBox(height: 8),
          Text('仅供个人学习使用，请勿用于商业用途。'),
        ],
      ),
    );
  }

  // ======================================================
  // 摇一摇解析
  // ======================================================
  Widget _buildShakeToParseSetting(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        return SwitchListTile(
          secondary: const Icon(Icons.screen_rotation_outlined),
          title: const Text('摇一摇解析'),
          subtitle: const Text('在首页摇一摇手机，自动读取剪贴板并解析'),
          value: settings.shakeToParseEnabled,
          onChanged: (value) => settings.setShakeToParseEnabled(value),
        );
      },
    );
  }

  // ======================================================
  // 3D 视差效果
  // ======================================================
  Widget _buildParallaxSetting(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        return SwitchListTile(
          secondary: const Icon(Icons.view_in_ar_outlined),
          title: const Text('3D 视差效果'),
          subtitle: const Text('结果卡片随设备倾斜产生轻微 3D 旋转效果'),
          value: settings.parallaxEnabled,
          onChanged: (value) => settings.setParallaxEnabled(value),
        );
      },
    );
  }

  // ======================================================
  // 字体大小
  // ======================================================
  Widget _buildFontSizeSetting(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        return ListTile(
          leading: const Icon(Icons.text_fields_outlined),
          title: const Text('字体大小'),
          subtitle: Text(
            _fontSizeLabel(settings.fontSizeScale),
            style: TextStyle(
              fontSize: 12,
              color: Theme.of(context).textTheme.bodySmall?.color,
            ),
          ),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _showFontSizeDialog(context),
        );
      },
    );
  }

  Widget _buildLargeFontModeSetting(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        return SwitchListTile(
          secondary: const Icon(Icons.font_download_outlined),
          title: const Text('大字体模式'),
          subtitle: const Text('全局字体放大 15%，按钮和交互元素也相应放大，更易读易点'),
          value: settings.largeFontMode,
          onChanged: (value) async {
            await settings.setLargeFontMode(value);
          },
        );
      },
    );
  }

  Future<void> _showFontSizeDialog(BuildContext context) async {
    final settings = context.read<SettingsProvider>();
    final currentScale = settings.fontSizeScale;
    final options = [
      ('small', '小', '适合一屏展示更多内容', Icons.text_decrease),
      ('medium', '标准', '默认大小，推荐使用', Icons.text_fields),
      ('large', '大', '更大的文字，更易阅读', Icons.text_increase),
      ('xlarge', '特大', '超大字体，适合视力不佳', Icons.text_rotate_up),
    ];

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('字体大小'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: options.map((opt) {
            final isSelected = currentScale == opt.$1;
            return ListTile(
              leading: Icon(opt.$4, color: isSelected ? AppTheme.primaryColor : null),
              title: Text(opt.$2),
              subtitle: Text(opt.$3),
              trailing: isSelected
                  ? const Icon(Icons.check_circle, color: AppTheme.primaryColor)
                  : null,
              onTap: () {
                settings.setFontSizeScale(opt.$1);
                Navigator.pop(context);
              },
            );
          }).toList(),
        ),
      ),
    );
  }

  // ======================================================
  // 重置手势提示
  // ======================================================
  Widget _buildResetGestureHintsSetting(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        return ListTile(
          leading: const Icon(Icons.tips_and_updates_outlined),
          title: const Text('重置手势提示'),
          subtitle: const Text('重新显示所有页面的手势操作提示'),
          trailing: const Icon(Icons.refresh),
          onTap: () async {
            await settings.resetGestureHints();
            if (context.mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('手势提示已重置，下次进入页面时会重新显示'),
                  duration: Duration(seconds: 2),
                ),
              );
            }
          },
        );
      },
    );
  }

  // ======================================================
  // 双指手势
  // ======================================================
  Widget _buildTwoFingerGestureSetting(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        return SwitchListTile(
          secondary: const Icon(Icons.pan_tool_outlined),
          title: const Text('双指手势'),
          subtitle: const Text('双指缩放切换布局密度，双指下滑进入搜索'),
          value: settings.twoFingerGestureEnabled,
          onChanged: (value) => settings.setTwoFingerGestureEnabled(value),
        );
      },
    );
  }

  // ======================================================
  // 隐私锁
  // ======================================================
  Widget _buildPrivacyLockSetting(BuildContext context) {
    return Consumer2<SettingsProvider, PrivacyLockProvider>(
      builder: (context, settings, privacyLock, child) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        final unlockMethod = UnlockMethodX.fromString(settings.privacyUnlockMethod);
        final autoLockDelay = AutoLockDelay.fromSeconds(settings.privacyAutoLockDelay);
        final hasPassword = settings.hasPrivacyPassword;

        return Card(
          child: Column(
            children: [
              SwitchListTile(
                secondary: const Icon(Icons.lock_outline),
                title: const Text('隐私锁'),
                subtitle: Text(
                  settings.privacyLockEnabled
                      ? '已启用 · ${unlockMethod.label}'
                      : '保护您的私密内容',
                ),
                value: settings.privacyLockEnabled,
                onChanged: (value) => _handlePrivacyLockToggle(context, value),
              ),
              if (settings.privacyLockEnabled) ...[
                const Divider(height: 1, indent: 72),
                // 解锁方式
                ListTile(
                  leading: const SizedBox.shrink(),
                  title: const Text('解锁方式'),
                  subtitle: Text(
                    '${unlockMethod.label} · ${unlockMethod.description}',
                    style: TextStyle(color: secondaryTextColor, fontSize: 13),
                  ),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => _showUnlockMethodDialog(context),
                ),
                const Divider(height: 1, indent: 72),
                // 设置/修改密码
                ListTile(
                  leading: const SizedBox.shrink(),
                  title: Text(hasPassword ? '修改密码' : '设置密码'),
                  subtitle: Text(
                    hasPassword ? '6位数字密码' : '未设置密码，点击设置',
                    style: TextStyle(color: secondaryTextColor, fontSize: 13),
                  ),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => _showPasswordSetup(context),
                ),
                const Divider(height: 1, indent: 72),
                // 自动锁定时机
                ListTile(
                  leading: const SizedBox.shrink(),
                  title: const Text('自动锁定'),
                  subtitle: Text(
                    '进入后台后${autoLockDelay.label}自动锁定',
                    style: TextStyle(color: secondaryTextColor, fontSize: 13),
                  ),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => _showAutoLockDelayDialog(context),
                ),
                const Divider(height: 1, indent: 72),
                // 锁定范围
                ListTile(
                  leading: const SizedBox.shrink(),
                  title: const Text('锁定范围'),
                  subtitle: Text(
                    _privacyLockScopeName(settings.privacyLockScope),
                    style: TextStyle(color: secondaryTextColor, fontSize: 13),
                  ),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => _showPrivacyLockScopeDialog(context),
                ),
                const Divider(height: 1, indent: 72),
                // 立即锁定
                ListTile(
                  leading: const SizedBox.shrink(),
                  title: const Text('立即锁定'),
                  subtitle: Text(
                    '手动锁定应用',
                    style: TextStyle(color: secondaryTextColor, fontSize: 13),
                  ),
                  trailing: Icon(
                    Icons.lock_outline,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                  onTap: () => _lockNow(context),
                ),
              ],
            ],
          ),
        );
      },
    );
  }

  String _privacyLockScopeName(String scope) {
    switch (scope) {
      case 'history': return '历史记录';
      case 'all': return '全部内容';
      case 'favorites':
      default: return '收藏夹';
    }
  }

  String _unlockMethodName(String method) {
    return UnlockMethodX.fromString(method).label;
  }

  Future<void> _handlePrivacyLockToggle(BuildContext context, bool value) async {
    final settings = context.read<SettingsProvider>();
    final privacyLock = context.read<PrivacyLockProvider>();

    if (value) {
      // 开启前检查：需要至少有一种可用的解锁方式
      final hasBiometric = await privacyLock.isBiometricAvailable();

      if (!hasBiometric) {
        // 没有生物识别，需要设置密码
        final setPassword = await _showEnableWithoutBiometricDialog(context);
        if (!setPassword) return;

        // 弹出设置密码对话框
        if (context.mounted) {
          final success = await _showSetPasswordDialog(context, requireOld: false);
          if (success) {
            // 设置密码后，解锁方式自动设为 password
            await settings.setPrivacyUnlockMethod('password');
            await settings.setPrivacyLockEnabled(true);
          }
        }
      } else {
        // 有生物识别，直接开启，默认使用生物识别
        await settings.setPrivacyLockEnabled(true);
        // 如果解锁方式是 password 但有生物识别，提示用户可以切换
      }
    } else {
      // 关闭隐私锁
      settings.setPrivacyLockEnabled(false);
    }
  }

  /// 没有生物识别时的提示对话框
  Future<bool> _showEnableWithoutBiometricDialog(BuildContext context) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('开启隐私锁'),
        content: const Text('您的设备未设置生物识别，需要设置应用密码才能开启隐私锁。\n\n是否现在设置密码？'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('取消'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('设置密码'),
          ),
        ],
      ),
    );
    return result ?? false;
  }

  /// 显示解锁方式选择对话框
  Future<void> _showUnlockMethodDialog(BuildContext context) async {
    final settings = context.read<SettingsProvider>();
    final privacyLock = context.read<PrivacyLockProvider>();
    final currentMethod = settings.privacyUnlockMethod;
    final hasBiometric = privacyLock.biometricAvailable;
    final hasPassword = settings.hasPrivacyPassword;

    final methods = [
      ('biometric', '生物识别', '使用指纹或面容解锁', hasBiometric),
      ('password', '应用密码', '使用6位数字密码解锁', hasPassword),
      ('both', '生物识别 + 密码', '生物识别优先，失败后可使用密码', hasBiometric && hasPassword),
    ];

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('解锁方式'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: methods.map((method) {
            final isSelected = currentMethod == method.$1;
            final isAvailable = method.$4;
            return RadioListTile<String>(
              value: method.$1,
              groupValue: currentMethod,
              onChanged: isAvailable
                  ? (value) {
                      if (value != null) {
                        settings.setPrivacyUnlockMethod(value);
                        Navigator.of(context).pop();
                      }
                    }
                  : null,
              title: Row(
                children: [
                  Text(method.$2),
                  if (!isAvailable) ...[
                    const SizedBox(width: 8),
                    Text(
                      '(不可用)',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey.shade500,
                      ),
                    ),
                  ],
                ],
              ),
              subtitle: Text(
                method.$3,
                style: const TextStyle(fontSize: 12),
              ),
              activeColor: AppTheme.primaryColor,
            );
          }).toList(),
        ),
        actions: [
          if (!hasPassword)
            TextButton(
              onPressed: () async {
                Navigator.of(context).pop();
                await _showSetPasswordDialog(context, requireOld: false);
              },
              child: const Text('设置密码'),
            ),
        ],
      ),
    );
  }

  /// 显示自动锁定时长选择对话框
  Future<void> _showAutoLockDelayDialog(BuildContext context) async {
    final settings = context.read<SettingsProvider>();
    final currentDelay = settings.privacyAutoLockDelay;
    final delays = AutoLockDelay.values;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('自动锁定时机'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: delays.map((delay) {
            final isSelected = currentDelay == delay.seconds;
            return RadioListTile<int>(
              value: delay.seconds,
              groupValue: currentDelay,
              onChanged: (value) {
                if (value != null) {
                  settings.setPrivacyAutoLockDelay(value);
                  Navigator.of(context).pop();
                }
              },
              title: Text(delay.label),
              activeColor: AppTheme.primaryColor,
            );
          }).toList(),
        ),
      ),
    );
  }

  /// 显示密码设置/修改对话框
  void _showPasswordSetup(BuildContext context) {
    final settings = context.read<SettingsProvider>();
    final hasPassword = settings.hasPrivacyPassword;

    if (hasPassword) {
      // 修改密码：需要先验证旧密码
      _showSetPasswordDialog(context, requireOld: true);
    } else {
      // 设置密码：直接设置
      _showSetPasswordDialog(context, requireOld: false);
    }
  }

  /// 显示设置密码对话框
  Future<bool> _showSetPasswordDialog(BuildContext context, {required bool requireOld}) async {
    final settings = context.read<SettingsProvider>();

    final result = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (context) => PasswordSetupDialog(
        title: requireOld ? '修改密码' : '设置密码',
        requireOldPassword: requireOld,
        verifyOldPassword: (password) => settings.verifyPrivacyPassword(password),
        onPasswordSet: (password) async {
          await settings.setPrivacyPassword(password);
          // 如果当前解锁方式仅为生物识别且设置了密码，询问是否切换
        },
      ),
    );

    return result ?? false;
  }

  /// 立即锁定
  void _lockNow(BuildContext context) {
    final privacyLock = context.read<PrivacyLockProvider>();
    privacyLock.lock();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('应用已锁定'),
        duration: Duration(seconds: 1),
      ),
    );
  }

  Future<void> _showPrivacyLockScopeDialog(BuildContext context) async {
    final settings = context.read<SettingsProvider>();
    final currentScope = settings.privacyLockScope;
    final scopes = [
      ('favorites', '收藏夹', '仅锁定收藏夹页面'),
      ('history', '历史记录', '仅锁定历史记录页面'),
      ('all', '全部内容', '锁定整个应用'),
    ];

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('锁定范围'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: scopes.map((scope) {
            final isSelected = currentScope == scope.$1;
            return RadioListTile<String>(
              value: scope.$1,
              groupValue: currentScope,
              onChanged: (value) {
                if (value != null) {
                  settings.setPrivacyLockScope(value);
                  Navigator.of(context).pop();
                }
              },
              title: Text(scope.$2),
              subtitle: Text(
                scope.$3,
                style: const TextStyle(fontSize: 12),
              ),
              activeColor: AppTheme.primaryColor,
            );
          }).toList(),
        ),
      ),
    );
  }

  // ======================================================
  // 重压快捷菜单
  // ======================================================
  Widget _buildForceTouchSetting(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        return SwitchListTile(
          secondary: const Icon(Icons.touch_app_outlined),
          title: const Text('重压快捷菜单'),
          subtitle: const Text('长按列表项和结果卡片弹出快捷操作菜单'),
          value: settings.forceTouchEnabled,
          onChanged: (value) => settings.setForceTouchEnabled(value),
        );
      },
    );
  }

  // ======================================================
  // 底部导航管理
  // ======================================================
  Widget _buildBottomNavManagementEntry(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        final configJson = settings.bottomNavConfigJson;
        int visibleCount = 5; // 默认数量
        if (configJson.isNotEmpty) {
          try {
            final config = settings.bottomNavConfig;
            visibleCount = (config['visibleTabs'] as List?)?.length ?? 5;
          } catch (_) {}
        }
        return ListTile(
          leading: const Icon(Icons.view_column_outlined),
          title: const Text('底部导航管理'),
          subtitle: Text('已显示 $visibleCount 个 Tab，可自定义顺序和显隐'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () {
            Navigator.push(
              context,
              AppPageRoute.slideRight(const BottomNavManagementPage()),
            );
          },
        );
      },
    );
  }

  Widget _buildQuickActionsEntry(BuildContext context) {
    return Consumer<QuickActionsService>(
      builder: (context, quickActions, child) {
        return ListTile(
          leading: const Icon(Icons.shortcut_outlined),
          title: const Text('桌面快捷方式'),
          subtitle: const Text('添加一键解析、批量抓取、下载管理快捷方式'),
          trailing: const Icon(Icons.add_circle_outline, color: AppTheme.primaryColor),
          onTap: () async {
            await quickActions.setShortcuts();
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('已添加桌面快捷方式'),
                  duration: Duration(seconds: 2),
                ),
              );
            }
          },
        );
      },
    );
  }
}

// ======================================================
// 解析源选择弹窗（Stateful，因为有即时配置）
// ======================================================
class _ApiSourceDialog extends StatefulWidget {
  const _ApiSourceDialog();

  @override
  State<_ApiSourceDialog> createState() => _ApiSourceDialogState();
}

class _ApiSourceDialogState extends State<_ApiSourceDialog> {
  /// 当前正在配置的源（null 表示列表态）
  ApiSource? _configuringSource;

  TextEditingController? _urlController;
  TextEditingController? _keyController;

  @override
  void dispose() {
    _urlController?.dispose();
    _keyController?.dispose();
    super.dispose();
  }

  void _initConfigControllers(ApiSource source) {
    final settings = context.read<SettingsProvider>();
    final isCustom = source.id == 'custom';
    _urlController?.dispose();
    _keyController?.dispose();
    _urlController = TextEditingController(
      text: isCustom ? (settings.customApiUrl ?? '') : (source.apiUrl ?? ''),
    );
    _keyController = TextEditingController(
      text: settings.getApiKey(source.id) ?? '',
    );
  }

  void _disposeConfigControllers() {
    _urlController?.dispose();
    _keyController?.dispose();
    _urlController = null;
    _keyController = null;
  }

  @override
  Widget build(BuildContext context) {
    if (_configuringSource != null) {
      return _buildConfigDialog();
    }
    return _buildListDialog();
  }

  Widget _buildListDialog() {
    final settings = context.watch<SettingsProvider>();
    final allSources = [
      ...ApiSource.presets,
    ];
    return AlertDialog(
      title: const Text('选择解析API源'),
      content: SizedBox(
        width: double.maxFinite,
        child: ListView.builder(
          shrinkWrap: true,
          itemCount: allSources.length,
          itemBuilder: (context, index) {
            final source = allSources[index];
            final isSelected = source.id == settings.apiSourceId;
            final hasKey = settings.getApiKey(source.id)?.isNotEmpty ?? false;
            return Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: _buildSourceCard(
                source: source,
                isSelected: isSelected,
                hasKey: hasKey,
                onTap: () => _handleSourceTap(source),
              ),
            );
          },
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('关闭'),
        ),
      ],
    );
  }

  Widget _buildSourceCard({
    required ApiSource source,
    required bool isSelected,
    required bool hasKey,
    required VoidCallback onTap,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final borderColor = isSelected
        ? AppTheme.primaryColor
        : (isDark ? Colors.grey.shade700 : Colors.grey.shade200);
    final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
    final greenColor = isDark ? Colors.green.shade400 : Colors.green;
    final orangeColor = isDark ? Colors.orange.shade400 : Colors.orange;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: isSelected
              ? AppTheme.primaryColor.withOpacity(isDark ? 0.15 : 0.08)
              : Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: borderColor,
            width: isSelected ? 1.5 : 1,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                gradient: source.isBuiltIn
                    ? AppTheme.primaryGradient
                    : LinearGradient(
                        colors: [
                          Colors.purple.shade400,
                          Colors.blue.shade400,
                        ],
                      ),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(
                source.isBuiltIn ? Icons.code : Icons.cloud_outlined,
                color: Colors.white,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          source.name,
                          style: const TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: 14,
                          ),
                        ),
                      ),
                      if (isSelected)
                        const Icon(
                          Icons.check_circle,
                          color: AppTheme.primaryColor,
                          size: 18,
                        ),
                    ],
                  ),
                  const SizedBox(height: 2),
                  Text(
                    source.description,
                    style: TextStyle(
                      fontSize: 12,
                      color: secondaryTextColor,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      if (source.website != null && source.website!.isNotEmpty)
                        _buildLinkChip(
                          icon: Icons.open_in_new,
                          text: '官网',
                          url: source.website!,
                        ),
                      if (hasKey) ...[
                        const SizedBox(width: 8),
                        _buildStatusChip(
                          icon: Icons.vpn_key_outlined,
                          text: '已配置Key',
                          color: greenColor,
                        ),
                      ],
                      if (source.id == 'custom') ...[
                        const SizedBox(width: 8),
                        _buildStatusChip(
                          icon: Icons.settings_outlined,
                          text: '需配置',
                          color: orangeColor,
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLinkChip({
    required IconData icon,
    required String text,
    required String url,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final blueColor = isDark ? Colors.blue.shade400 : Colors.blue.shade600;
    return GestureDetector(
      onTap: () async {
        try {
          final uri = Uri.parse(url);
          if (await canLaunchUrl(uri)) {
            await launchUrl(uri,
                mode: LaunchMode.externalApplication);
          }
        } catch (_) {}
      },
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12, color: blueColor),
          const SizedBox(width: 3),
          Text(
            text,
            style: TextStyle(
              fontSize: 11,
              color: blueColor,
              decoration: TextDecoration.underline,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusChip({
    required IconData icon,
    required String text,
    required Color color,
  }) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 12, color: color),
        const SizedBox(width: 3),
        Text(
          text,
          style: TextStyle(fontSize: 11, color: color),
        ),
      ],
    );
  }

  /// 处理源点击
  void _handleSourceTap(ApiSource source) {
    final settings = context.read<SettingsProvider>();

    if (source.isBuiltIn) {
      // 内置：直接切换
      settings.setApiSourceId(source.id);
      Navigator.of(context).pop();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('已切换到${source.name}')),
      );
      return;
    }

    if (source.id == 'custom') {
      // 自定义源：必须进入配置
      _initConfigControllers(source);
      setState(() => _configuringSource = source);
      return;
    }

    // 预设第三方源：
    // 如果用户没配过 Key 且该源需要配置，弹配置；否则直接切换
    final hasKey = settings.getApiKey(source.id)?.isNotEmpty ?? false;
    if (!hasKey && source.apiKeyRequired) {
      _initConfigControllers(source);
      setState(() => _configuringSource = source);
      return;
    }

    // 直接切换
    settings.setApiSourceId(source.id);
    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('已切换到${source.name}')),
    );
  }

  // ======================================================
  // 配置弹窗
  // ======================================================
  Widget _buildConfigDialog() {
    final source = _configuringSource!;
    final settings = context.watch<SettingsProvider>();
    final isCustom = source.id == 'custom';
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final blueBgColor = isDark ? Colors.blue.shade900.withOpacity(0.3) : Colors.blue.shade50;
    final blueTextColor = isDark ? Colors.blue.shade400 : Colors.blue.shade700;
    final fillColor = isDark ? const Color(0xFF1E293B) : Colors.grey.shade100;
    final borderColor = isDark ? Colors.grey.shade700 : Colors.grey.shade300;
    final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade700;
    final hintTextColor = isDark ? Colors.grey.shade600 : Colors.grey.shade500;
    final subtleTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;

    final urlController = _urlController!;
    final keyController = _keyController!;

    return AlertDialog(
      title: Row(
        children: [
          IconButton(
            onPressed: () {
              _disposeConfigControllers();
              setState(() => _configuringSource = null);
            },
            icon: const Icon(Icons.arrow_back),
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(),
          ),
          const SizedBox(width: 8),
          Expanded(child: Text('${source.name} 配置')),
        ],
      ),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 官网链接
            if (source.website != null && source.website!.isNotEmpty)
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: blueBgColor,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    Icon(Icons.info_outline,
                        size: 16, color: blueTextColor),
                    const SizedBox(width: 8),
                    Expanded(
                      child: GestureDetector(
                        onTap: () async {
                          try {
                            final uri = Uri.parse(source.website!);
                            if (await canLaunchUrl(uri)) {
                              await launchUrl(uri,
                                  mode: LaunchMode.externalApplication);
                            }
                          } catch (_) {}
                        },
                        child: Text(
                          '前往 ${source.website} 获取 API Key / 了解详情',
                          style: TextStyle(
                            fontSize: 12,
                            color: blueTextColor,
                            decoration: TextDecoration.underline,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            const SizedBox(height: 12),

            // API 地址
            Text(
              isCustom ? 'API 地址（必填）' : 'API 地址',
              style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 6),
            if (isCustom)
              TextField(
                controller: urlController,
                decoration: const InputDecoration(
                  hintText: 'https://api.example.com/parse',
                  border: OutlineInputBorder(),
                  isDense: true,
                ),
              )
            else
              Container(
                width: double.infinity,
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                decoration: BoxDecoration(
                  color: fillColor,
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: borderColor),
                ),
                child: Text(
                  source.apiUrl ?? '',
                  style: TextStyle(
                    fontSize: 12,
                    color: secondaryTextColor,
                    fontFamily: 'monospace',
                  ),
                ),
              ),
            const SizedBox(height: 12),

            // API Key
            if (source.apiKeyParam != null) ...[
              Row(
                children: [
                  Text(
                    'API Key (${source.apiKeyParam})',
                    style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  if (!source.apiKeyRequired)
                    Padding(
                      padding: const EdgeInsets.only(left: 6),
                      child: Text(
                        '可选',
                        style: TextStyle(
                          fontSize: 11,
                          color: hintTextColor,
                        ),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 6),
              TextField(
                controller: keyController,
                decoration: InputDecoration(
                  hintText: '请输入你的 API Key',
                  border: const OutlineInputBorder(),
                  isDense: true,
                  suffixIcon: IconButton(
                    icon: const Icon(Icons.clear, size: 18),
                    onPressed: () => keyController.clear(),
                    padding: const EdgeInsets.all(8),
                    constraints: const BoxConstraints(),
                  ),
                ),
              ),
              if (source.apiKeyHint != null) ...[
                const SizedBox(height: 6),
                Text(
                  source.apiKeyHint!,
                  style: TextStyle(
                    fontSize: 11,
                    color: subtleTextColor,
                  ),
                ),
              ],
            ],
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () {
            _disposeConfigControllers();
            setState(() => _configuringSource = null);
          },
          child: const Text('返回'),
        ),
        TextButton(
          onPressed: () async {
            final url = urlController.text.trim();
            final key = keyController.text.trim();

            // 自定义源必填 URL
            if (isCustom && url.isEmpty) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('请输入 API 地址')),
              );
              return;
            }

            // 保存配置
            if (isCustom) {
              await settings.setCustomApiUrl(url.isEmpty ? null : url);
            }
            await settings.setApiKey(source.id, key.isEmpty ? null : key);
            // 切换到该源
            await settings.setApiSourceId(source.id);

            if (mounted) {
              Navigator.of(context).pop();
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('已配置并切换到${source.name}')),
              );
            }
          },
          child: const Text('保存并使用'),
        ),
      ],
    );
  }
}

/// 常用设置项数据模型
class _QuickSettingItem {
  final IconData icon;
  final String label;
  final List<Color> gradient;
  final String sectionKey;
  final VoidCallback onTap;

  const _QuickSettingItem({
    required this.icon,
    required this.label,
    required this.gradient,
    required this.sectionKey,
    required this.onTap,
  });
}

/// 导入进度对话框
class _ImportProgressDialog extends StatefulWidget {
  final String filePath;
  final String mode;

  const _ImportProgressDialog({
    required this.filePath,
    required this.mode,
  });

  @override
  State<_ImportProgressDialog> createState() => _ImportProgressDialogState();
}

class _ImportProgressDialogState extends State<_ImportProgressDialog> {
  double _progress = 0;
  Map<String, dynamic>? _result;
  bool _completed = false;

  @override
  void initState() {
    super.initState();
    _startImport();
  }

  Future<void> _startImport() async {
    try {
      final backupService = DataBackupService(
        crawlHistoryService: context.read<CrawlHistoryService>(),
        historyService: context.read<HistoryService>(),
        customSourceService: context.read<CustomSourceService>(),
        settingsService: context.read<SettingsService>(),
      );

      final result = await backupService.importFromFile(
        widget.filePath,
        mode: widget.mode,
        onProgress: (p) {
          if (mounted) {
            setState(() => _progress = p);
          }
        },
      );

      // 刷新 providers
      if (mounted) {
        await context.read<CrawlHistoryProvider>().refresh();
      }

      if (mounted) {
        setState(() {
          _result = result;
          _completed = true;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _result = {
            'success': false,
            'error': e.toString(),
          };
          _completed = true;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return AlertDialog(
      title: Text(_completed ? '导入完成' : '正在导入数据...'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (!_completed) ...[
            LinearProgressIndicator(
              value: _progress > 0 ? _progress : null,
              valueColor: AlwaysStoppedAnimation<Color>(AppTheme.primaryColor),
            ),
            const SizedBox(height: 12),
            Text(
              '${(_progress * 100).toStringAsFixed(0)}%',
              style: TextStyle(
                fontSize: 14,
                color: isDark ? Colors.grey.shade400 : Colors.grey.shade600,
              ),
            ),
          ] else ...[
            Icon(
              _result?['success'] == true
                  ? Icons.check_circle
                  : Icons.error_outline,
              size: 48,
              color: _result?['success'] == true ? Colors.green : Colors.red,
            ),
            const SizedBox(height: 12),
            if (_result?['success'] == true) ...[
              const Text(
                '数据导入成功',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              _buildResultRow(
                  '抓取历史',
                  '${_result?['crawlHistoryImported'] ?? 0} 条导入',
                  '${_result?['crawlHistorySkipped'] ?? 0} 条跳过'),
              _buildResultRow(
                  '解析历史',
                  '${_result?['parseHistoryImported'] ?? 0} 条导入',
                  '${_result?['parseHistorySkipped'] ?? 0} 条跳过'),
              _buildResultRow(
                  '自定义源',
                  '${_result?['customSourcesImported'] ?? 0} 个导入',
                  '${_result?['customSourcesSkipped'] ?? 0} 个跳过'),
              _buildResultRow(
                '设置项',
                (_result?['settingsImported'] == true) ? '已导入' : '未导入',
                '',
              ),
            ] else ...[
              Text(
                '导入失败：${_result?['error'] ?? '未知错误'}',
                style: const TextStyle(color: Colors.red),
              ),
            ],
          ],
        ],
      ),
      actions: [
        if (_completed)
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('确定'),
          ),
      ],
    );
  }

  Widget _buildResultRow(String label, String primary, String secondary) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          SizedBox(
            width: 80,
            child: Text(
              label,
              style: TextStyle(
                fontSize: 13,
                color: Colors.grey.shade600,
              ),
            ),
          ),
          Expanded(
            child: Text(
              primary,
              style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          if (secondary.isNotEmpty)
            Text(
              secondary,
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey.shade500,
              ),
            ),
        ],
      ),
    );
  }
}
