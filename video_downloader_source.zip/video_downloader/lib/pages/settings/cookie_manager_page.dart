import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../../models/cookie_profile.dart';
import '../../providers/cookie_provider.dart';
import '../../theme/app_theme.dart';
import '../../widgets/confirm_dialog.dart';
import '../../utils/page_route.dart';
import 'webview_cookie_page.dart';

/// Cookie 可视化管理面板
class CookieManagerPage extends StatefulWidget {
  const CookieManagerPage({super.key});

  @override
  State<CookieManagerPage> createState() => _CookieManagerPageState();
}

class _CookieManagerPageState extends State<CookieManagerPage> {
  String _selectedPlatform = 'all';
  final TextEditingController _searchController = TextEditingController();
  String _searchKeyword = '';

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Cookie 管理'),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_horiz),
            onSelected: _handleMenuAction,
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'import',
                child: Row(
                  children: [
                    Icon(Icons.file_download_outlined, size: 20),
                    SizedBox(width: 8),
                    Text('导入 JSON'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'export',
                child: Row(
                  children: [
                    Icon(Icons.file_upload_outlined, size: 20),
                    SizedBox(width: 8),
                    Text('导出 JSON'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'refresh',
                child: Row(
                  children: [
                    Icon(Icons.refresh_outlined, size: 20),
                    SizedBox(width: 8),
                    Text('刷新状态'),
                  ],
                ),
              ),
              const PopupMenuDivider(),
              const PopupMenuItem(
                value: 'clear',
                child: Row(
                  children: [
                    Icon(Icons.delete_sweep_outlined, size: 20, color: Colors.red),
                    SizedBox(width: 8),
                    Text('清除全部', style: TextStyle(color: Colors.red)),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: Consumer<CookieProvider>(
        builder: (context, provider, child) {
          final profiles = _filterProfiles(provider.profiles);
          return Column(
            children: [
              _buildStatsHeader(context, provider),
              _buildFilterBar(context),
              Expanded(
                child: profiles.isEmpty
                    ? _buildEmptyState(context)
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
                        itemCount: profiles.length,
                        itemBuilder: (context, index) {
                          return Padding(
                            padding: const EdgeInsets.only(bottom: 12),
                            child: _buildCookieCard(context, profiles[index]),
                          );
                        },
                      ),
              ),
            ],
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddOptions(context),
        icon: const Icon(Icons.add),
        label: const Text('添加 Cookie'),
        backgroundColor: AppTheme.primaryColor,
      ),
    );
  }

  // ==================== 顶部统计 ====================

  Widget _buildStatsHeader(BuildContext context, CookieProvider provider) {
    final isDark = AppTheme.isDark(context);
    return Container(
      margin: const EdgeInsets.fromLTRB(20, 8, 20, 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: AppTheme.primaryGradient,
        borderRadius: BorderRadius.circular(AppTheme.radiusLg),
        boxShadow: AppTheme.shadowMd,
      ),
      child: Row(
        children: [
          _buildStatItem(
            '总计',
            provider.totalCount.toString(),
            Colors.white.withOpacity(0.9),
          ),
          Container(
            width: 1,
            height: 32,
            color: Colors.white.withOpacity(0.3),
          ),
          _buildStatItem(
            '有效',
            provider.activeCount.toString(),
            Colors.white,
          ),
          Container(
            width: 1,
            height: 32,
            color: Colors.white.withOpacity(0.3),
          ),
          _buildStatItem(
            '即将过期',
            provider.expiringSoonCount.toString(),
            Colors.amber.shade200,
          ),
          Container(
            width: 1,
            height: 32,
            color: Colors.white.withOpacity(0.3),
          ),
          _buildStatItem(
            '已失效',
            provider.expiredCount.toString(),
            Colors.red.shade200,
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem(String label, String value, Color valueColor) {
    return Expanded(
      child: Column(
        children: [
          Text(
            value,
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w700,
              color: valueColor,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: TextStyle(
              fontSize: 12,
              color: Colors.white.withOpacity(0.8),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== 筛选栏 ====================

  Widget _buildFilterBar(BuildContext context) {
    final isDark = AppTheme.isDark(context);
    final platforms = [
      {'id': 'all', 'label': '全部'},
      {'id': 'douyin', 'label': '抖音'},
      {'id': 'kuaishou', 'label': '快手'},
      {'id': 'xiaohongshu', 'label': '小红书'},
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        children: [
          SizedBox(
            height: 36,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: platforms.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (context, index) {
                final p = platforms[index];
                final isSelected = _selectedPlatform == p['id'];
                return GestureDetector(
                  onTap: () {
                    setState(() => _selectedPlatform = p['id']!);
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: isSelected
                          ? AppTheme.primaryColor
                          : (isDark ? const Color(0xFF1E293B) : Colors.white),
                      borderRadius: BorderRadius.circular(AppTheme.radiusFull),
                      border: Border.all(
                        color: isSelected
                            ? Colors.transparent
                            : (isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0)),
                        width: 0.5,
                      ),
                    ),
                    child: Text(
                      p['label']!,
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: isSelected
                            ? Colors.white
                            : AppTheme.textSecondaryColor(context),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _searchController,
            onChanged: (value) {
              setState(() => _searchKeyword = value);
            },
            decoration: InputDecoration(
              hintText: '搜索 Cookie 名称...',
              prefixIcon: const Icon(Icons.search, size: 20),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              isDense: true,
            ),
          ),
        ],
      ),
    );
  }

  // ==================== Cookie 卡片 ====================

  Widget _buildCookieCard(BuildContext context, CookieProfile profile) {
    final isDark = AppTheme.isDark(context);
    final statusColor = _getStatusColor(profile.status);
    final statusBgColor = statusColor.withOpacity(0.1);

    return Container(
      decoration: BoxDecoration(
        color: AppTheme.cardBg(context),
        borderRadius: BorderRadius.circular(AppTheme.radiusLg),
        border: Border.all(
          color: isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
          width: 0.5,
        ),
        boxShadow: AppTheme.shadowSm,
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(AppTheme.radiusLg),
          onTap: () => _showCookieDetail(context, profile),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: AppTheme.surfaceBg(context),
                        borderRadius: BorderRadius.circular(AppTheme.radiusSm),
                      ),
                      child: Text(
                        profile.platformLabel,
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: AppTheme.textSecondaryColor(context),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        profile.name,
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                          color: AppTheme.textPrimaryColor(context),
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: statusBgColor,
                        borderRadius: BorderRadius.circular(AppTheme.radiusSm),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 6,
                            height: 6,
                            decoration: BoxDecoration(
                              color: statusColor,
                              shape: BoxShape.circle,
                            ),
                          ),
                          const SizedBox(width: 4),
                          Text(
                            profile.statusLabel,
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                              color: statusColor,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Icon(
                      Icons.cookie_outlined,
                      size: 16,
                      color: AppTheme.textTertiaryColor(context),
                    ),
                    const SizedBox(width: 4),
                    Text(
                      '${profile.cookieCount} 个 Cookie',
                      style: TextStyle(
                        fontSize: 12,
                        color: AppTheme.textTertiaryColor(context),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Icon(
                      Icons.schedule_outlined,
                      size: 16,
                      color: AppTheme.textTertiaryColor(context),
                    ),
                    const SizedBox(width: 4),
                    Text(
                      profile.remainingTimeText,
                      style: TextStyle(
                        fontSize: 12,
                        color: profile.status == CookieStatus.expired
                            ? Colors.red
                            : AppTheme.textTertiaryColor(context),
                      ),
                    ),
                  ],
                ),
                if (profile.lastUsedAt != null) ...[
                  const SizedBox(height: 6),
                  Text(
                    '最后使用：${_formatDate(profile.lastUsedAt!)}',
                    style: TextStyle(
                      fontSize: 11,
                      color: AppTheme.textTertiaryColor(context),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ==================== 空状态 ====================

  Widget _buildEmptyState(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.cookie_outlined,
            size: 64,
            color: AppTheme.textMuted,
          ),
          const SizedBox(height: 16),
          Text(
            '暂无 Cookie 配置',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: AppTheme.textSecondaryColor(context),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            '点击右下角按钮添加你的第一个 Cookie',
            style: TextStyle(
              fontSize: 13,
              color: AppTheme.textTertiaryColor(context),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== 操作方法 ====================

  List<CookieProfile> _filterProfiles(List<CookieProfile> all) {
    var result = all;
    if (_selectedPlatform != 'all') {
      result = result.where((p) => p.platform == _selectedPlatform).toList();
    }
    if (_searchKeyword.isNotEmpty) {
      final kw = _searchKeyword.toLowerCase();
      result = result.where((p) {
        return p.name.toLowerCase().contains(kw) ||
            p.platformLabel.toLowerCase().contains(kw);
      }).toList();
    }
    return result;
  }

  Color _getStatusColor(CookieStatus status) {
    switch (status) {
      case CookieStatus.active:
        return AppTheme.successColor;
      case CookieStatus.expiringSoon:
        return AppTheme.warningColor;
      case CookieStatus.expired:
        return AppTheme.errorColor;
    }
  }

  String _formatDate(DateTime date) {
    return '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')} '
        '${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
  }

  void _handleMenuAction(String action) {
    switch (action) {
      case 'import':
        _showImportDialog(context);
        break;
      case 'export':
        _handleExport(context);
        break;
      case 'refresh':
        context.read<CookieProvider>().refreshStatus();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('已刷新 Cookie 状态')),
        );
        break;
      case 'clear':
        _handleClearAll(context);
        break;
    }
  }

  void _showAddOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '添加 Cookie',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.textPrimaryColor(context),
                ),
              ),
              const SizedBox(height: 16),
              ListTile(
                leading: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: AppTheme.primaryColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(AppTheme.radiusMd),
                  ),
                  child: const Icon(Icons.paste_outlined, color: AppTheme.primaryColor),
                ),
                title: const Text('手动粘贴'),
                subtitle: const Text('粘贴 Cookie 字符串'),
                onTap: () {
                  Navigator.pop(context);
                  _showManualAddDialog(context);
                },
              ),
              ListTile(
                leading: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: AppTheme.secondaryColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(AppTheme.radiusMd),
                  ),
                  child: const Icon(Icons.language_outlined, color: AppTheme.secondaryColor),
                ),
                title: const Text('从 WebView 获取'),
                subtitle: const Text('登录网页版后自动提取'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(context, AppPageRoute.slideRight(const WebviewCookiePage()));
                },
              ),
              ListTile(
                leading: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: AppTheme.infoColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(AppTheme.radiusMd),
                  ),
                  child: const Icon(Icons.file_download_outlined, color: AppTheme.infoColor),
                ),
                title: const Text('导入 JSON 文件'),
                subtitle: const Text('从备份文件批量导入'),
                onTap: () {
                  Navigator.pop(context);
                  _showImportDialog(context);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showManualAddDialog(BuildContext context) {
    final nameController = TextEditingController();
    final cookieController = TextEditingController();
    String selectedPlatform = 'douyin';
    final platforms = ['douyin', 'kuaishou', 'xiaohongshu'];
    final platformLabels = {'douyin': '抖音', 'kuaishou': '快手', 'xiaohongshu': '小红书'};

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) {
          return AlertDialog(
            title: const Text('手动添加 Cookie'),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('平台', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    children: platforms.map((p) {
                      final isSelected = selectedPlatform == p;
                      return ChoiceChip(
                        label: Text(platformLabels[p]!),
                        selected: isSelected,
                        onSelected: (selected) {
                          if (selected) {
                            setDialogState(() => selectedPlatform = p);
                          }
                        },
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: nameController,
                    decoration: const InputDecoration(
                      labelText: '名称',
                      hintText: '如：工作号、备用号',
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: cookieController,
                    maxLines: 4,
                    decoration: const InputDecoration(
                      labelText: 'Cookie 字符串',
                      hintText: 'key1=value1; key2=value2',
                      alignLabelWithHint: true,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '提示：也支持粘贴 JSON 格式',
                    style: TextStyle(
                      fontSize: 12,
                      color: AppTheme.textTertiaryColor(context),
                    ),
                  ),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('取消'),
              ),
              ElevatedButton(
                onPressed: () async {
                  final name = nameController.text.trim();
                  final cookieStr = cookieController.text.trim();
                  if (cookieStr.isEmpty) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('请输入 Cookie 字符串')),
                    );
                    return;
                  }

                  // 尝试解析 JSON 或字符串格式
                  String finalCookieStr = cookieStr;
                  try {
                    final decoded = jsonDecode(cookieStr);
                    if (decoded is Map) {
                      final cookieMap = decoded.map((k, v) => MapEntry(k.toString(), v.toString()));
                      finalCookieStr = CookieProfile.mapToString(cookieMap);
                    }
                  } catch (_) {}

                  final provider = context.read<CookieProvider>();
                  await provider.createFromString(
                    platform: selectedPlatform,
                    name: name.isEmpty ? '${platformLabels[selectedPlatform]}Cookie' : name,
                    cookieString: finalCookieStr,
                  );

                  if (context.mounted) {
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Cookie 添加成功')),
                    );
                  }
                },
                child: const Text('添加'),
              ),
            ],
          );
        },
      ),
    );
  }

  void _showCookieDetail(BuildContext context, CookieProfile profile) {
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.6,
        minChildSize: 0.4,
        maxChildSize: 0.95,
        expand: false,
        builder: (context, scrollController) {
          return SingleChildScrollView(
            controller: scrollController,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: AppTheme.surfaceBg(context),
                          borderRadius: BorderRadius.circular(AppTheme.radiusSm),
                        ),
                        child: Text(
                          profile.platformLabel,
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: AppTheme.textSecondaryColor(context),
                          ),
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        icon: const Icon(Icons.edit_outlined),
                        onPressed: () {
                          Navigator.pop(context);
                          _showEditDialog(context, profile);
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete_outline, color: Colors.red),
                        onPressed: () {
                          Navigator.pop(context);
                          _handleDelete(context, profile);
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    profile.name,
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                      color: AppTheme.textPrimaryColor(context),
                    ),
                  ),
                  const SizedBox(height: 12),
                  _buildDetailRow(context, '状态', profile.statusLabel,
                      color: _getStatusColor(profile.status)),
                  _buildDetailRow(context, 'Cookie 数量', '${profile.cookieCount} 个'),
                  _buildDetailRow(context, '创建时间', _formatDate(profile.createdAt)),
                  _buildDetailRow(
                    context,
                    '过期时间',
                    profile.expiresAt != null ? _formatDate(profile.expiresAt!) : '永不过期',
                  ),
                  _buildDetailRow(
                    context,
                    '最后使用',
                    profile.lastUsedAt != null ? _formatDate(profile.lastUsedAt!) : '从未使用',
                  ),
                  if (profile.remark != null && profile.remark!.isNotEmpty)
                    _buildDetailRow(context, '备注', profile.remark!),
                  const SizedBox(height: 16),
                  Text(
                    'Cookie 内容',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: AppTheme.textSecondaryColor(context),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppTheme.surfaceBg(context),
                      borderRadius: BorderRadius.circular(AppTheme.radiusMd),
                    ),
                    child: Text(
                      profile.cookieString,
                      style: const TextStyle(
                        fontSize: 12,
                        fontFamily: 'monospace',
                        height: 1.5,
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () {
                            Clipboard.setData(ClipboardData(text: profile.cookieString));
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Cookie 已复制到剪贴板')),
                            );
                          },
                          icon: const Icon(Icons.copy, size: 18),
                          label: const Text('复制'),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () {
                            Navigator.pop(context);
                            Navigator.push(context, AppPageRoute.slideRight(const WebviewCookiePage()));
                          },
                          icon: const Icon(Icons.refresh, size: 18),
                          label: const Text('刷新 Cookie'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildDetailRow(BuildContext context, String label, String value, {Color? color}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          SizedBox(
            width: 80,
            child: Text(
              label,
              style: TextStyle(
                fontSize: 13,
                color: AppTheme.textTertiaryColor(context),
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w500,
                color: color ?? AppTheme.textPrimaryColor(context),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showEditDialog(BuildContext context, CookieProfile profile) {
    final nameController = TextEditingController(text: profile.name);
    final cookieController = TextEditingController(text: profile.cookieString);
    final remarkController = TextEditingController(text: profile.remark ?? '');

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('编辑 Cookie'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                decoration: const InputDecoration(labelText: '名称'),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: cookieController,
                maxLines: 4,
                decoration: const InputDecoration(
                  labelText: 'Cookie 字符串',
                  alignLabelWithHint: true,
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: remarkController,
                decoration: const InputDecoration(labelText: '备注'),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消'),
          ),
          ElevatedButton(
            onPressed: () async {
              final updated = profile.copyWith(
                name: nameController.text.trim(),
                cookieString: cookieController.text.trim(),
                remark: remarkController.text.trim().isEmpty ? null : remarkController.text.trim(),
              );
              await context.read<CookieProvider>().update(updated);
              if (context.mounted) {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Cookie 已更新')),
                );
              }
            },
            child: const Text('保存'),
          ),
        ],
      ),
    );
  }

  Future<void> _handleDelete(BuildContext context, CookieProfile profile) async {
    final confirmed = await showConfirmDialog(
      context,
      title: '删除 Cookie',
      content: '确定要删除「${profile.name}」吗？此操作不可恢复。',
      confirmText: '删除',
      isDestructive: true,
    );
    if (confirmed == true && context.mounted) {
      await context.read<CookieProvider>().remove(profile.id);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Cookie 已删除')),
      );
    }
  }

  Future<void> _handleClearAll(BuildContext context) async {
    final confirmed = await showConfirmDialog(
      context,
      title: '清除全部',
      content: '确定要清除所有 Cookie 配置吗？此操作不可恢复，建议先导出备份。',
      confirmText: '全部清除',
      isDestructive: true,
    );
    if (confirmed == true && context.mounted) {
      await context.read<CookieProvider>().clear();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('已清除全部 Cookie')),
      );
    }
  }

  void _showImportDialog(BuildContext context) {
    final controller = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('导入 Cookie'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('粘贴 JSON 格式的 Cookie 数据：'),
            const SizedBox(height: 12),
            TextField(
              controller: controller,
              maxLines: 6,
              decoration: const InputDecoration(
                hintText: '粘贴 JSON 内容...',
                alignLabelWithHint: true,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消'),
          ),
          ElevatedButton(
            onPressed: () async {
              final jsonStr = controller.text.trim();
              if (jsonStr.isEmpty) return;
              final count = await context.read<CookieProvider>().importFromJson(jsonStr);
              if (context.mounted) {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('成功导入 $count 个 Cookie')),
                );
              }
            },
            child: const Text('导入'),
          ),
        ],
      ),
    );
  }

  void _handleExport(BuildContext context) {
    final jsonStr = context.read<CookieProvider>().exportAllJson();
    Clipboard.setData(ClipboardData(text: jsonStr));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Cookie 数据已复制到剪贴板')),
    );
  }
}
