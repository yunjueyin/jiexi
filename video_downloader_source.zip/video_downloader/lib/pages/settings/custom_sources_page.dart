import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import '../../models/api_source.dart';
import '../../models/custom_api_source.dart';
import '../../providers/custom_source_provider.dart';
import '../../theme/app_theme.dart';
import '../../widgets/confirm_dialog.dart';

/// 自定义解析源管理页面
class CustomSourcesPage extends StatefulWidget {
  const CustomSourcesPage({super.key});

  @override
  State<CustomSourcesPage> createState() => _CustomSourcesPageState();
}

class _CustomSourcesPageState extends State<CustomSourcesPage> {
  /// 搜索控制器
  final TextEditingController _searchController = TextEditingController();

  /// 搜索关键词
  String _searchQuery = '';

  /// 当前筛选的平台（null 表示全部）
  String? _filterPlatform;

  /// 所有平台列表
  static const List<String> _allPlatforms = ['douyin', 'kuaishou', 'xiaohongshu'];
  static const Map<String, String> _platformLabels = {
    'douyin': '抖音',
    'kuaishou': '快手',
    'xiaohongshu': '小红书',
  };

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('解析源管理'),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert_outlined, size: 22),
            onSelected: _handleMenuAction,
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'export',
                child: Row(
                  children: [
                    Icon(Icons.file_upload_outlined, size: 20),
                    SizedBox(width: 12),
                    Text('导出自定义源'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'import',
                child: Row(
                  children: [
                    Icon(Icons.file_download_outlined, size: 20),
                    SizedBox(width: 12),
                    Text('导入自定义源'),
                  ],
                ),
              ),
              const PopupMenuDivider(),
              const PopupMenuItem(
                value: 'help',
                child: Row(
                  children: [
                    Icon(Icons.help_outline, size: 20),
                    SizedBox(width: 12),
                    Text('使用帮助'),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: Consumer<CustomSourceProvider>(
        builder: (context, provider, child) {
          final customSources = _filterSources(provider.sources);
          return Column(
            children: [
              _buildSummaryCard(context, provider),
              _buildSearchBar(context),
              _buildPlatformFilter(context),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(20, 8, 20, 100),
                  children: [
                    _buildSectionTitle(context, '内置解析源'),
                    _buildBuiltInSourcesList(context),
                    const SizedBox(height: 24),
                    _buildSectionTitle(context, '自定义解析源 (${customSources.length})'),
                    if (customSources.isEmpty)
                      _buildEmptyCustomSources(context)
                    else
                      _buildCustomSourcesList(context, customSources, provider),
                  ],
                ),
              ),
            ],
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddEditDialog(context),
        icon: const Icon(Icons.add, size: 22),
        label: const Text('添加源'),
        backgroundColor: AppTheme.primaryColor,
      ),
    );
  }

  // ==================== 筛选逻辑 ====================

  /// 根据搜索和筛选条件过滤源列表
  List<CustomApiSource> _filterSources(List<CustomApiSource> sources) {
    var filtered = sources;

    // 平台筛选
    if (_filterPlatform != null) {
      filtered = filtered
          .where((s) => s.supportedPlatforms.contains(_filterPlatform))
          .toList();
    }

    // 搜索筛选
    if (_searchQuery.isNotEmpty) {
      final query = _searchQuery.toLowerCase();
      filtered = filtered.where((s) {
        final nameMatch = s.name.toLowerCase().contains(query);
        final platformMatch = s.supportedPlatforms.any((p) =>
            p.toLowerCase().contains(query) ||
            (_platformLabels[p] ?? '').toLowerCase().contains(query));
        final remarkMatch = (s.remark ?? '').toLowerCase().contains(query);
        return nameMatch || platformMatch || remarkMatch;
      }).toList();
    }

    return filtered;
  }

  // ==================== 搜索栏 ====================

  Widget _buildSearchBar(BuildContext context) {
    final isDark = AppTheme.isDark(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
      child: Container(
        height: 40,
        decoration: BoxDecoration(
          color: isDark ? const Color(0xFF1E293B) : const Color(0xFFF1F5F9),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          children: [
            const SizedBox(width: 12),
            Icon(
              Icons.search,
              size: 20,
              color: AppTheme.textTertiaryColor(context),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: TextField(
                controller: _searchController,
                onChanged: (value) {
                  setState(() {
                    _searchQuery = value.trim();
                  });
                },
                decoration: InputDecoration(
                  hintText: '搜索源名称、平台...',
                  hintStyle: TextStyle(
                    color: AppTheme.textTertiaryColor(context),
                    fontSize: 14,
                  ),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(vertical: 10),
                ),
                style: TextStyle(
                  fontSize: 14,
                  color: AppTheme.textPrimaryColor(context),
                ),
              ),
            ),
            if (_searchQuery.isNotEmpty)
              GestureDetector(
                onTap: () {
                  _searchController.clear();
                  setState(() {
                    _searchQuery = '';
                  });
                },
                child: Padding(
                  padding: const EdgeInsets.only(right: 12),
                  child: Icon(
                    Icons.cancel,
                    size: 18,
                    color: AppTheme.textTertiaryColor(context),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  // ==================== 平台筛选 ====================

  Widget _buildPlatformFilter(BuildContext context) {
    final isDark = AppTheme.isDark(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
      child: SizedBox(
        height: 32,
        child: ListView(
          scrollDirection: Axis.horizontal,
          children: [
            _buildFilterChip(
              label: '全部',
              isSelected: _filterPlatform == null,
              onTap: () {
                setState(() {
                  _filterPlatform = null;
                });
              },
              isDark: isDark,
            ),
            const SizedBox(width: 8),
            ..._allPlatforms.map((platform) {
              return Padding(
                padding: const EdgeInsets.only(right: 8),
                child: _buildFilterChip(
                  label: _platformLabels[platform] ?? platform,
                  isSelected: _filterPlatform == platform,
                  onTap: () {
                    setState(() {
                      _filterPlatform = platform;
                    });
                  },
                  isDark: isDark,
                ),
              );
            }),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterChip({
    required String label,
    required bool isSelected,
    required VoidCallback onTap,
    required bool isDark,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: isSelected
              ? AppTheme.primaryColor
              : (isDark ? const Color(0xFF1E293B) : const Color(0xFFF1F5F9)),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected
                ? AppTheme.primaryColor
                : (isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0)),
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w500,
            color: isSelected
                ? Colors.white
                : AppTheme.textSecondaryColor(context),
          ),
        ),
      ),
    );
  }

  // ==================== 菜单操作 ====================

  void _handleMenuAction(String action) {
    switch (action) {
      case 'export':
        _handleExport();
        break;
      case 'import':
        _handleImport();
        break;
      case 'help':
        _showHelpDialog(context);
        break;
    }
  }

  /// 导出自定义源
  Future<void> _handleExport() async {
    final provider = context.read<CustomSourceProvider>();
    if (provider.totalCount == 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('暂无可导出的自定义源')),
      );
      return;
    }

    try {
      final jsonStr = provider.exportToJson();
      final tempDir = await getTemporaryDirectory();
      final now = DateTime.now();
      final fileName = 'custom_sources_${now.year}${now.month.toString().padLeft(2, '0')}${now.day.toString().padLeft(2, '0')}.json';
      final file = File('${tempDir.path}/$fileName');
      await file.writeAsString(jsonStr);

      await Share.shareFiles(
        [file.path],
        subject: '自定义解析源备份',
        text: '共 ${provider.totalCount} 个自定义源',
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('导出失败：$e')),
        );
      }
    }
  }

  /// 导入自定义源
  Future<void> _handleImport() async {
    final controller = TextEditingController();
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('导入自定义源'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              '粘贴 JSON 格式的自定义源数据：',
              style: TextStyle(fontSize: 13),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: controller,
              maxLines: 6,
              decoration: const InputDecoration(
                hintText: '粘贴 JSON 数据...',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 8),
            TextButton.icon(
              onPressed: () async {
                final data = await Clipboard.getData(Clipboard.kTextPlain);
                if (data?.text != null) {
                  controller.text = data!.text!;
                }
              },
              icon: const Icon(Icons.paste, size: 18),
              label: const Text('从剪贴板粘贴'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('取消'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('导入'),
          ),
        ],
      ),
    );

    if (result == true && mounted) {
      final jsonStr = controller.text.trim();
      if (jsonStr.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('请输入 JSON 数据')),
        );
        return;
      }

      final count = await context.read<CustomSourceProvider>().importFromJson(jsonStr);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(count > 0 ? '成功导入 $count 个自定义源' : '导入失败，请检查 JSON 格式'),
            backgroundColor: count > 0 ? AppTheme.successColor : AppTheme.errorColor,
          ),
        );
      }
    }
  }

  // ==================== 顶部摘要 ====================

  Widget _buildSummaryCard(BuildContext context, CustomSourceProvider provider) {
    final isDark = AppTheme.isDark(context);
    return Container(
      margin: const EdgeInsets.fromLTRB(20, 8, 20, 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: AppTheme.primaryGradient,
        borderRadius: BorderRadius.circular(AppTheme.radiusLg),
        boxShadow: AppTheme.shadowMd,
      ),
      child: Row(
        children: [
          _buildSummaryItem('内置', '${ApiSource.presets.length}'),
          Container(
            width: 1,
            height: 32,
            color: Colors.white.withOpacity(0.3),
          ),
          _buildSummaryItem('自定义', '${provider.totalCount}'),
          Container(
            width: 1,
            height: 32,
            color: Colors.white.withOpacity(0.3),
          ),
          _buildSummaryItem('已启用', '${provider.enabledCount + 1}'), // +1 for builtIn
        ],
      ),
    );
  }

  Widget _buildSummaryItem(String label, String value) {
    return Expanded(
      child: Column(
        children: [
          Text(
            value,
            style: const TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w700,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: TextStyle(
              fontSize: 12,
              color: Colors.white.withOpacity(0.8),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== 分组标题 ====================

  Widget _buildSectionTitle(BuildContext context, String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 16, 4, 10),
      child: Row(
        children: [
          Container(
            width: 3,
            height: 14,
            decoration: BoxDecoration(
              gradient: AppTheme.primaryGradient,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(width: 8),
          Text(
            title,
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: AppTheme.textSecondaryColor(context),
              letterSpacing: 0.2,
            ),
          ),
        ],
      ),
    );
  }

  // ==================== 内置源列表 ====================

  Widget _buildBuiltInSourcesList(BuildContext context) {
    final isDark = AppTheme.isDark(context);
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.cardBg(context),
        borderRadius: BorderRadius.circular(AppTheme.radiusLg),
        border: Border.all(
          color: isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
          width: 0.5,
        ),
        boxShadow: AppTheme.shadowSm,
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        children: ApiSource.presets.asMap().entries.map((entry) {
          final index = entry.key;
          final source = entry.value;
          final isLast = index == ApiSource.presets.length - 1;
          return Column(
            children: [
              _buildBuiltInSourceTile(context, source),
              if (!isLast)
                Divider(
                  height: 0.5,
                  thickness: 0.5,
                  indent: 56,
                  endIndent: 16,
                  color: isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
                ),
            ],
          );
        }).toList(),
      ),
    );
  }

  Widget _buildBuiltInSourceTile(BuildContext context, ApiSource source) {
    return ListTile(
      leading: Container(
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          color: AppTheme.primaryColor.withOpacity(0.1),
          borderRadius: BorderRadius.circular(AppTheme.radiusMd),
        ),
        child: Icon(
          Icons.code_outlined,
          size: 20,
          color: AppTheme.primaryColor,
        ),
      ),
      title: Text(
        source.name,
        style: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w600,
          color: AppTheme.textPrimaryColor(context),
        ),
      ),
      subtitle: Padding(
        padding: const EdgeInsets.only(top: 2),
        child: Text(
          source.description,
          style: TextStyle(
            fontSize: 12,
            color: AppTheme.textTertiaryColor(context),
          ),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
      ),
      trailing: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        decoration: BoxDecoration(
          color: AppTheme.successColor.withOpacity(0.1),
          borderRadius: BorderRadius.circular(AppTheme.radiusSm),
        ),
        child: Text(
          '内置',
          style: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w600,
            color: AppTheme.successColor,
          ),
        ),
      ),
    );
  }

  // ==================== 自定义源列表 ====================

  Widget _buildEmptyCustomSources(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AppTheme.cardBg(context),
        borderRadius: BorderRadius.circular(AppTheme.radiusLg),
        border: Border.all(
          color: AppTheme.isDark(context)
              ? const Color(0xFF334155)
              : const Color(0xFFE2E8F0),
          width: 0.5,
        ),
      ),
      child: Column(
        children: [
          Icon(
            Icons.add_link_outlined,
            size: 48,
            color: AppTheme.textMuted,
          ),
          const SizedBox(height: 12),
          Text(
            _searchQuery.isNotEmpty || _filterPlatform != null
                ? '未找到匹配的解析源'
                : '暂无自定义解析源',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: AppTheme.textSecondaryColor(context),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            _searchQuery.isNotEmpty || _filterPlatform != null
                ? '试试其他搜索条件'
                : '点击右下角按钮添加你的解析 API',
            style: TextStyle(
              fontSize: 12,
              color: AppTheme.textTertiaryColor(context),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCustomSourcesList(
    BuildContext context,
    List<CustomApiSource> sources,
    CustomSourceProvider provider,
  ) {
    final isDark = AppTheme.isDark(context);
    return ReorderableListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: sources.length,
      onReorder: (oldIndex, newIndex) {
        if (newIndex > oldIndex) newIndex--;
        // 只在没有搜索和筛选时允许拖拽排序
        if (_searchQuery.isEmpty && _filterPlatform == null) {
          final list = sources.map((s) => s.id).toList();
          final item = list.removeAt(oldIndex);
          list.insert(newIndex, item);
          provider.reorder(list);
        }
      },
      itemBuilder: (context, index) {
        final source = sources[index];
        return Padding(
          key: ValueKey(source.id),
          padding: const EdgeInsets.only(bottom: 8),
          child: _buildCustomSourceCard(context, source, index, provider),
        );
      },
    );
  }

  Widget _buildCustomSourceCard(
    BuildContext context,
    CustomApiSource source,
    int index,
    CustomSourceProvider provider,
  ) {
    final isDark = AppTheme.isDark(context);
    final borderColor = isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0);

    return Container(
      decoration: BoxDecoration(
        color: AppTheme.cardBg(context),
        borderRadius: BorderRadius.circular(AppTheme.radiusLg),
        border: Border.all(color: borderColor, width: 0.5),
        boxShadow: AppTheme.shadowSm,
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(8, 4, 8, 4),
        child: Row(
          children: [
            // 拖拽手柄（仅在无搜索/筛选时显示）
            if (_searchQuery.isEmpty && _filterPlatform == null)
              ReorderableDragStartListener(
                index: index,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: Icon(
                    Icons.drag_indicator,
                    size: 20,
                    color: AppTheme.textTertiaryColor(context),
                  ),
                ),
              ),
            // 优先级编号
            Container(
              width: 24,
              height: 24,
              decoration: BoxDecoration(
                color: source.enabled
                    ? AppTheme.primaryColor.withOpacity(0.1)
                    : AppTheme.textMuted.withOpacity(0.1),
                borderRadius: BorderRadius.circular(6),
              ),
              alignment: Alignment.center,
              child: Text(
                '${index + 1}',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: source.enabled
                      ? AppTheme.primaryColor
                      : AppTheme.textMuted,
                ),
              ),
            ),
            const SizedBox(width: 10),
            // 主体内容
            Expanded(
              child: ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: source.enabled
                        ? AppTheme.secondaryColor.withOpacity(0.1)
                        : AppTheme.textMuted.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(AppTheme.radiusMd),
                  ),
                  child: Icon(
                    Icons.link_outlined,
                    size: 20,
                    color: source.enabled
                        ? AppTheme.secondaryColor
                        : AppTheme.textMuted,
                  ),
                ),
                title: Row(
                  children: [
                    Expanded(
                      child: Text(
                        source.name,
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: source.enabled
                              ? AppTheme.textPrimaryColor(context)
                              : AppTheme.textTertiaryColor(context),
                          decoration: source.enabled
                              ? TextDecoration.none
                              : TextDecoration.lineThrough,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    // 状态标签
                    Container(
                      margin: const EdgeInsets.only(left: 8),
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: source.enabled
                            ? AppTheme.successColor.withOpacity(0.1)
                            : AppTheme.textMuted.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        source.enabled ? '启用' : '禁用',
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                          color: source.enabled
                              ? AppTheme.successColor
                              : AppTheme.textMuted,
                        ),
                      ),
                    ),
                  ],
                ),
                subtitle: Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                            decoration: BoxDecoration(
                              color: AppTheme.surfaceBg(context),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              source.methodLabel,
                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'monospace',
                                color: AppTheme.textTertiaryColor(context),
                              ),
                            ),
                          ),
                          const SizedBox(width: 6),
                          Expanded(
                            child: Text(
                              source.platformsLabel,
                              style: TextStyle(
                                fontSize: 11,
                                color: AppTheme.textTertiaryColor(context),
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 3),
                      // 上次使用时间
                      Row(
                        children: [
                          Icon(
                            Icons.history,
                            size: 11,
                            color: AppTheme.textTertiaryColor(context),
                          ),
                          const SizedBox(width: 4),
                          Text(
                            source.lastUsedAt != null
                                ? _formatLastUsed(source.lastUsedAt!)
                                : '从未使用',
                            style: TextStyle(
                              fontSize: 10,
                              color: AppTheme.textTertiaryColor(context),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                trailing: Switch(
                  value: source.enabled,
                  onChanged: (value) => provider.toggleEnabled(source.id),
                ),
                onTap: () => _showAddEditDialog(context, source: source),
              ),
            ),
            // 操作按钮
            Column(
              children: [
                IconButton(
                  icon: const Icon(Icons.play_arrow_outlined, size: 20),
                  onPressed: source.enabled
                      ? () => _testConnection(context, source)
                      : null,
                  tooltip: '测试连通性',
                  constraints: const BoxConstraints(),
                  padding: const EdgeInsets.all(4),
                ),
                IconButton(
                  icon: const Icon(Icons.delete_outline, size: 20, color: Colors.red),
                  onPressed: () => _handleDelete(context, source),
                  tooltip: '删除',
                  constraints: const BoxConstraints(),
                  padding: const EdgeInsets.all(4),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  /// 格式化上次使用时间
  String _formatLastUsed(DateTime time) {
    final now = DateTime.now();
    final diff = now.difference(time);
    if (diff.inMinutes < 1) {
      return '刚刚使用';
    } else if (diff.inHours < 1) {
      return '${diff.inMinutes} 分钟前使用';
    } else if (diff.inDays < 1) {
      return '${diff.inHours} 小时前使用';
    } else if (diff.inDays < 7) {
      return '${diff.inDays} 天前使用';
    } else {
      return '${time.year}-${time.month.toString().padLeft(2, '0')}-${time.day.toString().padLeft(2, '0')} 使用';
    }
  }

  // ==================== 测试连通性 ====================

  Future<void> _testConnection(BuildContext context, CustomApiSource source) async {
    final messenger = ScaffoldMessenger.of(context);
    messenger.showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const SizedBox(
              width: 16,
              height: 16,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                color: Colors.white,
              ),
            ),
            const SizedBox(width: 12),
            Text('正在测试 ${source.name}...'),
          ],
        ),
        duration: const Duration(seconds: 15),
      ),
    );

    final result = await context.read<CustomSourceProvider>().testConnection(source);
    final success = result.$1;
    final message = result.$2;
    final duration = result.$3;

    // 更新使用时间
    if (success) {
      // ignore: use_build_context_synchronously
      await context.read<CustomSourceProvider>().updateLastUsed(source.id);
    }

    messenger.hideCurrentSnackBar();
    messenger.showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              success ? Icons.check_circle : Icons.error_outline,
              color: success ? Colors.white : Colors.red.shade200,
              size: 20,
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                success ? '连接成功：$message (${duration}ms)' : '连接失败：$message',
              ),
            ),
          ],
        ),
        backgroundColor: success ? AppTheme.successColor : AppTheme.errorColor,
      ),
    );
  }

  // ==================== 添加/编辑对话框 ====================

  void _showAddEditDialog(BuildContext context, {CustomApiSource? source}) {
    final isEdit = source != null;
    final nameController = TextEditingController(text: source?.name ?? '');
    final urlController = TextEditingController(text: source?.apiUrl ?? '');
    final apiKeyParamController = TextEditingController(text: source?.apiKeyParam ?? '');
    final apiKeyController = TextEditingController(text: source?.apiKey ?? '');
    final headersController = TextEditingController(text: source?.headersTemplate ?? '');
    final bodyController = TextEditingController(text: source?.bodyTemplate ?? '');
    final remarkController = TextEditingController(text: source?.remark ?? '');

    HttpRequestMethod method = source?.method ?? HttpRequestMethod.get;
    final platforms = <String>{...?source?.supportedPlatforms};
    if (platforms.isEmpty) platforms.add('douyin');

    const allPlatforms = ['douyin', 'kuaishou', 'xiaohongshu'];
    const platformLabels = {'douyin': '抖音', 'kuaishou': '快手', 'xiaohongshu': '小红书'};

    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (context) => StatefulBuilder(
        builder: (context, setSheetState) {
          return DraggableScrollableSheet(
            initialChildSize: 0.8,
            minChildSize: 0.5,
            maxChildSize: 0.95,
            expand: false,
            builder: (context, scrollController) {
              return SingleChildScrollView(
                controller: scrollController,
                child: Padding(
                  padding: EdgeInsets.fromLTRB(
                    20, 8, 20,
                    MediaQuery.of(context).viewInsets.bottom + 20,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        isEdit ? '编辑解析源' : '添加解析源',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                          color: AppTheme.textPrimaryColor(context),
                        ),
                      ),
                      const SizedBox(height: 20),
                      TextField(
                        controller: nameController,
                        decoration: const InputDecoration(
                          labelText: '名称',
                          hintText: '如：我的私有 API',
                        ),
                      ),
                      const SizedBox(height: 16),
                      TextField(
                        controller: urlController,
                        decoration: const InputDecoration(
                          labelText: 'API URL',
                          hintText: 'https://api.example.com/parse',
                        ),
                        keyboardType: TextInputType.url,
                      ),
                      const SizedBox(height: 16),
                      const Text('请求方式', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 8),
                      Row(
                        children: HttpRequestMethod.values.map((m) {
                          final isSelected = method == m;
                          return Padding(
                            padding: const EdgeInsets.only(right: 8),
                            child: ChoiceChip(
                              label: Text(m == HttpRequestMethod.get ? 'GET' : 'POST'),
                              selected: isSelected,
                              onSelected: (selected) {
                                if (selected) setSheetState(() => method = m);
                              },
                            ),
                          );
                        }).toList(),
                      ),
                      const SizedBox(height: 16),
                      const Text('支持的平台', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        children: allPlatforms.map((p) {
                          final isSelected = platforms.contains(p);
                          return FilterChip(
                            label: Text(platformLabels[p]!),
                            selected: isSelected,
                            onSelected: (selected) {
                              setSheetState(() {
                                if (selected) {
                                  platforms.add(p);
                                } else {
                                  platforms.remove(p);
                                }
                              });
                            },
                          );
                        }).toList(),
                      ),
                      const SizedBox(height: 16),
                      TextField(
                        controller: apiKeyParamController,
                        decoration: const InputDecoration(
                          labelText: 'API Key 参数名（可选）',
                          hintText: '如：token、key、apikey',
                        ),
                      ),
                      const SizedBox(height: 16),
                      TextField(
                        controller: apiKeyController,
                        decoration: const InputDecoration(
                          labelText: 'API Key（可选）',
                          hintText: '你的 API 密钥',
                        ),
                        obscureText: true,
                      ),
                      const SizedBox(height: 16),
                      TextField(
                        controller: headersController,
                        maxLines: 3,
                        decoration: const InputDecoration(
                          labelText: '请求头模板（可选，JSON 格式）',
                          hintText: '{"User-Agent": "xxx"}',
                          alignLabelWithHint: true,
                        ),
                      ),
                      const SizedBox(height: 16),
                      TextField(
                        controller: bodyController,
                        maxLines: 3,
                        decoration: const InputDecoration(
                          labelText: '请求体模板（可选，POST 时使用）',
                          hintText: '{"url": "{{url}}"}',
                          alignLabelWithHint: true,
                        ),
                      ),
                      const SizedBox(height: 16),
                      TextField(
                        controller: remarkController,
                        decoration: const InputDecoration(
                          labelText: '备注（可选）',
                          hintText: '源的说明信息',
                        ),
                      ),
                      const SizedBox(height: 24),
                      Row(
                        children: [
                          if (isEdit)
                            Expanded(
                              child: OutlinedButton.icon(
                                onPressed: () async {
                                  final success = await context.read<CustomSourceProvider>()
                                      .testConnection(source!);
                                  if (context.mounted) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Text(
                                          success.$1
                                              ? '连接成功 (${success.$3}ms)'
                                              : '连接失败：${success.$2}',
                                        ),
                                        backgroundColor: success.$1
                                            ? AppTheme.successColor
                                            : AppTheme.errorColor,
                                      ),
                                    );
                                  }
                                },
                                icon: const Icon(Icons.network_check, size: 18),
                                label: const Text('测试'),
                              ),
                            ),
                          if (isEdit) const SizedBox(width: 12),
                          Expanded(
                            flex: 2,
                            child: ElevatedButton.icon(
                              onPressed: () async {
                                final name = nameController.text.trim();
                                final url = urlController.text.trim();
                                if (name.isEmpty) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(content: Text('请输入名称')),
                                  );
                                  return;
                                }
                                if (url.isEmpty) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(content: Text('请输入 API URL')),
                                  );
                                  return;
                                }
                                if (platforms.isEmpty) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(content: Text('请至少选择一个平台')),
                                  );
                                  return;
                                }

                                final provider = context.read<CustomSourceProvider>();
                                if (isEdit) {
                                  final updated = source!.copyWith(
                                    name: name,
                                    apiUrl: url,
                                    method: method,
                                    supportedPlatforms: platforms.toList(),
                                    apiKeyParam: apiKeyParamController.text.isEmpty
                                        ? null
                                        : apiKeyParamController.text.trim(),
                                    apiKey: apiKeyController.text.isEmpty
                                        ? null
                                        : apiKeyController.text.trim(),
                                    headersTemplate: headersController.text.isEmpty
                                        ? null
                                        : headersController.text.trim(),
                                    bodyTemplate: bodyController.text.isEmpty
                                        ? null
                                        : bodyController.text.trim(),
                                    remark: remarkController.text.isEmpty
                                        ? null
                                        : remarkController.text.trim(),
                                  );
                                  await provider.update(updated);
                                } else {
                                  await provider.create(
                                    name: name,
                                    apiUrl: url,
                                    method: method,
                                    supportedPlatforms: platforms.toList(),
                                    apiKeyParam: apiKeyParamController.text.isEmpty
                                        ? null
                                        : apiKeyParamController.text.trim(),
                                    apiKey: apiKeyController.text.isEmpty
                                        ? null
                                        : apiKeyController.text.trim(),
                                    headersTemplate: headersController.text.isEmpty
                                        ? null
                                        : headersController.text.trim(),
                                    bodyTemplate: bodyController.text.isEmpty
                                        ? null
                                        : bodyController.text.trim(),
                                    remark: remarkController.text.isEmpty
                                        ? null
                                        : remarkController.text.trim(),
                                  );
                                }

                                if (context.mounted) {
                                  Navigator.pop(context);
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content: Text(isEdit ? '解析源已更新' : '解析源已添加'),
                                    ),
                                  );
                                }
                              },
                              icon: Icon(isEdit ? Icons.save : Icons.add),
                              label: Text(isEdit ? '保存' : '添加'),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  // ==================== 删除 ====================

  Future<void> _handleDelete(BuildContext context, CustomApiSource source) async {
    final confirmed = await showConfirmDialog(
      context,
      title: '删除解析源',
      content: '确定要删除「${source.name}」吗？此操作不可恢复。',
      confirmText: '删除',
      isDestructive: true,
    );
    if (confirmed == true && context.mounted) {
      await context.read<CustomSourceProvider>().remove(source.id);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('解析源已删除')),
      );
    }
  }

  // ==================== 帮助 ====================

  void _showHelpDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('解析源说明'),
        content: const SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('内置解析源', style: TextStyle(fontWeight: FontWeight.w700)),
              SizedBox(height: 4),
              Text(
                '由 App 内置的解析器直接调用官方接口，速度快但可能因平台更新而失效。',
                style: TextStyle(fontSize: 13, height: 1.5),
              ),
              SizedBox(height: 12),
              Text('自定义解析源', style: TextStyle(fontWeight: FontWeight.w700)),
              SizedBox(height: 4),
              Text(
                '你可以添加自己的 API 解析服务。解析时会按优先级顺序尝试，前一个失败后自动 fallback 到下一个。',
                style: TextStyle(fontSize: 13, height: 1.5),
              ),
              SizedBox(height: 12),
              Text('拖拽排序', style: TextStyle(fontWeight: FontWeight.w700)),
              SizedBox(height: 4),
              Text(
                '长按左侧拖拽手柄可以调整优先级顺序。',
                style: TextStyle(fontSize: 13, height: 1.5),
              ),
              SizedBox(height: 12),
              Text('导入/导出', style: TextStyle(fontWeight: FontWeight.w700)),
              SizedBox(height: 4),
              Text(
                '支持将自定义源导出为 JSON 文件备份，或从 JSON 文件导入。',
                style: TextStyle(fontSize: 13, height: 1.5),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('我知道了'),
          ),
        ],
      ),
    );
  }
}
