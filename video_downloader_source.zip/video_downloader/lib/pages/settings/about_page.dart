import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';

/// 关于页面：展示作者信息与版本更新日志
class AboutPage extends StatelessWidget {
  const AboutPage({super.key});

  static const String _appVersion = '2.1.0';

  /// 更新日志（最新版本在最上方）
  static const List<Map<String, String>> _changelog = [
    {
      'version': 'v2.1.0',
      'date': '2026-09-15',
      'note': '新增“关于”页面；批量抓取每一批次右上角独立“复制字段”按钮；修复批量记录垃圾桶图标溢出；解析/抓取/转换页限制空白区无限下滑；优化开屏动画时长；历史记录防无限滚动。',
    },
    {
      'version': 'v2.0.6',
      'date': '2026-08-30',
      'note': '新增批量抓取作者信息；解析结果支持“复制字段”功能；摇一摇解析、3D 视差效果上线。',
    },
    {
      'version': 'v2.0.5',
      'date': '2026-08-18',
      'note': '新增自定义解析源管理与导入导出；支持抖音作者 UID 校验与清洗。',
    },
    {
      'version': 'v2.0.4',
      'date': '2026-08-05',
      'note': '新增用户自定义主题色、OLED 纯黑主题；优化深色模式细节。',
    },
    {
      'version': 'v2.0.3',
      'date': '2026-07-20',
      'note': '新增父辈/紧凑/标准三种界面密度切换；优化列表排版与图标。',
    },
    {
      'version': 'v2.0.2',
      'date': '2026-07-06',
      'note': '新增历史记录管理、批量清理缓存；多项性能与稳定性优化。',
    },
    {
      'version': 'v2.0.0',
      'date': '2026-06-20',
      'note': '全新 2.0 版本，重构界面设计；支持抖音/快手/小红书视频与图文无水印解析下载。',
    },
  ];

  @override
  Widget build(BuildContext context) {
    final isDark = AppTheme.isDark(context);
    final primaryColor = Theme.of(context).colorScheme.primary;
    final cardBg = AppTheme.cardBg(context);
    final borderColor = AppTheme.cardBorderColor(context);
    final secondaryText = AppTheme.textSecondaryColor(context);

    return Scaffold(
      appBar: AppBar(title: const Text('关于')),
      body: ListView(
        // 禁止无限下滑，内容到底即止
        physics: const ClampingScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 60),
        children: [
          _buildHeader(context, primaryColor),
          const SizedBox(height: 24),
          _buildAuthorCard(context, cardBg, borderColor, secondaryText),
          const SizedBox(height: 28),
          _buildChangelogTitle(),
          const SizedBox(height: 8),
          _buildChangelog(context, cardBg, borderColor, secondaryText, primaryColor),
        ],
      ),
    );
  }

  /// 顶部：Logo + 应用名 + 版本号
  Widget _buildHeader(BuildContext context, Color primaryColor) {
    return Column(
      children: [
        Container(
          width: 88,
          height: 88,
          decoration: BoxDecoration(
            gradient: AppTheme.primaryGradient,
            borderRadius: BorderRadius.circular(22),
            boxShadow: AppTheme.shadowLg,
          ),
          child: const Icon(Icons.download_rounded, color: Colors.white, size: 46),
        ),
        const SizedBox(height: 16),
        const Text(
          '无水印下载',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, letterSpacing: -0.3),
        ),
        const SizedBox(height: 4),
        Text(
          '一键解析，畅享无水印',
          style: TextStyle(fontSize: 14, color: AppTheme.textSecondaryColor(context)),
        ),
        const SizedBox(height: 10),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
          decoration: BoxDecoration(
            color: primaryColor.withOpacity(0.1),
            borderRadius: BorderRadius.circular(AppTheme.radiusFull),
          ),
          child: Text(
            'v$_appVersion',
            style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: primaryColor),
          ),
        ),
      ],
    );
  }

  /// 作者信息卡片
  Widget _buildAuthorCard(
    BuildContext context,
    Color cardBg,
    Color borderColor,
    Color secondaryText,
  ) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(AppTheme.radiusLg),
        border: Border.all(color: borderColor, width: 0.5),
        boxShadow: AppTheme.shadowMd,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.person_outline,
                  size: 20, color: Theme.of(context).colorScheme.primary),
              const SizedBox(width: 8),
              const Text('作者信息',
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
            ],
          ),
          const SizedBox(height: 14),
          _buildAuthorRow(context, Icons.badge_outlined, '开发者', '美好生活团队'),
          _buildAuthorRow(context, Icons.email_outlined, '联系邮箱', 'support@app.com'),
          _buildAuthorRow(context, Icons.web_outlined, '应用简介', '专注于短视频无水印解析下载的轻量工具'),
          const SizedBox(height: 4),
          Text(
            '本应用仅供个人学习使用，请勿用于商业用途。请尊重原作者版权，下载内容请勿二次传播。',
            style: TextStyle(fontSize: 12, color: secondaryText, height: 1.5),
          ),
        ],
      ),
    );
  }

  Widget _buildAuthorRow(BuildContext context, IconData icon, String label, String value) {
    final isDark = AppTheme.isDark(context);
    final labelColor = isDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B);
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 16, color: labelColor),
          const SizedBox(width: 8),
          SizedBox(
            width: 72,
            child: Text(label,
                style: TextStyle(fontSize: 13, color: labelColor, fontWeight: FontWeight.w500)),
          ),
          Expanded(
            child: SelectableText(value,
                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
          ),
        ],
      ),
    );
  }

  Widget _buildChangelogTitle() {
    return const Row(
      children: [
        Icon(Icons.history_rounded, size: 20),
        SizedBox(width: 8),
        Text('更新日志',
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
      ],
    );
  }

  /// 更新日志列表（每版本一张卡片）
  Widget _buildChangelog(
    BuildContext context,
    Color cardBg,
    Color borderColor,
    Color secondaryText,
    Color primaryColor,
  ) {
    return Column(
      children: List.generate(_changelog.length, (index) {
        final log = _changelog[index];
        final isLatest = index == 0;
        return Container(
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: cardBg,
            borderRadius: BorderRadius.circular(AppTheme.radiusLg),
            border: Border.all(
              color: isLatest ? primaryColor.withOpacity(0.5) : borderColor,
              width: isLatest ? 1.2 : 0.5,
            ),
            boxShadow: isLatest ? AppTheme.shadowMd : null,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                    decoration: BoxDecoration(
                      color: isLatest
                          ? primaryColor
                          : primaryColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(AppTheme.radiusFull),
                    ),
                    child: Text(
                      log['version']!,
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: isLatest ? Colors.white : primaryColor,
                      ),
                    ),
                  ),
                  const Spacer(),
                  Text(
                    log['date'] ?? '',
                    style: TextStyle(fontSize: 12, color: secondaryText),
                  ),
                ],
              ),
              if (isLatest) ...[
                const SizedBox(height: 8),
                Row(
                  children: [
                    const Icon(Icons.new_releases, size: 14, color: Color(0xFFF59E0B)),
                    const SizedBox(width: 4),
                    Text('最新版本',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: const Color(0xFFF59E0B),
                        )),
                  ],
                ),
              ],
              const SizedBox(height: 10),
              SelectableText(
                log['note'] ?? '',
                style: TextStyle(
                  fontSize: 13,
                  height: 1.6,
                  color: AppTheme.textSecondaryColor(context),
                ),
              ),
            ],
          ),
        );
      }),
    );
  }
}