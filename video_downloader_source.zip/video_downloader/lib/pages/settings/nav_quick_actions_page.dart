import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/settings_provider.dart';
import '../../services/quick_actions_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/frosted_app_bar.dart';
import '../../utils/page_route.dart';
import 'bottom_nav_management_page.dart';

/// 导航与快捷方式设置页面
///
/// 合并了「底部导航管理」和「桌面快捷方式」两个设置项，
/// 方便用户在同一页面统一管理导航栏和快捷操作。
class NavQuickActionsPage extends StatefulWidget {
  const NavQuickActionsPage({super.key});

  @override
  State<NavQuickActionsPage> createState() => _NavQuickActionsPageState();
}

class _NavQuickActionsPageState extends State<NavQuickActionsPage> {
  @override
  Widget build(BuildContext context) {
    final isDark = AppTheme.isDark(context);
    final borderColor = isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0);

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: const FrostedAppBar(
        title: '导航与快捷方式',
      ),
      body: ListView(
        padding: EdgeInsets.fromLTRB(20, MediaQuery.of(context).padding.top + kToolbarHeight + 16, 20, 32),
        children: [
          _buildSectionTitle('导航栏'),
          const SizedBox(height: 8),
          _buildSettingsGroup([
            _buildBottomNavManagementTile(),
          ]),
          const SizedBox(height: 24),
          _buildSectionTitle('快捷方式'),
          const SizedBox(height: 8),
          _buildSettingsGroup([
            _buildQuickActionsTile(),
          ]),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 0, 4, 0),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w600,
          color: AppTheme.textSecondaryColor(context),
        ),
      ),
    );
  }

  Widget _buildSettingsGroup(List<Widget> children) {
    final isDark = AppTheme.isDark(context);
    final borderColor = isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0);

    return Container(
      decoration: BoxDecoration(
        color: AppTheme.cardBg(context),
        borderRadius: BorderRadius.circular(AppTheme.radiusLg),
        border: Border.all(color: borderColor, width: 0.5),
        boxShadow: AppTheme.shadowSm,
      ),
      clipBehavior: Clip.antiAlias,
      child: IconTheme(
        data: IconThemeData(
          size: 22,
          color: AppTheme.primaryColor,
        ),
        child: Column(
          children: List.generate(children.length * 2 - 1, (index) {
            if (index.isEven) {
              return children[index ~/ 2];
            } else {
              return Divider(
                height: 0.5,
                thickness: 0.5,
                indent: 56,
                endIndent: 16,
                color: borderColor,
              );
            }
          }),
        ),
      ),
    );
  }

  /// 底部导航管理
  Widget _buildBottomNavManagementTile() {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        final configJson = settings.bottomNavConfigJson;
        int visibleCount = 5; // 默认数量
        if (configJson.isNotEmpty) {
          try {
            final config = settings.bottomNavConfig;
            visibleCount = (config['visibleTabs'] as List?)?.length ?? 5;
          } catch (_) {}
        }
        return ListTile(
          leading: const Icon(Icons.view_column_outlined),
          title: const Text('底部导航管理'),
          subtitle: Text('已显示 $visibleCount 个 Tab，可自定义顺序和显隐'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () {
            Navigator.push(
              context,
              AppPageRoute.slideRight(const BottomNavManagementPage()),
            );
          },
        );
      },
    );
  }

  /// 桌面快捷方式
  Widget _buildQuickActionsTile() {
    return Consumer<QuickActionsService>(
      builder: (context, quickActions, child) {
        return ListTile(
          leading: const Icon(Icons.shortcut_outlined),
          title: const Text('桌面快捷方式'),
          subtitle: const Text('添加一键解析、批量抓取、下载管理快捷方式'),
          trailing: const Icon(Icons.add_circle_outline, color: AppTheme.primaryColor),
          onTap: () async {
            await quickActions.setShortcuts();
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('已添加桌面快捷方式'),
                  duration: Duration(seconds: 2),
                ),
              );
            }
          },
        );
      },
    );
  }
}
