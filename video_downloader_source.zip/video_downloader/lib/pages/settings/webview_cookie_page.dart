import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../../providers/settings_provider.dart';
import '../../theme/app_theme.dart';

class WebviewCookiePage extends StatefulWidget {
  const WebviewCookiePage({super.key});

  @override
  State<WebviewCookiePage> createState() => _WebviewCookiePageState();
}

class _WebviewCookiePageState extends State<WebviewCookiePage> {
  late final WebViewController _controller;
  bool _isLoading = true;
  Map<String, String> _extractedCookies = {};
  bool _hasExtracted = false;
  bool _showTipBanner = true;

  /// 关注的关键 Cookie 名称
  static const List<String> _keyCookieNames = [
    'sessionid',
    'sessionid_ss',
    'ttwid',
    'passport_csrf_token',
    'sid_guard',
    'sid_tt',
    'uid_tt',
    'uid_tt_ss',
  ];

  @override
  void initState() {
    super.initState();

    // 初始化 WebViewController
    // 使用桌面端 UA，确保抖音返回完整的网页版页面（带登录入口）
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setUserAgent(
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      )
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (url) {
            setState(() => _isLoading = true);
          },
          onPageFinished: (url) {
            setState(() => _isLoading = false);
          },
        ),
      )
      ..loadRequest(Uri.parse('https://www.douyin.com'));

    // Android 平台设置
    if (Platform.isAndroid) {
      _controller.enableZoom(false);
    }
  }

  /// 提取当前页面的 Cookie
  Future<void> _extractCookies() async {
    try {
      // 通过 WebViewController 执行 JavaScript 获取 document.cookie
      final result = await _controller.runJavaScriptReturningResult('document.cookie');
      final cookieString = result.toString();

      final Map<String, String> cookieMap = {};
      if (cookieString.isNotEmpty && cookieString != 'null') {
        final pairs = cookieString.split('; ');
        for (final pair in pairs) {
          final idx = pair.indexOf('=');
          if (idx > 0) {
            final name = pair.substring(0, idx).trim();
            final value = pair.substring(idx + 1).trim();
            cookieMap[name] = value;
          }
        }
      }

      // 只保留关键 Cookie
      final Map<String, String> keyCookies = {};
      for (final name in _keyCookieNames) {
        if (cookieMap.containsKey(name)) {
          keyCookies[name] = cookieMap[name]!;
        }
      }

      setState(() {
        _extractedCookies = keyCookies;
        _hasExtracted = true;
      });

      if (keyCookies.isNotEmpty) {
        // 保存到设置中
        if (mounted) {
          await context.read<SettingsProvider>().setDouyinCookies(keyCookies);
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('成功提取 ${keyCookies.length} 个关键 Cookie')),
          );
        }
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('未找到关键 Cookie，请先登录抖音账号')),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('提取 Cookie 失败：$e')),
        );
      }
    }
  }

  /// 清除已保存的 Cookie
  Future<void> _clearCookies() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('清除 Cookie'),
        content: const Text('确定要清除已保存的抖音 Cookie 吗？\n\n清除前会自动备份，之后可在设置中恢复。\n\n将同时清除：\n• 已保存到本地的 Cookie\n• 浏览器中的登录状态'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('确定清除', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirmed == true && mounted) {
      // 先备份再清除
      final settings = context.read<SettingsProvider>();
      await settings.backupDouyinCookies();
      await settings.clearDouyinCookies();
      // 清除 WebView 本身的 Cookie（退出登录）
      try {
        // 通过 JavaScript 清除所有 Cookie
        await _controller.runJavaScript(
          'document.cookie.split(";").forEach(function(c) { '
          'document.cookie = c.replace(/^ +/, "").replace(/=.*/, "=;expires=" + new Date().toUTCString() + ";path=/"); '
          '});',
        );
        await _controller.clearCache();
        await _controller.clearLocalStorage();
        // 重新加载页面以确认已退出登录
        _controller.loadRequest(Uri.parse('https://www.douyin.com'));
      } catch (_) {
        // 出错时至少重新加载页面
        _controller.loadRequest(Uri.parse('https://www.douyin.com'));
      }
      setState(() {
        _extractedCookies = {};
        _hasExtracted = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Cookie 已清除（已自动备份），浏览器已退出登录')),
      );
    }
  }

  /// 脱敏显示 Cookie 值
  String _maskValue(String value) {
    if (value.length <= 8) {
      return '${value.substring(0, 2)}****';
    }
    return '${value.substring(0, 4)}****${value.substring(value.length - 4)}';
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;

    return Scaffold(
      appBar: AppBar(
        title: const Text('抖音 Cookie 获取'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: '刷新',
            onPressed: () => _controller.reload(),
          ),
        ],
      ),
      body: Column(
        children: [
          // 进度条
          if (_isLoading)
            const LinearProgressIndicator(minHeight: 2),
          // 登录提示条
          if (_showTipBanner) _buildTipBanner(isDark),
          // WebView
          Expanded(
            child: WebViewWidget(controller: _controller),
          ),
          // 底部操作栏
          _buildBottomBar(isDark, secondaryTextColor),
        ],
      ),
    );
  }

  /// 顶部登录提示条
  Widget _buildTipBanner(bool isDark) {
    final bgColor = isDark ? Colors.grey.shade800 : Colors.amber.shade50;
    final textColor = isDark ? Colors.amber.shade200 : Colors.amber.shade800;
    final borderColor = isDark ? Colors.grey.shade700 : Colors.amber.shade200;

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.fromLTRB(12, 10, 12, 6),
      padding: const EdgeInsets.fromLTRB(12, 10, 4, 10),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: borderColor),
      ),
      child: Row(
        children: [
          Icon(Icons.lightbulb_outline, size: 18, color: textColor),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              '点击页面右上角「登录」按钮登录抖音，登录成功后点击底部"提取 Cookie"',
              style: TextStyle(fontSize: 13, color: textColor, height: 1.3),
            ),
          ),
          IconButton(
            icon: Icon(Icons.close, size: 18, color: textColor),
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
            onPressed: () {
              setState(() => _showTipBanner = false);
            },
          ),
        ],
      ),
    );
  }

  Widget _buildBottomBar(bool isDark, Color secondaryTextColor) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        border: Border(
          top: BorderSide(
            color: isDark ? Colors.grey.shade800 : Colors.grey.shade200,
          ),
        ),
      ),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // 提示信息
            Row(
              children: [
                Icon(Icons.info_outline, size: 16, color: secondaryTextColor),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    '请在上方浏览器中登录抖音账号，登录完成后点击"提取 Cookie"',
                    style: TextStyle(fontSize: 12, color: secondaryTextColor),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            // 已提取的 Cookie 信息
            if (_hasExtracted && _extractedCookies.isNotEmpty)
              _buildCookieInfo(isDark, secondaryTextColor),
            if (_hasExtracted && _extractedCookies.isNotEmpty)
              const SizedBox(height: 12),
            // 按钮行
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _hasExtracted ? _clearCookies : null,
                    icon: const Icon(Icons.delete_outline, size: 18),
                    label: const Text('清除 Cookie'),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  flex: 2,
                  child: FilledButton.icon(
                    onPressed: _isLoading ? null : _extractCookies,
                    icon: const Icon(Icons.cookie_outlined, size: 18),
                    label: const Text('提取 Cookie'),
                    style: FilledButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      backgroundColor: AppTheme.primaryColor,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCookieInfo(bool isDark, Color secondaryTextColor) {
    final borderColor = isDark ? Colors.grey.shade700 : Colors.grey.shade300;
    final greenColor = isDark ? Colors.green.shade400 : Colors.green;

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: greenColor.withOpacity(isDark ? 0.1 : 0.05),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: greenColor.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.check_circle, size: 16, color: greenColor),
              const SizedBox(width: 6),
              Text(
                '已获取 ${_extractedCookies.length} 个关键 Cookie',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: greenColor,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          ..._extractedCookies.entries.map((entry) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: Row(
                children: [
                  SizedBox(
                    width: 120,
                    child: Text(
                      entry.key,
                      style: TextStyle(
                        fontSize: 12,
                        fontFamily: 'monospace',
                        color: secondaryTextColor,
                      ),
                    ),
                  ),
                  Expanded(
                    child: Text(
                      _maskValue(entry.value),
                      style: const TextStyle(
                        fontSize: 12,
                        fontFamily: 'monospace',
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            );
          }).toList(),
        ],
      ),
    );
  }
}
