import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/settings_provider.dart';
import '../../providers/download_provider.dart';
import '../../theme/app_theme.dart';
import '../../widgets/frosted_app_bar.dart';

/// 存储规则设置页面
///
/// 合并了「存储组织模式」和「文件命名规则」两个设置项，
/// 方便用户在同一页面统一管理文件存储方式。
class StorageRulesPage extends StatefulWidget {
  const StorageRulesPage({super.key});

  @override
  State<StorageRulesPage> createState() => _StorageRulesPageState();
}

class _StorageRulesPageState extends State<StorageRulesPage> {
  @override
  Widget build(BuildContext context) {
    final isDark = AppTheme.isDark(context);
    final borderColor = isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0);

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: const FrostedAppBar(
        title: '存储规则',
      ),
      body: ListView(
        padding: EdgeInsets.fromLTRB(20, MediaQuery.of(context).padding.top + kToolbarHeight + 16, 20, 32),
        children: [
          // 存储组织模式
          _buildSectionTitle('存储组织模式'),
          const SizedBox(height: 8),
          _buildSettingsGroup([
            _buildOrganizeModeTile(),
          ]),
          const SizedBox(height: 24),
          // 文件命名规则
          _buildSectionTitle('文件命名规则'),
          const SizedBox(height: 8),
          _buildSettingsGroup([
            _buildNamingRuleTile(),
          ]),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 0, 4, 0),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w600,
          color: AppTheme.textSecondaryColor(context),
        ),
      ),
    );
  }

  Widget _buildSettingsGroup(List<Widget> children) {
    final isDark = AppTheme.isDark(context);
    final borderColor = isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0);

    return Container(
      decoration: BoxDecoration(
        color: AppTheme.cardBg(context),
        borderRadius: BorderRadius.circular(AppTheme.radiusLg),
        border: Border.all(color: borderColor, width: 0.5),
        boxShadow: AppTheme.shadowSm,
      ),
      clipBehavior: Clip.antiAlias,
      child: IconTheme(
        data: IconThemeData(
          size: 22,
          color: AppTheme.primaryColor,
        ),
        child: Column(
          children: List.generate(children.length * 2 - 1, (index) {
            if (index.isEven) {
              return children[index ~/ 2];
            } else {
              return Divider(
                height: 0.5,
                thickness: 0.5,
                indent: 56,
                endIndent: 16,
                color: borderColor,
              );
            }
          }),
        ),
      ),
    );
  }

  /// 存储组织模式
  Widget _buildOrganizeModeTile() {
    return Consumer2<SettingsProvider, DownloadProvider>(
      builder: (context, settings, downloadProvider, child) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        return ListTile(
          leading: const Icon(Icons.folder_special_outlined),
          title: const Text('存储组织模式'),
          subtitle: Text(
            _organizeModeName(settings.storageOrganizeMode),
            style: TextStyle(color: secondaryTextColor, fontSize: 13),
          ),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _showOrganizeModeDialog(context),
        );
      },
    );
  }

  /// 文件命名规则
  Widget _buildNamingRuleTile() {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        return ListTile(
          leading: const Icon(Icons.text_fields),
          title: const Text('文件命名规则'),
          subtitle: Text(
            _namingRuleName(settings.storageNamingRule),
            style: TextStyle(color: secondaryTextColor, fontSize: 13),
          ),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _showNamingRuleDialog(context),
        );
      },
    );
  }

  String _organizeModeName(String mode) {
    switch (mode) {
      case 'flat': return '平铺（所有文件在同一目录）';
      case 'platform': return '按平台分类（抖音/快手/小红书）';
      case 'author': return '按作者分类';
      case 'date': return '按日期分类';
      case 'platform_author': return '平台 + 作者（两级目录）';
      default: return '平铺';
    }
  }

  String _namingRuleName(String rule) {
    switch (rule) {
      case 'title': return '标题';
      case 'platform_title': return '平台_标题';
      case 'date_title': return '日期_标题';
      case 'id_title': return 'ID_标题';
      default: return '标题';
    }
  }

  /// 显示存储组织模式对话框
  Future<void> _showOrganizeModeDialog(BuildContext context) async {
    final settings = context.read<SettingsProvider>();
    final downloadProvider = context.read<DownloadProvider>();
    final currentMode = settings.storageOrganizeMode;
    final currentDateFormat = settings.storageDateFormat;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade500;

    final modes = [
      ('flat', '平铺', '所有文件保存在同一目录', Icons.folder_outlined),
      ('platform', '按平台', '抖音/快手/小红书 子文件夹', Icons.language_outlined),
      ('author', '按作者', '以作者名创建子文件夹', Icons.person_outline),
      ('date', '按日期', '以日期创建子文件夹', Icons.calendar_today_outlined),
      ('platform_author', '平台+作者', '两级目录：平台/作者', Icons.account_tree_outlined),
    ];

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('存储组织模式'),
        content: StatefulBuilder(
          builder: (context, setDialogState) {
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ...modes.map((mode) {
                  final isSelected = currentMode == mode.$1;
                  return ListTile(
                    leading: Icon(mode.$4, color: isSelected ? AppTheme.primaryColor : null),
                    title: Text(mode.$2),
                    subtitle: Text(
                      mode.$3,
                      style: TextStyle(color: secondaryTextColor, fontSize: 12),
                    ),
                    trailing: isSelected
                        ? Icon(Icons.check_circle, color: AppTheme.primaryColor)
                        : null,
                    onTap: () {
                      settings.setStorageOrganizeMode(mode.$1);
                      downloadProvider.manager.storageOrganizeMode = mode.$1;
                      Navigator.pop(context);
                    },
                  );
                }).toList(),
                if (currentMode == 'date') ...[
                  const Divider(height: 24),
                  Row(
                    children: [
                      const Text('日期格式：'),
                      const SizedBox(width: 8),
                      DropdownButton<String>(
                        value: currentDateFormat,
                        items: const [
                          DropdownMenuItem(value: 'yyyy-MM-dd', child: Text('年-月-日')),
                          DropdownMenuItem(value: 'yyyyMMdd', child: Text('年月日')),
                          DropdownMenuItem(value: 'MM-dd', child: Text('月-日')),
                        ],
                        onChanged: (value) {
                          if (value != null) {
                            settings.setStorageDateFormat(value);
                            downloadProvider.manager.storageDateFormat = value;
                            setDialogState(() {});
                          }
                        },
                      ),
                    ],
                  ),
                ],
              ],
            );
          },
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('关闭'),
          ),
        ],
      ),
    );
  }

  /// 显示文件命名规则对话框
  Future<void> _showNamingRuleDialog(BuildContext context) async {
    final settings = context.read<SettingsProvider>();
    final currentRule = settings.storageNamingRule;

    final rules = [
      ('title', '标题', '直接使用视频标题作为文件名'),
      ('platform_title', '平台_标题', '例：抖音_这是一个视频标题'),
      ('date_title', '日期_标题', '例：20240101_这是一个视频标题'),
      ('id_title', 'ID_标题', '例：123456_这是一个视频标题'),
    ];

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('文件命名规则'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: rules.map((rule) {
            final isSelected = currentRule == rule.$1;
            return ListTile(
              leading: Icon(
                Icons.drive_file_rename_outline_outlined,
                color: isSelected ? AppTheme.primaryColor : null,
              ),
              title: Text(rule.$2),
              subtitle: Text(
                rule.$3,
                style: const TextStyle(fontSize: 12),
              ),
              trailing: isSelected
                  ? Icon(Icons.check_circle, color: AppTheme.primaryColor)
                  : null,
              onTap: () {
                settings.setStorageNamingRule(rule.$1);
                Navigator.pop(context);
              },
            );
          }).toList(),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('关闭'),
          ),
        ],
      ),
    );
  }
}
