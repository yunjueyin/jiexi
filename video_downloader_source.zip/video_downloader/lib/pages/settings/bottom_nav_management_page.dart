import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/settings_provider.dart';
import '../../models/bottom_nav_config.dart';
import '../../theme/app_theme.dart';
import '../../widgets/frosted_app_bar.dart';
import '../../utils/page_route.dart';

/// 底部导航管理页面
///
/// 用户可以自定义底部 Tab 的显示顺序（拖拽排序），
/// 选择显示/隐藏某些 Tab，以及恢复默认配置。
class BottomNavManagementPage extends StatefulWidget {
  const BottomNavManagementPage({super.key});

  @override
  State<BottomNavManagementPage> createState() => _BottomNavManagementPageState();
}

class _BottomNavManagementPageState extends State<BottomNavManagementPage> {
  late BottomNavConfig _config;
  bool _isDragging = false;

  @override
  void initState() {
    super.initState();
    _loadConfig();
  }

  /// 加载配置
  void _loadConfig() {
    final settings = context.read<SettingsProvider>();
    final jsonStr = settings.bottomNavConfigJson;
    if (jsonStr.isEmpty) {
      _config = BottomNavConfig.defaultConfig;
    } else {
      try {
        _config = BottomNavConfig.fromJson(settings.bottomNavConfig);
      } catch (_) {
        _config = BottomNavConfig.defaultConfig;
      }
    }
  }

  /// 保存配置
  Future<void> _saveConfig() async {
    final settings = context.read<SettingsProvider>();
    final jsonStr = _config.toJsonString();
    await settings.setBottomNavConfig(jsonStr);
  }

  /// 拖拽排序：移动 Tab
  void _reorderTabs(int oldIndex, int newIndex) {
    if (newIndex > oldIndex) newIndex -= 1;
    setState(() {
      _config = _config.moveTab(oldIndex, newIndex);
    });
    _saveConfig();
  }

  /// 切换 Tab 显示/隐藏
  Future<void> _toggleTabVisibility(BottomNavTab tab) async {
    if (_config.isVisible(tab)) {
      // 隐藏
      if (!_config.canHideMore) {
        _showMinTabWarning();
        return;
      }
      setState(() {
        _config = _config.hideTab(tab);
      });
    } else {
      // 显示
      if (!_config.canShowMore) {
        _showMaxTabWarning();
        return;
      }
      setState(() {
        _config = _config.showTab(tab);
      });
    }
    await _saveConfig();
  }

  /// 显示最少 Tab 数量警告
  void _showMinTabWarning() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('至少保留 ${BottomNavConfig.minTabCount} 个 Tab'),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  /// 显示最多 Tab 数量警告
  void _showMaxTabWarning() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('最多显示 ${BottomNavConfig.maxTabCount} 个 Tab'),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  /// 恢复默认配置
  Future<void> _resetToDefault() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('恢复默认'),
        content: const Text('确定要将底部导航恢复为默认配置吗？'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('恢复', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirm == true && mounted) {
      setState(() {
        _config = BottomNavConfig.defaultConfig;
      });
      await _saveConfig();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('已恢复默认配置')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = AppTheme.isDark(context);

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: FrostedAppBar(
        title: '底部导航管理',
        actions: [
          TextButton(
            onPressed: _resetToDefault,
            child: const Text('恢复默认', style: TextStyle(fontSize: 14)),
          ),
        ],
      ),
      body: ListView(
        padding: EdgeInsets.fromLTRB(20, kToolbarHeight + MediaQuery.of(context).padding.top + 16, 20, 32),
        children: [
          // 提示信息
          _buildTipCard(isDark),
          const SizedBox(height: 20),

          // 显示的 Tab（可拖拽排序）
          _buildSectionTitle('显示的 Tab（拖拽排序）', isDark),
          const SizedBox(height: 8),
          _buildVisibleTabsList(isDark),

          const SizedBox(height: 24),

          // 隐藏的 Tab
          _buildSectionTitle('隐藏的 Tab（点击添加）', isDark),
          const SizedBox(height: 8),
          _buildHiddenTabsList(isDark),
        ],
      ),
    );
  }

  Widget _buildTipCard(bool isDark) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: isDark
            ? const Color(0xFF1E293B)
            : AppTheme.primaryColor.withOpacity(0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isDark
              ? const Color(0xFF334155)
              : AppTheme.primaryColor.withOpacity(0.2),
        ),
      ),
      child: Row(
        children: [
          Icon(
            Icons.info_outline,
            size: 20,
            color: isDark ? Colors.blue.shade400 : AppTheme.primaryColor,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              '长按并拖拽右侧图标可调整顺序，点击眼睛图标可显示/隐藏 Tab。最少保留 ${BottomNavConfig.minTabCount} 个，最多显示 ${BottomNavConfig.maxTabCount} 个。',
              style: TextStyle(
                fontSize: 13,
                color: isDark ? Colors.grey.shade300 : Colors.grey.shade700,
                height: 1.4,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title, bool isDark) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w600,
          color: isDark ? Colors.grey.shade300 : Colors.grey.shade700,
        ),
      ),
    );
  }

  Widget _buildVisibleTabsList(bool isDark) {
    final borderColor = isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0);

    return Container(
      decoration: BoxDecoration(
        color: AppTheme.cardBg(context),
        borderRadius: BorderRadius.circular(AppTheme.radiusLg),
        border: Border.all(color: borderColor, width: 0.5),
        boxShadow: AppTheme.shadowSm,
      ),
      clipBehavior: Clip.antiAlias,
      child: ReorderableListView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: _config.visibleTabs.length,
        onReorder: _reorderTabs,
        buildDefaultDragHandles: false,
        itemBuilder: (context, index) {
          final tab = _config.visibleTabs[index];
          return _buildTabItem(
            tab: tab,
            isVisible: true,
            index: index,
            isDark: isDark,
            showDragHandle: true,
          );
        },
      ),
    );
  }

  Widget _buildHiddenTabsList(bool isDark) {
    final borderColor = isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0);

    if (_config.hiddenTabs.isEmpty) {
      return Container(
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
        decoration: BoxDecoration(
          color: AppTheme.cardBg(context),
          borderRadius: BorderRadius.circular(AppTheme.radiusLg),
          border: Border.all(color: borderColor, width: 0.5),
        ),
        child: Center(
          child: Text(
            '暂无隐藏的 Tab',
            style: TextStyle(
              fontSize: 14,
              color: isDark ? Colors.grey.shade500 : Colors.grey.shade400,
            ),
          ),
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        color: AppTheme.cardBg(context),
        borderRadius: BorderRadius.circular(AppTheme.radiusLg),
        border: Border.all(color: borderColor, width: 0.5),
        boxShadow: AppTheme.shadowSm,
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          for (int i = 0; i < _config.hiddenTabs.length; i++)
            _buildTabItem(
              tab: _config.hiddenTabs[i],
              isVisible: false,
              index: i,
              isDark: isDark,
              showDragHandle: false,
            ),
        ],
      ),
    );
  }

  Widget _buildTabItem({
    required BottomNavTab tab,
    required bool isVisible,
    required int index,
    required bool isDark,
    required bool showDragHandle,
  }) {
    final borderColor =
        isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0);
    final isLast = isVisible
        ? index == _config.visibleTabs.length - 1
        : index == _config.hiddenTabs.length - 1;

    return Material(
      key: ValueKey('${isVisible ? 'vis' : 'hid'}_${tab.id}'),
      color: Colors.transparent,
      child: Container(
        decoration: BoxDecoration(
          border: isLast
              ? null
              : Border(
                  bottom: BorderSide(color: borderColor, width: 0.5),
                ),
        ),
        child: ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
          leading: Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: isVisible
                  ? AppTheme.primaryColor.withOpacity(isDark ? 0.2 : 0.1)
                  : Colors.grey.withOpacity(isDark ? 0.15 : 0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              tab.activeIcon,
              size: 18,
              color: isVisible
                  ? AppTheme.primaryColor
                  : (isDark ? Colors.grey.shade500 : Colors.grey.shade400),
            ),
          ),
          title: Text(
            tab.label,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w500,
              color: isVisible
                  ? AppTheme.textPrimaryColor(context)
                  : (isDark ? Colors.grey.shade500 : Colors.grey.shade400),
            ),
          ),
          subtitle: isVisible
              ? Text(
                  '第 ${index + 1} 个',
                  style: TextStyle(
                    fontSize: 12,
                    color: isDark ? Colors.grey.shade500 : Colors.grey.shade400,
                  ),
                )
              : null,
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              // 显示/隐藏按钮
              IconButton(
                icon: Icon(
                  isVisible ? Icons.visibility : Icons.visibility_off,
                  size: 20,
                  color: isVisible
                      ? AppTheme.primaryColor
                      : (isDark ? Colors.grey.shade600 : Colors.grey.shade400),
                ),
                onPressed: () => _toggleTabVisibility(tab),
                tooltip: isVisible ? '隐藏' : '显示',
              ),
              // 拖拽手柄
              if (showDragHandle)
                ReorderableDragStartListener(
                  index: index,
                  child: Icon(
                    Icons.drag_handle,
                    size: 20,
                    color: isDark ? Colors.grey.shade500 : Colors.grey.shade400,
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

/// 页面跳转工具
Future<T?> navigateToBottomNavManagement<T>(BuildContext context) {
  return Navigator.of(context).push<T>(
    AppPageRoute.slideRight(const BottomNavManagementPage()),
  );
}
