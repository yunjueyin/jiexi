import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:open_filex/open_filex.dart';
import 'package:share_plus/share_plus.dart';
import 'package:cross_file/cross_file.dart';
import 'package:path_provider/path_provider.dart';
import 'package:excel/excel.dart' as excel;
import 'package:intl/intl.dart';
import 'package:file_picker/file_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../providers/download_provider.dart';
import '../../providers/transcode_provider.dart';
import '../../models/download_task.dart';
import '../../widgets/download_progress_item.dart';
import '../../widgets/empty_state.dart';
import '../../widgets/slide_action_item.dart';
import '../../services/download_manager.dart';
import '../../services/subtitle_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/frosted_app_bar.dart';

class DownloadsPage extends StatefulWidget {
  const DownloadsPage({super.key});

  @override
  State<DownloadsPage> createState() => _DownloadsPageState();
}

class _DownloadsPageState extends State<DownloadsPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  // 筛选条件
  String? _filterPlatform; // 'douyin' / 'kuaishou' / null
  String? _filterType; // 'video' / 'image' / null
  DateTime? _filterDateStart;
  DateTime? _filterDateEnd;
  String? _filterDatePreset; // '7days' / '30days' / 'custom' / null

  // 排序
  String _sortBy = 'date_desc'; // date_desc / date_asc / size_desc / size_asc / title_asc

  // 多选模式
  bool _isMultiSelectMode = false;
  Set<String> _selectedTaskIds = {};

  // 滚动控制器（用于双击回到顶部）
  final ScrollController _downloadingScrollController = ScrollController();
  final ScrollController _completedScrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _downloadingScrollController.dispose();
    _completedScrollController.dispose();
    super.dispose();
  }

  /// 双击 AppBar 滚动到顶部
  void _scrollToTop() {
    final controller = _tabController.index == 0
        ? _downloadingScrollController
        : _completedScrollController;
    if (controller.hasClients) {
      controller.animateTo(
        0,
        duration: const Duration(milliseconds: 500),
        curve: Curves.easeOutCubic,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = AppTheme.isDark(context);
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: FrostedAppBar(
        title: _isMultiSelectMode ? '已选 ${_selectedTaskIds.length} 项' : '下载管理',
        onDoubleTap: _scrollToTop,
        actions: _buildAppBarActions(),
        bottom: TabBar(
          controller: _tabController,
          onTap: (index) {
            // 切换 tab 时退出多选模式
            if (_isMultiSelectMode) {
              setState(() {
                _isMultiSelectMode = false;
                _selectedTaskIds.clear();
              });
            }
          },
          labelColor: Theme.of(context).primaryColor,
          unselectedLabelColor: isDark ? Colors.grey.shade500 : Colors.grey,
          indicatorColor: Theme.of(context).primaryColor,
          labelStyle: const TextStyle(fontWeight: FontWeight.w600),
          tabs: [
            Consumer<DownloadProvider>(
              builder: (context, provider, child) {
                final count = provider.tasks
                    .where((t) =>
                        t.status == DownloadStatus.downloading ||
                        t.status == DownloadStatus.queued ||
                        t.status == DownloadStatus.paused ||
                        t.status == DownloadStatus.failed)
                    .length;
                return Tab(
                  text: count > 0 ? '下载中 ($count)' : '下载中',
                );
              },
            ),
            Consumer<DownloadProvider>(
              builder: (context, provider, child) {
                final count = provider.tasks
                    .where((t) => t.status == DownloadStatus.completed)
                    .length;
                return Tab(
                  text: count > 0 ? '已完成 ($count)' : '已完成',
                );
              },
            ),
          ],
        ),
      ),
      body: Padding(
        padding: EdgeInsets.only(
          top: kToolbarHeight + kTextTabBarHeight + MediaQuery.of(context).padding.top,
        ),
        child: TabBarView(
          controller: _tabController,
          children: [
            _buildDownloadingList(),
            _buildCompletedList(),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildAppBarActions() {
    return [
      AnimatedBuilder(
        animation: _tabController,
        builder: (context, child) {
          final isCompletedTab = _tabController.index == 1;
          final isDownloadingTab = _tabController.index == 0;

          if (_isMultiSelectMode) {
            return Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextButton(
                  onPressed: _selectAllCurrentTab,
                  child: const Text('全选', style: TextStyle(fontSize: 13)),
                ),
                TextButton(
                  onPressed: _toggleMultiSelectMode,
                  child: const Text('取消', style: TextStyle(fontSize: 13)),
                ),
              ],
            );
          }

          // 已完成 tab
          if (isCompletedTab) {
            return Consumer<DownloadProvider>(
              builder: (context, provider, child) {
                final hasCompleted = provider.tasks
                    .any((t) => t.status == DownloadStatus.completed);
                if (!hasCompleted) return const SizedBox.shrink();
                return Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextButton(
                      onPressed: _toggleMultiSelectMode,
                      child: const Text('多选', style: TextStyle(fontSize: 13)),
                    ),
                    TextButton.icon(
                      onPressed: _exportCompletedTasks,
                      icon: const Icon(Icons.file_download_outlined, size: 16),
                      label: const Text('导出', style: TextStyle(fontSize: 13)),
                    ),
                    TextButton(
                      onPressed: _clearCompleted,
                      child: const Text('清理',
                          style: TextStyle(fontSize: 13)),
                    ),
                  ],
                );
              },
            );
          }

          // 下载中 tab
          if (isDownloadingTab) {
            return Consumer<DownloadProvider>(
              builder: (context, provider, child) {
                final hasActive = provider.tasks
                    .any((t) =>
                        t.status == DownloadStatus.downloading ||
                        t.status == DownloadStatus.queued ||
                        t.status == DownloadStatus.paused ||
                        t.status == DownloadStatus.failed);
                if (!hasActive) return const SizedBox.shrink();
                return Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextButton(
                      onPressed: _toggleMultiSelectMode,
                      child: const Text('多选', style: TextStyle(fontSize: 13)),
                    ),
                  ],
                );
              },
            );
          }

          return const SizedBox.shrink();
        },
      ),
    ];
  }

  Widget _buildDownloadingList() {
    return Consumer<DownloadProvider>(
      builder: (context, provider, child) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final activeTasks = provider.tasks
            .where((t) =>
                t.status == DownloadStatus.downloading ||
                t.status == DownloadStatus.queued ||
                t.status == DownloadStatus.paused ||
                t.status == DownloadStatus.failed)
            .toList();

        if (activeTasks.isEmpty) {
          return EmptyState.noDownloads();
        }

        // 多选模式下同步已选ID（清理不存在的）
        if (_isMultiSelectMode && _tabController.index == 0) {
          final allIds = activeTasks.map((t) => t.id).toSet();
          _selectedTaskIds.removeWhere((id) => !allIds.contains(id));
        }

        return Stack(
          children: [
            RefreshIndicator(
              onRefresh: () async {
                // 下载列表实时更新，下拉刷新仅做 UI 刷新
                await Future.delayed(const Duration(milliseconds: 500));
              },
              child: ListView.separated(
                controller: _downloadingScrollController,
                padding: EdgeInsets.fromLTRB(16, 16, 16, _isMultiSelectMode && _tabController.index == 0 ? 80 : 16),
                physics: const AlwaysScrollableScrollPhysics(),
                itemCount: activeTasks.length,
                separatorBuilder: (_, __) => const SizedBox(height: 12),
                itemBuilder: (context, index) {
                  final task = activeTasks[index];
                  return _buildTaskItem(task, provider);
                },
              ),
            ),
            // 多选底部操作栏（下载中 tab）
            if (_isMultiSelectMode && _tabController.index == 0)
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                child: _buildDownloadingMultiSelectBottomBar(),
              ),
          ],
        );
      },
    );
  }

  Widget _buildTaskItem(DownloadTask task, DownloadProvider provider) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isFailed = task.status == DownloadStatus.failed;
    final isSelected = _selectedTaskIds.contains(task.id);

    // 多选模式下不显示左滑操作
    if (_isMultiSelectMode) {
      return _buildTaskItemContent(task, provider, isDark, isFailed, isSelected);
    }

    return SlideActionItem(
      actions: [
        SlideAction(
          icon: Icons.delete_outline,
          label: '删除',
          color: Colors.red,
          onTap: () => _deleteTaskWithUndo(task),
        ),
      ],
      child: _buildTaskItemContent(task, provider, isDark, isFailed, isSelected),
    );
  }

  Widget _buildTaskItemContent(
    DownloadTask task,
    DownloadProvider provider,
    bool isDark,
    bool isFailed,
    bool isSelected,
  ) {

    // 动态颜色
    final coverBgColor = isDark ? const Color(0xFF1E293B) : Colors.grey.shade100;
    final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
    final borderColor = isDark ? Colors.grey.shade700 : Colors.grey.shade300;
    final progressBgColor = isDark ? Colors.grey.shade800 : Colors.grey.shade100;
    final buttonFgColor = isDark ? Colors.grey.shade300 : Colors.grey.shade700;
    final iconColor = isDark ? Colors.grey.shade400 : Colors.grey.shade500;

    return InkWell(
      onTap: _isMultiSelectMode
          ? () => _toggleTaskSelection(task.id)
          : null,
      onLongPress: _isMultiSelectMode
          ? null
          : () {
              // 长按进入多选模式并选中当前项
              setState(() {
                _isMultiSelectMode = true;
                _selectedTaskIds.add(task.id);
              });
            },
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: isSelected
              ? AppTheme.primaryColor.withOpacity(isDark ? 0.1 : 0.05)
              : Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(14),
          border: isSelected
              ? Border.all(color: AppTheme.primaryColor.withOpacity(0.3), width: 1.5)
              : null,
          boxShadow: isDark
              ? []
              : [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.04),
                    blurRadius: 10,
                    offset: const Offset(0, 2),
                  ),
                ],
        ),
        child: Column(
          children: [
            Row(
              children: [
                if (_isMultiSelectMode) ...[
                  Container(
                    width: 24,
                    height: 24,
                    margin: const EdgeInsets.only(right: 10),
                    decoration: BoxDecoration(
                      color: isSelected ? AppTheme.primaryColor : Colors.transparent,
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: isSelected ? AppTheme.primaryColor : (isDark ? Colors.grey.shade600 : Colors.grey.shade400),
                        width: 2,
                      ),
                    ),
                    child: isSelected
                        ? const Icon(Icons.check, size: 14, color: Colors.white)
                        : null,
                  ),
                ],
                ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: Container(
                    width: 52,
                    height: 52,
                    color: coverBgColor,
                    child: task.videoCover.isNotEmpty
                        ? Image.network(task.videoCover, fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) =>
                                Icon(Icons.videocam,
                                    size: 24, color: iconColor))
                        : Icon(Icons.videocam,
                            size: 24, color: iconColor),
                  ),
                ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      task.videoTitle,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Text(
                          task.qualityLabel,
                          style: TextStyle(
                            fontSize: 11,
                            color: secondaryTextColor,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: _statusBgColor(task.status, isDark),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            task.statusText,
                            style: TextStyle(
                              fontSize: 10,
                              color: _statusTextColor(task.status, isDark),
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              // 更多操作菜单
              PopupMenuButton<String>(
                onSelected: (value) =>
                    _handleTaskMenuAction(value, task),
                itemBuilder: (context) => [
                  if (task.status == DownloadStatus.downloading)
                    const PopupMenuItem(
                        value: 'pause', child: Text('暂停下载')),
                  if (task.status == DownloadStatus.paused)
                    const PopupMenuItem(
                        value: 'resume', child: Text('继续下载')),
                  if (isFailed)
                    const PopupMenuItem(
                        value: 'retry', child: Text('重新下载')),
                  const PopupMenuItem(
                      value: 'delete',
                      child: Text('删除任务',
                          style: TextStyle(color: Colors.red))),
                ],
                icon: Icon(Icons.more_vert,
                    size: 20, color: iconColor),
              ),
            ],
          ),
          const SizedBox(height: 12),
          // 进度条
          ClipRRect(
            borderRadius: BorderRadius.circular(3),
            child: LinearProgressIndicator(
              value: task.progress > 0 ? task.progress : 0,
              backgroundColor: progressBgColor,
              valueColor:
                  AlwaysStoppedAnimation<Color>(_statusColor(task.status, isDark)),
              minHeight: 4,
            ),
          ),
          const SizedBox(height: 6),
          // 进度信息行：已下载/总大小 · 速度 · 剩余时间
          _buildProgressInfoRow(task, isDark, secondaryTextColor),
          const SizedBox(height: 10),
          // 底部操作按钮
          Row(
            children: [
              if (task.status == DownloadStatus.downloading) ...[
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => provider.pauseTask(task.id),
                    icon: const Icon(Icons.pause, size: 16),
                    label: const Text('暂停', style: TextStyle(fontSize: 12)),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      foregroundColor: buttonFgColor,
                      side: BorderSide(color: borderColor),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _showCancelDialog(task.id),
                    icon: const Icon(Icons.close, size: 16),
                    label: const Text('取消', style: TextStyle(fontSize: 12)),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      foregroundColor: Colors.red,
                      side: BorderSide(color: isDark ? Colors.red.shade800 : Colors.red.shade200),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                ),
              ] else if (task.status == DownloadStatus.paused) ...[
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => provider.resumeTask(task.id),
                    icon: const Icon(Icons.play_arrow, size: 16),
                    label: const Text('继续下载',
                        style: TextStyle(fontSize: 12)),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      foregroundColor: AppTheme.primaryColor,
                      side: BorderSide(color: AppTheme.primaryColor),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _showCancelDialog(task.id),
                    icon: const Icon(Icons.delete_outline, size: 16),
                    label: const Text('删除', style: TextStyle(fontSize: 12)),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      foregroundColor: Colors.red,
                      side: BorderSide(color: isDark ? Colors.red.shade800 : Colors.red.shade200),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                ),
              ] else if (isFailed) ...[
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => provider.resumeTask(task.id),
                    icon: const Icon(Icons.refresh, size: 16),
                    label: const Text('重新下载',
                        style: TextStyle(fontSize: 12)),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      foregroundColor: AppTheme.primaryColor,
                      side: BorderSide(color: AppTheme.primaryColor),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _showDeleteTaskDialog(task),
                    icon: const Icon(Icons.delete_outline, size: 16),
                    label: const Text('删除任务',
                        style: TextStyle(fontSize: 12)),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      foregroundColor: Colors.red,
                      side: BorderSide(color: isDark ? Colors.red.shade800 : Colors.red.shade200),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                ),
              ] else ...[
                // queued 状态
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _showCancelDialog(task.id),
                    icon: const Icon(Icons.close, size: 16),
                    label: const Text('取消等待',
                        style: TextStyle(fontSize: 12)),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      foregroundColor: buttonFgColor,
                      side: BorderSide(color: borderColor),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                ),
              ],
            ],
          ),
        ],
      ),
      ),
    );
  }

  /// 构建进度信息行：已下载/总大小 · 速度 · 剩余时间
  Widget _buildProgressInfoRow(DownloadTask task, bool isDark, Color secondaryTextColor) {
    final receivedText = DownloadManager.formatSize(task.receivedBytes);
    final totalText = task.totalBytes > 0 ? DownloadManager.formatSize(task.totalBytes) : '计算中';
    final sizeText = '已下载 $receivedText / $totalText';

    // 下载中状态：显示速度和剩余时间
    if (task.status == DownloadStatus.downloading) {
      final speedText = task.speedText.isNotEmpty ? task.speedText : '';
      final remainingText = task.remainingTimeText.isNotEmpty ? task.remainingTimeText : '';

      if (speedText.isNotEmpty && remainingText.isNotEmpty) {
        return Text(
          '$sizeText · $speedText · $remainingText',
          style: TextStyle(
            fontSize: 11,
            color: isDark ? Colors.blue.shade400 : Colors.blue.shade600,
            fontWeight: FontWeight.w500,
          ),
        );
      } else if (speedText.isNotEmpty) {
        return Text(
          '$sizeText · $speedText',
          style: TextStyle(
            fontSize: 11,
            color: isDark ? Colors.blue.shade400 : Colors.blue.shade600,
            fontWeight: FontWeight.w500,
          ),
        );
      }
      return Text(
        sizeText,
        style: TextStyle(
          fontSize: 11,
          color: secondaryTextColor,
        ),
      );
    }

    // 失败状态：显示错误信息
    if (task.status == DownloadStatus.failed && task.errorMessage != null) {
      return Text(
        '$sizeText · ${task.errorMessage!}',
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(
          fontSize: 11,
          color: Colors.red,
        ),
      );
    }

    // 其他状态：只显示大小
    return Text(
      sizeText,
      style: TextStyle(
        fontSize: 11,
        color: secondaryTextColor,
      ),
    );
  }

  Color _statusColor(DownloadStatus status, bool isDark) {
    switch (status) {
      case DownloadStatus.downloading:
        return isDark ? Colors.blue.shade400 : Colors.blue;
      case DownloadStatus.completed:
        return isDark ? Colors.green.shade400 : Colors.green;
      case DownloadStatus.failed:
        return isDark ? Colors.red.shade400 : Colors.red;
      case DownloadStatus.paused:
        return isDark ? Colors.orange.shade400 : Colors.orange;
      default:
        return isDark ? Colors.grey.shade400 : Colors.grey;
    }
  }

  Color _statusBgColor(DownloadStatus status, bool isDark) {
    final opacity = isDark ? 0.2 : 0.1;
    switch (status) {
      case DownloadStatus.downloading:
        return Colors.blue.withOpacity(opacity);
      case DownloadStatus.completed:
        return Colors.green.withOpacity(opacity);
      case DownloadStatus.failed:
        return Colors.red.withOpacity(opacity);
      case DownloadStatus.paused:
        return Colors.orange.withOpacity(opacity);
      default:
        return Colors.grey.withOpacity(opacity);
    }
  }

  Color _statusTextColor(DownloadStatus status, bool isDark) {
    switch (status) {
      case DownloadStatus.downloading:
        return isDark ? Colors.blue.shade400 : Colors.blue;
      case DownloadStatus.completed:
        return isDark ? Colors.green.shade400 : Colors.green;
      case DownloadStatus.failed:
        return isDark ? Colors.red.shade400 : Colors.red;
      case DownloadStatus.paused:
        return isDark ? Colors.orange.shade400 : Colors.orange;
      default:
        return isDark ? Colors.grey.shade400 : Colors.grey;
    }
  }

  void _handleTaskMenuAction(String action, DownloadTask task) {
    final provider = context.read<DownloadProvider>();
    switch (action) {
      case 'pause':
        provider.pauseTask(task.id);
        break;
      case 'resume':
      case 'retry':
        provider.resumeTask(task.id);
        break;
      case 'delete':
        _showDeleteTaskDialog(task);
        break;
    }
  }

  Widget _buildCompletedList() {
    return Consumer<DownloadProvider>(
      builder: (context, provider, child) {
        var completedTasks = provider.tasks
            .where((t) => t.status == DownloadStatus.completed)
            .toList();

        // 应用平台筛选
        if (_filterPlatform != null) {
          completedTasks = completedTasks
              .where((t) => t.platform == _filterPlatform)
              .toList();
        }

        // 应用类型筛选
        if (_filterType != null) {
          completedTasks = completedTasks
              .where((t) =>
                  _filterType == 'image' ? t.isImage : !t.isImage)
              .toList();
        }

        // 应用日期筛选
        if (_filterDateStart != null || _filterDateEnd != null) {
          completedTasks = completedTasks.where((t) {
            final date = t.completedAt ?? t.createdAt;
            if (_filterDateStart != null && date.isBefore(_filterDateStart!)) {
              return false;
            }
            if (_filterDateEnd != null) {
              // 包含结束日期的整天
              final endOfDay = DateTime(_filterDateEnd!.year, _filterDateEnd!.month, _filterDateEnd!.day, 23, 59, 59);
              if (date.isAfter(endOfDay)) {
                return false;
              }
            }
            return true;
          }).toList();
        }

        // 应用排序
        completedTasks = _applySorting(completedTasks);

        // 多选模式下同步已选ID（清理不存在的）
        if (_isMultiSelectMode) {
          final allIds = completedTasks.map((t) => t.id).toSet();
          _selectedTaskIds.removeWhere((id) => !allIds.contains(id));
        }

        return Column(
          children: [
            _buildFilterBar(completedTasks.length),
            Expanded(
              child: Stack(
                children: [
                  RefreshIndicator(
                    onRefresh: () async {
                      // 下载列表实时更新，下拉刷新仅做 UI 刷新
                      await Future.delayed(const Duration(milliseconds: 500));
                    },
                    child: completedTasks.isEmpty
                        ? ListView(
                            physics: const AlwaysScrollableScrollPhysics(),
                            children: [
                              SizedBox(
                                height: MediaQuery.of(context).size.height * 0.4,
                                child: EmptyState(
                                  iconData: Icons.filter_list_rounded,
                                  title: '没有匹配的记录',
                                  subtitle: '试试调整筛选条件',
                                ),
                              ),
                            ],
                          )
                        : ListView.separated(
                            controller: _completedScrollController,
                            padding: EdgeInsets.fromLTRB(16, 16, 16, _isMultiSelectMode ? 80 : 16),
                            physics: const AlwaysScrollableScrollPhysics(),
                            itemCount: completedTasks.length,
                            separatorBuilder: (_, __) => const SizedBox(height: 12),
                            itemBuilder: (context, index) {
                              final task = completedTasks[index];
                              return _buildCompletedItem(task);
                            },
                          ),
                  ),
                  // 多选底部操作栏
                  if (_isMultiSelectMode)
                    Positioned(
                      left: 0,
                      right: 0,
                      bottom: 0,
                      child: _buildMultiSelectBottomBar(),
                    ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }

  /// 应用排序规则
  List<DownloadTask> _applySorting(List<DownloadTask> tasks) {
    switch (_sortBy) {
      case 'date_asc':
        tasks.sort((a, b) => (a.completedAt ?? a.createdAt).compareTo(b.completedAt ?? b.createdAt));
        break;
      case 'size_desc':
        tasks.sort((a, b) => b.totalBytes.compareTo(a.totalBytes));
        break;
      case 'size_asc':
        tasks.sort((a, b) => a.totalBytes.compareTo(b.totalBytes));
        break;
      case 'title_asc':
        tasks.sort((a, b) => a.videoTitle.compareTo(b.videoTitle));
        break;
      case 'date_desc':
      default:
        tasks.sort((a, b) => (b.completedAt ?? b.createdAt).compareTo(a.completedAt ?? a.createdAt));
        break;
    }
    return tasks;
  }

  Widget _buildFilterBar(int resultCount) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final borderColor = isDark ? Colors.grey.shade700 : Colors.grey.shade200;
    final hasFilter = _filterPlatform != null ||
        _filterType != null ||
        _filterDatePreset != null ||
        _filterDateStart != null ||
        _filterDateEnd != null;

    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
      decoration: BoxDecoration(
        color: Theme.of(context).scaffoldBackgroundColor,
        border: Border(
          bottom: BorderSide(color: borderColor, width: 0.5),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      _buildFilterChip(
                        label: _platformLabel(_filterPlatform),
                        icon: Icons.apps,
                        isActive: _filterPlatform != null,
                        onTap: _showPlatformFilter,
                      ),
                      const SizedBox(width: 8),
                      _buildFilterChip(
                        label: _typeLabel(_filterType),
                        icon: Icons.category,
                        isActive: _filterType != null,
                        onTap: _showTypeFilter,
                      ),
                      const SizedBox(width: 8),
                      _buildFilterChip(
                        label: _datePresetLabel(),
                        icon: Icons.date_range,
                        isActive: _filterDatePreset != null || _filterDateStart != null,
                        onTap: _showDateFilter,
                      ),
                      const SizedBox(width: 8),
                      _buildFilterChip(
                        label: _sortLabel(),
                        icon: Icons.sort,
                        isActive: _sortBy != 'date_desc',
                        onTap: _showSortOptions,
                      ),
                    ],
                  ),
                ),
              ),
              if (hasFilter) ...[
                const SizedBox(width: 8),
                _buildClearFilterButton(),
              ],
            ],
          ),
          const SizedBox(height: 8),
          Text(
            '共 $resultCount 条记录',
            style: TextStyle(
              fontSize: 12,
              color: isDark ? Colors.grey.shade500 : Colors.grey.shade600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildClearFilterButton() {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      height: 32,
      decoration: BoxDecoration(
        color: Colors.red.withOpacity(isDark ? 0.15 : 0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.red.withOpacity(0.3)),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: _clearAllFilters,
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.close, size: 14, color: Colors.red.shade400),
                const SizedBox(width: 4),
                Text(
                  '清除筛选',
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.red.shade400,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _clearAllFilters() {
    setState(() {
      _filterPlatform = null;
      _filterType = null;
      _filterDateStart = null;
      _filterDateEnd = null;
      _filterDatePreset = null;
    });
  }

  String _datePresetLabel() {
    switch (_filterDatePreset) {
      case '7days': return '最近7天';
      case '30days': return '最近30天';
      case 'custom':
        if (_filterDateStart != null && _filterDateEnd != null) {
          return '${DateFormat('MM/dd').format(_filterDateStart!)}-${DateFormat('MM/dd').format(_filterDateEnd!)}';
        }
        return '自定义';
      default: return '全部时间';
    }
  }

  String _sortLabel() {
    switch (_sortBy) {
      case 'date_asc': return '时间升序';
      case 'size_desc': return '大小降序';
      case 'size_asc': return '大小升序';
      case 'title_asc': return '标题 A-Z';
      case 'date_desc':
      default: return '时间降序';
    }
  }

  Widget _buildFilterChip({
    required String label,
    required IconData icon,
    required bool isActive,
    required VoidCallback onTap,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final chipBgColor = isDark ? const Color(0xFF1E293B) : Colors.grey.shade100;
    final chipIconColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
    final chipTextColor = isDark ? Colors.grey.shade300 : Colors.grey.shade700;

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: isActive
              ? AppTheme.primaryColor.withOpacity(isDark ? 0.2 : 0.1)
              : chipBgColor,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isActive
                ? AppTheme.primaryColor.withOpacity(0.3)
                : Colors.transparent,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              size: 14,
              color: isActive ? AppTheme.primaryColor : chipIconColor,
            ),
            const SizedBox(width: 4),
            Text(
              label,
              style: TextStyle(
                fontSize: 12,
                color: isActive ? AppTheme.primaryColor : chipTextColor,
                fontWeight: isActive ? FontWeight.w600 : FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _platformLabel(String? platform) {
    switch (platform) {
      case 'douyin': return '抖音';
      case 'kuaishou': return '快手';
      default: return '全部平台';
    }
  }

  String _typeLabel(String? type) {
    switch (type) {
      case 'video': return '视频';
      case 'image': return '图文';
      default: return '全部类型';
    }
  }

  void _showPlatformFilter() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) {
        final options = [
          (null, '全部平台', Icons.all_inclusive),
          ('douyin', '抖音', Icons.music_video),
          ('kuaishou', '快手', Icons.slow_motion_video),
        ];
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 14),
                child: Text('选择平台', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
              ),
              const Divider(height: 1),
              ...options.map((o) {
                final isSelected = o.$1 == _filterPlatform;
                return ListTile(
                  leading: Icon(o.$3, color: isSelected ? AppTheme.primaryColor : null),
                  title: Text(o.$2),
                  trailing: isSelected
                      ? Icon(Icons.check_circle, color: AppTheme.primaryColor)
                      : null,
                  onTap: () {
                    setState(() => _filterPlatform = o.$1);
                    Navigator.pop(context);
                  },
                );
              }),
            ],
          ),
        );
      },
    );
  }

  void _showTypeFilter() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) {
        final options = [
          (null, '全部类型', Icons.all_inclusive),
          ('video', '视频', Icons.videocam),
          ('image', '图文', Icons.image),
        ];
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 14),
                child: Text('选择类型', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
              ),
              const Divider(height: 1),
              ...options.map((o) {
                final isSelected = o.$1 == _filterType;
                return ListTile(
                  leading: Icon(o.$3, color: isSelected ? AppTheme.primaryColor : null),
                  title: Text(o.$2),
                  trailing: isSelected
                      ? Icon(Icons.check_circle, color: AppTheme.primaryColor)
                      : null,
                  onTap: () {
                    setState(() => _filterType = o.$1);
                    Navigator.pop(context);
                  },
                );
              }),
            ],
          ),
        );
      },
    );
  }

  void _showDateFilter() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) {
        final options = [
          (null, '全部时间', Icons.all_inclusive),
          ('7days', '最近7天', Icons.filter_7),
          ('30days', '最近30天', Icons.filter_9_plus),
          ('custom', '自定义日期', Icons.date_range),
        ];
        return StatefulBuilder(
          builder: (context, setSheetState) {
            return SafeArea(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 14),
                    child: Center(
                      child: Text('选择日期范围', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                    ),
                  ),
                  const Divider(height: 1),
                  ...options.map((o) {
                    final isSelected = o.$1 == _filterDatePreset ||
                        (o.$1 == null && _filterDatePreset == null);
                    return ListTile(
                      leading: Icon(o.$3, color: isSelected ? AppTheme.primaryColor : null),
                      title: Text(o.$2),
                      trailing: isSelected
                          ? Icon(Icons.check_circle, color: AppTheme.primaryColor)
                          : null,
                      onTap: () async {
                        if (o.$1 == 'custom') {
                          Navigator.pop(context);
                          await _showDateRangePicker();
                        } else {
                          setState(() {
                            _filterDatePreset = o.$1;
                            if (o.$1 == '7days') {
                              _filterDateStart = DateTime.now().subtract(const Duration(days: 7));
                              _filterDateEnd = null;
                            } else if (o.$1 == '30days') {
                              _filterDateStart = DateTime.now().subtract(const Duration(days: 30));
                              _filterDateEnd = null;
                            } else {
                              _filterDateStart = null;
                              _filterDateEnd = null;
                            }
                          });
                          Navigator.pop(context);
                        }
                      },
                    );
                  }),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Future<void> _showDateRangePicker() async {
    final now = DateTime.now();
    final initialStart = _filterDateStart ?? now.subtract(const Duration(days: 7));
    final initialEnd = _filterDateEnd ?? now;

    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: now,
      initialDateRange: DateTimeRange(
        start: initialStart,
        end: initialEnd,
      ),
      helpText: '选择日期范围',
      cancelText: '取消',
      confirmText: '确定',
      saveText: '确定',
    );

    if (picked != null) {
      setState(() {
        _filterDatePreset = 'custom';
        _filterDateStart = picked.start;
        _filterDateEnd = picked.end;
      });
    }
  }

  void _showSortOptions() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) {
        final options = [
          ('date_desc', '按下载时间降序', Icons.arrow_downward),
          ('date_asc', '按下载时间升序', Icons.arrow_upward),
          ('size_desc', '按文件大小降序', Icons.download_done),
          ('size_asc', '按文件大小升序', Icons.upload),
          ('title_asc', '按标题 A-Z', Icons.sort_by_alpha),
        ];
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 14),
                child: Text('排序方式', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
              ),
              const Divider(height: 1),
              ...options.map((o) {
                final isSelected = o.$1 == _sortBy;
                return ListTile(
                  leading: Icon(o.$3, color: isSelected ? AppTheme.primaryColor : null),
                  title: Text(o.$2),
                  trailing: isSelected
                      ? Icon(Icons.check_circle, color: AppTheme.primaryColor)
                      : null,
                  onTap: () {
                    setState(() => _sortBy = o.$1);
                    Navigator.pop(context);
                  },
                );
              }),
            ],
          ),
        );
      },
    );
  }

  Widget _buildCompletedItem(DownloadTask task) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isSelected = _selectedTaskIds.contains(task.id);

    // 多选模式下不显示左滑操作
    if (_isMultiSelectMode) {
      return _buildCompletedItemContent(task, isDark, isSelected);
    }

    return SlideActionItem(
      actions: [
        SlideAction(
          icon: Icons.delete_outline,
          label: '删除',
          color: Colors.red,
          onTap: () => _deleteCompletedTaskWithUndo(task),
        ),
        SlideAction(
          icon: Icons.share_outlined,
          label: '分享',
          color: Colors.blue,
          onTap: () => _shareFile(task),
        ),
      ],
      child: _buildCompletedItemContent(task, isDark, isSelected),
    );
  }

  Widget _buildCompletedItemContent(DownloadTask task, bool isDark, bool isSelected) {
    final coverBgColor = isDark ? const Color(0xFF1E293B) : Colors.grey.shade100;
    final iconColor = isDark ? Colors.grey.shade400 : Colors.grey.shade500;
    final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
    final playBtnBgColor = isDark ? Colors.black54 : Colors.black45;

    return InkWell(
      onTap: _isMultiSelectMode
          ? () => _toggleTaskSelection(task.id)
          : () => _openVideo(task),
      onLongPress: _isMultiSelectMode
          ? null
          : () {
              // 长按进入多选模式并选中当前项
              setState(() {
                _isMultiSelectMode = true;
                _selectedTaskIds.add(task.id);
              });
            },
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: isSelected
              ? AppTheme.primaryColor.withOpacity(isDark ? 0.1 : 0.05)
              : Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(14),
          border: isSelected
              ? Border.all(color: AppTheme.primaryColor.withOpacity(0.3), width: 1.5)
              : null,
          boxShadow: isDark
              ? []
              : [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.04),
                    blurRadius: 10,
                    offset: const Offset(0, 2),
                  ),
                ],
        ),
        child: Row(
          children: [
            if (_isMultiSelectMode) ...[
              Container(
                width: 24,
                height: 24,
                margin: const EdgeInsets.only(right: 10),
                decoration: BoxDecoration(
                  color: isSelected ? AppTheme.primaryColor : Colors.transparent,
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: isSelected ? AppTheme.primaryColor : (isDark ? Colors.grey.shade600 : Colors.grey.shade400),
                    width: 2,
                  ),
                ),
                child: isSelected
                    ? const Icon(Icons.check, size: 14, color: Colors.white)
                    : null,
              ),
            ],
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Container(
                width: 52,
                height: 52,
                color: coverBgColor,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    if (task.videoCover.isNotEmpty)
                      Image.network(task.videoCover, fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) =>
                              Icon(Icons.videocam,
                                  size: 24, color: iconColor)),
                    if (task.videoCover.isEmpty)
                      Center(
                          child: Icon(Icons.videocam,
                              size: 24, color: iconColor)),
                    Center(
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          color: playBtnBgColor,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: const Icon(Icons.play_arrow,
                            color: Colors.white, size: 14),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    task.videoTitle,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: Colors.green.withOpacity(isDark ? 0.2 : 0.1),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          '已完成',
                          style: TextStyle(
                              fontSize: 10,
                              color: isDark ? Colors.green.shade400 : Colors.green,
                              fontWeight: FontWeight.w600),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        DownloadManager.formatSize(task.totalBytes),
                        style: TextStyle(
                            fontSize: 11, color: secondaryTextColor),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          _formatDateTime(task.completedAt ?? task.createdAt),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              fontSize: 11, color: secondaryTextColor),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            // 更多操作（多选模式下隐藏）
            if (!_isMultiSelectMode)
              PopupMenuButton<String>(
                onSelected: (value) => _handleCompletedMenuAction(value, task),
                itemBuilder: (context) => [
                  const PopupMenuItem(value: 'play', child: Text('播放')),
                  const PopupMenuItem(value: 'share', child: Text('分享')),
                  if (!task.isImage) ...[
                    const PopupMenuItem(value: 'extractAudio', child: Text('提取音频')),
                    const PopupMenuItem(value: 'transcode', child: Text('格式转码')),
                    const PopupMenuItem(value: 'extractSubtitle', child: Text('提取字幕')),
                  ],
                  const PopupMenuItem(
                      value: 'delete',
                      child: Text('删除', style: TextStyle(color: Colors.red))),
                ],
                icon:
                    Icon(Icons.more_vert, size: 20, color: iconColor),
              ),
          ],
        ),
      ),
    );
  }

  String _formatDateTime(DateTime dt) {
    final now = DateTime.now();
    final diff = now.difference(dt);
    if (diff.inDays == 0) {
      return '今天 ${DateFormat('HH:mm').format(dt)}';
    } else if (diff.inDays == 1) {
      return '昨天 ${DateFormat('HH:mm').format(dt)}';
    } else if (diff.inDays < 7) {
      return '${diff.inDays}天前';
    } else {
      return DateFormat('yyyy-MM-dd').format(dt);
    }
  }

  /// 删除任务并显示撤销提示
  void _deleteTaskWithUndo(DownloadTask task) {
    final provider = context.read<DownloadProvider>();
    provider.removeTask(task.id, deleteFile: false);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('已删除 1 条记录'),
        action: SnackBarAction(
          label: '撤销',
          onPressed: () {
            provider.undoLastRemove();
          },
        ),
        duration: const Duration(seconds: 3),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  /// 删除已完成任务并显示撤销提示
  void _deleteCompletedTaskWithUndo(DownloadTask task) {
    final provider = context.read<DownloadProvider>();
    provider.removeTask(task.id, deleteFile: false);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('已删除 1 条记录'),
        action: SnackBarAction(
          label: '撤销',
          onPressed: () {
            provider.undoLastRemove();
          },
        ),
        duration: const Duration(seconds: 3),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _handleCompletedMenuAction(String action, DownloadTask task) {
    switch (action) {
      case 'play':
        _openVideo(task);
        break;
      case 'share':
        _shareFile(task);
        break;
      case 'extractAudio':
        _showExtractAudioDialog(task);
        break;
      case 'transcode':
        _showTranscodeDialog(task);
        break;
      case 'extractSubtitle':
        _showExtractSubtitleDialog(task);
        break;
      case 'delete':
        _showDeleteDialog(task);
        break;
    }
  }

  Future<void> _clearCompleted() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('清理已完成'),
        content: const Text('确定要清理所有已完成的下载记录吗？\n（不会删除本地文件）'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            child:
                const Text('确定', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
    if (confirm == true && mounted) {
      context.read<DownloadProvider>().clearCompleted();
    }
  }

  /// 获取文件的 MIME 类型
  String _getMimeType(String fileName) {
    final lower = fileName.toLowerCase();
    if (lower.endsWith('.mp4')) return 'video/mp4';
    if (lower.endsWith('.mov')) return 'video/quicktime';
    if (lower.endsWith('.avi')) return 'video/x-msvideo';
    if (lower.endsWith('.mkv')) return 'video/x-matroska';
    if (lower.endsWith('.webm')) return 'video/webm';
    if (lower.endsWith('.jpg') || lower.endsWith('.jpeg')) return 'image/jpeg';
    if (lower.endsWith('.png')) return 'image/png';
    if (lower.endsWith('.gif')) return 'image/gif';
    if (lower.endsWith('.webp')) return 'image/webp';
    if (lower.endsWith('.bmp')) return 'image/bmp';
    // 默认按视频处理
    return 'video/*';
  }

  /// Android 上将文件复制到 cache 目录（FileProvider 一定授权），
  /// 避免 DCIM/Download 等外部目录因路径不在授权范围内而分享/打开失败
  Future<String> _ensureShareablePath(String filePath, String fileName) async {
    if (!Platform.isAndroid) return filePath;
    try {
      final cacheDir = await getTemporaryDirectory();
      final shareFile = File('${cacheDir.path}/$fileName');
      // 如果已经在 cache 目录就直接返回
      if (filePath.startsWith(cacheDir.path)) return filePath;
      // 复制到 cache 目录
      await File(filePath).copy(shareFile.path);
      return shareFile.path;
    } catch (_) {
      // 复制失败时用原路径尝试
      return filePath;
    }
  }

  Future<void> _openVideo(DownloadTask task) async {
    try {
      // 先检查文件是否存在
      final file = File(task.savePath);
      if (!await file.exists()) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('文件不存在：${task.fileName}')),
          );
        }
        return;
      }
      // Android 上确保路径可被其他应用访问
      final openPath = await _ensureShareablePath(task.savePath, task.fileName);
      final mimeType = _getMimeType(task.fileName);
      final result = await OpenFilex.open(
        openPath,
        type: mimeType,
      );
      if (result.type != ResultType.done && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('无法打开：${result.message ?? '未找到可用的播放器'}')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('打开失败：${e.toString()}')),
        );
      }
    }
  }

  Future<void> _shareFile(DownloadTask task) async {
    try {
      final file = File(task.savePath);
      if (!await file.exists()) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('文件不存在，无法分享')),
          );
        }
        return;
      }
      final mimeType = _getMimeType(task.fileName);
      // 直接使用 shareXFiles API，share_plus 内部会自动处理 FileProvider 和文件复制
      // 不需要手动复制到 cache 目录（之前的 _ensureShareablePath 是多余的，
      // 双重复制反而可能导致失败和性能问题）
      await Share.shareXFiles(
        [XFile(task.savePath, mimeType: mimeType)],
        text: task.videoTitle,
      );
    } catch (e) {
      debugPrint('分享失败: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('分享失败：${e.toString()}')),
        );
      }
    }
  }

  Future<bool?> _showDeleteDialog(DownloadTask task) async {
    return showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('删除下载'),
        content: const Text('是否同时删除本地视频文件？'),
        actions: [
          TextButton(
            onPressed: () {
              context.read<DownloadProvider>().removeTask(task.id, deleteFile: false);
              Navigator.of(context).pop();
            },
            child: const Text('仅移除记录'),
          ),
          TextButton(
            onPressed: () {
              context.read<DownloadProvider>().removeTask(task.id, deleteFile: true);
              Navigator.of(context).pop();
            },
            child: const Text('删除文件', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  Future<bool?> _showDeleteTaskDialog(DownloadTask task) async {
    return showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('删除任务'),
        content: const Text('确定要删除这个下载任务吗？'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () {
              context.read<DownloadProvider>().removeTask(task.id, deleteFile: false);
              Navigator.of(context).pop();
            },
            child: const Text('删除', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  Future<bool?> _showCancelDialog(String taskId) async {
    return showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('取消下载'),
        content: const Text('确定要取消这个下载任务吗？'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('继续下载'),
          ),
          TextButton(
            onPressed: () {
              context.read<DownloadProvider>().cancelTask(taskId);
              Navigator.of(context).pop(true);
            },
            child: const Text('取消下载', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  // ========== 提取音频 ==========

  Future<void> _showExtractAudioDialog(DownloadTask task) async {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade500;

    final formats = [
      ('mp3', 'MP3', '兼容性最好'),
      ('aac', 'AAC', '音质更好，体积更小'),
      ('m4a', 'M4A', '苹果设备推荐'),
    ];

    String selectedFormat = 'mp3';

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('提取音频'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '选择输出格式：',
                style: TextStyle(fontSize: 13, color: secondaryTextColor),
              ),
              const SizedBox(height: 8),
              ...formats.map((f) {
                final isSelected = f.$1 == selectedFormat;
                return ListTile(
                  title: Text(f.$2),
                  subtitle: Text(f.$3, style: TextStyle(fontSize: 12, color: secondaryTextColor)),
                  trailing: isSelected
                      ? Icon(Icons.check_circle, color: AppTheme.primaryColor)
                      : const SizedBox.shrink(),
                  onTap: () {
                    setDialogState(() {
                      selectedFormat = f.$1;
                    });
                  },
                );
              }).toList(),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('取消'),
            ),
            TextButton(
              onPressed: () async {
                Navigator.of(context).pop();
                await _extractAudio(task, selectedFormat);
              },
              child: const Text('开始提取'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _extractAudio(DownloadTask task, String format) async {
    final provider = context.read<DownloadProvider>();

    try {
      // 输出到与视频同一目录
      final outputDir = task.savePath.substring(0, task.savePath.lastIndexOf('/'));
      final outputPath = await provider.extractAudio(
        videoPath: task.savePath,
        outputDir: outputDir,
        audioFormat: format,
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('音频提取成功：${outputPath.split('/').last}')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('提取失败：${e.toString()}')),
        );
      }
    }
  }

  // ========== 格式转码 ==========

  Future<void> _showTranscodeDialog(DownloadTask task) async {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade500;

    final videoFormats = ['mp4', 'mov', 'mkv', 'avi'];
    final audioFormats = ['mp3', 'aac', 'm4a', 'wav'];

    String transcodeType = 'video'; // video / audio / compress
    String selectedFormat = 'mp4';
    String selectedResolution = '720p';

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) {
          final isVideoType = transcodeType == 'video';
          final isAudioType = transcodeType == 'audio';
          final isCompressType = transcodeType == 'videoCompress';

          return AlertDialog(
            title: const Text('格式转码'),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // 转码类型选择
                  Text('转码类型', style: TextStyle(fontSize: 13, color: secondaryTextColor)),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () => setDialogState(() {
                            transcodeType = 'video';
                            selectedFormat = 'mp4';
                          }),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: isVideoType ? AppTheme.primaryColor : null,
                            side: BorderSide(
                              color: isVideoType ? AppTheme.primaryColor : Colors.grey.shade300,
                            ),
                          ),
                          child: const Text('视频转换', style: TextStyle(fontSize: 12)),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () => setDialogState(() {
                            transcodeType = 'audio';
                            selectedFormat = 'mp3';
                          }),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: isAudioType ? AppTheme.primaryColor : null,
                            side: BorderSide(
                              color: isAudioType ? AppTheme.primaryColor : Colors.grey.shade300,
                            ),
                          ),
                          child: const Text('音频提取', style: TextStyle(fontSize: 12)),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton(
                      onPressed: () => setDialogState(() {
                        transcodeType = 'videoCompress';
                        selectedFormat = 'mp4';
                      }),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: isCompressType ? AppTheme.primaryColor : null,
                        side: BorderSide(
                          color: isCompressType ? AppTheme.primaryColor : Colors.grey.shade300,
                        ),
                      ),
                      child: const Text('视频压缩', style: TextStyle(fontSize: 12)),
                    ),
                  ),
                  const SizedBox(height: 16),
                  // 目标格式
                  Text('目标格式', style: TextStyle(fontSize: 13, color: secondaryTextColor)),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: (isAudioType ? audioFormats : videoFormats).map((f) {
                      final isSelected = f == selectedFormat;
                      return ChoiceChip(
                        label: Text(f.toUpperCase(), style: const TextStyle(fontSize: 12)),
                        selected: isSelected,
                        onSelected: (_) => setDialogState(() {
                          selectedFormat = f;
                        }),
                        selectedColor: AppTheme.primaryColor.withOpacity(0.15),
                      );
                    }).toList(),
                  ),
                  // 视频压缩的分辨率选项
                  if (isCompressType) ...[
                    const SizedBox(height: 16),
                    Text('分辨率', style: TextStyle(fontSize: 13, color: secondaryTextColor)),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: ['original', '720p', '480p', '360p'].map((r) {
                        final isSelected = r == selectedResolution;
                        return ChoiceChip(
                          label: Text(r == 'original' ? '原分辨率' : r,
                              style: const TextStyle(fontSize: 12)),
                          selected: isSelected,
                          onSelected: (_) => setDialogState(() {
                            selectedResolution = r;
                          }),
                          selectedColor: AppTheme.primaryColor.withOpacity(0.15),
                        );
                      }).toList(),
                    ),
                  ],
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('取消'),
              ),
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                  _startTranscode(task, transcodeType, selectedFormat, selectedResolution);
                },
                child: const Text('开始转码'),
              ),
            ],
          );
        },
      ),
    );
  }

  Future<void> _startTranscode(
    DownloadTask task,
    String transcodeType,
    String targetFormat,
    String resolution,
  ) async {
    final transcodeProvider = context.read<TranscodeProvider>();

    try {
      // 输出到与视频同一目录
      final outputDir = task.savePath.substring(0, task.savePath.lastIndexOf('/'));

      if (transcodeType == 'video') {
        await transcodeProvider.createVideoConvertTask(
          sourcePath: task.savePath,
          outputDir: outputDir,
          targetFormat: targetFormat,
          videoCover: task.videoCover,
          videoTitle: task.videoTitle,
        );
      } else if (transcodeType == 'audio') {
        await transcodeProvider.createAudioConvertTask(
          sourcePath: task.savePath,
          outputDir: outputDir,
          targetFormat: targetFormat,
          videoCover: task.videoCover,
          videoTitle: task.videoTitle,
        );
      } else if (transcodeType == 'videoCompress') {
        await transcodeProvider.createVideoCompressTask(
          sourcePath: task.savePath,
          outputDir: outputDir,
          targetFormat: targetFormat,
          resolution: resolution,
          videoCover: task.videoCover,
          videoTitle: task.videoTitle,
        );
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('已添加转码任务：${task.videoTitle}')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('添加转码任务失败：${e.toString()}')),
        );
      }
    }
  }

  // ========== 提取字幕 ==========

  Future<void> _showExtractSubtitleDialog(DownloadTask task) async {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade500;

    final formats = [
      ('srt', 'SRT', '最通用的字幕格式'),
      ('vtt', 'VTT', 'WebVTT 格式，适合网页使用'),
    ];

    String selectedFormat = 'srt';

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('提取字幕'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '选择字幕格式：',
                style: TextStyle(fontSize: 13, color: secondaryTextColor),
              ),
              const SizedBox(height: 8),
              ...formats.map((f) {
                final isSelected = f.$1 == selectedFormat;
                return ListTile(
                  title: Text(f.$2),
                  subtitle: Text(f.$3, style: TextStyle(fontSize: 12, color: secondaryTextColor)),
                  trailing: isSelected
                      ? Icon(Icons.check_circle, color: AppTheme.primaryColor)
                      : const SizedBox.shrink(),
                  onTap: () {
                    setDialogState(() {
                      selectedFormat = f.$1;
                    });
                  },
                );
              }).toList(),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.orange.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    Icon(Icons.info_outline, size: 16, color: Colors.orange.shade700),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        '短视频通常没有内嵌字幕，若未检测到字幕将生成说明文件',
                        style: TextStyle(fontSize: 11, color: Colors.orange.shade700),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('取消'),
            ),
            TextButton(
              onPressed: () async {
                Navigator.of(context).pop();
                await _extractSubtitle(task, selectedFormat);
              },
              child: const Text('开始提取'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _extractSubtitle(DownloadTask task, String format) async {
    final subtitleService = SubtitleService();

    try {
      // 输出到与视频同一目录
      final outputDir = task.savePath.substring(0, task.savePath.lastIndexOf('/'));
      final result = await subtitleService.extractSubtitles(
        videoPath: task.savePath,
        outputDir: outputDir,
        format: SubtitleService.parseFormat(format),
      );

      if (mounted) {
        final message = result.isPlaceholder
            ? '未检测到内嵌字幕，已生成说明文件'
            : '字幕提取成功：${result.outputPath!.split('/').last}';
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(message)),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('提取失败：${e.toString()}')),
        );
      }
    }
  }

  // ========== 多选模式 ==========

  void _toggleMultiSelectMode() {
    setState(() {
      _isMultiSelectMode = !_isMultiSelectMode;
      if (!_isMultiSelectMode) {
        _selectedTaskIds.clear();
      }
    });
  }

  void _toggleTaskSelection(String taskId) {
    setState(() {
      if (_selectedTaskIds.contains(taskId)) {
        _selectedTaskIds.remove(taskId);
        if (_selectedTaskIds.isEmpty) {
          _isMultiSelectMode = false;
        }
      } else {
        _selectedTaskIds.add(taskId);
      }
    });
  }

  void _selectAllCurrentTab() {
    if (_tabController.index == 0) {
      _selectAllDownloading();
    } else {
      _selectAllCompleted();
    }
  }

  void _selectAllDownloading() {
    final provider = context.read<DownloadProvider>();
    final activeTasks = provider.tasks
        .where((t) =>
            t.status == DownloadStatus.downloading ||
            t.status == DownloadStatus.queued ||
            t.status == DownloadStatus.paused ||
            t.status == DownloadStatus.failed)
        .toList();
    setState(() {
      final allIds = activeTasks.map((t) => t.id).toSet();
      if (_selectedTaskIds.length == allIds.length && allIds.isNotEmpty) {
        _selectedTaskIds.clear();
      } else {
        _selectedTaskIds = allIds;
      }
    });
  }

  void _selectAllCompleted() {
    final provider = context.read<DownloadProvider>();
    var completedTasks = provider.tasks
        .where((t) => t.status == DownloadStatus.completed);
    if (_filterPlatform != null) {
      completedTasks = completedTasks.where((t) => t.platform == _filterPlatform);
    }
    if (_filterType != null) {
      completedTasks = completedTasks.where((t) =>
          _filterType == 'image' ? t.isImage : !t.isImage);
    }
    if (_filterDateStart != null || _filterDateEnd != null) {
      completedTasks = completedTasks.where((t) {
        final date = t.completedAt ?? t.createdAt;
        if (_filterDateStart != null && date.isBefore(_filterDateStart!)) {
          return false;
        }
        if (_filterDateEnd != null) {
          final endOfDay = DateTime(_filterDateEnd!.year, _filterDateEnd!.month, _filterDateEnd!.day, 23, 59, 59);
          if (date.isAfter(endOfDay)) {
            return false;
          }
        }
        return true;
      });
    }
    setState(() {
      final allIds = completedTasks.map((t) => t.id).toSet();
      if (_selectedTaskIds.length == allIds.length && allIds.isNotEmpty) {
        _selectedTaskIds.clear();
      } else {
        _selectedTaskIds = allIds;
      }
    });
  }

  Future<void> _deleteSelected() async {
    if (_selectedTaskIds.isEmpty) return;

    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('删除选中 (${_selectedTaskIds.length})'),
        content: const Text('是否同时删除本地文件？'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop(false);
            },
            child: const Text('仅移除记录'),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop(true);
            },
            child: const Text('删除文件', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirm == null) return;

    final provider = context.read<DownloadProvider>();
    for (final id in _selectedTaskIds) {
      provider.removeTask(id, deleteFile: confirm);
    }
    setState(() {
      _selectedTaskIds.clear();
      _isMultiSelectMode = false;
    });
  }

  /// 批量暂停选中的下载任务
  void _pauseSelected() {
    if (_selectedTaskIds.isEmpty) return;
    final provider = context.read<DownloadProvider>();
    for (final id in _selectedTaskIds) {
      provider.pauseTask(id);
    }
  }

  /// 批量开始/重试选中的下载任务
  void _resumeSelected() {
    if (_selectedTaskIds.isEmpty) return;
    final provider = context.read<DownloadProvider>();
    for (final id in _selectedTaskIds) {
      provider.resumeTask(id);
    }
  }

  /// 删除选中的下载中任务
  Future<void> _deleteSelectedDownloading() async {
    if (_selectedTaskIds.isEmpty) return;

    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('删除选中 (${_selectedTaskIds.length})'),
        content: const Text('确定要删除选中的下载任务吗？'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop(true);
            },
            child: const Text('删除', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    final provider = context.read<DownloadProvider>();
    for (final id in _selectedTaskIds) {
      provider.removeTask(id, deleteFile: false);
    }
    setState(() {
      _selectedTaskIds.clear();
      _isMultiSelectMode = false;
    });
  }

  Future<void> _shareSelected() async {
    if (_selectedTaskIds.isEmpty) return;

    final provider = context.read<DownloadProvider>();
    final selectedTasks = provider.tasks
        .where((t) => _selectedTaskIds.contains(t.id))
        .toList();

    final files = <XFile>[];
    for (final task in selectedTasks) {
      final file = File(task.savePath);
      if (await file.exists()) {
        files.add(XFile(task.savePath, mimeType: _getMimeType(task.fileName)));
      }
    }

    if (files.isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('文件不存在，无法分享')),
        );
      }
      return;
    }

    try {
      await Share.shareXFiles(
        files,
        text: '分享 ${files.length} 个文件',
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('分享失败：${e.toString()}')),
        );
      }
    }
  }

  Widget _buildDownloadingMultiSelectBottomBar() {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final hasSelection = _selectedTaskIds.isNotEmpty;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF1E293B) : Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            Expanded(
              child: _buildBottomActionButton(
                icon: Icons.play_arrow_outlined,
                label: '开始',
                color: AppTheme.successColor,
                onTap: hasSelection ? _resumeSelected : null,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _buildBottomActionButton(
                icon: Icons.pause_outlined,
                label: '暂停',
                color: Colors.orange,
                onTap: hasSelection ? _pauseSelected : null,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _buildBottomActionButton(
                icon: Icons.delete_outline,
                label: '删除',
                color: Colors.red,
                onTap: hasSelection ? _deleteSelectedDownloading : null,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMultiSelectBottomBar() {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final hasSelection = _selectedTaskIds.isNotEmpty;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF1E293B) : Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            Expanded(
              child: _buildBottomActionButton(
                icon: Icons.delete_outline,
                label: '删除',
                color: Colors.red,
                onTap: hasSelection ? _deleteSelected : null,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _buildBottomActionButton(
                icon: Icons.file_download_outlined,
                label: '导出',
                color: AppTheme.primaryColor,
                onTap: hasSelection ? _exportSelected : null,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _buildBottomActionButton(
                icon: Icons.share_outlined,
                label: '分享',
                color: Colors.blue,
                onTap: hasSelection ? _shareSelected : null,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBottomActionButton({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback? onTap,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isEnabled = onTap != null;

    return Material(
      color: isDark ? Colors.grey.shade800 : Colors.grey.shade100,
      borderRadius: BorderRadius.circular(10),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 10),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                icon,
                size: 20,
                color: isEnabled ? color : Colors.grey.shade400,
              ),
              const SizedBox(height: 4),
              Text(
                label,
                style: TextStyle(
                  fontSize: 11,
                  color: isEnabled ? color : Colors.grey.shade400,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ========== 导出功能 ==========

  /// 生成带时间戳的导出文件名
  String _exportFileName(String prefix, String ext) {
    final now = DateTime.now();
    String two(int n) => n.toString().padLeft(2, '0');
    final stamp =
        '${now.year}${two(now.month)}${two(now.day)}_${two(now.hour)}${two(now.minute)}${two(now.second)}';
    return '${prefix}_$stamp.$ext';
  }

  Future<void> _exportCompletedTasks() async {
    final provider = context.read<DownloadProvider>();
    var completedTasks = provider.tasks
        .where((t) => t.status == DownloadStatus.completed)
        .toList();

    // 应用当前筛选
    if (_filterPlatform != null) {
      completedTasks = completedTasks
          .where((t) => t.platform == _filterPlatform)
          .toList();
    }
    if (_filterType != null) {
      completedTasks = completedTasks
          .where((t) => _filterType == 'image' ? t.isImage : !t.isImage)
          .toList();
    }
    if (_filterDateStart != null || _filterDateEnd != null) {
      completedTasks = completedTasks.where((t) {
        final date = t.completedAt ?? t.createdAt;
        if (_filterDateStart != null && date.isBefore(_filterDateStart!)) {
          return false;
        }
        if (_filterDateEnd != null) {
          final endOfDay = DateTime(_filterDateEnd!.year, _filterDateEnd!.month, _filterDateEnd!.day, 23, 59, 59);
          if (date.isAfter(endOfDay)) {
            return false;
          }
        }
        return true;
      }).toList();
    }

    if (completedTasks.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('没有可导出的记录')),
      );
      return;
    }

    await _exportTasksToExcel(completedTasks, 'download_records_${completedTasks.length}');
  }

  Future<void> _exportSelected() async {
    if (_selectedTaskIds.isEmpty) return;

    final provider = context.read<DownloadProvider>();
    final selectedTasks = provider.tasks
        .where((t) => _selectedTaskIds.contains(t.id) && t.status == DownloadStatus.completed)
        .toList();

    if (selectedTasks.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('没有可导出的记录')),
      );
      return;
    }

    await _exportTasksToExcel(selectedTasks, 'selected_downloads_${selectedTasks.length}');
  }

  Future<void> _exportTasksToExcel(List<DownloadTask> tasks, String prefix) async {
    try {
      final book = excel.Excel.createExcel();
      // 直接使用默认工作表
      final sheet = book.sheets.values.first;

      // 表头
      final headers = [
        '序号', '标题', '平台', '类型', '文件大小', '下载时间', '保存路径', '时长',
      ];
      for (int i = 0; i < headers.length; i++) {
        sheet.cell(excel.CellIndex.indexByColumnRow(columnIndex: i, rowIndex: 0)).value =
            excel.TextCellValue(headers[i]);
      }

      // 数据行
      for (int i = 0; i < tasks.length; i++) {
        final task = tasks[i];
        final row = [
          (i + 1).toString(),
          task.videoTitle,
          _platformLabel(task.platform),
          task.isImage ? '图片' : '视频',
          DownloadManager.formatSize(task.totalBytes),
          task.completedAt != null
              ? DateFormat('yyyy-MM-dd HH:mm:ss').format(task.completedAt!)
              : DateFormat('yyyy-MM-dd HH:mm:ss').format(task.createdAt),
          task.savePath,
          task.isAudioOnly ? '纯音频' : '-',
        ];
        for (int j = 0; j < row.length; j++) {
          sheet.cell(excel.CellIndex.indexByColumnRow(columnIndex: j, rowIndex: i + 1)).value =
              excel.TextCellValue(row[j].toString());
        }
      }

      // 设置列宽
      try {
        final colWidths = [6.0, 40.0, 10.0, 8.0, 12.0, 20.0, 50.0, 10.0];
        for (var i = 0; i < colWidths.length; i++) {
          sheet.setColumnWidth(i, colWidths[i]);
        }
      } catch (_) {}

      // 生成文件
      final bytes = book.save();
      if (bytes == null) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('生成 Excel 文件失败')),
          );
        }
        return;
      }
      final uint8Bytes = Uint8List.fromList(bytes);

      await _saveAndShowExportedFile(
        fileName: _exportFileName(prefix, 'xlsx'),
        bytes: uint8Bytes,
        mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('导出失败：${e.toString().replaceAll('Exception: ', '')}')),
        );
      }
    }
  }

  /// 保存导出文件并弹窗展示
  Future<void> _saveAndShowExportedFile({
    required String fileName,
    required Uint8List bytes,
    required String mimeType,
  }) async {
    String? savedPath;
    String? savedDesc;

    // 1. 公共 Download 目录
    if (Platform.isAndroid) {
      try {
        try {
          final ps = await Permission.storage.status;
          if (!ps.isGranted) {
            await Permission.storage.request();
          }
        } catch (_) {}

        final dir = Directory('/storage/emulated/0/Download');
        if (await dir.exists()) {
          final file = File('${dir.path}/$fileName');
          await file.writeAsBytes(bytes);
          if (await file.exists() && await file.length() == bytes.length) {
            savedPath = file.path;
            savedDesc = 'Download/$fileName';
          }
        }
      } catch (_) {}
    }

    // 2. Android 11+：SAF 系统保存对话框
    if (savedPath == null && Platform.isAndroid) {
      try {
        final pickedPath = await FilePicker.platform.saveFile(
          fileName: fileName,
          bytes: bytes,
        );
        if (pickedPath != null && pickedPath.isNotEmpty) {
          savedPath = pickedPath;
          savedDesc = pickedPath;
        }
      } catch (_) {}
    }

    // 3. 应用外部文件目录 / 文档目录
    if (savedPath == null) {
      try {
        final Directory? dir = Platform.isAndroid
            ? await getExternalStorageDirectory()
            : await getApplicationDocumentsDirectory();
        if (dir != null) {
          if (!await dir.exists()) {
            await dir.create(recursive: true);
          }
          final file = File('${dir.path}/$fileName');
          await file.writeAsBytes(bytes);
          if (await file.exists() && await file.length() == bytes.length) {
            savedPath = file.path;
            savedDesc = file.path;
          }
        }
      } catch (_) {}
    }

    // 4. 临时目录最终兜底
    if (savedPath == null) {
      try {
        final dir = await getTemporaryDirectory();
        final file = File('${dir.path}/$fileName');
        await file.writeAsBytes(bytes);
        savedPath = file.path;
        savedDesc = file.path;
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('导出失败：文件写入异常（${e.toString()}）')),
          );
        }
        return;
      }
    }

    if (!mounted) return;
    _showExportedDialog(
      fileName: fileName,
      savedPath: savedPath,
      savedDesc: savedDesc ?? savedPath,
      mimeType: mimeType,
    );
  }

  /// 导出成功弹窗
  void _showExportedDialog({
    required String fileName,
    required String savedPath,
    required String savedDesc,
    required String mimeType,
  }) {
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.check_circle, color: Colors.green, size: 22),
            SizedBox(width: 8),
            Text('导出成功', style: TextStyle(fontSize: 17)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('文件已保存到：', style: TextStyle(fontSize: 13)),
            const SizedBox(height: 8),
            Container(
              width: double.maxFinite,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.grey.shade100,
                borderRadius: BorderRadius.circular(8),
              ),
              child: SelectableText(
                savedDesc,
                style: const TextStyle(fontSize: 12),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('关闭'),
          ),
          TextButton.icon(
            onPressed: () async {
              Navigator.of(dialogContext).pop();
              // 打开所在文件夹
              final dirPath = savedPath.substring(0, savedPath.lastIndexOf('/'));
              await OpenFilex.open(dirPath);
            },
            icon: const Icon(Icons.folder_outlined, size: 16),
            label: const Text('打开文件夹'),
          ),
          TextButton.icon(
            onPressed: () async {
              Navigator.of(dialogContext).pop();
              await OpenFilex.open(savedPath, type: mimeType);
            },
            icon: const Icon(Icons.open_in_new, size: 16),
            label: const Text('打开文件'),
          ),
        ],
      ),
    );
  }
}
