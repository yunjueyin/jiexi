import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../home/home_page.dart';

/// 新手引导页
///
/// 首次启动 App 时显示，介绍主要功能。
/// 使用 PageView 实现，带进度指示器和开始使用按钮。
class GuidePage extends StatefulWidget {
  /// 引导完成回调
  final VoidCallback? onComplete;

  const GuidePage({super.key, this.onComplete});

  @override
  State<GuidePage> createState() => _GuidePageState();
}

class _GuidePageState extends State<GuidePage> {
  final PageController _pageController = PageController();
  int _currentPage = 0;

  final List<_GuidePageData> _pages = [
    _GuidePageData(
      icon: Icons.play_circle_fill_rounded,
      title: '欢迎使用',
      subtitle: '无水印视频下载器',
      description: '一款功能强大的视频解析下载工具，\n支持多平台无水印下载，让你畅享高清内容。',
      gradient: [AppTheme.primaryColor, AppTheme.secondaryColor],
    ),
    _GuidePageData(
      icon: Icons.download_for_offline_rounded,
      title: '解析下载',
      subtitle: '一键解析，轻松下载',
      description: '复制视频链接，粘贴到输入框，\n一键解析即可下载无水印高清视频和图片。\n支持抖音、快手、小红书等多个平台。',
      gradient: [const Color(0xFF6366F1), const Color(0xFF8B5CF6)],
    ),
    _GuidePageData(
      icon: Icons.cloud_download_rounded,
      title: '批量抓取',
      subtitle: '高效批量下载',
      description: '支持批量抓取作者主页作品，\n一次粘贴链接，自动解析下载全部内容，\n省时省力，高效便捷。',
      gradient: [AppTheme.infoColor, const Color(0xFF0EA5E9)],
    ),
    _GuidePageData(
      icon: Icons.star_rounded,
      title: '开始使用',
      subtitle: '更多功能等你发现',
      description: '还有收藏管理、格式转换、隐私锁等\n更多实用功能等你来探索。\n现在就开始你的无水印下载之旅吧！',
      gradient: [AppTheme.accentColor, const Color(0xFFF97316)],
    ),
  ];

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  void _onPageChanged(int index) {
    setState(() {
      _currentPage = index;
    });
  }

  void _nextPage() {
    if (_currentPage < _pages.length - 1) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    } else {
      _finishGuide();
    }
  }

  void _finishGuide() {
    widget.onComplete?.call();
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const HomePage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isLastPage = _currentPage == _pages.length - 1;

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: _pages[_currentPage].gradient,
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // 跳过按钮
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: _finishGuide,
                  style: TextButton.styleFrom(
                    foregroundColor: Colors.white70,
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  ),
                  child: const Text('跳过'),
                ),
              ),
              // 页面内容
              Expanded(
                child: PageView.builder(
                  controller: _pageController,
                  onPageChanged: _onPageChanged,
                  itemCount: _pages.length,
                  itemBuilder: (context, index) {
                    return _buildGuidePage(_pages[index]);
                  },
                ),
              ),
              // 底部指示器和按钮
              Padding(
                padding: const EdgeInsets.fromLTRB(32, 0, 32, 40),
                child: Column(
                  children: [
                    // 进度指示器
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(_pages.length, (index) {
                        return AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          margin: const EdgeInsets.symmetric(horizontal: 4),
                          width: _currentPage == index ? 24 : 8,
                          height: 8,
                          decoration: BoxDecoration(
                            color: _currentPage == index
                                ? Colors.white
                                : Colors.white.withOpacity(0.4),
                            borderRadius: BorderRadius.circular(4),
                          ),
                        );
                      }),
                    ),
                    const SizedBox(height: 40),
                    // 下一步/开始使用按钮
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton(
                        onPressed: _nextPage,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white,
                          foregroundColor: _pages[_currentPage].gradient.first,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(25),
                          ),
                          textStyle: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        child: Text(isLastPage ? '开始使用' : '下一步'),
                      ),
                    ),
                    const SizedBox(height: 16),
                    // 页码指示
                    Text(
                      '${_currentPage + 1} / ${_pages.length}',
                      style: const TextStyle(
                        color: Colors.white70,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildGuidePage(_GuidePageData data) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 40),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // 图标
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2),
              shape: BoxShape.circle,
            ),
            child: Icon(
              data.icon,
              size: 60,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 40),
          // 标题
          Text(
            data.title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 28,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          // 副标题
          Text(
            data.subtitle,
            style: TextStyle(
              color: Colors.white.withOpacity(0.85),
              fontSize: 16,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 24),
          // 描述
          Text(
            data.description,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white.withOpacity(0.75),
              fontSize: 14,
              height: 1.6,
            ),
          ),
        ],
      ),
    );
  }
}

/// 引导页数据
class _GuidePageData {
  final IconData icon;
  final String title;
  final String subtitle;
  final String description;
  final List<Color> gradient;

  const _GuidePageData({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.description,
    required this.gradient,
  });
}
