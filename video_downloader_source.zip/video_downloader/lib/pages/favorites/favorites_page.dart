import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import '../../models/video_info.dart';
import '../../models/crawl_record.dart';
import '../../models/favorite_folder.dart';
import '../../providers/history_provider.dart';
import '../../providers/crawl_history_provider.dart';
import '../../providers/favorite_folder_provider.dart';
import '../../theme/app_theme.dart';
import '../../widgets/platform_badge.dart';
import '../../widgets/empty_state.dart';
import '../../widgets/skeleton.dart';
import '../../widgets/confirm_dialog.dart';
import '../../widgets/slidable_item.dart';
import '../../services/haptic_service.dart';

/// 收藏夹页面
///
/// 支持分组管理、左滑操作、长按菜单、撤销删除
class FavoritesPage extends StatefulWidget {
  const FavoritesPage({super.key});

  @override
  State<FavoritesPage> createState() => _FavoritesPageState();
}

class _FavoritesPageState extends State<FavoritesPage>
    with SingleTickerProviderStateMixin {
  late TabController _typeTabController;

  // 当前选中的分组 ID（null 表示"全部"）
  String? _selectedFolderId;
  bool _showAllFolders = true; // 是否显示全部分组

  // 多选模式状态
  bool _isSelectionMode = false;
  Set<String> _selectedParseIds = {};
  Set<String> _selectedCrawlIds = {};

  // 双击收藏动画状态
  String? _animatingFavoriteId;

  @override
  void initState() {
    super.initState();
    _typeTabController = TabController(length: 2, vsync: this);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<HistoryProvider>().loadHistory();
      context.read<CrawlHistoryProvider>().loadHistory();
      context.read<FavoriteFolderProvider>().loadFolders();
    });
  }

  @override
  void dispose() {
    _typeTabController.dispose();
    super.dispose();
  }

  // ==================== 多选模式相关 ====================

  Set<String> get _currentSelectedIds =>
      _typeTabController.index == 0 ? _selectedParseIds : _selectedCrawlIds;

  void _enterSelectionMode(String firstSelectedId) {
    HapticService.selectionClick();
    setState(() {
      _isSelectionMode = true;
      if (_typeTabController.index == 0) {
        _selectedParseIds
          ..clear()
          ..add(firstSelectedId);
      } else {
        _selectedCrawlIds
          ..clear()
          ..add(firstSelectedId);
      }
    });
  }

  void _exitSelectionMode() {
    setState(() {
      _isSelectionMode = false;
      _selectedParseIds.clear();
      _selectedCrawlIds.clear();
    });
  }

  void _toggleSelection(String id) {
    HapticService.selectionClick();
    setState(() {
      if (_typeTabController.index == 0) {
        if (_selectedParseIds.contains(id)) {
          _selectedParseIds.remove(id);
          if (_selectedParseIds.isEmpty) {
            _isSelectionMode = false;
          }
        } else {
          _selectedParseIds.add(id);
        }
      } else {
        if (_selectedCrawlIds.contains(id)) {
          _selectedCrawlIds.remove(id);
          if (_selectedCrawlIds.isEmpty) {
            _isSelectionMode = false;
          }
        } else {
          _selectedCrawlIds.add(id);
        }
      }
    });
  }

  void _toggleSelectAll() {
    if (_typeTabController.index == 0) {
      final provider = context.read<HistoryProvider>();
      final favIds = _getCurrentFavorites(provider.videos).map((v) => v.id).toSet();
      setState(() {
        if (_selectedParseIds.length == favIds.length && favIds.isNotEmpty) {
          _selectedParseIds.clear();
          _isSelectionMode = false;
        } else {
          _selectedParseIds = favIds;
        }
      });
    } else {
      final provider = context.read<CrawlHistoryProvider>();
      final favIds = _getCurrentCrawlFavorites(provider.records).map((r) => r.id).toSet();
      setState(() {
        if (_selectedCrawlIds.length == favIds.length && favIds.isNotEmpty) {
          _selectedCrawlIds.clear();
          _isSelectionMode = false;
        } else {
          _selectedCrawlIds = favIds;
        }
      });
    }
  }

  bool _isAllSelected() {
    if (_typeTabController.index == 0) {
      final provider = context.read<HistoryProvider>();
      final favIds = _getCurrentFavorites(provider.videos).map((v) => v.id).toSet();
      return _selectedParseIds.length == favIds.length && favIds.isNotEmpty;
    } else {
      final provider = context.read<CrawlHistoryProvider>();
      final favIds = _getCurrentCrawlFavorites(provider.records).map((r) => r.id).toSet();
      return _selectedCrawlIds.length == favIds.length && favIds.isNotEmpty;
    }
  }

  // ==================== 分组过滤 ====================

  List<VideoInfo> _getCurrentFavorites(List<VideoInfo> allVideos) {
    final favs = allVideos.where((v) => v.isFavorite).toList();
    if (_showAllFolders) return favs;
    return favs.where((v) => v.favoriteFolderId == _selectedFolderId).toList();
  }

  List<CrawlRecord> _getCurrentCrawlFavorites(List<CrawlRecord> allRecords) {
    final favs = allRecords.where((r) => r.isFavorite).toList();
    if (_showAllFolders) return favs;
    return favs.where((r) => r.favoriteFolderId == _selectedFolderId).toList();
  }

  // ==================== 分组管理 ====================

  void _showNewFolderDialog() {
    final controller = TextEditingController();
    final formKey = GlobalKey<FormState>();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('新建分组'),
        content: Form(
          key: formKey,
          child: TextFormField(
            controller: controller,
            autofocus: true,
            maxLength: 20,
            decoration: const InputDecoration(
              labelText: '分组名称',
              hintText: '请输入分组名称',
              border: OutlineInputBorder(),
              counterText: '',
            ),
            validator: (value) {
              if (value == null || value.trim().isEmpty) {
                return '请输入分组名称';
              }
              if (context
                  .read<FavoriteFolderProvider>()
                  .nameExists(value.trim())) {
                return '该分组名称已存在';
              }
              return null;
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () async {
              if (formKey.currentState?.validate() ?? false) {
                final name = controller.text.trim();
                await context.read<FavoriteFolderProvider>().createFolder(name);
                if (mounted) Navigator.pop(context);
              }
            },
            child: const Text('创建'),
          ),
        ],
      ),
    );
  }

  void _showRenameFolderDialog(FavoriteFolder folder) {
    final controller = TextEditingController(text: folder.name);
    final formKey = GlobalKey<FormState>();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('重命名分组'),
        content: Form(
          key: formKey,
          child: TextFormField(
            controller: controller,
            autofocus: true,
            maxLength: 20,
            decoration: const InputDecoration(
              labelText: '分组名称',
              border: OutlineInputBorder(),
              counterText: '',
            ),
            validator: (value) {
              if (value == null || value.trim().isEmpty) {
                return '请输入分组名称';
              }
              if (context
                  .read<FavoriteFolderProvider>()
                  .nameExists(value.trim(), excludeId: folder.id)) {
                return '该分组名称已存在';
              }
              return null;
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () async {
              if (formKey.currentState?.validate() ?? false) {
                final name = controller.text.trim();
                await context
                    .read<FavoriteFolderProvider>()
                    .renameFolder(folder.id, name);
                if (mounted) Navigator.pop(context);
              }
            },
            child: const Text('保存'),
          ),
        ],
      ),
    );
  }

  Future<void> _showDeleteFolderDialog(FavoriteFolder folder) async {
    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('删除分组'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('确定要删除分组"${folder.name}"吗？'),
            const SizedBox(height: 12),
            const Text(
              '组内的收藏内容将：',
              style: TextStyle(fontWeight: FontWeight.w500),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, {'move': true}),
            child: const Text('移至默认分组'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, {'delete': true}),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('同时删除'),
          ),
        ],
      ),
    );

    if (result == null) return;

    final deleteContents = result['delete'] == true;

    if (_typeTabController.index == 0) {
      await context
          .read<HistoryProvider>()
          .clearFolderAssociation(folder.id, deleteFavorites: deleteContents);
    } else {
      await context
          .read<CrawlHistoryProvider>()
          .clearFolderAssociation(folder.id, deleteFavorites: deleteContents);
    }

    // 同时处理两种类型的收藏
    if (_typeTabController.index == 0) {
      await context
          .read<CrawlHistoryProvider>()
          .clearFolderAssociation(folder.id, deleteFavorites: deleteContents);
    } else {
      await context
          .read<HistoryProvider>()
          .clearFolderAssociation(folder.id, deleteFavorites: deleteContents);
    }

    await context.read<FavoriteFolderProvider>().deleteFolder(folder.id);

    // 如果删除的是当前选中的分组，切换到"全部"
    if (!_showAllFolders && _selectedFolderId == folder.id) {
      setState(() {
        _showAllFolders = true;
        _selectedFolderId = null;
      });
    }

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('已删除分组"${folder.name}"')),
      );
    }
  }

  void _showFolderLongPressMenu(FavoriteFolder folder) {
    if (folder.isDefault) return;
    HapticService.mediumImpact();
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 12),
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.grey.shade700
                      : Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 8),
            ListTile(
              leading: const Icon(Icons.edit, color: Colors.blue),
              title: const Text('重命名'),
              onTap: () {
                Navigator.pop(context);
                _showRenameFolderDialog(folder);
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete_outline, color: Colors.red),
              title: const Text('删除分组', style: TextStyle(color: Colors.red)),
              onTap: () {
                Navigator.pop(context);
                _showDeleteFolderDialog(folder);
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  // ==================== 移动到分组 ====================

  void _showMoveToFolderSheet({
    String? parseId,
    String? crawlId,
    List<String>? parseIds,
    List<String>? crawlIds,
  }) {
    final folderProvider = context.read<FavoriteFolderProvider>();
    final folders = folderProvider.folders;

    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 12),
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.grey.shade700
                      : Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              '移动到分组',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 8),
            SizedBox(
              height: 200,
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: folders.length,
                itemBuilder: (context, index) {
                  final folder = folders[index];
                  return ListTile(
                    leading: Icon(
                      folder.isDefault ? Icons.folder : Icons.folder_outlined,
                      color: AppTheme.primaryColor,
                    ),
                    title: Text(folder.name),
                    onTap: () async {
                      Navigator.pop(context);
                      final targetId = folder.isDefault ? null : folder.id;

                      if (_typeTabController.index == 0) {
                        final provider = context.read<HistoryProvider>();
                        if (parseIds != null && parseIds.isNotEmpty) {
                          await provider.moveBatchToFolder(parseIds, targetId);
                        } else if (parseId != null) {
                          await provider.moveToFolder(parseId, targetId);
                        }
                      } else {
                        final provider = context.read<CrawlHistoryProvider>();
                        if (crawlIds != null && crawlIds.isNotEmpty) {
                          await provider.moveBatchToFolder(crawlIds, targetId);
                        } else if (crawlId != null) {
                          await provider.moveToFolder(crawlId, targetId);
                        }
                      }

                      if (mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('已移动到"${folder.name}"')),
                        );
                      }
                    },
                  );
                },
              ),
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  // ==================== 撤销删除 ====================

  void _deleteParseItemWithUndo(VideoInfo video) {
    final provider = context.read<HistoryProvider>();
    // 先保存副本用于撤销
    final backup = video;
    provider.removeVideo(video.id);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('已删除'),
        action: SnackBarAction(
          label: '撤销',
          onPressed: () {
            provider.addVideo(backup);
          },
        ),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  void _deleteCrawlItemWithUndo(CrawlRecord record) {
    final provider = context.read<CrawlHistoryProvider>();
    final backup = record;
    provider.removeRecord(record.id);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('已删除'),
        action: SnackBarAction(
          label: '撤销',
          onPressed: () {
            provider.addRecord(backup);
          },
        ),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  // ==================== 收藏操作 ====================

  Future<void> _toggleParseFavorite(VideoInfo video) async {
    HapticService.lightImpact();
    setState(() {
      _animatingFavoriteId = video.id;
    });

    await context.read<HistoryProvider>().toggleFavorite(video.id);

    Future.delayed(const Duration(milliseconds: 600), () {
      if (mounted) {
        setState(() {
          if (_animatingFavoriteId == video.id) {
            _animatingFavoriteId = null;
          }
        });
      }
    });
  }

  Future<void> _toggleCrawlFavorite(CrawlRecord record) async {
    HapticService.lightImpact();
    setState(() {
      _animatingFavoriteId = record.id;
    });

    await context.read<CrawlHistoryProvider>().toggleFavorite(record.id);

    Future.delayed(const Duration(milliseconds: 600), () {
      if (mounted) {
        setState(() {
          if (_animatingFavoriteId == record.id) {
            _animatingFavoriteId = null;
          }
        });
      }
    });
  }

  // ==================== 长按菜单 ====================

  void _showParseActionMenu(VideoInfo video) {
    final isFav = video.isFavorite;
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 12),
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.grey.shade700
                      : Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 8),
            ListTile(
              leading: const Icon(Icons.link, color: Colors.blue),
              title: const Text('复制链接'),
              onTap: () {
                Navigator.pop(context);
                Clipboard.setData(ClipboardData(text: video.url));
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('链接已复制')),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.share, color: Colors.green),
              title: const Text('分享'),
              onTap: () {
                Navigator.pop(context);
                Share.share('${video.title}\n${video.url}');
              },
            ),
            ListTile(
              leading: const Icon(Icons.folder_outlined, color: Colors.orange),
              title: const Text('移动到分组'),
              onTap: () {
                Navigator.pop(context);
                _showMoveToFolderSheet(parseId: video.id);
              },
            ),
            ListTile(
              leading: Icon(
                isFav ? Icons.favorite : Icons.favorite_border,
                color: isFav ? Colors.red : Colors.grey,
              ),
              title: Text(isFav ? '取消收藏' : '收藏'),
              onTap: () {
                Navigator.pop(context);
                _toggleParseFavorite(video);
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete_outline, color: Colors.red),
              title: const Text('删除', style: TextStyle(color: Colors.red)),
              onTap: () {
                Navigator.pop(context);
                _deleteParseItemWithUndo(video);
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  void _showCrawlActionMenu(CrawlRecord record) {
    final isFav = record.isFavorite;
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 12),
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.grey.shade700
                      : Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 8),
            ListTile(
              leading: const Icon(Icons.link, color: Colors.blue),
              title: const Text('复制链接'),
              onTap: () {
                Navigator.pop(context);
                Clipboard.setData(ClipboardData(text: record.url));
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('链接已复制')),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.share, color: Colors.green),
              title: const Text('分享'),
              onTap: () {
                Navigator.pop(context);
                Share.share(record.url);
              },
            ),
            ListTile(
              leading: const Icon(Icons.folder_outlined, color: Colors.orange),
              title: const Text('移动到分组'),
              onTap: () {
                Navigator.pop(context);
                _showMoveToFolderSheet(crawlId: record.id);
              },
            ),
            ListTile(
              leading: Icon(
                isFav ? Icons.favorite : Icons.favorite_border,
                color: isFav ? Colors.red : Colors.grey,
              ),
              title: Text(isFav ? '取消收藏' : '收藏'),
              onTap: () {
                Navigator.pop(context);
                _toggleCrawlFavorite(record);
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete_outline, color: Colors.red),
              title: const Text('删除', style: TextStyle(color: Colors.red)),
              onTap: () {
                Navigator.pop(context);
                _deleteCrawlItemWithUndo(record);
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  // ==================== 批量操作 ====================

  Future<void> _deleteSelected() async {
    final ids = _currentSelectedIds.toList();
    if (ids.isEmpty) return;

    final confirm = await showConfirmDialog(
      context,
      title: '删除选中记录',
      content: '确定要删除选中的 ${ids.length} 条记录吗？',
      isDestructive: true,
      confirmText: '删除',
    );

    if (!confirm) return;

    if (!mounted) return;

    if (_typeTabController.index == 0) {
      await context.read<HistoryProvider>().removeVideos(ids);
    } else {
      await context.read<CrawlHistoryProvider>().removeRecords(ids);
    }

    _exitSelectionMode();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('已删除 ${ids.length} 条记录'),
          duration: const Duration(seconds: 3),
        ),
      );
    }
  }

  Future<void> _toggleFavoriteBatch() async {
    final ids = _currentSelectedIds.toList();
    if (ids.isEmpty) return;

    if (_typeTabController.index == 0) {
      await context.read<HistoryProvider>().toggleFavoriteBatch(ids);
    } else {
      await context.read<CrawlHistoryProvider>().toggleFavoriteBatch(ids);
    }

    _exitSelectionMode();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('操作成功')),
      );
    }
  }

  Future<void> _moveSelectedToFolder() async {
    final ids = _currentSelectedIds.toList();
    if (ids.isEmpty) return;

    _showMoveToFolderSheet(
      parseIds: _typeTabController.index == 0 ? ids : null,
      crawlIds: _typeTabController.index == 1 ? ids : null,
    );
  }

  // ==================== 构建 UI ====================

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // 顶部标题栏
        Container(
          decoration: BoxDecoration(
            gradient: AppTheme.primaryGradient,
          ),
          child: SafeArea(
            bottom: false,
            child: Column(
              children: [
                const SizedBox(height: 12),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: _isSelectionMode
                      ? _buildSelectionAppBar()
                      : _buildNormalAppBar(),
                ),
                const SizedBox(height: 8),
                // 分组选择器
                _buildFolderSelector(),
                const SizedBox(height: 4),
                // 类型 Tab
                TabBar(
                  controller: _typeTabController,
                  labelColor: Colors.white,
                  unselectedLabelColor: Colors.white60,
                  indicatorColor: Colors.white,
                  indicatorSize: TabBarIndicatorSize.label,
                  labelStyle: const TextStyle(
                      fontSize: 14, fontWeight: FontWeight.w600),
                  tabs: const [
                    Tab(text: '解析收藏'),
                    Tab(text: '抓取收藏'),
                  ],
                ),
              ],
            ),
          ),
        ),
        Expanded(
          child: TabBarView(
            controller: _typeTabController,
            children: [
              _buildParseFavoritesTab(),
              _buildCrawlFavoritesTab(),
            ],
          ),
        ),
        if (_isSelectionMode) _buildSelectionBottomBar(),
      ],
    );
  }

  Widget _buildNormalAppBar() {
    return Row(
      children: [
        const Icon(Icons.favorite, color: Colors.white, size: 22),
        const SizedBox(width: 8),
        const Text(
          '我的收藏',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const Spacer(),
        IconButton(
          icon: const Icon(Icons.create_new_folder_outlined,
              color: Colors.white, size: 22),
          onPressed: _showNewFolderDialog,
          tooltip: '新建分组',
          padding: EdgeInsets.zero,
          constraints: const BoxConstraints(),
        ),
        const SizedBox(width: 8),
        TextButton(
          onPressed: _enterManageMode,
          child: const Text(
            '管理',
            style: TextStyle(color: Colors.white, fontSize: 14),
          ),
        ),
      ],
    );
  }

  void _enterManageMode() {
    if (_typeTabController.index == 0) {
      final provider = context.read<HistoryProvider>();
      final favCount = _getCurrentFavorites(provider.videos).length;
      if (favCount == 0) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('暂无收藏内容')),
        );
        return;
      }
    } else {
      final provider = context.read<CrawlHistoryProvider>();
      final favCount = _getCurrentCrawlFavorites(provider.records).length;
      if (favCount == 0) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('暂无收藏内容')),
        );
        return;
      }
    }

    HapticService.selectionClick();
    setState(() {
      _isSelectionMode = true;
    });
  }

  Widget _buildSelectionAppBar() {
    final selectedCount = _currentSelectedIds.length;

    return Row(
      children: [
        IconButton(
          icon: const Icon(Icons.close, color: Colors.white, size: 22),
          onPressed: _exitSelectionMode,
          tooltip: '取消',
          padding: EdgeInsets.zero,
          constraints: const BoxConstraints(),
        ),
        const SizedBox(width: 8),
        Text(
          '已选 $selectedCount 项',
          style: const TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const Spacer(),
        TextButton(
          onPressed: _toggleSelectAll,
          child: Text(
            _isAllSelected() ? '取消全选' : '全选',
            style: const TextStyle(color: Colors.white, fontSize: 14),
          ),
        ),
      ],
    );
  }

  /// 分组选择器
  Widget _buildFolderSelector() {
    return Consumer<FavoriteFolderProvider>(
      builder: (context, provider, child) {
        final folders = provider.folders;
        return SizedBox(
          height: 36,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            children: [
              _buildFolderChip(
                label: '全部',
                isSelected: _showAllFolders,
                onTap: () {
                  setState(() {
                    _showAllFolders = true;
                    _selectedFolderId = null;
                  });
                },
              ),
              const SizedBox(width: 8),
              ...folders.map((folder) => Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: GestureDetector(
                      onLongPress: () => _showFolderLongPressMenu(folder),
                      child: _buildFolderChip(
                        label: folder.name,
                        isSelected:
                            !_showAllFolders && _selectedFolderId == folder.id,
                        onTap: () {
                          setState(() {
                            _showAllFolders = false;
                            _selectedFolderId = folder.id;
                          });
                        },
                      ),
                    ),
                  )),
            ],
          ),
        );
      },
    );
  }

  Widget _buildFolderChip({
    required String label,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: isSelected ? Colors.white.withOpacity(0.25) : Colors.white.withOpacity(0.1),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: isSelected ? Colors.white : Colors.transparent,
            width: 1,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: isSelected ? Colors.white : Colors.white70,
            fontSize: 13,
            fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
          ),
        ),
      ),
    );
  }

  /// 多选模式底部操作栏
  Widget _buildSelectionBottomBar() {
    final hasSelection = _currentSelectedIds.isNotEmpty;
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 10,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
          child: Row(
            children: [
              Expanded(
                child: _buildBottomAction(
                  icon: Icons.select_all,
                  label: '全选',
                  onTap: _toggleSelectAll,
                ),
              ),
              Expanded(
                child: _buildBottomAction(
                  icon: Icons.folder_outlined,
                  label: '移动',
                  onTap: hasSelection ? _moveSelectedToFolder : null,
                ),
              ),
              Expanded(
                child: _buildBottomAction(
                  icon: Icons.delete_outline,
                  label: '删除',
                  color: Colors.red,
                  onTap: hasSelection ? _deleteSelected : null,
                ),
              ),
              Expanded(
                child: _buildBottomAction(
                  icon: Icons.favorite_border,
                  label: '收藏',
                  onTap: hasSelection ? _toggleFavoriteBatch : null,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBottomAction({
    required IconData icon,
    required String label,
    required VoidCallback? onTap,
    Color? color,
  }) {
    final isEnabled = onTap != null;
    final iconColor = color ??
        (isEnabled
            ? AppTheme.textPrimaryColor(context)
            : Colors.grey.shade400);

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 20, color: iconColor),
            const SizedBox(height: 2),
            Text(
              label,
              style: TextStyle(
                fontSize: 11,
                color: iconColor,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ==================== 解析收藏 Tab ====================

  Widget _buildParseFavoritesTab() {
    return Consumer<HistoryProvider>(
      builder: (context, provider, child) {
        if (provider.loading && provider.videos.isEmpty) {
          return const ListSkeleton(count: 6);
        }

        final favorites = _getCurrentFavorites(provider.videos);

        if (favorites.isEmpty) {
          return EmptyState.noFavorites();
        }

        return RefreshIndicator(
          onRefresh: () => provider.refresh(),
          child: ListView.builder(
            padding: const EdgeInsets.all(12),
            physics: const AlwaysScrollableScrollPhysics(),
            itemCount: favorites.length,
            itemBuilder: (context, index) {
              final video = favorites[index];
              return _buildParseFavoriteItem(video);
            },
          ),
        );
      },
    );
  }

  Widget _buildParseFavoriteItem(VideoInfo video) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final secondaryTextColor =
        isDark ? Colors.grey.shade400 : Colors.grey.shade600;
    final fillColor = isDark ? const Color(0xFF1E293B) : Colors.grey.shade50;
    final isSelected = _selectedParseIds.contains(video.id);
    final isAnimating = _animatingFavoriteId == video.id;

    if (_isSelectionMode) {
      return InkWell(
        onTap: () => _toggleSelection(video.id),
        borderRadius: BorderRadius.circular(12),
        child: Container(
          margin: const EdgeInsets.only(bottom: 10),
          child: Row(
            children: [
              Container(
                width: 24,
                height: 24,
                margin: const EdgeInsets.only(right: 10),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: isSelected ? AppTheme.primaryColor : Colors.transparent,
                  border: Border.all(
                    color: isSelected
                        ? AppTheme.primaryColor
                        : Colors.grey.shade400,
                    width: 2,
                  ),
                ),
                child: isSelected
                    ? const Icon(Icons.check, color: Colors.white, size: 16)
                    : null,
              ),
              Expanded(
                child: _buildParseCardContent(
                    video, isDark, secondaryTextColor, fillColor, false),
              ),
            ],
          ),
        ),
      );
    }

    // 普通模式：左滑操作 + 长按菜单 + 双击收藏
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: SlidableItem(
        actions: [
          SlideAction(
            label: '分享',
            icon: Icons.share,
            color: Colors.green,
            onTap: () => Share.share('${video.title}\n${video.url}'),
          ),
          SlideAction(
            label: '移动',
            icon: Icons.folder_outlined,
            color: Colors.orange,
            onTap: () => _showMoveToFolderSheet(parseId: video.id),
          ),
          SlideAction(
            label: '删除',
            icon: Icons.delete,
            color: Colors.red,
            onTap: () => _deleteParseItemWithUndo(video),
          ),
        ],
        child: GestureDetector(
          onLongPress: () => _showParseActionMenu(video),
          onDoubleTap: () => _toggleParseFavorite(video),
          child: Card(
            margin: EdgeInsets.zero,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            elevation: isDark ? 0 : null,
            color: Theme.of(context).cardColor,
            child: InkWell(
              borderRadius: BorderRadius.circular(12),
              onTap: () => _showParseDetail(video),
              child: _buildParseCardContent(
                  video, isDark, secondaryTextColor, fillColor, isAnimating),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildParseCardContent(
    VideoInfo video,
    bool isDark,
    Color secondaryTextColor,
    Color fillColor,
    bool showFavoriteAnim,
  ) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Row(
        children: [
          _buildCover(video, fillColor, secondaryTextColor),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  video.title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                    color: isDark ? Colors.white : Colors.black87,
                  ),
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    PlatformBadge(platform: video.platform, size: 12),
                    const SizedBox(width: 6),
                    Text(
                      _formatTime(video.parsedAt),
                      style: TextStyle(
                        fontSize: 11,
                        color: secondaryTextColor,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          AnimatedScale(
            scale: showFavoriteAnim ? 1.3 : 1.0,
            duration: const Duration(milliseconds: 200),
            curve: Curves.easeOutBack,
            child: Icon(
              Icons.favorite,
              color: Colors.red.shade400,
              size: 20,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCover(VideoInfo video, Color fillColor, Color iconColor) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(8),
      child: Container(
        width: 70,
        height: 56,
        color: fillColor,
        child: video.cover.isNotEmpty
            ? Image.network(
                video.cover,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) =>
                    Icon(Icons.image, color: iconColor, size: 24),
              )
            : Icon(Icons.image, color: iconColor, size: 24),
      ),
    );
  }

  void _showParseDetail(VideoInfo video) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        return DraggableScrollableSheet(
          initialChildSize: 0.7,
          maxChildSize: 0.95,
          minChildSize: 0.5,
          builder: (_, controller) => Container(
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(20)),
            ),
            child: ListView(
              controller: controller,
              padding: const EdgeInsets.all(20),
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: isDark ? Colors.grey.shade700 : Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  video.title,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: isDark ? Colors.white : Colors.black87,
                  ),
                ),
                const SizedBox(height: 12),
                _detailRow('平台', video.platformName),
                _detailRow('类型', video.typeName),
                _detailRow('作者', video.author),
                _detailRow('视频ID', video.id),
                _detailRow('解析时间', _formatDateTime(video.parsedAt)),
                if (video.durationSeconds != null)
                  _detailRow('时长', '${video.durationSeconds}秒'),
                if (video.isImage)
                  _detailRow('图片数量', '${video.imageCount}张'),
                _detailRow('收藏状态', video.isFavorite ? '已收藏' : '未收藏'),
                if (video.isFavorite && video.favoritedAt != null)
                  _detailRow('收藏时间', _formatDateTime(video.favoritedAt!)),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () {
                          Clipboard.setData(ClipboardData(text: video.url));
                          Navigator.pop(context);
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('链接已复制')),
                          );
                        },
                        icon: const Icon(Icons.copy, size: 16),
                        label: const Text('复制原链接'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _detailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 80,
            child: Text(
              label,
              style: TextStyle(fontSize: 13, color: Colors.grey.shade600),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(fontSize: 13),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== 抓取收藏 Tab ====================

  Widget _buildCrawlFavoritesTab() {
    return Consumer<CrawlHistoryProvider>(
      builder: (context, provider, child) {
        if (provider.loading && provider.records.isEmpty) {
          return const ListSkeleton(count: 6);
        }

        final favorites = _getCurrentCrawlFavorites(provider.records);

        if (favorites.isEmpty) {
          return EmptyState.noFavorites();
        }

        return RefreshIndicator(
          onRefresh: () => provider.refresh(),
          child: ListView.builder(
            padding: const EdgeInsets.all(12),
            physics: const AlwaysScrollableScrollPhysics(),
            itemCount: favorites.length,
            itemBuilder: (context, index) {
              final record = favorites[index];
              return _buildCrawlFavoriteItem(record);
            },
          ),
        );
      },
    );
  }

  Widget _buildCrawlFavoriteItem(CrawlRecord record) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final secondaryTextColor =
        isDark ? Colors.grey.shade400 : Colors.grey.shade600;
    final accentOpacity = isDark ? 0.2 : 0.1;
    final isSelected = _selectedCrawlIds.contains(record.id);
    final isAnimating = _animatingFavoriteId == record.id;
    final isAuthor = record.isAuthor;

    final title = _getCrawlTitle(record);
    final subtitle = _getCrawlSubtitle(record);

    if (_isSelectionMode) {
      return InkWell(
        onTap: () => _toggleSelection(record.id),
        borderRadius: BorderRadius.circular(12),
        child: Container(
          margin: const EdgeInsets.only(bottom: 10),
          child: Row(
            children: [
              Container(
                width: 24,
                height: 24,
                margin: const EdgeInsets.only(right: 10),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: isSelected ? AppTheme.primaryColor : Colors.transparent,
                  border: Border.all(
                    color: isSelected
                        ? AppTheme.primaryColor
                        : Colors.grey.shade400,
                    width: 2,
                  ),
                ),
                child: isSelected
                    ? const Icon(Icons.check, color: Colors.white, size: 16)
                    : null,
              ),
              Expanded(
                child: _buildCrawlCardContent(record, isDark,
                    secondaryTextColor, accentOpacity, isAuthor, title,
                    subtitle, false),
              ),
            ],
          ),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: SlidableItem(
        actions: [
          SlideAction(
            label: '分享',
            icon: Icons.share,
            color: Colors.green,
            onTap: () => Share.share(record.url),
          ),
          SlideAction(
            label: '移动',
            icon: Icons.folder_outlined,
            color: Colors.orange,
            onTap: () => _showMoveToFolderSheet(crawlId: record.id),
          ),
          SlideAction(
            label: '删除',
            icon: Icons.delete,
            color: Colors.red,
            onTap: () => _deleteCrawlItemWithUndo(record),
          ),
        ],
        child: GestureDetector(
          onLongPress: () => _showCrawlActionMenu(record),
          onDoubleTap: () => _toggleCrawlFavorite(record),
          child: Card(
            margin: EdgeInsets.zero,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            elevation: isDark ? 0 : null,
            color: Theme.of(context).cardColor,
            child: InkWell(
              borderRadius: BorderRadius.circular(12),
              onTap: () => _showCrawlDetail(record),
              child: _buildCrawlCardContent(record, isDark, secondaryTextColor,
                  accentOpacity, isAuthor, title, subtitle, isAnimating),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCrawlCardContent(
    CrawlRecord record,
    bool isDark,
    Color secondaryTextColor,
    double accentOpacity,
    bool isAuthor,
    String title,
    String subtitle,
    bool showFavoriteAnim,
  ) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: isAuthor
                  ? Colors.purple.withOpacity(accentOpacity)
                  : Colors.blue.withOpacity(accentOpacity),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              isAuthor ? Icons.person_outline : Icons.play_circle_outline,
              color: isAuthor ? Colors.purple : Colors.blue,
              size: 24,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                    color: isDark ? Colors.white : Colors.black87,
                  ),
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 1),
                      decoration: BoxDecoration(
                        color: isAuthor
                            ? Colors.purple.withOpacity(accentOpacity)
                            : Colors.blue.withOpacity(accentOpacity),
                        borderRadius: BorderRadius.circular(3),
                      ),
                      child: Text(
                        record.typeLabel,
                        style: TextStyle(
                          fontSize: 10,
                          color: isAuthor ? Colors.purple : Colors.blue,
                        ),
                      ),
                    ),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        subtitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 11,
                          color: secondaryTextColor,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          AnimatedScale(
            scale: showFavoriteAnim ? 1.3 : 1.0,
            duration: const Duration(milliseconds: 200),
            curve: Curves.easeOutBack,
            child: Icon(
              Icons.favorite,
              color: Colors.red.shade400,
              size: 20,
            ),
          ),
        ],
      ),
    );
  }

  String _getCrawlTitle(CrawlRecord record) {
    if (record.isAuthor) {
      return record.data['nickname']?.toString() ??
          record.data['authorName']?.toString() ??
          record.data['uniqueId']?.toString() ??
          '作者信息';
    } else {
      return record.data['title']?.toString() ??
          record.data['desc']?.toString() ??
          '视频信息';
    }
  }

  String _getCrawlSubtitle(CrawlRecord record) {
    return '${record.platformName} · ${_formatTime(record.crawledAt)}';
  }

  void _showCrawlDetail(CrawlRecord record) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        return DraggableScrollableSheet(
          initialChildSize: 0.7,
          maxChildSize: 0.95,
          minChildSize: 0.5,
          builder: (_, controller) => Container(
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(20)),
            ),
            child: ListView(
              controller: controller,
              padding: const EdgeInsets.all(20),
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: isDark ? Colors.grey.shade700 : Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  _getCrawlTitle(record),
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: isDark ? Colors.white : Colors.black87,
                  ),
                ),
                const SizedBox(height: 12),
                _detailRow('平台', record.platformName),
                _detailRow('类型', record.typeLabel),
                _detailRow('抓取时间', _formatDateTime(record.crawledAt)),
                _detailRow('收藏状态', record.isFavorite ? '已收藏' : '未收藏'),
                if (record.isFavorite && record.favoritedAt != null)
                  _detailRow(
                      '收藏时间', _formatDateTime(record.favoritedAt!)),
                const SizedBox(height: 12),
                const Divider(),
                const SizedBox(height: 8),
                const Text(
                  '详细数据',
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 8),
                ...record.fields.map((f) => _detailRow(f.key, f.value)),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () {
                          Clipboard.setData(ClipboardData(text: record.url));
                          Navigator.pop(context);
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('链接已复制')),
                          );
                        },
                        icon: const Icon(Icons.copy, size: 16),
                        label: const Text('复制原链接'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ==================== 工具方法 ====================

  String _formatTime(DateTime dateTime) {
    final now = DateTime.now();
    final diff = now.difference(dateTime);
    if (diff.inDays == 0) {
      if (diff.inHours == 0) {
        if (diff.inMinutes == 0) {
          return '刚刚';
        }
        return '${diff.inMinutes}分钟前';
      }
      return '${diff.inHours}小时前';
    } else if (diff.inDays == 1) {
      return '昨天';
    } else if (diff.inDays < 7) {
      return '${diff.inDays}天前';
    } else {
      return '${dateTime.month}月${dateTime.day}日';
    }
  }

  String _formatDateTime(DateTime dateTime) {
    return '${dateTime.year}-${dateTime.month.toString().padLeft(2, '0')}-${dateTime.day.toString().padLeft(2, '0')} '
        '${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}';
  }
}
