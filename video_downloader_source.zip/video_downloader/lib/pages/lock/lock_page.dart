import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../../providers/privacy_lock_provider.dart';
import '../../providers/settings_provider.dart';

/// 解锁页面
///
/// 支持生物识别和密码两种解锁方式，根据设置显示对应的解锁选项。
class LockPage extends StatefulWidget {
  /// 解锁成功后的回调
  final VoidCallback? onUnlocked;

  const LockPage({super.key, this.onUnlocked});

  @override
  State<LockPage> createState() => _LockPageState();
}

class _LockPageState extends State<LockPage> {
  final TextEditingController _passwordController = TextEditingController();
  final FocusNode _passwordFocusNode = FocusNode();
  String _errorMessage = '';
  bool _isAuthenticating = false;

  @override
  void initState() {
    super.initState();
    // 页面加载后，如果支持生物识别且解锁方式允许，自动触发生物识别
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final privacyLock = context.read<PrivacyLockProvider>();
      final settings = context.read<SettingsProvider>();
      final method = UnlockMethodX.fromString(settings.privacyUnlockMethod);

      if (privacyLock.biometricAvailable &&
          (method == UnlockMethod.biometric || method == UnlockMethod.both)) {
        _authenticateWithBiometrics();
      } else {
        // 否则聚焦到密码输入框
        _passwordFocusNode.requestFocus();
      }
    });
  }

  @override
  void dispose() {
    _passwordController.dispose();
    _passwordFocusNode.dispose();
    super.dispose();
  }

  /// 生物识别解锁
  Future<void> _authenticateWithBiometrics() async {
    if (_isAuthenticating) return;

    setState(() {
      _isAuthenticating = true;
      _errorMessage = '';
    });

    final privacyLock = context.read<PrivacyLockProvider>();
    final success = await privacyLock.unlockWithBiometric();

    if (!mounted) return;

    setState(() {
      _isAuthenticating = false;
    });

    if (success) {
      widget.onUnlocked?.call();
    } else {
      // 生物识别失败，如果支持密码，聚焦到密码输入
      final settings = context.read<SettingsProvider>();
      final method = UnlockMethodX.fromString(settings.privacyUnlockMethod);
      if (method == UnlockMethod.both || method == UnlockMethod.password) {
        _passwordFocusNode.requestFocus();
      }
    }
  }

  /// 密码解锁
  void _verifyPassword(String value) {
    if (value.length != 6) return;

    final privacyLock = context.read<PrivacyLockProvider>();
    final success = privacyLock.unlockWithPassword(value);

    if (success) {
      widget.onUnlocked?.call();
    } else {
      setState(() {
        _errorMessage = '密码错误，请重试';
      });
      _passwordController.clear();
      // 震动反馈
      HapticFeedback.mediumImpact();
    }
  }

  /// 显示忘记密码提示
  void _showForgotPasswordDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('忘记密码'),
        content: const Text('为保护您的隐私安全，密码无法找回。\n\n如需重置密码，您只能清除应用数据，这将同时删除所有下载记录和设置。'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('我知道了'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final themeColor = Theme.of(context).colorScheme.primary;
    final settings = context.watch<SettingsProvider>();
    final privacyLock = context.watch<PrivacyLockProvider>();
    final unlockMethod = UnlockMethodX.fromString(settings.privacyUnlockMethod);

    final showBiometric = privacyLock.biometricAvailable &&
        (unlockMethod == UnlockMethod.biometric || unlockMethod == UnlockMethod.both);
    final showPassword = unlockMethod == UnlockMethod.password || unlockMethod == UnlockMethod.both;

    return Scaffold(
      backgroundColor: isDark ? Colors.grey.shade900 : Colors.grey.shade50,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // 图标
                Icon(
                  Icons.lock_outline,
                  size: 72,
                  color: themeColor,
                ),
                const SizedBox(height: 24),
                // 标题
                Text(
                  '应用已锁定',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w600,
                    color: isDark ? Colors.white : Colors.grey.shade800,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  '请验证身份以继续使用',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 14,
                    color: isDark ? Colors.grey.shade400 : Colors.grey.shade600,
                  ),
                ),
                const SizedBox(height: 48),

                // 密码输入区域
                if (showPassword) ...[
                  _buildPasswordInput(isDark, themeColor),
                  const SizedBox(height: 16),
                  // 错误提示
                  if (_errorMessage.isNotEmpty)
                    Text(
                      _errorMessage,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: Colors.redAccent,
                        fontSize: 13,
                      ),
                    ),
                  if (_errorMessage.isNotEmpty)
                    const SizedBox(height: 16),
                ],

                // 生物识别按钮
                if (showBiometric) ...[
                  if (showPassword) ...[
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(child: Divider(color: isDark ? Colors.grey.shade700 : Colors.grey.shade300)),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          child: Text(
                            '或使用',
                            style: TextStyle(
                              fontSize: 12,
                              color: isDark ? Colors.grey.shade500 : Colors.grey.shade500,
                            ),
                          ),
                        ),
                        Expanded(child: Divider(color: isDark ? Colors.grey.shade700 : Colors.grey.shade300)),
                      ],
                    ),
                    const SizedBox(height: 24),
                  ],
                  _buildBiometricButton(isDark, themeColor),
                ],

                const SizedBox(height: 32),

                // 忘记密码
                if (showPassword)
                  TextButton(
                    onPressed: _showForgotPasswordDialog,
                    child: Text(
                      '忘记密码？',
                      style: TextStyle(
                        fontSize: 13,
                        color: isDark ? Colors.grey.shade400 : Colors.grey.shade600,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// 构建密码输入区域
  Widget _buildPasswordInput(bool isDark, Color themeColor) {
    return Column(
      children: [
        TextField(
          controller: _passwordController,
          focusNode: _passwordFocusNode,
          keyboardType: TextInputType.number,
          obscureText: true,
          maxLength: 6,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 32,
            letterSpacing: 16,
            fontWeight: FontWeight.w500,
            color: isDark ? Colors.white : Colors.grey.shade800,
          ),
          decoration: InputDecoration(
            counterText: '',
            hintText: '••••••',
            hintStyle: TextStyle(
              fontSize: 32,
              letterSpacing: 16,
              color: isDark ? Colors.grey.shade700 : Colors.grey.shade400,
            ),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: isDark ? Colors.grey.shade700 : Colors.grey.shade300),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: isDark ? Colors.grey.shade700 : Colors.grey.shade300),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: themeColor, width: 2),
            ),
            contentPadding: const EdgeInsets.symmetric(vertical: 20, horizontal: 24),
          ),
          onChanged: (value) {
            if (_errorMessage.isNotEmpty) {
              setState(() {
                _errorMessage = '';
              });
            }
            if (value.length == 6) {
              _verifyPassword(value);
            }
          },
        ),
        const SizedBox(height: 8),
        Text(
          '请输入6位数字密码',
          style: TextStyle(
            fontSize: 12,
            color: isDark ? Colors.grey.shade500 : Colors.grey.shade500,
          ),
        ),
      ],
    );
  }

  /// 构建生物识别按钮
  Widget _buildBiometricButton(bool isDark, Color themeColor) {
    return Center(
      child: InkWell(
        onTap: _isAuthenticating ? null : _authenticateWithBiometrics,
        borderRadius: BorderRadius.circular(40),
        child: Container(
          width: 72,
          height: 72,
          decoration: BoxDecoration(
            color: themeColor.withOpacity(0.1),
            shape: BoxShape.circle,
            border: Border.all(color: themeColor.withOpacity(0.3), width: 2),
          ),
          child: _isAuthenticating
              ? Padding(
                  padding: const EdgeInsets.all(20),
                  child: CircularProgressIndicator(
                    strokeWidth: 3,
                    valueColor: AlwaysStoppedAnimation<Color>(themeColor),
                  ),
                )
              : Icon(
                  Icons.fingerprint,
                  size: 36,
                  color: themeColor,
                ),
        ),
      ),
    );
  }
}

/// 设置密码对话框
///
/// 用于首次设置密码或修改密码。
class PasswordSetupDialog extends StatefulWidget {
  /// 标题
  final String title;

  /// 是否需要验证旧密码（修改密码时为 true）
  final bool requireOldPassword;

  /// 验证旧密码的回调（返回 true 表示验证通过）
  final bool Function(String password)? verifyOldPassword;

  /// 设置完成后的回调
  final Future<void> Function(String newPassword) onPasswordSet;

  const PasswordSetupDialog({
    super.key,
    this.title = '设置密码',
    this.requireOldPassword = false,
    this.verifyOldPassword,
    required this.onPasswordSet,
  });

  @override
  State<PasswordSetupDialog> createState() => _PasswordSetupDialogState();
}

class _PasswordSetupDialogState extends State<PasswordSetupDialog> {
  final TextEditingController _controller = TextEditingController();
  final FocusNode _focusNode = FocusNode();

  /// 当前步骤：0=输入旧密码（如果需要），1=输入新密码，2=确认新密码
  int _step = 0;
  String _firstPassword = '';
  String _errorMessage = '';
  bool _isSetting = false;

  String get _title {
    if (widget.requireOldPassword && _step == 0) {
      return '验证旧密码';
    }
    return _step == 0 || (widget.requireOldPassword && _step == 1) ? '设置新密码' : '确认新密码';
  }

  String get _hint {
    if (widget.requireOldPassword && _step == 0) {
      return '请输入旧密码';
    }
    return _step == 0 || (widget.requireOldPassword && _step == 1) ? '请输入6位新密码' : '请再次输入新密码';
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _focusNode.requestFocus();
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _onInput(String value) {
    if (value.length != 6) return;

    setState(() {
      _errorMessage = '';
    });

    // 验证旧密码
    if (widget.requireOldPassword && _step == 0) {
      if (widget.verifyOldPassword?.call(value) ?? false) {
        setState(() {
          _step = 1;
          _controller.clear();
        });
      } else {
        setState(() {
          _errorMessage = '旧密码错误';
          _controller.clear();
        });
        HapticFeedback.mediumImpact();
      }
      return;
    }

    // 第一次输入新密码
    if (_step == 0 || (widget.requireOldPassword && _step == 1)) {
      // 检查是否为纯数字
      if (int.tryParse(value) == null) {
        setState(() {
          _errorMessage = '密码必须为6位数字';
          _controller.clear();
        });
        return;
      }
      setState(() {
        _firstPassword = value;
        _step = widget.requireOldPassword ? 2 : 1;
        _controller.clear();
      });
      return;
    }

    // 确认密码
    if (value == _firstPassword) {
      _setPassword(value);
    } else {
      setState(() {
        _errorMessage = '两次输入的密码不一致';
        _firstPassword = '';
        _step = widget.requireOldPassword ? 1 : 0;
        _controller.clear();
      });
      HapticFeedback.mediumImpact();
    }
  }

  Future<void> _setPassword(String password) async {
    setState(() {
      _isSetting = true;
    });

    try {
      await widget.onPasswordSet(password);
      if (mounted) {
        Navigator.of(context).pop(true);
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _errorMessage = '设置失败，请重试';
          _isSetting = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final themeColor = Theme.of(context).colorScheme.primary;

    return AlertDialog(
      title: Text(_title),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _controller,
            focusNode: _focusNode,
            keyboardType: TextInputType.number,
            obscureText: true,
            maxLength: 6,
            textAlign: TextAlign.center,
            enabled: !_isSetting,
            style: TextStyle(
              fontSize: 28,
              letterSpacing: 12,
              fontWeight: FontWeight.w500,
              color: isDark ? Colors.white : Colors.grey.shade800,
            ),
            decoration: InputDecoration(
              counterText: '',
              hintText: '••••••',
              hintStyle: TextStyle(
                fontSize: 28,
                letterSpacing: 12,
                color: isDark ? Colors.grey.shade700 : Colors.grey.shade400,
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide(color: isDark ? Colors.grey.shade700 : Colors.grey.shade300),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide(color: isDark ? Colors.grey.shade700 : Colors.grey.shade300),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide(color: themeColor, width: 2),
              ),
              contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
            ),
            onChanged: _onInput,
          ),
          const SizedBox(height: 8),
          Text(
            _hint,
            style: TextStyle(
              fontSize: 12,
              color: isDark ? Colors.grey.shade500 : Colors.grey.shade500,
            ),
          ),
          if (_errorMessage.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text(
              _errorMessage,
              style: const TextStyle(
                color: Colors.redAccent,
                fontSize: 12,
              ),
            ),
          ],
        ],
      ),
      actions: [
        TextButton(
          onPressed: _isSetting ? null : () => Navigator.of(context).pop(false),
          child: const Text('取消'),
        ),
      ],
    );
  }
}
