import 'dart:convert';
import 'dart:io';
import 'package:excel/excel.dart' as excel;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import '../../models/video_info.dart';
import '../../models/crawl_record.dart';
import '../../models/convert_record.dart';
import '../../providers/history_provider.dart';
import '../../providers/crawl_history_provider.dart';
import '../../providers/convert_history_provider.dart';
import '../../providers/download_provider.dart';
import '../../theme/app_theme.dart';
import '../../widgets/platform_badge.dart';
import '../../widgets/empty_state.dart';
import '../../widgets/skeleton.dart';
import '../../widgets/confirm_dialog.dart';
import '../../widgets/context_menu.dart';
import '../../widgets/slidable_item.dart';
import '../../services/haptic_service.dart';

/// 历史记录页面（Tab 切换：解析记录 / 抓取记录 / 转换记录）
class HistoryPage extends StatefulWidget {
  /// 初始显示的 Tab：0=解析记录，1=抓取记录，2=转换记录
  final int initialTab;

  const HistoryPage({super.key, this.initialTab = 0});

  @override
  State<HistoryPage> createState() => HistoryPageState();
}

class HistoryPageState extends State<HistoryPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final Set<String> _expandedBatches = {}; // 展开的批次 ID 集合

  // 多选模式状态（仅解析记录 Tab）
  bool _isSelectionMode = false;
  Set<String> _selectedIds = {};

  // 滚动控制器（用于分页加载）
  final ScrollController _parseScrollController = ScrollController();
  final ScrollController _crawlScrollController = ScrollController();
  final ScrollController _convertScrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(
      length: 3,
      vsync: this,
      initialIndex: widget.initialTab,
    );
    // 加载数据
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<HistoryProvider>().loadHistory();
      context.read<CrawlHistoryProvider>().loadHistory();
      context.read<ConvertHistoryProvider>().loadHistory();
    });
    // 监听滚动，实现分页加载
    _parseScrollController.addListener(_onParseScroll);
    _crawlScrollController.addListener(_onCrawlScroll);
    _convertScrollController.addListener(_onConvertScroll);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _parseScrollController.dispose();
    _crawlScrollController.dispose();
    _convertScrollController.dispose();
    super.dispose();
  }

  /// 解析记录列表滚动监听 - 滚动到底部时加载更多
  void _onParseScroll() {
    if (_isSelectionMode) return; // 多选模式下不触发加载更多
    final provider = context.read<HistoryProvider>();
    if (provider.loading || provider.loadingMore || !provider.hasMore) return;

    final maxScroll = _parseScrollController.position.maxScrollExtent;
    final currentScroll = _parseScrollController.position.pixels;
    // 距离底部 200 像素时开始加载更多
    if (maxScroll - currentScroll <= 200) {
      provider.loadMore();
    }
  }

  /// 抓取记录列表滚动监听 - 滚动到底部时加载更多
  void _onCrawlScroll() {
    final provider = context.read<CrawlHistoryProvider>();
    if (provider.loading || provider.loadingMore || !provider.hasMore) return;

    final maxScroll = _crawlScrollController.position.maxScrollExtent;
    final currentScroll = _crawlScrollController.position.pixels;
    // 距离底部 200 像素时开始加载更多
    if (maxScroll - currentScroll <= 200) {
      provider.loadMore();
    }
  }

  /// 转换记录列表滚动监听 - 滚动到底部时加载更多
  void _onConvertScroll() {
    final provider = context.read<ConvertHistoryProvider>();
    if (provider.loading || provider.loadingMore || !provider.hasMore) return;

    final maxScroll = _convertScrollController.position.maxScrollExtent;
    final currentScroll = _convertScrollController.position.pixels;
    // 距离底部 200 像素时开始加载更多
    if (maxScroll - currentScroll <= 200) {
      provider.loadMore();
    }
  }

  /// 外部调用：切换到指定 Tab（0=解析记录，1=抓取记录，2=转换记录）
  void switchToTab(int index) {
    if (index >= 0 && index < 3 && _tabController.index != index) {
      _tabController.animateTo(index);
    }
  }

  // ==================== 多选模式相关 ====================

  /// 进入多选模式
  void _enterSelectionMode(String firstSelectedId) {
    setState(() {
      _isSelectionMode = true;
      _selectedIds
        ..clear()
        ..add(firstSelectedId);
    });
  }

  /// 退出多选模式
  void _exitSelectionMode() {
    setState(() {
      _isSelectionMode = false;
      _selectedIds.clear();
    });
  }

  /// 显示条目长按上下文菜单
  Future<void> _showItemContextMenu(VideoInfo video) async {
    HapticService.mediumImpact();

    final isFavorited = video.isFavorite;
    final result = await ContextMenu.show(
      context,
      title: video.title,
      items: [
        ContextMenuItem(
          id: 'share',
          label: '分享',
          icon: Icons.share_outlined,
          iconColor: Colors.blue,
        ),
        ContextMenuItem(
          id: 'copy',
          label: '复制链接',
          icon: Icons.link_outlined,
          iconColor: Colors.green,
        ),
        ContextMenuItem(
          id: 'favorite',
          label: isFavorited ? '取消收藏' : '收藏',
          icon: isFavorited ? Icons.favorite : Icons.favorite_border,
          iconColor: isFavorited ? Colors.red : Colors.pink,
        ),
        ContextMenuItem(
          id: 'delete',
          label: '删除',
          icon: Icons.delete_outline,
          isDestructive: true,
        ),
      ],
    );

    if (result == null) return;

    switch (result) {
      case 'share':
        Share.share('${video.title}\n${video.url}');
        break;
      case 'copy':
        Clipboard.setData(ClipboardData(text: video.url));
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('链接已复制'), duration: Duration(seconds: 1)),
          );
        }
        break;
      case 'favorite':
        context.read<HistoryProvider>().toggleFavorite(video.id);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(isFavorited ? '已取消收藏' : '已收藏'),
              duration: const Duration(seconds: 1),
            ),
          );
        }
        break;
      case 'delete':
        _deleteParseItemWithUndo(video);
        break;
    }
  }

  /// 删除解析记录并显示撤销提示
  void _deleteParseItemWithUndo(VideoInfo video) {
    final provider = context.read<HistoryProvider>();
    final backup = video;
    provider.removeVideo(video.id);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('已删除'),
        action: SnackBarAction(
          label: '撤销',
          onPressed: () {
            provider.addVideo(backup);
          },
        ),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  /// 删除抓取记录并显示撤销提示
  void _deleteCrawlItemWithUndo(CrawlRecord record) {
    final provider = context.read<CrawlHistoryProvider>();
    final backup = record;
    provider.removeRecord(record.id);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('已删除'),
        action: SnackBarAction(
          label: '撤销',
          onPressed: () {
            provider.addRecord(backup);
          },
        ),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  /// 进入管理模式（点击"管理"按钮）
  void _enterManageMode() {
    // 仅在解析记录 Tab 支持多选模式（当前实现）
    if (_tabController.index != 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('当前 Tab 暂不支持批量管理')),
      );
      return;
    }
    final provider = context.read<HistoryProvider>();
    if (provider.videos.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('暂无记录')),
      );
      return;
    }
    setState(() {
      _isSelectionMode = true;
      _selectedIds.clear();
    });
  }

  /// 切换选中状态
  void _toggleSelection(String id) {
    setState(() {
      if (_selectedIds.contains(id)) {
        _selectedIds.remove(id);
        // 如果全部取消选中，退出多选模式
        if (_selectedIds.isEmpty) {
          _isSelectionMode = false;
        }
      } else {
        _selectedIds.add(id);
      }
    });
  }

  /// 全选/取消全选
  void _toggleSelectAll() {
    final provider = context.read<HistoryProvider>();
    final allIds = provider.videos.map((v) => v.id).toSet();
    setState(() {
      if (_selectedIds.length == allIds.length) {
        _selectedIds.clear();
        _isSelectionMode = false;
      } else {
        _selectedIds = allIds;
      }
    });
  }

  /// 批量删除选中项
  Future<void> _deleteSelected() async {
    if (_selectedIds.isEmpty) return;

    final confirm = await showConfirmDialog(
      context,
      title: '删除选中记录',
      content: '确定要删除选中的 ${_selectedIds.length} 条记录吗？',
      isDestructive: true,
      confirmText: '删除',
    );

    if (!confirm) return;

    if (!mounted) return;
    final ids = _selectedIds.toList();
    await context.read<HistoryProvider>().removeVideos(ids);
    _exitSelectionMode();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('已删除 ${ids.length} 条记录')),
      );
    }
  }

  /// 批量导出选中项
  Future<void> _exportSelected() async {
    if (_selectedIds.isEmpty) return;
    final provider = context.read<HistoryProvider>();
    final selectedVideos =
        provider.videos.where((v) => _selectedIds.contains(v.id)).toList();
    _exportVideosToExcel(selectedVideos, 'selected_parse_history', '选中的解析记录');
  }

  // ==================== 构建 UI ====================

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // 顶部标题栏
        Container(
          decoration: BoxDecoration(
            gradient: AppTheme.primaryGradient,
          ),
          child: SafeArea(
            bottom: false,
            child: Column(
              children: [
                const SizedBox(height: 12),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: _isSelectionMode
                      ? _buildSelectionAppBar()
                      : _buildNormalAppBar(),
                ),
                const SizedBox(height: 12),
                TabBar(
                  controller: _tabController,
                  labelColor: Colors.white,
                  unselectedLabelColor: Colors.white60,
                  indicatorColor: Colors.white,
                  indicatorSize: TabBarIndicatorSize.label,
                  labelStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
                  tabs: const [
                    Tab(text: '解析记录'),
                    Tab(text: '抓取记录'),
                    Tab(text: '转换记录'),
                  ],
                ),
              ],
            ),
          ),
        ),
        Expanded(
          child: TabBarView(
            controller: _tabController,
            children: [
              _buildParseHistoryTab(),
              _buildCrawlHistoryTab(),
              _buildConvertHistoryTab(),
            ],
          ),
        ),
        // 多选模式底部操作栏
        if (_isSelectionMode) _buildSelectionBottomBar(),
      ],
    );
  }

  /// 普通模式顶部栏
  Widget _buildNormalAppBar() {
    return Row(
      children: [
        const Icon(Icons.history, color: Colors.white, size: 22),
        const SizedBox(width: 8),
        const Text(
          '历史记录',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const Spacer(),
        TextButton(
          onPressed: _enterManageMode,
          child: const Text(
            '管理',
            style: TextStyle(color: Colors.white, fontSize: 14),
          ),
        ),
        const SizedBox(width: 4),
        IconButton(
          icon: const Icon(Icons.file_download_outlined, color: Colors.white, size: 22),
          onPressed: _exportCurrentTab,
          tooltip: '导出',
          padding: EdgeInsets.zero,
          constraints: const BoxConstraints(),
        ),
        const SizedBox(width: 8),
        IconButton(
          icon: const Icon(Icons.delete_outline, color: Colors.white, size: 22),
          onPressed: _clearCurrentTab,
          tooltip: '清空',
          padding: EdgeInsets.zero,
          constraints: const BoxConstraints(),
        ),
      ],
    );
  }

  /// 多选模式顶部栏
  Widget _buildSelectionAppBar() {
    final total = context.read<HistoryProvider>().videos.length;
    final isAllSelected = _selectedIds.length == total && total > 0;

    return Row(
      children: [
        IconButton(
          icon: const Icon(Icons.close, color: Colors.white, size: 22),
          onPressed: _exitSelectionMode,
          tooltip: '取消',
          padding: EdgeInsets.zero,
          constraints: const BoxConstraints(),
        ),
        const SizedBox(width: 8),
        Text(
          '已选 ${_selectedIds.length} 项',
          style: const TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const Spacer(),
        TextButton(
          onPressed: _toggleSelectAll,
          child: Text(
            isAllSelected ? '取消全选' : '全选',
            style: const TextStyle(color: Colors.white, fontSize: 14),
          ),
        ),
      ],
    );
  }

  /// 多选模式底部操作栏
  Widget _buildSelectionBottomBar() {
    final hasSelection = _selectedIds.isNotEmpty;
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 10,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
          child: Row(
            children: [
              Expanded(
                child: _buildBottomAction(
                  icon: Icons.select_all,
                  label: '全选',
                  onTap: _toggleSelectAll,
                ),
              ),
              Expanded(
                child: _buildBottomAction(
                  icon: Icons.favorite_border,
                  label: '收藏',
                  onTap: hasSelection ? _toggleFavoriteBatch : null,
                ),
              ),
              Expanded(
                child: _buildBottomAction(
                  icon: Icons.file_download_outlined,
                  label: '导出',
                  onTap: hasSelection ? _showExportOptions : null,
                ),
              ),
              Expanded(
                child: _buildBottomAction(
                  icon: Icons.delete_outline,
                  label: '删除',
                  color: Colors.red,
                  onTap: hasSelection ? _deleteSelected : null,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// 底部操作按钮
  Widget _buildBottomAction({
    required IconData icon,
    required String label,
    required VoidCallback? onTap,
    Color? color,
  }) {
    final isEnabled = onTap != null;
    final iconColor = color ?? (isEnabled
        ? AppTheme.textPrimaryColor(context)
        : Colors.grey.shade400);

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 20, color: iconColor),
            const SizedBox(height: 2),
            Text(
              label,
              style: TextStyle(
                fontSize: 11,
                color: iconColor,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// 批量收藏/取消收藏
  Future<void> _toggleFavoriteBatch() async {
    if (_selectedIds.isEmpty) return;
    final ids = _selectedIds.toList();
    await context.read<HistoryProvider>().toggleFavoriteBatch(ids);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('操作成功')),
    );
  }

  /// 显示导出选项（JSON 或 Excel）
  void _showExportOptions() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 12),
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.grey.shade700
                      : Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              '导出格式',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 8),
            ListTile(
              leading: const Icon(Icons.code, color: Colors.orange),
              title: const Text('导出 JSON'),
              subtitle: Text(
                '导出为 JSON 文本，可分享或复制',
                style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
              ),
              onTap: () {
                Navigator.pop(context);
                _exportSelectedJson();
              },
            ),
            ListTile(
              leading: const Icon(Icons.table_chart_outlined, color: Colors.green),
              title: const Text('导出 Excel'),
              subtitle: Text(
                '导出为 .xlsx 表格文件',
                style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
              ),
              onTap: () {
                Navigator.pop(context);
                _exportSelected();
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  /// 批量导出为 JSON
  Future<void> _exportSelectedJson() async {
    if (_selectedIds.isEmpty) return;
    final provider = context.read<HistoryProvider>();
    final jsonStr = provider.exportBatch(_selectedIds.toList());
    if (jsonStr.isEmpty) return;

    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 12),
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.grey.shade700
                      : Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              'JSON 导出',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 8),
            ListTile(
              leading: const Icon(Icons.copy, color: Colors.blue),
              title: const Text('复制到剪贴板'),
              onTap: () {
                Navigator.pop(context);
                Clipboard.setData(ClipboardData(text: jsonStr));
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('已复制到剪贴板')),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.share, color: Colors.green),
              title: const Text('分享'),
              onTap: () async {
                Navigator.pop(context);
                await Share.share(
                  jsonStr,
                  subject: 'parse_history_${DateTime.now().millisecondsSinceEpoch}.json',
                );
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  // ==================== 解析记录 Tab ====================

  Widget _buildParseHistoryTab() {
    return Consumer<HistoryProvider>(
      builder: (context, provider, child) {
        if (provider.loading && provider.videos.isEmpty) {
          return const ListSkeleton(count: 6);
        }
        if (provider.videos.isEmpty) {
          return EmptyState.noHistory();
        }
        return RefreshIndicator(
          onRefresh: () => provider.refresh(),
          child: ListView.builder(
            controller: _parseScrollController,
            padding: const EdgeInsets.all(12),
            physics: const AlwaysScrollableScrollPhysics(),
            itemCount: provider.videos.length + 1, // +1 用于底部加载指示器
            itemBuilder: (context, index) {
              if (index == provider.videos.length) {
                return _buildLoadMoreIndicator(provider);
              }
              final video = provider.videos[index];
              return _buildParseRecordItem(context, video, index);
            },
          ),
        );
      },
    );
  }

  /// 底部加载更多指示器
  Widget _buildLoadMoreIndicator(HistoryProvider provider) {
    if (provider.loadingMore) {
      return Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        alignment: Alignment.center,
        child: const SizedBox(
          width: 24,
          height: 24,
          child: CircularProgressIndicator(strokeWidth: 2),
        ),
      );
    }
    if (!provider.hasMore && provider.videos.isNotEmpty) {
      return Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        alignment: Alignment.center,
        child: Text(
          '没有更多了',
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey.shade500,
          ),
        ),
      );
    }
    return const SizedBox.shrink();
  }

  Widget _buildParseRecordItem(BuildContext context, VideoInfo video, int index) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
    final fillColor = isDark ? const Color(0xFF1E293B) : Colors.grey.shade50;
    final isSelected = _selectedIds.contains(video.id);

    // 多选模式下不使用左滑操作
    if (_isSelectionMode) {
      return _buildSelectableParseItem(video, isSelected, isDark, secondaryTextColor, fillColor);
    }

    // 普通模式：左滑操作 + 长按菜单
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: SlidableItem(
        actions: [
          SlideAction(
            label: '收藏',
            icon: video.isFavorite ? Icons.favorite : Icons.favorite_border,
            color: video.isFavorite ? Colors.grey : Colors.red,
            onTap: () {
              context.read<HistoryProvider>().toggleFavorite(video.id);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(video.isFavorite ? '已取消收藏' : '已收藏'),
                  duration: const Duration(seconds: 1),
                ),
              );
            },
          ),
          SlideAction(
            label: '复制',
            icon: Icons.link,
            color: Colors.blue,
            onTap: () {
              Clipboard.setData(ClipboardData(text: video.url));
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('链接已复制'), duration: Duration(seconds: 1)),
              );
            },
          ),
          SlideAction(
            label: '删除',
            icon: Icons.delete,
            color: Colors.red,
            onTap: () => _deleteParseItemWithUndo(video),
          ),
        ],
        child: _buildParseCard(video, isDark, secondaryTextColor, fillColor),
      ),
    );
  }

  /// 多选模式下的条目
  Widget _buildSelectableParseItem(
    VideoInfo video,
    bool isSelected,
    bool isDark,
    Color secondaryTextColor,
    Color fillColor,
  ) {
    return InkWell(
      onTap: () => _toggleSelection(video.id),
      borderRadius: BorderRadius.circular(12),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        child: Row(
          children: [
            // 选中指示器
            Container(
              width: 24,
              height: 24,
              margin: const EdgeInsets.only(right: 10),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isSelected ? AppTheme.primaryColor : Colors.transparent,
                border: Border.all(
                  color: isSelected ? AppTheme.primaryColor : Colors.grey.shade400,
                  width: 2,
                ),
              ),
              child: isSelected
                  ? const Icon(Icons.check, color: Colors.white, size: 16)
                  : null,
            ),
            Expanded(
              child: _buildParseCardContent(video, isDark, secondaryTextColor, fillColor),
            ),
          ],
        ),
      ),
    );
  }

  /// 解析记录卡片
  Widget _buildParseCard(
    VideoInfo video,
    bool isDark,
    Color secondaryTextColor,
    Color fillColor,
  ) {
    return Card(
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: isDark ? 0 : null,
      color: Theme.of(context).cardColor,
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => _showParseDetail(video),
        onLongPress: () => _showItemContextMenu(video),
        child: _buildParseCardContent(video, isDark, secondaryTextColor, fillColor),
      ),
    );
  }

  /// 解析记录卡片内容
  Widget _buildParseCardContent(
    VideoInfo video,
    bool isDark,
    Color secondaryTextColor,
    Color fillColor,
  ) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Row(
        children: [
          // 懒加载封面图
          _buildLazyCover(video, fillColor, secondaryTextColor),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  video.title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                    color: isDark ? Colors.white : Colors.black87,
                  ),
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    PlatformBadge(platform: video.platform, size: 12),
                    const SizedBox(width: 6),
                    Text(
                      _formatTime(video.parsedAt),
                      style: TextStyle(
                        fontSize: 11,
                        color: secondaryTextColor,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Icon(Icons.chevron_right, color: secondaryTextColor, size: 20),
        ],
      ),
    );
  }

  /// 懒加载封面图
  Widget _buildLazyCover(VideoInfo video, Color fillColor, Color iconColor) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(8),
      child: Container(
        width: 70,
        height: 56,
        color: fillColor,
        child: video.cover.isNotEmpty
            ? _LazyNetworkImage(
                url: video.cover,
                fit: BoxFit.cover,
                placeholder: Icon(Icons.image, color: iconColor, size: 24),
              )
            : Icon(Icons.image, color: iconColor, size: 24),
      ),
    );
  }

  void _showParseDetail(VideoInfo video) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final dividerColor = isDark ? Colors.grey.shade700 : Colors.grey.shade300;
        return DraggableScrollableSheet(
          initialChildSize: 0.7,
          maxChildSize: 0.95,
          minChildSize: 0.5,
          builder: (_, controller) => Container(
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
            ),
            child: ListView(
              controller: controller,
              padding: const EdgeInsets.all(20),
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: dividerColor,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  video.title,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: isDark ? Colors.white : Colors.black87,
                  ),
                ),
                const SizedBox(height: 12),
                _detailRow(context, '平台', video.platformName),
                _detailRow(context, '类型', video.typeName),
                _detailRow(context, '作者', video.author),
                _detailRow(context, '视频ID', video.id),
                _detailRow(context, '解析时间', _formatDateTime(video.parsedAt)),
                if (video.durationSeconds != null)
                  _detailRow(context, '时长', '${video.durationSeconds}秒'),
                if (video.isImage)
                  _detailRow(context, '图片数量', '${video.imageCount}张'),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () {
                          Clipboard.setData(ClipboardData(text: video.url));
                          Navigator.pop(context);
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('链接已复制')),
                          );
                        },
                        icon: const Icon(Icons.copy, size: 16),
                        label: const Text('复制原链接'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ==================== 抓取记录 Tab ====================

  Widget _buildCrawlHistoryTab() {
    return Consumer<CrawlHistoryProvider>(
      builder: (context, provider, child) {
        if (provider.loading) {
          return const ListSkeleton(count: 6);
        }
        if (provider.records.isEmpty) {
          return EmptyState.noCrawlHistory();
        }

        // 按 batchId 分组记录
        final groupedItems = _groupRecordsByBatch(provider.records);

        return RefreshIndicator(
          onRefresh: () => provider.refresh(),
          child: ListView.builder(
            controller: _crawlScrollController,
            padding: const EdgeInsets.all(12),
            physics: const AlwaysScrollableScrollPhysics(),
            itemCount: groupedItems.length + 1, // +1 用于底部加载指示器
            itemBuilder: (context, index) {
              if (index == groupedItems.length) {
                return _buildCrawlLoadMoreIndicator(provider);
              }
              final item = groupedItems[index];
              if (item is _SingleRecordItem) {
                return _buildCrawlRecordItem(context, item.record);
              } else if (item is _BatchRecordItem) {
                return _buildBatchGroupItem(context, item);
              }
              return const SizedBox.shrink();
            },
          ),
        );
      },
    );
  }

  /// 抓取记录底部加载更多指示器
  Widget _buildCrawlLoadMoreIndicator(CrawlHistoryProvider provider) {
    if (provider.loadingMore) {
      return Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        alignment: Alignment.center,
        child: const SizedBox(
          width: 24,
          height: 24,
          child: CircularProgressIndicator(strokeWidth: 2),
        ),
      );
    }
    if (!provider.hasMore && provider.records.isNotEmpty) {
      return Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        alignment: Alignment.center,
        child: Text(
          '没有更多了',
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey.shade500,
          ),
        ),
      );
    }
    return const SizedBox.shrink();
  }

  List<dynamic> _groupRecordsByBatch(List<CrawlRecord> records) {
    final batchMap = <String, List<CrawlRecord>>{};
    final singleRecords = <CrawlRecord>[];

    for (final record in records) {
      if (record.batchId != null && record.batchId!.isNotEmpty) {
        batchMap.putIfAbsent(record.batchId!, () => []).add(record);
      } else {
        singleRecords.add(record);
      }
    }

    final result = <dynamic>[];

    for (final record in singleRecords) {
      result.add(_SingleRecordItem(record));
    }

    batchMap.forEach((batchId, batchRecords) {
      result.add(_BatchRecordItem(batchId, batchRecords));
    });

    result.sort((a, b) {
      DateTime timeA;
      DateTime timeB;
      if (a is _SingleRecordItem) {
        timeA = a.record.crawledAt;
      } else if (a is _BatchRecordItem) {
        timeA = a.records.first.crawledAt;
      } else {
        timeA = DateTime.now();
      }
      if (b is _SingleRecordItem) {
        timeB = b.record.crawledAt;
      } else if (b is _BatchRecordItem) {
        timeB = b.records.first.crawledAt;
      } else {
        timeB = DateTime.now();
      }
      return timeB.compareTo(timeA);
    });

    return result;
  }

  Widget _buildBatchGroupItem(BuildContext context, _BatchRecordItem batch) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
    final tertiaryTextColor = isDark ? Colors.grey.shade500 : Colors.grey.shade400;
    final accentOpacity = isDark ? 0.2 : 0.1;
    final isExpanded = _expandedBatches.contains(batch.batchId);
    final records = batch.records;
    final isAuthor = records.first.isAuthor;
    final latestTime = records.first.crawledAt;

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: isDark ? 0 : null,
      color: Theme.of(context).cardColor,
      child: Column(
        children: [
          InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: () {
              setState(() {
                if (isExpanded) {
                  _expandedBatches.remove(batch.batchId);
                } else {
                  _expandedBatches.add(batch.batchId);
                }
              });
            },
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      color: Colors.orange.withOpacity(accentOpacity),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(
                      Icons.playlist_add_check,
                      color: Colors.orange,
                      size: 24,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '批量抓取 - ${records.length} 条',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                            color: isDark ? Colors.white : Colors.black87,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 6, vertical: 1),
                              decoration: BoxDecoration(
                                color: isAuthor
                                    ? Colors.purple.withOpacity(accentOpacity)
                                    : Colors.blue.withOpacity(accentOpacity),
                                borderRadius: BorderRadius.circular(3),
                              ),
                              child: Text(
                                isAuthor ? '作者信息' : '视频信息',
                                style: TextStyle(
                                  fontSize: 10,
                                  color: isAuthor ? Colors.purple : Colors.blue,
                                ),
                              ),
                            ),
                            const SizedBox(width: 6),
                            Expanded(
                              child: Text(
                                '${records.first.platformName} 等',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontSize: 11,
                                  color: secondaryTextColor,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Text(
                          _formatTime(latestTime),
                          style: TextStyle(
                            fontSize: 11,
                            color: tertiaryTextColor,
                          ),
                        ),
                      ],
                    ),
                  ),
                  // 右上角：复制字段按钮
                  InkWell(
                    onTap: () {
                      _showBatchCopyDialog(records);
                    },
                    borderRadius: BorderRadius.circular(6),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: AppTheme.primaryColor.withOpacity(isDark ? 0.18 : 0.1),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(
                          color: AppTheme.primaryColor.withOpacity(0.4),
                          width: 0.8,
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.content_copy,
                              size: 12, color: AppTheme.primaryColor),
                          const SizedBox(width: 3),
                          Text(
                            '复制字段',
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w500,
                              color: isDark
                                  ? AppTheme.primaryColor.withOpacity(0.95)
                                  : AppTheme.primaryColorDark,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 6),
                  Icon(
                    isExpanded ? Icons.expand_less : Icons.expand_more,
                    color: secondaryTextColor,
                    size: 24,
                  ),
                ],
              ),
            ),
          ),
          if (isExpanded) ...[
            Divider(height: 1, indent: 72, color: isDark ? Colors.grey.shade700 : Colors.grey.shade300),
            ...records.asMap().entries.map((entry) {
              final record = entry.value;
              return InkWell(
                onTap: () => _showCrawlDetail(record),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(24, 10, 12, 10),
                  child: Row(
                    children: [
                      Container(
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                          color: record.isAuthor
                              ? Colors.purple.withOpacity(accentOpacity)
                              : Colors.blue.withOpacity(accentOpacity),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Icon(
                          record.isAuthor
                              ? Icons.person_outline
                              : Icons.play_circle_outline,
                          color: record.isAuthor
                              ? Colors.purple
                              : Colors.blue,
                          size: 18,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              record.displayTitle,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w500,
                                color: isDark ? Colors.white : Colors.black87,
                              ),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              record.displaySubtitle,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 11,
                                color: secondaryTextColor,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Icon(Icons.chevron_right,
                          color: secondaryTextColor, size: 18),
                    ],
                  ),
                ),
              );
            }),
            if (records.isNotEmpty) ...[
              const SizedBox(height: 8),
              Divider(height: 1, indent: 72, color: isDark ? Colors.grey.shade700 : Colors.grey.shade300),
              Padding(
                padding: const EdgeInsets.fromLTRB(24, 10, 12, 12),
                child: Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => _showBatchCopyDialog(records),
                        icon: const Icon(Icons.copy_all, size: 16),
                        label: Text('批量复制（${records.length}条）'),
                        style: OutlinedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => _exportBatchToJson(records),
                        icon: const Icon(Icons.ios_share, size: 16),
                        label: const Text('导出'),
                        style: OutlinedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ],
      ),
    );
  }

  Widget _buildCrawlRecordItem(BuildContext context, CrawlRecord record) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
    final tertiaryTextColor = isDark ? Colors.grey.shade500 : Colors.grey.shade400;
    final accentOpacity = isDark ? 0.2 : 0.1;
    final isAuthor = record.isAuthor;

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: SlidableItem(
        actions: [
          SlideAction(
            label: '收藏',
            icon: record.isFavorite ? Icons.favorite : Icons.favorite_border,
            color: record.isFavorite ? Colors.grey : Colors.red,
            onTap: () {
              context.read<CrawlHistoryProvider>().toggleFavorite(record.id);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(record.isFavorite ? '已取消收藏' : '已收藏'),
                  duration: const Duration(seconds: 1),
                ),
              );
            },
          ),
          SlideAction(
            label: '复制',
            icon: Icons.link,
            color: Colors.blue,
            onTap: () {
              Clipboard.setData(ClipboardData(text: record.url));
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('链接已复制'), duration: Duration(seconds: 1)),
              );
            },
          ),
          SlideAction(
            label: '删除',
            icon: Icons.delete,
            color: Colors.red,
            onTap: () => _deleteCrawlItemWithUndo(record),
          ),
        ],
        child: Card(
          margin: EdgeInsets.zero,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          elevation: isDark ? 0 : null,
          color: Theme.of(context).cardColor,
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () => _showCrawlDetail(record),
          onLongPress: () => _showDeleteCrawlConfirm(record),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: isAuthor
                        ? Colors.purple.withOpacity(accentOpacity)
                        : Colors.blue.withOpacity(accentOpacity),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(
                    isAuthor ? Icons.person_outline : Icons.play_circle_outline,
                    color: isAuthor ? Colors.purple : Colors.blue,
                    size: 24,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        record.displayTitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                          color: isDark ? Colors.white : Colors.black87,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Row(
                        children: [
                          PlatformBadge(platform: record.platform, size: 12),
                          const SizedBox(width: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 6, vertical: 1),
                            decoration: BoxDecoration(
                              color: isAuthor
                                  ? Colors.purple.withOpacity(accentOpacity)
                                  : Colors.blue.withOpacity(accentOpacity),
                              borderRadius: BorderRadius.circular(3),
                            ),
                            child: Text(
                              record.typeLabel,
                              style: TextStyle(
                                fontSize: 10,
                                color: isAuthor
                                    ? Colors.purple
                                    : Colors.blue,
                              ),
                            ),
                          ),
                          const SizedBox(width: 6),
                          Expanded(
                            child: Text(
                              record.displaySubtitle,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 11,
                                color: secondaryTextColor,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        _formatTime(record.crawledAt),
                        style: TextStyle(
                          fontSize: 11,
                          color: tertiaryTextColor,
                        ),
                      ),
                    ],
                  ),
                ),
                Icon(Icons.chevron_right, color: secondaryTextColor, size: 20),
              ],
            ),
          ),
        ),
      ),
    ),
    );
  }

  void _showDeleteCrawlConfirm(CrawlRecord record) {
    _showCrawlActionMenu(record);
  }

  /// 显示抓取记录的长按操作菜单
  void _showCrawlActionMenu(CrawlRecord record) {
    HapticService.mediumImpact();
    final isFav = record.isFavorite;

    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 12),
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.grey.shade700
                      : Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 8),
            ListTile(
              leading: const Icon(Icons.link, color: Colors.blue),
              title: const Text('复制链接'),
              onTap: () {
                Navigator.pop(context);
                Clipboard.setData(ClipboardData(text: record.url));
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('链接已复制')),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.share, color: Colors.green),
              title: const Text('分享'),
              onTap: () {
                Navigator.pop(context);
                Share.share(record.url);
              },
            ),
            ListTile(
              leading: Icon(
                isFav ? Icons.favorite : Icons.favorite_border,
                color: isFav ? Colors.red : Colors.grey,
              ),
              title: Text(isFav ? '取消收藏' : '收藏'),
              onTap: () {
                Navigator.pop(context);
                context.read<CrawlHistoryProvider>().toggleFavorite(record.id);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(isFav ? '已取消收藏' : '已收藏'),
                    duration: const Duration(seconds: 1),
                  ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete_outline, color: Colors.red),
              title: const Text('删除', style: TextStyle(color: Colors.red)),
              onTap: () {
                Navigator.pop(context);
                _deleteCrawlItemWithUndo(record);
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  void _showCrawlDetail(CrawlRecord record) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        final dividerColor = isDark ? Colors.grey.shade700 : Colors.grey.shade300;
        final accentOpacity = isDark ? 0.2 : 0.1;
        return DraggableScrollableSheet(
          initialChildSize: 0.7,
          maxChildSize: 0.95,
          minChildSize: 0.5,
          builder: (_, controller) => Container(
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
            ),
            child: ListView(
              controller: controller,
              padding: const EdgeInsets.all(20),
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: dividerColor,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: record.isAuthor
                            ? Colors.purple.withOpacity(accentOpacity)
                            : Colors.blue.withOpacity(accentOpacity),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        record.typeLabel,
                        style: TextStyle(
                          fontSize: 12,
                          color: record.isAuthor
                              ? Colors.purple
                              : Colors.blue,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    PlatformBadge(platform: record.platform, size: 12),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  record.displayTitle,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: isDark ? Colors.white : Colors.black87,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  '抓取时间：${_formatDateTime(record.crawledAt)}',
                  style: TextStyle(fontSize: 12, color: secondaryTextColor),
                ),
                const SizedBox(height: 16),
                Divider(height: 1, color: dividerColor),
                const SizedBox(height: 12),
                ...record.fields.map((f) => Padding(
                      padding: const EdgeInsets.symmetric(vertical: 6),
                      child: _detailRow(context, f.key, f.value),
                    )),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () {
                          final text = record.fields
                              .map((f) => '${f.key}：${f.value}')
                              .join('\n');
                          Clipboard.setData(ClipboardData(text: text));
                          Navigator.pop(context);
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('已复制全部信息')),
                          );
                        },
                        icon: const Icon(Icons.copy, size: 16),
                        label: const Text('复制全部'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ==================== 批量复制功能 ====================

  /// 显示批量复制字段选择对话框
  void _showBatchCopyDialog(List<CrawlRecord> records) {
    if (records.isEmpty) return;

    // 收集所有记录中出现过的字段（保持顺序，用第一条的顺序作为基础）
    final fieldLabels = <String>[];
    final fieldKeysSet = <String>{};

    for (final record in records) {
      for (final field in record.fields) {
        if (fieldKeysSet.add(field.key)) {
          fieldLabels.add(field.key);
        }
      }
    }

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        final dividerColor = isDark ? Colors.grey.shade700 : Colors.grey.shade300;

        return StatefulBuilder(
          builder: (context, setModalState) {
            return DraggableScrollableSheet(
              initialChildSize: 0.6,
              maxChildSize: 0.9,
              minChildSize: 0.4,
              builder: (_, controller) => Container(
                decoration: BoxDecoration(
                  color: Theme.of(context).cardColor,
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
                ),
                child: Column(
                  children: [
                    const SizedBox(height: 12),
                    Center(
                      child: Container(
                        width: 40,
                        height: 4,
                        decoration: BoxDecoration(
                          color: dividerColor,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Row(
                        children: [
                          const Text(
                            '批量复制',
                            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                          const Spacer(),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: Colors.orange.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(
                              '${records.length} 条记录',
                              style: const TextStyle(
                                fontSize: 12,
                                color: Colors.orange,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 8),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Text(
                        '选择要复制的字段，或复制全部字段',
                        style: TextStyle(fontSize: 13, color: secondaryTextColor),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Divider(height: 1, color: dividerColor),
                    // 全部字段选项
                    InkWell(
                      onTap: () {
                        _batchCopyAllFields(records);
                        Navigator.pop(context);
                      },
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                        child: Row(
                          children: [
                            Container(
                              width: 36,
                              height: 36,
                              decoration: BoxDecoration(
                                color: Colors.blue.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: const Icon(Icons.copy_all, color: Colors.blue, size: 20),
                            ),
                            const SizedBox(width: 12),
                            const Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    '复制全部字段',
                                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
                                  ),
                                  SizedBox(height: 2),
                                  Text(
                                    '每条记录的所有字段，key：value 格式',
                                    style: TextStyle(fontSize: 12, color: Colors.grey),
                                  ),
                                ],
                              ),
                            ),
                            Icon(Icons.chevron_right, color: secondaryTextColor, size: 20),
                          ],
                        ),
                      ),
                    ),
                    Divider(height: 1, indent: 68, color: dividerColor),
                    // 单字段列表
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 12, 20, 8),
                      child: Text(
                        '按字段复制（每行一个值）',
                        style: TextStyle(fontSize: 12, color: secondaryTextColor),
                      ),
                    ),
                    Expanded(
                      child: ListView.builder(
                        controller: controller,
                        padding: const EdgeInsets.only(bottom: 20),
                        itemCount: fieldLabels.length,
                        itemBuilder: (context, index) {
                          final label = fieldLabels[index];
                          // 计算该字段有多少条记录有值
                          int nonEmptyCount = 0;
                          for (final r in records) {
                            final val = r.data[label]?.toString() ?? '';
                            if (val.isNotEmpty) nonEmptyCount++;
                          }
                          return InkWell(
                            onTap: () {
                              _batchCopySingleField(records, label);
                              Navigator.pop(context);
                            },
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                              child: Row(
                                children: [
                                  Container(
                                    width: 36,
                                    height: 36,
                                    decoration: BoxDecoration(
                                      color: Colors.green.withOpacity(0.1),
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: const Icon(Icons.text_fields, color: Colors.green, size: 18),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          label,
                                          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
                                        ),
                                        const SizedBox(height: 2),
                                        Text(
                                          '$nonEmptyCount / ${records.length} 条有值',
                                          style: TextStyle(fontSize: 12, color: secondaryTextColor),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Icon(Icons.chevron_right, color: secondaryTextColor, size: 20),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  /// 批量复制全部字段
  void _batchCopyAllFields(List<CrawlRecord> records) {
    final buffer = StringBuffer();
    for (var i = 0; i < records.length; i++) {
      if (i > 0) buffer.writeln('---');
      for (final field in records[i].fields) {
        buffer.writeln('${field.key}：${field.value}');
      }
    }
    Clipboard.setData(ClipboardData(text: buffer.toString()));
    HapticService.mediumImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('已复制 ${records.length} 条记录的全部字段')),
    );
  }

  /// 批量复制单个字段
  void _batchCopySingleField(List<CrawlRecord> records, String fieldLabel) {
    final values = <String>[];
    for (final record in records) {
      final val = record.data[fieldLabel]?.toString() ?? '';
      values.add(val);
    }
    // 过滤空值？保留空值以保持记录顺序，用 - 占位
    final text = values.map((v) => v.isEmpty ? '-' : v).join('\n');
    Clipboard.setData(ClipboardData(text: text));
    HapticService.mediumImpact();
    final nonEmpty = values.where((v) => v.isNotEmpty).length;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('已复制 ${records.length} 条记录的「$fieldLabel」字段（$nonEmpty 条有值）')),
    );
  }

  /// 批量导出 JSON
  void _exportBatchToJson(List<CrawlRecord> records) {
    final jsonList = records.map((r) => r.toJson()).toList();
    final jsonStr = _prettyJson(jsonList);

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        return SafeArea(
          child: Container(
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
            ),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: isDark ? Colors.grey.shade700 : Colors.grey.shade300,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    '批量导出',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 16),
                  ListTile(
                    leading: const Icon(Icons.copy, color: Colors.blue),
                    title: const Text('复制 JSON'),
                    subtitle: Text('${records.length} 条记录', style: TextStyle(fontSize: 12, color: secondaryTextColor)),
                    onTap: () {
                      Clipboard.setData(ClipboardData(text: jsonStr));
                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('已复制到剪贴板')),
                      );
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.save_alt, color: Colors.green),
                    title: const Text('保存为文件'),
                    subtitle: Text('JSON 格式', style: TextStyle(fontSize: 12, color: secondaryTextColor)),
                    onTap: () async {
                      Navigator.pop(context);
                      await _saveJsonFile(jsonStr, 'batch_${records.length}.json');
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.share, color: Colors.purple),
                    title: const Text('分享'),
                    subtitle: Text('通过系统分享', style: TextStyle(fontSize: 12, color: secondaryTextColor)),
                    onTap: () {
                      Navigator.pop(context);
                      Share.share(jsonStr);
                    },
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ==================== 转换记录 Tab ====================

  Widget _buildConvertHistoryTab() {
    return Consumer<ConvertHistoryProvider>(
      builder: (context, provider, child) {
        if (provider.loading) {
          return const ListSkeleton(count: 6);
        }
        if (provider.records.isEmpty) {
          return _buildConvertEmptyState();
        }

        // 按 batchId 分组
        final groupedItems = _groupConvertRecordsByBatch(provider.records);

        return RefreshIndicator(
          onRefresh: () => provider.refresh(),
          child: ListView.builder(
            controller: _convertScrollController,
            padding: const EdgeInsets.all(12),
            physics: const AlwaysScrollableScrollPhysics(),
            itemCount: groupedItems.length + 1, // +1 用于底部加载指示器
            itemBuilder: (context, index) {
              if (index == groupedItems.length) {
                return _buildConvertLoadMoreIndicator(provider);
              }
              final item = groupedItems[index];
              if (item is _SingleConvertItem) {
                return _buildConvertRecordItem(context, item.record);
              } else if (item is _BatchConvertItem) {
                return _buildConvertBatchGroupItem(context, item);
              }
              return const SizedBox.shrink();
            },
          ),
        );
      },
    );
  }

  /// 转换记录底部加载更多指示器
  Widget _buildConvertLoadMoreIndicator(ConvertHistoryProvider provider) {
    if (provider.loadingMore) {
      return Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        alignment: Alignment.center,
        child: const SizedBox(
          width: 24,
          height: 24,
          child: CircularProgressIndicator(strokeWidth: 2),
        ),
      );
    }
    if (!provider.hasMore && provider.records.isNotEmpty) {
      return Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        alignment: Alignment.center,
        child: Text(
          '没有更多了',
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey.shade500,
          ),
        ),
      );
    }
    return const SizedBox.shrink();
  }

  Widget _buildConvertEmptyState() {
    return EmptyState.noConvert();
  }

  List<dynamic> _groupConvertRecordsByBatch(List<ConvertRecord> records) {
    final batchMap = <String, List<ConvertRecord>>{};
    final singleRecords = <ConvertRecord>[];

    for (final record in records) {
      if (record.batchId != null && record.batchId!.isNotEmpty) {
        batchMap.putIfAbsent(record.batchId!, () => []).add(record);
      } else {
        singleRecords.add(record);
      }
    }

    final result = <dynamic>[];

    for (final record in singleRecords) {
      result.add(_SingleConvertItem(record));
    }

    batchMap.forEach((batchId, batchRecords) {
      result.add(_BatchConvertItem(batchId, batchRecords));
    });

    result.sort((a, b) {
      DateTime timeA;
      DateTime timeB;
      if (a is _SingleConvertItem) {
        timeA = a.record.convertedAt;
      } else if (a is _BatchConvertItem) {
        timeA = a.records.first.convertedAt;
      } else {
        timeA = DateTime.now();
      }
      if (b is _SingleConvertItem) {
        timeB = b.record.convertedAt;
      } else if (b is _BatchConvertItem) {
        timeB = b.records.first.convertedAt;
      } else {
        timeB = DateTime.now();
      }
      return timeB.compareTo(timeA);
    });

    return result;
  }

  Widget _buildConvertBatchGroupItem(BuildContext context, _BatchConvertItem batch) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
    final tertiaryTextColor = isDark ? Colors.grey.shade500 : Colors.grey.shade400;
    final accentOpacity = isDark ? 0.2 : 0.1;
    final isExpanded = _expandedBatches.contains('conv_${batch.batchId}');
    final records = batch.records;
    final isToShort = records.first.isToShort;
    final latestTime = records.first.convertedAt;

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: isDark ? 0 : null,
      color: Theme.of(context).cardColor,
      child: Column(
        children: [
          InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: () {
              setState(() {
                final key = 'conv_${batch.batchId}';
                if (isExpanded) {
                  _expandedBatches.remove(key);
                } else {
                  _expandedBatches.add(key);
                }
              });
            },
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      color: Colors.teal.withOpacity(accentOpacity),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(
                      Icons.swap_horiz,
                      color: Colors.teal,
                      size: 24,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '批量转换 - ${records.length} 条',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                            color: isDark ? Colors.white : Colors.black87,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 6, vertical: 1),
                              decoration: BoxDecoration(
                                color: isToShort
                                    ? Colors.blue.withOpacity(accentOpacity)
                                    : Colors.green.withOpacity(accentOpacity),
                                borderRadius: BorderRadius.circular(3),
                              ),
                              child: Text(
                                isToShort ? '转短链' : '转长链',
                                style: TextStyle(
                                  fontSize: 10,
                                  color: isToShort ? Colors.blue : Colors.green,
                                ),
                              ),
                            ),
                            const SizedBox(width: 6),
                            Expanded(
                              child: Text(
                                '${records.first.platformName} 等',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontSize: 11,
                                  color: secondaryTextColor,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Text(
                          _formatTime(latestTime),
                          style: TextStyle(
                            fontSize: 11,
                            color: tertiaryTextColor,
                          ),
                        ),
                      ],
                    ),
                  ),
                  // 右上角：复制字段按钮
                  InkWell(
                    onTap: () {
                      _showConvertBatchCopyDialog(records);
                    },
                    borderRadius: BorderRadius.circular(6),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: AppTheme.primaryColor.withOpacity(isDark ? 0.18 : 0.1),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(
                          color: AppTheme.primaryColor.withOpacity(0.4),
                          width: 0.8,
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.content_copy,
                              size: 12, color: AppTheme.primaryColor),
                          const SizedBox(width: 3),
                          Text(
                            '复制字段',
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w500,
                              color: isDark
                                  ? AppTheme.primaryColor.withOpacity(0.95)
                                  : AppTheme.primaryColorDark,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 6),
                  Icon(
                    isExpanded ? Icons.expand_less : Icons.expand_more,
                    color: secondaryTextColor,
                    size: 24,
                  ),
                ],
              ),
            ),
          ),
          if (isExpanded) ...[
            Divider(height: 1, indent: 72, color: isDark ? Colors.grey.shade700 : Colors.grey.shade300),
            ...records.asMap().entries.map((entry) {
              final record = entry.value;
              return InkWell(
                onTap: () => _showConvertDetail(record),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(24, 10, 12, 10),
                  child: Row(
                    children: [
                      Container(
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                          color: record.isToShort
                              ? Colors.blue.withOpacity(accentOpacity)
                              : Colors.green.withOpacity(accentOpacity),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Icon(
                          record.isToShort ? Icons.compress : Icons.open_in_new,
                          color: record.isToShort ? Colors.blue : Colors.green,
                          size: 18,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              record.displayTitle,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w500,
                                color: isDark ? Colors.white : Colors.black87,
                              ),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              record.resultUrl,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 11,
                                color: secondaryTextColor,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Icon(Icons.chevron_right,
                          color: secondaryTextColor, size: 18),
                    ],
                  ),
                ),
              );
            }),
          ],
        ],
      ),
    );
  }

  Widget _buildConvertRecordItem(BuildContext context, ConvertRecord record) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
    final tertiaryTextColor = isDark ? Colors.grey.shade500 : Colors.grey.shade400;
    final accentOpacity = isDark ? 0.2 : 0.1;

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: isDark ? 0 : null,
      color: Theme.of(context).cardColor,
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => _showConvertDetail(record),
        onLongPress: () => _showDeleteConvertConfirm(record),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: record.isToShort
                      ? Colors.blue.withOpacity(accentOpacity)
                      : Colors.green.withOpacity(accentOpacity),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(
                  record.isToShort ? Icons.compress : Icons.open_in_new,
                  color: record.isToShort ? Colors.blue : Colors.green,
                  size: 24,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      record.displayTitle,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                        color: isDark ? Colors.white : Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        PlatformBadge(platform: record.platform, size: 12),
                        const SizedBox(width: 6),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 1),
                          decoration: BoxDecoration(
                            color: record.isToShort
                                ? Colors.blue.withOpacity(accentOpacity)
                                : Colors.green.withOpacity(accentOpacity),
                            borderRadius: BorderRadius.circular(3),
                          ),
                          child: Text(
                            record.typeLabel,
                            style: TextStyle(
                              fontSize: 10,
                              color: record.isToShort ? Colors.blue : Colors.green,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _formatTime(record.convertedAt),
                      style: TextStyle(
                        fontSize: 11,
                        color: tertiaryTextColor,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(Icons.chevron_right, color: secondaryTextColor, size: 20),
            ],
          ),
        ),
      ),
    );
  }

  void _showDeleteConvertConfirm(ConvertRecord record) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('删除记录'),
        content: const Text('确定要删除这条转换记录吗？'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () async {
              Navigator.of(context).pop();
              await context.read<ConvertHistoryProvider>().removeRecord(record.id);
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('已删除')),
                );
              }
            },
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('删除'),
          ),
        ],
      ),
    );
  }

  /// 转换批次 - 显示复制字段选择对话框
  void _showConvertBatchCopyDialog(List<ConvertRecord> records) {
    if (records.isEmpty) return;
    final successRecords = records.where((r) => r.success).toList();
    if (successRecords.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('暂无可复制的记录')),
      );
      return;
    }

    final fields = <_ConvertBatchCopyField>[
      _ConvertBatchCopyField('resultUrl', '转换后链接', (r) => r.resultUrl),
      _ConvertBatchCopyField('originalUrl', '原始链接', (r) => r.originalUrl),
      _ConvertBatchCopyField('platform', '平台', (r) => r.platformName),
    ];

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        final dividerColor = isDark ? Colors.grey.shade700 : Colors.grey.shade300;

        return StatefulBuilder(
          builder: (context, setModalState) {
            return DraggableScrollableSheet(
              initialChildSize: 0.5,
              maxChildSize: 0.75,
              minChildSize: 0.35,
              builder: (_, controller) => Container(
                decoration: BoxDecoration(
                  color: Theme.of(context).cardColor,
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
                ),
                child: Column(
                  children: [
                    const SizedBox(height: 12),
                    Center(
                      child: Container(
                        width: 40,
                        height: 4,
                        decoration: BoxDecoration(
                          color: dividerColor,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Row(
                        children: [
                          const Text(
                            '批量复制',
                            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                          const Spacer(),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: Colors.orange.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(
                              '${successRecords.length} 条记录',
                              style: const TextStyle(
                                fontSize: 12,
                                color: Colors.orange,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 8),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Text(
                        '选择要复制的字段，每条一行',
                        style: TextStyle(fontSize: 13, color: secondaryTextColor),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Divider(height: 1, color: dividerColor),
                    // 全部转换结果
                    InkWell(
                      onTap: () {
                        _batchCopyConvertAll(successRecords);
                        Navigator.pop(context);
                      },
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                        child: Row(
                          children: [
                            Container(
                              width: 36,
                              height: 36,
                              decoration: BoxDecoration(
                                color: Colors.blue.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: const Icon(Icons.copy_all, color: Colors.blue, size: 20),
                            ),
                            const SizedBox(width: 12),
                            const Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('转换后链接（全部）',
                                      style: TextStyle(
                                          fontSize: 15, fontWeight: FontWeight.w600)),
                                  SizedBox(height: 2),
                                  Text('快速复制所有转换结果链接',
                                      style: TextStyle(fontSize: 12)),
                                ],
                              ),
                            ),
                            Icon(Icons.chevron_right,
                                color: secondaryTextColor, size: 18),
                          ],
                        ),
                      ),
                    ),
                    Divider(height: 1, color: dividerColor, indent: 68),
                    // 单字段列表
                    Expanded(
                      child: ListView.builder(
                        controller: controller,
                        shrinkWrap: true,
                        itemCount: fields.length,
                        itemBuilder: (context, index) {
                          final field = fields[index];
                          return InkWell(
                            onTap: () {
                              _batchCopyConvertField(successRecords, field);
                              Navigator.pop(context);
                            },
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 20, vertical: 13),
                              child: Row(
                                children: [
                                  Container(
                                    width: 36,
                                    height: 36,
                                    decoration: BoxDecoration(
                                      color: AppTheme.primaryColor.withOpacity(0.1),
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: Icon(Icons.text_fields,
                                        color: AppTheme.primaryColor, size: 18),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Text(
                                      field.label,
                                      style: const TextStyle(
                                          fontSize: 14, fontWeight: FontWeight.w500),
                                    ),
                                  ),
                                  Icon(Icons.chevron_right,
                                      color: secondaryTextColor, size: 18),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  void _batchCopyConvertAll(List<ConvertRecord> records) {
    final text = records.map((r) => r.resultUrl).join('\n');
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('已复制 ${records.length} 条转换结果')),
    );
  }

  void _batchCopyConvertField(
      List<ConvertRecord> records, _ConvertBatchCopyField field) {
    final values = records.map((r) => field.getValue(r)).where((v) => v.isNotEmpty).toList();
    if (values.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('暂无可复制的内容')),
      );
      return;
    }
    Clipboard.setData(ClipboardData(text: values.join('\n')));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('已复制 ${values.length} 条${field.label}')),
    );
  }

  void _showConvertDetail(ConvertRecord record) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
        final dividerColor = isDark ? Colors.grey.shade700 : Colors.grey.shade300;
        final accentOpacity = isDark ? 0.2 : 0.1;
        return DraggableScrollableSheet(
          initialChildSize: 0.6,
          maxChildSize: 0.9,
          minChildSize: 0.4,
          builder: (_, controller) => Container(
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
            ),
            child: ListView(
              controller: controller,
              padding: const EdgeInsets.all(20),
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: dividerColor,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: record.isToShort
                            ? Colors.blue.withOpacity(accentOpacity)
                            : Colors.green.withOpacity(accentOpacity),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        record.typeLabel,
                        style: TextStyle(
                          fontSize: 12,
                          color: record.isToShort ? Colors.blue : Colors.green,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    PlatformBadge(platform: record.platform, size: 12),
                  ],
                ),
                const SizedBox(height: 16),
                Divider(height: 1, color: dividerColor),
                const SizedBox(height: 12),
                _detailRow(context, '原始链接', record.originalUrl),
                const SizedBox(height: 8),
                _detailRow(context, '转换结果', record.resultUrl),
                const SizedBox(height: 8),
                _detailRow(context, '转换时间', _formatDateTime(record.convertedAt)),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () {
                          Clipboard.setData(ClipboardData(text: record.resultUrl));
                          Navigator.pop(context);
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('已复制结果链接')),
                          );
                        },
                        icon: const Icon(Icons.copy, size: 16),
                        label: const Text('复制结果'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ==================== 通用组件 ====================

  Widget _detailRow(BuildContext context, String label, String value) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;
    final primaryTextColor = isDark ? Colors.white : Colors.black87;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: InkWell(
        onTap: value.isEmpty
            ? null
            : () {
                Clipboard.setData(ClipboardData(text: value));
                HapticService.lightImpact();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('已复制 $label'),
                    duration: const Duration(seconds: 1),
                  ),
                );
              },
        borderRadius: BorderRadius.circular(6),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 2),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                width: 80,
                child: Text(
                  label,
                  style: TextStyle(fontSize: 13, color: secondaryTextColor),
                ),
              ),
              Expanded(
                child: SelectableText(
                  value.isEmpty ? '-' : value,
                  style: TextStyle(fontSize: 13, color: primaryTextColor, height: 1.4),
                ),
              ),
              if (value.isNotEmpty) ...[
                const SizedBox(width: 4),
                Icon(Icons.copy, size: 14, color: secondaryTextColor),
              ],
            ],
          ),
        ),
      ),
    );
  }

  String _formatTime(DateTime dt) {
    final now = DateTime.now();
    final diff = now.difference(dt);
    if (diff.inMinutes < 1) return '刚刚';
    if (diff.inMinutes < 60) return '${diff.inMinutes}分钟前';
    if (diff.inHours < 24) return '${diff.inHours}小时前';
    if (diff.inDays < 7) return '${dt.month}/${dt.day}';
    return '${dt.month}/${dt.day}';
  }

  String _formatDateTime(DateTime dt) {
    return '${dt.year}-${dt.month.toString().padLeft(2, '0')}-${dt.day.toString().padLeft(2, '0')} '
        '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
  }

  /// 美化 JSON 输出
  String _prettyJson(dynamic data) {
    const JsonEncoder encoder = JsonEncoder.withIndent('  ');
    return encoder.convert(data);
  }

  /// 保存 JSON 文件到本地
  Future<void> _saveJsonFile(String content, String fileName) async {
    try {
      final directory = await getApplicationDocumentsDirectory();
      final file = File('${directory.path}/$fileName');
      await file.writeAsString(content);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('已保存到 ${file.path}')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('保存失败：$e')),
      );
    }
  }

  void _clearCurrentTab() {
    final index = _tabController.index;
    String typeName = '';
    int count = 0;

    if (index == 0) {
      typeName = '解析';
      count = context.read<HistoryProvider>().videos.length;
    } else if (index == 1) {
      typeName = '抓取';
      count = context.read<CrawlHistoryProvider>().count;
    } else {
      typeName = '转换';
      count = context.read<ConvertHistoryProvider>().count;
    }

    if (count == 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('暂无记录')),
      );
      return;
    }

    // 转换记录和抓取记录没有下载文件，直接确认清空
    if (index != 0) {
      _showSimpleClearConfirm(typeName, index);
      return;
    }

    // 解析记录支持两种清空方式
    _showClearWithOptionsDialog(typeName, index);
  }

  /// 简单确认清空（转换记录用）
  void _showSimpleClearConfirm(String typeName, int index) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('确认清空'),
        content: Text('确定要清空所有${typeName}记录吗？\n此操作不可恢复。'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              // 二次确认
              _showSecondConfirm(typeName, index, 'records');
            },
            child: const Text('确定', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  /// 带选项的清空对话框（解析和抓取记录用）
  void _showClearWithOptionsDialog(String typeName, int index) {
    String clearOption = 'records'; // records: 仅清空记录, files: 清空记录及文件

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: const Text('清空方式'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('确定要清空所有$typeName记录吗？'),
              const SizedBox(height: 16),
              const Text(
                '请选择清空方式：',
                style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
              ),
              const SizedBox(height: 8),
              RadioListTile<String>(
                title: const Text('仅清空记录'),
                subtitle: Text(
                  '只删除历史记录，保留已下载的文件',
                  style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                ),
                value: 'records',
                groupValue: clearOption,
                onChanged: (value) {
                  if (value != null) {
                    setState(() => clearOption = value);
                  }
                },
                dense: true,
                contentPadding: EdgeInsets.zero,
              ),
              RadioListTile<String>(
                title: const Text('清空记录及下载文件'),
                subtitle: Text(
                  '同时删除历史记录和已下载的视频/图片文件',
                  style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                ),
                value: 'files',
                groupValue: clearOption,
                onChanged: (value) {
                  if (value != null) {
                    setState(() => clearOption = value);
                  }
                },
                dense: true,
                contentPadding: EdgeInsets.zero,
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('取消'),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                // 二次确认
                _showSecondConfirm(typeName, index, clearOption);
              },
              child: const Text('下一步', style: TextStyle(color: Colors.red)),
            ),
          ],
        ),
      ),
    );
  }

  /// 二次确认对话框
  void _showSecondConfirm(String typeName, int index, String clearOption) {
    final isDeleteFiles = clearOption == 'files';
    final message = isDeleteFiles
        ? '您选择了「清空记录及下载文件」。\n\n此操作将永久删除所有$typeName记录以及对应的下载文件，且无法恢复。\n\n确定要继续吗？'
        : '您选择了「仅清空记录」。\n\n此操作将永久删除所有$typeName记录，但已下载的文件会保留。\n\n确定要继续吗？';

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('⚠️ 二次确认'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              await _performClear(index, isDeleteFiles);
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(isDeleteFiles ? '已清空记录及文件' : '已清空记录'),
                  ),
                );
              }
            },
            child: const Text('确认清空', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  /// 执行清空操作
  Future<void> _performClear(int index, bool deleteFiles) async {
    if (index == 0) {
      // 解析记录：如果需要删除文件，先获取所有视频 ID 并删除相关下载文件
      if (deleteFiles) {
        final videoIds = context.read<HistoryProvider>().videos.map((v) => v.id).toList();
        if (videoIds.isNotEmpty) {
          context.read<DownloadProvider>().removeTasksByVideoIds(videoIds, deleteFile: true);
        }
      }
      await context.read<HistoryProvider>().clearHistory();
    } else if (index == 1) {
      await context.read<CrawlHistoryProvider>().clearHistory();
    } else {
      await context.read<ConvertHistoryProvider>().clearHistory();
    }
  }

  /// 导出当前 Tab 的记录
  void _exportCurrentTab() {
    final index = _tabController.index;
    int count = 0;

    if (index == 0) {
      count = context.read<HistoryProvider>().videos.length;
    } else if (index == 1) {
      count = context.read<CrawlHistoryProvider>().count;
    } else {
      count = context.read<ConvertHistoryProvider>().count;
    }

    if (count == 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('暂无记录可导出')),
      );
      return;
    }

    final isDark = Theme.of(context).brightness == Brightness.dark;
    final secondaryTextColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;

    showModalBottomSheet(
      context: context,
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  const Text(
                    '导出格式',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                  const Spacer(),
                  Text(
                    '共 $count 条记录',
                    style: TextStyle(fontSize: 12, color: secondaryTextColor),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            ListTile(
              leading: const Icon(Icons.grid_on_outlined, color: Colors.teal),
              title: const Text('导出 Excel (.xlsx)'),
              subtitle: Text(
                '标准 Excel 表格格式，支持 WPS / Office 打开',
                style: TextStyle(fontSize: 11, color: secondaryTextColor),
              ),
              onTap: () {
                Navigator.pop(context);
                _exportExcel(index);
              },
            ),
            ListTile(
              leading: const Icon(Icons.description_outlined, color: Colors.blue),
              title: const Text('导出 TXT 文本'),
              subtitle: Text(
                '纯文本格式，方便查看和复制',
                style: TextStyle(fontSize: 11, color: secondaryTextColor),
              ),
              onTap: () {
                Navigator.pop(context);
                _exportTxt(index);
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  /// 生成时间戳文件名
  String _timestampFileName(String prefix, String ext) {
    final now = DateTime.now();
    final ts = '${now.year}${now.month.toString().padLeft(2, '0')}${now.day.toString().padLeft(2, '0')}_'
        '${now.hour.toString().padLeft(2, '0')}${now.minute.toString().padLeft(2, '0')}';
    return '${prefix}_$ts.$ext';
  }

  /// 保存并分享文件
  Future<void> _saveAndShareFile(String fileName, List<int> bytes, String subject) async {
    final tempDir = await getTemporaryDirectory();
    final file = File('${tempDir.path}/$fileName');
    await file.writeAsBytes(bytes);
    await Share.shareFiles(
      [file.path],
      subject: subject,
      text: subject,
    );
  }

  /// 导出视频列表为 Excel
  Future<void> _exportVideosToExcel(List<VideoInfo> videos, String filePrefix, String subject) async {
    try {
      final book = excel.Excel.createExcel();
      const defaultSheetName = 'Sheet1';
      const sheetName = '解析记录';
      final fileName = _timestampFileName(filePrefix, 'xlsx');
      book.rename(defaultSheetName, sheetName);
      final sheet = book[sheetName];

      final headerStyle = excel.CellStyle(
        bold: true,
        horizontalAlign: excel.HorizontalAlign.Center,
        verticalAlign: excel.VerticalAlign.Center,
      );

      final dataStyle = excel.CellStyle(
        verticalAlign: excel.VerticalAlign.Center,
        textWrapping: excel.TextWrapping.WrapText,
      );

      final headers = ['序号', '平台', '标题', '作者', '类型', '视频链接', '解析时间'];
      for (var i = 0; i < headers.length; i++) {
        final cell = sheet.cell(
            excel.CellIndex.indexByColumnRow(columnIndex: i, rowIndex: 0));
        cell.value = excel.TextCellValue(headers[i]);
        cell.cellStyle = headerStyle;
      }

      for (var i = 0; i < videos.length; i++) {
        final v = videos[i];
        final row = [
          (i + 1).toString(),
          _platformName(v.platform),
          v.title,
          v.author,
          v.type == 'image' ? '图文' : '视频',
          v.videoUrl ?? '',
          _formatDateTime(v.parsedAt),
        ];
        for (var j = 0; j < row.length; j++) {
          final cell = sheet.cell(
              excel.CellIndex.indexByColumnRow(columnIndex: j, rowIndex: i + 1));
          cell.value = excel.TextCellValue(row[j]);
          cell.cellStyle = dataStyle;
        }
      }

      try {
        sheet.setColumnWidth(0, 6);
        sheet.setColumnWidth(1, 8);
        sheet.setColumnWidth(2, 30);
        sheet.setColumnWidth(3, 15);
        sheet.setColumnWidth(4, 8);
        sheet.setColumnWidth(5, 50);
        sheet.setColumnWidth(6, 18);
      } catch (_) {}

      final bytes = book.save();
      if (bytes == null) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('生成 Excel 文件失败')),
          );
        }
        return;
      }

      await _saveAndShareFile(fileName, bytes, subject);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('导出失败：${e.toString()}')),
        );
      }
    }
  }

  /// 导出 Excel
  Future<void> _exportExcel(int tabIndex) async {
    if (tabIndex == 0) {
      // 解析记录
      final videos = context.read<HistoryProvider>().videos;
      _exportVideosToExcel(videos, 'parse_history', '解析历史记录');
      return;
    }

    try {
      final book = excel.Excel.createExcel();
      const defaultSheetName = 'Sheet1';
      String sheetName = '记录';
      String fileName = '';
      String subject = '';

      final headerStyle = excel.CellStyle(
        bold: true,
        horizontalAlign: excel.HorizontalAlign.Center,
        verticalAlign: excel.VerticalAlign.Center,
      );

      final dataStyle = excel.CellStyle(
        verticalAlign: excel.VerticalAlign.Center,
        textWrapping: excel.TextWrapping.WrapText,
      );

      if (tabIndex == 1) {
        // 抓取记录
        sheetName = '抓取记录';
        fileName = _timestampFileName('crawl_history', 'xlsx');
        subject = '抓取历史记录';
        book.rename(defaultSheetName, sheetName);
        final sheet = book[sheetName];

        final headers = ['序号', '类型', '平台', '标题', '抓取时间', '字段数'];
        for (var i = 0; i < headers.length; i++) {
          final cell = sheet.cell(
              excel.CellIndex.indexByColumnRow(columnIndex: i, rowIndex: 0));
          cell.value = excel.TextCellValue(headers[i]);
          cell.cellStyle = headerStyle;
        }

        final records = context.read<CrawlHistoryProvider>().records;
        for (var i = 0; i < records.length; i++) {
          final r = records[i];
          final title = r.data['视频标题'] ?? r.data['昵称'] ?? r.data['标题'] ?? r.url;
          final row = [
            (i + 1).toString(),
            r.isAuthor ? '作者' : '视频',
            r.platform,
            title,
            _formatDateTime(r.crawledAt),
            r.data.length.toString(),
          ];
          for (var j = 0; j < row.length; j++) {
            final cell = sheet.cell(
                excel.CellIndex.indexByColumnRow(columnIndex: j, rowIndex: i + 1));
            cell.value = excel.TextCellValue(row[j]);
            cell.cellStyle = dataStyle;
          }
        }

        try {
          sheet.setColumnWidth(0, 6);
          sheet.setColumnWidth(1, 8);
          sheet.setColumnWidth(2, 8);
          sheet.setColumnWidth(3, 30);
          sheet.setColumnWidth(4, 18);
          sheet.setColumnWidth(5, 8);
        } catch (_) {}

        // 第二个 Sheet：详细数据
        const detailSheetName = '详细数据';
        final detailSheet = book[detailSheetName];
        int rowIdx = 0;
        final detailHeaders = ['序号', '标题', '字段名', '字段值'];
        for (var i = 0; i < detailHeaders.length; i++) {
          final cell = detailSheet.cell(
              excel.CellIndex.indexByColumnRow(columnIndex: i, rowIndex: rowIdx));
          cell.value = excel.TextCellValue(detailHeaders[i]);
          cell.cellStyle = headerStyle;
        }
        rowIdx++;

        for (var i = 0; i < records.length; i++) {
          final r = records[i];
          final title = r.data['视频标题'] ?? r.data['昵称'] ?? r.data['标题'] ?? r.url;
          r.data.forEach((key, value) {
            final row = [
              (i + 1).toString(),
              title,
              key,
              value?.toString() ?? '',
            ];
            for (var j = 0; j < row.length; j++) {
              final cell = detailSheet.cell(
                  excel.CellIndex.indexByColumnRow(columnIndex: j, rowIndex: rowIdx));
              cell.value = excel.TextCellValue(row[j]);
              cell.cellStyle = dataStyle;
            }
            rowIdx++;
          });
        }

        try {
          detailSheet.setColumnWidth(0, 6);
          detailSheet.setColumnWidth(1, 25);
          detailSheet.setColumnWidth(2, 15);
          detailSheet.setColumnWidth(3, 60);
        } catch (_) {}
      } else {
        // 转换记录
        sheetName = '转换记录';
        fileName = _timestampFileName('convert_history', 'xlsx');
        subject = '转换历史记录';
        book.rename(defaultSheetName, sheetName);
        final sheet = book[sheetName];

        final headers = ['序号', '平台', '转换类型', '原始链接', '转换结果', '状态', '转换时间'];
        for (var i = 0; i < headers.length; i++) {
          final cell = sheet.cell(
              excel.CellIndex.indexByColumnRow(columnIndex: i, rowIndex: 0));
          cell.value = excel.TextCellValue(headers[i]);
          cell.cellStyle = headerStyle;
        }

        final records = context.read<ConvertHistoryProvider>().records;
        for (var i = 0; i < records.length; i++) {
          final r = records[i];
          final row = [
            (i + 1).toString(),
            _platformName(r.platform),
            r.convertType == 'to_short' ? '转短链' : '转长链',
            r.originalUrl,
            r.resultUrl,
            r.success ? '成功' : '失败：${r.errorMessage ?? ''}',
            _formatDateTime(r.convertedAt),
          ];
          for (var j = 0; j < row.length; j++) {
            final cell = sheet.cell(
                excel.CellIndex.indexByColumnRow(columnIndex: j, rowIndex: i + 1));
            cell.value = excel.TextCellValue(row[j]);
            cell.cellStyle = dataStyle;
          }
        }

        try {
          sheet.setColumnWidth(0, 6);
          sheet.setColumnWidth(1, 8);
          sheet.setColumnWidth(2, 10);
          sheet.setColumnWidth(3, 50);
          sheet.setColumnWidth(4, 50);
          sheet.setColumnWidth(5, 15);
          sheet.setColumnWidth(6, 18);
        } catch (_) {}
      }

      final bytes = book.save();
      if (bytes == null) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('生成 Excel 文件失败')),
          );
        }
        return;
      }

      await _saveAndShareFile(fileName, bytes, subject);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('导出失败：${e.toString()}')),
        );
      }
    }
  }

  /// 导出 TXT
  Future<void> _exportTxt(int tabIndex) async {
    try {
      String fileName = '';
      String subject = '';
      final buffer = StringBuffer();

      if (tabIndex == 0) {
        // 解析记录
        fileName = _timestampFileName('parse_history', 'txt');
        subject = '解析历史记录';
        final videos = context.read<HistoryProvider>().videos;
        buffer.writeln('# 解析历史记录');
        buffer.writeln('# 共 ${videos.length} 条');
        buffer.writeln('# 导出时间：${DateTime.now().toString().substring(0, 19)}');
        buffer.writeln('');
        for (var i = 0; i < videos.length; i++) {
          final v = videos[i];
          buffer.writeln('=== 第 ${i + 1} 条 ===');
          buffer.writeln('平台：${_platformName(v.platform)}');
          buffer.writeln('标题：${v.title}');
          buffer.writeln('作者：${v.author}');
          buffer.writeln('类型：${v.type == "image" ? "图文" : "视频"}');
          buffer.writeln('视频链接：${v.videoUrl ?? "无"}');
          buffer.writeln('解析时间：${_formatDateTime(v.parsedAt)}');
          buffer.writeln('');
        }
      } else if (tabIndex == 1) {
        // 抓取记录
        fileName = _timestampFileName('crawl_history', 'txt');
        subject = '抓取历史记录';
        final records = context.read<CrawlHistoryProvider>().records;
        buffer.writeln('# 抓取历史记录');
        buffer.writeln('# 共 ${records.length} 条');
        buffer.writeln('# 导出时间：${DateTime.now().toString().substring(0, 19)}');
        buffer.writeln('');
        for (var i = 0; i < records.length; i++) {
          final r = records[i];
          final title = r.data['视频标题'] ?? r.data['昵称'] ?? r.data['标题'] ?? r.url;
          buffer.writeln('=== 第 ${i + 1} 条（${r.isAuthor ? "作者" : "视频"}）===');
          buffer.writeln('平台：${r.platform}');
          buffer.writeln('标题：$title');
          buffer.writeln('抓取时间：${_formatDateTime(r.crawledAt)}');
          buffer.writeln('字段数据：');
          r.data.forEach((key, value) {
            buffer.writeln('  $key：${value ?? ""}');
          });
          buffer.writeln('');
        }
      } else {
        // 转换记录
        fileName = _timestampFileName('convert_history', 'txt');
        subject = '转换历史记录';
        final records = context.read<ConvertHistoryProvider>().records;
        buffer.writeln('# 转换历史记录');
        buffer.writeln('# 共 ${records.length} 条');
        buffer.writeln('# 导出时间：${DateTime.now().toString().substring(0, 19)}');
        buffer.writeln('');
        for (var i = 0; i < records.length; i++) {
          final r = records[i];
          buffer.writeln('=== 第 ${i + 1} 条 ===');
          buffer.writeln('平台：${_platformName(r.platform)}');
          buffer.writeln('类型：${r.convertType == "to_short" ? "转短链" : "转长链"}');
          buffer.writeln('原始链接：${r.originalUrl}');
          buffer.writeln('转换结果：${r.success ? r.resultUrl : "失败 - ${r.errorMessage ?? "未知错误"}"}');
          buffer.writeln('转换时间：${_formatDateTime(r.convertedAt)}');
          buffer.writeln('');
        }
      }

      final bytes = buffer.toString().codeUnits;
      await _saveAndShareFile(fileName, bytes, subject);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('导出失败：${e.toString()}')),
        );
      }
    }
  }

  String _platformName(String? platform) {
    switch (platform) {
      case 'douyin':
        return '抖音';
      case 'kuaishou':
        return '快手';
      default:
        return platform ?? '未知';
    }
  }
}

/// 懒加载网络图片
/// 
/// 使用 FadeInImage 实现淡入效果，加载中显示占位图
class _LazyNetworkImage extends StatelessWidget {
  final String url;
  final BoxFit fit;
  final Widget placeholder;

  const _LazyNetworkImage({
    required this.url,
    this.fit = BoxFit.cover,
    required this.placeholder,
  });

  @override
  Widget build(BuildContext context) {
    return Image.network(
      url,
      fit: fit,
      loadingBuilder: (context, child, loadingProgress) {
        if (loadingProgress == null) return child;
        return Center(
          child: SizedBox(
            width: 20,
            height: 20,
            child: CircularProgressIndicator(
              strokeWidth: 2,
              value: loadingProgress.expectedTotalBytes != null
                  ? loadingProgress.cumulativeBytesLoaded /
                      loadingProgress.expectedTotalBytes!
                  : null,
            ),
          ),
        );
      },
      errorBuilder: (_, __, ___) => placeholder,
    );
  }
}

/// 单条抓取记录显示项
class _SingleRecordItem {
  final CrawlRecord record;
  _SingleRecordItem(this.record);
}

/// 批次抓取记录显示项
class _BatchRecordItem {
  final String batchId;
  final List<CrawlRecord> records;
  _BatchRecordItem(this.batchId, this.records);
}

/// 单条转换记录显示项
class _SingleConvertItem {
  final ConvertRecord record;
  _SingleConvertItem(this.record);
}

/// 批次转换记录显示项
class _BatchConvertItem {
  final String batchId;
  final List<ConvertRecord> records;
  _BatchConvertItem(this.batchId, this.records);
}

/// 转换批次复制字段配置
class _ConvertBatchCopyField {
  final String key;
  final String label;
  final String Function(ConvertRecord record) getValue;

  _ConvertBatchCopyField(this.key, this.label, this.getValue);
}
