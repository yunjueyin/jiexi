import 'package:flutter/material.dart';

class PlatformBadge extends StatelessWidget {
  final String platform;
  final double size;

  const PlatformBadge({
    super.key,
    required this.platform,
    this.size = 24,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: _bgColor,
        borderRadius: BorderRadius.circular(size / 4),
      ),
      child: Center(
        child: Text(
          _icon,
          style: TextStyle(fontSize: size * 0.6),
        ),
      ),
    );
  }

  String get _icon {
    switch (platform) {
      case 'douyin':
        return '🎵';
      case 'kuaishou':
        return '⚡';
      case 'xiaohongshu':
      case 'xhs':
        return '📕';
      default:
        return '📹';
    }
  }

  Color get _bgColor {
    switch (platform) {
      case 'douyin':
        return const Color(0xFFFE2C55).withOpacity(0.15);
      case 'kuaishou':
        return const Color(0xFFFF6600).withOpacity(0.15);
      case 'xiaohongshu':
      case 'xhs':
        return const Color(0xFFFF2442).withOpacity(0.15);
      default:
        return Colors.grey.withOpacity(0.15);
    }
  }

  String get name {
    switch (platform) {
      case 'douyin':
        return '抖音';
      case 'kuaishou':
        return '快手';
      case 'xiaohongshu':
      case 'xhs':
        return '小红书';
      default:
        return '未知';
    }
  }
}
