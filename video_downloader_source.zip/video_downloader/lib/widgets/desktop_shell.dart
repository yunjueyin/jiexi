import 'dart:ui';
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// 桌面端主布局组件
///
/// 采用左侧导航栏（NavigationRail）+ 右侧内容区的布局结构，
/// 导航栏宽度 220px，带毛玻璃效果，选中项有渐变高亮。
class DesktopShell extends StatelessWidget {
  /// 当前选中的导航索引
  final int currentIndex;

  /// 导航项点击回调
  final ValueChanged<int> onDestinationSelected;

  /// 内容页面列表（与导航项一一对应）
  final List<Widget> pages;

  const DesktopShell({
    super.key,
    required this.currentIndex,
    required this.onDestinationSelected,
    required this.pages,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = AppTheme.isDark(context);
    final isOled = AppTheme.isOledDark(context);
    final primaryColor = Theme.of(context).primaryColor;
    final secondaryColor = AppTheme.secondaryColor;

    // 固定的桌面端导航项（7 项，全部显示）
    const navItems = _DesktopNavItem.items;

    return Scaffold(
      body: Row(
        children: [
          // 左侧导航栏
          _buildNavigationRail(
            context: context,
            navItems: navItems,
            isDark: isDark,
            isOled: isOled,
            primaryColor: primaryColor,
            secondaryColor: secondaryColor,
          ),
          // 右侧内容区
          Expanded(
            child: IndexedStack(
              index: currentIndex < pages.length ? currentIndex : 0,
              children: pages,
            ),
          ),
        ],
      ),
    );
  }

  /// 构建左侧导航栏
  Widget _buildNavigationRail({
    required BuildContext context,
    required List<_DesktopNavItem> navItems,
    required bool isDark,
    required bool isOled,
    required Color primaryColor,
    required Color secondaryColor,
  }) {
    final bgColor = isOled
        ? Colors.black.withOpacity(0.85)
        : (isDark
            ? const Color(0xFF1E293B).withOpacity(0.85)
            : Colors.white.withOpacity(0.85));

    final borderColor = isDark
        ? const Color(0xFF334155).withOpacity(0.5)
        : Colors.grey.shade200.withOpacity(0.5);

    return SizedBox(
      width: 220,
      child: ClipRect(
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
          child: Container(
            decoration: BoxDecoration(
              color: bgColor,
              border: Border(
                right: BorderSide(color: borderColor, width: 0.5),
              ),
            ),
            child: SafeArea(
              right: false,
              child: Column(
                children: [
                  // 顶部 Logo 和标题
                  _buildHeader(primaryColor, secondaryColor),
                  const SizedBox(height: 12),
                  // 分隔线
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Divider(
                      height: 1,
                      thickness: 0.5,
                      color: borderColor,
                    ),
                  ),
                  const SizedBox(height: 12),
                  // 导航项列表
                  Expanded(
                    child: ListView.separated(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      itemCount: navItems.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 4),
                      itemBuilder: (context, index) {
                        final item = navItems[index];
                        final isSelected = currentIndex == index;
                        return _buildNavItem(
                          item: item,
                          isSelected: isSelected,
                          primaryColor: primaryColor,
                          secondaryColor: secondaryColor,
                          isDark: isDark,
                          onTap: () => onDestinationSelected(index),
                        );
                      },
                    ),
                  ),
                  // 底部版本信息
                  _buildFooter(isDark),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// 构建顶部 Logo 和标题
  Widget _buildHeader(Color primaryColor, Color secondaryColor) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 24, 20, 8),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [primaryColor, secondaryColor],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(14),
              boxShadow: [
                BoxShadow(
                  color: primaryColor.withOpacity(0.3),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: const Icon(
              Icons.play_circle_fill,
              color: Colors.white,
              size: 28,
            ),
          ),
          const SizedBox(width: 12),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '无水印下载',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.3,
                  ),
                ),
                SizedBox(height: 2),
                Text(
                  '高清视频解析下载',
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// 构建单个导航项
  Widget _buildNavItem({
    required _DesktopNavItem item,
    required bool isSelected,
    required Color primaryColor,
    required Color secondaryColor,
    required bool isDark,
    required VoidCallback onTap,
  }) {
    final unselectedColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;

    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeOutCubic,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          gradient: isSelected
              ? LinearGradient(
                  colors: [
                    primaryColor.withOpacity(0.15),
                    secondaryColor.withOpacity(0.1),
                  ],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                )
              : null,
          borderRadius: BorderRadius.circular(12),
          border: isSelected
              ? Border.all(
                  color: primaryColor.withOpacity(0.3),
                  width: 1,
                )
              : null,
        ),
        child: Row(
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              curve: Curves.easeOutCubic,
              width: isSelected ? 28 : 24,
              height: isSelected ? 28 : 24,
              child: Icon(
                isSelected ? item.activeIcon : item.icon,
                color: isSelected ? primaryColor : unselectedColor,
                size: isSelected ? 24 : 22,
              ),
            ),
            const SizedBox(width: 12),
            AnimatedDefaultTextStyle(
              duration: const Duration(milliseconds: 250),
              curve: Curves.easeOutCubic,
              style: TextStyle(
                fontSize: isSelected ? 14 : 13,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                color: isSelected ? primaryColor : unselectedColor,
              ),
              child: Text(item.label),
            ),
            const Spacer(),
            if (isSelected)
              Container(
                width: 4,
                height: 20,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [primaryColor, secondaryColor],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
          ],
        ),
      ),
    );
  }

  /// 构建底部版本信息
  Widget _buildFooter(bool isDark) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Text(
        'v2.1.0',
        style: TextStyle(
          fontSize: 12,
          color: isDark ? Colors.grey.shade500 : Colors.grey.shade400,
        ),
      ),
    );
  }
}

/// 桌面端导航项数据
class _DesktopNavItem {
  final String label;
  final IconData icon;
  final IconData activeIcon;

  const _DesktopNavItem({
    required this.label,
    required this.icon,
    required this.activeIcon,
  });

  /// 桌面端固定的 7 个导航项
  static const List<_DesktopNavItem> items = [
    _DesktopNavItem(
      label: '首页',
      icon: Icons.home_outlined,
      activeIcon: Icons.home,
    ),
    _DesktopNavItem(
      label: '批量抓取',
      icon: Icons.search_outlined,
      activeIcon: Icons.search,
    ),
    _DesktopNavItem(
      label: '格式转换',
      icon: Icons.swap_horiz_outlined,
      activeIcon: Icons.swap_horiz,
    ),
    _DesktopNavItem(
      label: '历史记录',
      icon: Icons.history_outlined,
      activeIcon: Icons.history,
    ),
    _DesktopNavItem(
      label: '下载管理',
      icon: Icons.download_outlined,
      activeIcon: Icons.download,
    ),
    _DesktopNavItem(
      label: '我的收藏',
      icon: Icons.favorite_border,
      activeIcon: Icons.favorite,
    ),
    _DesktopNavItem(
      label: '设置',
      icon: Icons.settings_outlined,
      activeIcon: Icons.settings,
    ),
  ];
}
