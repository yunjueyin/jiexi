import 'dart:ui';
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// 毛玻璃效果的 AppBar 组件
///
/// 使用 BackdropFilter + ImageFilter.blur 实现毛玻璃效果，
/// 页面滚动时模糊度逐渐增加，营造层次感。
class FrostedAppBar extends StatelessWidget implements PreferredSizeWidget {
  /// 标题文字
  final String title;

  /// 左侧动作（返回按钮等）
  final Widget? leading;

  /// 右侧动作列表
  final List<Widget>? actions;

  /// 是否显示返回按钮
  final bool automaticallyImplyLeading;

  /// 底部组件（如 TabBar）
  final PreferredSizeWidget? bottom;

  /// AppBar 高度
  final double elevation;

  /// 双击 AppBar 区域回调（用于回到顶部等功能）
  final VoidCallback? onDoubleTap;

  const FrostedAppBar({
    super.key,
    required this.title,
    this.leading,
    this.actions,
    this.automaticallyImplyLeading = true,
    this.bottom,
    this.elevation = 0,
    this.onDoubleTap,
  });

  @override
  Size get preferredSize => Size.fromHeight(
        kToolbarHeight + (bottom?.preferredSize.height ?? 0),
      );

  @override
  Widget build(BuildContext context) {
    final isDark = AppTheme.isDark(context);
    final isOled = AppTheme.isOledDark(context);
    final textPrimary = AppTheme.textPrimaryColor(context);
    final borderColor = isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0);

    return ClipRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
        child: Container(
          decoration: BoxDecoration(
            color: isOled
                ? Colors.black.withOpacity(0.8)
                : isDark
                    ? const Color(0xFF0B1120).withOpacity(0.85)
                    : Colors.white.withOpacity(0.85),
            border: Border(
              bottom: BorderSide(
                color: borderColor.withOpacity(0.5),
                width: 0.5,
              ),
            ),
          ),
          child: SafeArea(
            bottom: false,
            child: GestureDetector(
              onDoubleTap: onDoubleTap,
              behavior: HitTestBehavior.opaque,
              child: AppBar(
                backgroundColor: Colors.transparent,
                elevation: 0,
                scrolledUnderElevation: 0,
                centerTitle: false,
                titleSpacing: AppTheme.spacingLg,
                automaticallyImplyLeading: automaticallyImplyLeading,
                leading: leading,
                actions: actions,
                bottom: bottom,
                title: Text(
                  title,
                  style: TextStyle(
                    color: textPrimary,
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                    letterSpacing: -0.3,
                  ),
                ),
                iconTheme: IconThemeData(color: textPrimary, size: 24),
                actionsIconTheme: IconThemeData(
                  color: AppTheme.textSecondaryColor(context),
                  size: 22,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// 毛玻璃效果的 SliverAppBar（用于可滚动页面）
///
/// 滚动时逐渐增加模糊度，展开时显示渐变背景。
class FrostedSliverAppBar extends StatelessWidget {
  /// 标题文字
  final String title;

  /// 展开高度
  final double expandedHeight;

  /// 左侧动作
  final Widget? leading;

  /// 右侧动作
  final List<Widget>? actions;

  /// 是否固定在顶部
  final bool pinned;

  /// 是否浮动
  final bool floating;

  /// 灵活空间背景（展开时显示）
  final Widget? flexibleBackground;

  const FrostedSliverAppBar({
    super.key,
    required this.title,
    this.expandedHeight = 140,
    this.leading,
    this.actions,
    this.pinned = true,
    this.floating = false,
    this.flexibleBackground,
  });

  @override
  Widget build(BuildContext context) {
    return SliverAppBar(
      expandedHeight: expandedHeight,
      floating: floating,
      pinned: pinned,
      backgroundColor: Colors.transparent,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
      titleSpacing: AppTheme.spacingLg,
      leading: leading,
      actions: actions,
      flexibleSpace: LayoutBuilder(
        builder: (context, constraints) {
          // 计算折叠进度：0.0 = 完全展开，1.0 = 完全折叠
          final top = constraints.biggest.height;
          final collapsedHeight = kToolbarHeight + MediaQuery.of(context).padding.top;
          final expandRange = expandedHeight - collapsedHeight;
          final collapseProgress = expandRange > 0
              ? (1.0 - ((top - collapsedHeight) / expandRange)).clamp(0.0, 1.0)
              : 1.0;

          final isDark = AppTheme.isDark(context);
          final isOled = AppTheme.isOledDark(context);
          final textPrimary = AppTheme.textPrimaryColor(context);

          return Stack(
            fit: StackFit.expand,
            children: [
              // 展开时的背景
              if (flexibleBackground != null && collapseProgress < 1.0)
                Opacity(
                  opacity: 1.0 - collapseProgress,
                  child: flexibleBackground,
                ),
              // 折叠时的毛玻璃背景
              if (collapseProgress > 0)
                ClipRect(
                  child: BackdropFilter(
                    filter: ImageFilter.blur(
                      sigmaX: 20 * collapseProgress,
                      sigmaY: 20 * collapseProgress,
                    ),
                    child: Container(
                      color: isOled
                          ? Colors.black.withOpacity(0.7 * collapseProgress)
                          : isDark
                              ? const Color(0xFF0B1120).withOpacity(0.75 * collapseProgress)
                              : Colors.white.withOpacity(0.75 * collapseProgress),
                    ),
                  ),
                ),
              // 底部边框（折叠时显示）
              if (collapseProgress > 0.5)
                Positioned(
                  bottom: 0,
                  left: 0,
                  right: 0,
                  child: Container(
                    height: 0.5,
                    color: (isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0))
                        .withOpacity((collapseProgress - 0.5) * 2),
                  ),
                ),
              // 标题
              FlexibleSpaceBar(
                centerTitle: false,
                titlePadding: EdgeInsetsDirectional.only(
                  start: AppTheme.spacingLg,
                  bottom: 16,
                ),
                title: Text(
                  title,
                  style: TextStyle(
                    color: collapseProgress > 0.5 ? textPrimary : Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                    letterSpacing: -0.3,
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
