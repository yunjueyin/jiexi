import 'package:flutter/material.dart';

/// 滑动操作项配置
class SlideAction {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const SlideAction({
    required this.label,
    required this.icon,
    required this.color,
    required this.onTap,
  });
}

/// 可滑动的列表项组件（左滑显示操作按钮）
///
/// 支持自定义左滑操作按钮，类似 iOS 风格的左滑操作
class SlidableItem extends StatefulWidget {
  final Widget child;
  final List<SlideAction> actions;
  final double actionExtent;

  const SlidableItem({
    super.key,
    required this.child,
    required this.actions,
    this.actionExtent = 0.25,
  });

  @override
  State<SlidableItem> createState() => _SlidableItemState();
}

class _SlidableItemState extends State<SlidableItem>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<Offset> _slideAnimation;
  double _dragExtent = 0;
  bool _isOpen = false;
  static const double _minDragDistance = 30;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 200),
    );
    _slideAnimation = Tween<Offset>(
      begin: Offset.zero,
      end: Offset(-widget.actionExtent * widget.actions.length, 0),
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOut,
    ));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _handleDragStart(DragStartDetails details) {
    _controller.stop();
  }

  void _handleDragUpdate(DragUpdateDetails details) {
    final delta = details.primaryDelta ?? 0;
    setState(() {
      _dragExtent = (_dragExtent + delta).clamp(
        -MediaQuery.of(context).size.width * widget.actionExtent * widget.actions.length,
        0.0,
      );
    });
  }

  void _handleDragEnd(DragEndDetails details) {
    final velocity = details.primaryVelocity ?? 0;
    final maxExtent =
        -MediaQuery.of(context).size.width * widget.actionExtent * widget.actions.length;

    if (velocity < -500) {
      // 快速左滑，打开
      _open();
    } else if (velocity > 500) {
      // 快速右滑，关闭
      _close();
    } else if (_dragExtent < maxExtent / 2) {
      // 超过一半，打开
      _open();
    } else {
      // 不到一半，关闭
      _close();
    }
  }

  void _open() {
    _controller.forward();
    setState(() {
      _isOpen = true;
      _dragExtent =
          -MediaQuery.of(context).size.width * widget.actionExtent * widget.actions.length;
    });
  }

  void _close() {
    _controller.reverse();
    setState(() {
      _isOpen = false;
      _dragExtent = 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final actionWidth = screenWidth * widget.actionExtent;

    return GestureDetector(
      onHorizontalDragStart: _handleDragStart,
      onHorizontalDragUpdate: _handleDragUpdate,
      onHorizontalDragEnd: _handleDragEnd,
      child: Stack(
        children: [
          // 背景操作按钮
          Positioned.fill(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: widget.actions.map((action) {
                return SizedBox(
                  width: actionWidth,
                  child: Material(
                    color: action.color,
                    child: InkWell(
                      onTap: () {
                        _close();
                        action.onTap();
                      },
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(action.icon, color: Colors.white, size: 22),
                          const SizedBox(height: 4),
                          Text(
                            action.label,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 11,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
          // 前景内容（宽度占满、高度自适应，用于决定 Stack 的高度；左滑露出背景按钮）
          SizedBox(
            width: double.infinity,
            child: _isOpen
                ? AnimatedBuilder(
                    animation: _slideAnimation,
                    builder: (context, child) {
                      return Transform.translate(
                        offset: _slideAnimation.value * screenWidth,
                        child: child,
                      );
                    },
                    child: widget.child,
                  )
                : Transform.translate(
                    offset: Offset(_dragExtent, 0),
                    child: widget.child,
                  ),
          ),
        ],
      ),
    );
  }
}
