import 'package:flutter/material.dart';
import '../models/video_info.dart';
import '../theme/app_theme.dart';
import 'platform_badge.dart';

/// 视频/图文卡片组件（视觉分级版）
///
/// 根据内容类型展示不同的视觉样式：
/// - 视频：播放按钮 + 时长角标
/// - 图文：多图角标（如"9图"）+ 紫色系装饰
/// - 作者主页：头像 + 粉丝数样式（由 isAuthorProfile 控制）
class VideoCard extends StatelessWidget {
  final VideoInfo video;
  final VoidCallback? onTap;
  final VoidCallback? onDownload;

  /// 是否为作者主页卡片样式
  final bool isAuthorProfile;

  /// 粉丝数（作者主页样式时使用）
  final String? followerCount;

  const VideoCard({
    super.key,
    required this.video,
    this.onTap,
    this.onDownload,
    this.isAuthorProfile = false,
    this.followerCount,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = AppTheme.isDark(context);
    final platformColor = AppTheme.platformPrimaryColor(video.platform);

    // 根据类型获取左侧装饰条颜色
    final accentColor = _getAccentColor();

    return Container(
      decoration: BoxDecoration(
        color: AppTheme.cardBg(context),
        borderRadius: BorderRadius.circular(AppTheme.radiusLg),
        border: Border.all(
          color: isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
          width: 0.5,
        ),
        boxShadow: AppTheme.shadowSm,
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(AppTheme.radiusLg),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                // 封面区域
                _buildCover(context, isDark, platformColor),
                const SizedBox(width: 14),
                // 文字信息
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        video.title,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: AppTheme.textPrimaryColor(context),
                          height: 1.35,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          // 平台标签
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              color: platformColor.withOpacity(isDark ? 0.15 : 0.08),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                PlatformBadge(platform: video.platform, size: 12),
                                const SizedBox(width: 4),
                                Text(
                                  video.platformName,
                                  style: TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w600,
                                    color: platformColor,
                                    height: 1.2,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 8),
                          // 类型标签（图文/视频）
                          if (!isAuthorProfile)
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: accentColor.withOpacity(isDark ? 0.15 : 0.08),
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(
                                    _getTypeIcon(),
                                    size: 11,
                                    color: accentColor,
                                  ),
                                  const SizedBox(width: 3),
                                  Text(
                                    _getTypeLabel(),
                                    style: TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w600,
                                      color: accentColor,
                                      height: 1.2,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          // 作者主页粉丝数
                          if (isAuthorProfile && followerCount != null) ...[
                            const SizedBox(width: 8),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: Colors.pink.withOpacity(isDark ? 0.15 : 0.08),
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(
                                    Icons.people_outline,
                                    size: 11,
                                    color: Colors.pink.shade400,
                                  ),
                                  const SizedBox(width: 3),
                                  Text(
                                    followerCount!,
                                    style: TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w600,
                                      color: Colors.pink.shade400,
                                      height: 1.2,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ],
                      ),
                      // 作者信息
                      if (video.author.isNotEmpty) ...[
                        const SizedBox(height: 6),
                        Row(
                          children: [
                            Icon(
                              Icons.person_outline,
                              size: 12,
                              color: AppTheme.textTertiaryColor(context),
                            ),
                            const SizedBox(width: 4),
                            Expanded(
                              child: Text(
                                video.author,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontSize: 12,
                                  color: AppTheme.textTertiaryColor(context),
                                  fontWeight: FontWeight.w500,
                                  height: 1.2,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ],
                  ),
                ),
                // 下载按钮
                if (onDownload != null && !isAuthorProfile) ...[
                  const SizedBox(width: 8),
                  _buildDownloadButton(context, platformColor),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCover(BuildContext context, bool isDark, Color platformColor) {
    return SizedBox(
      width: 88,
      height: 72,
      child: Stack(
        fit: StackFit.expand,
        children: [
          // 封面图
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(AppTheme.radiusMd),
              color: isDark ? const Color(0xFF0F172A) : const Color(0xFFF1F5F9),
            ),
            clipBehavior: Clip.antiAlias,
            child: isAuthorProfile
                ? _buildAuthorAvatar(isDark)
                : (video.cover.isNotEmpty
                    ? Image.network(
                        video.cover,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => _buildPlaceholder(),
                      )
                    : _buildPlaceholder()),
          ),
          // 播放按钮（视频类型）
          if (video.isVideo && !isAuthorProfile)
            Positioned.fill(
              child: Center(
                child: Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.5),
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white.withOpacity(0.3), width: 1),
                  ),
                  child: const Icon(
                    Icons.play_arrow_rounded,
                    color: Colors.white,
                    size: 20,
                  ),
                ),
              ),
            ),
          // 时长角标（视频）
          if (video.durationSeconds != null && !isAuthorProfile)
            Positioned(
              right: 6,
              bottom: 6,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.75),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.play_arrow_rounded, color: Colors.white, size: 10),
                    const SizedBox(width: 2),
                    Text(
                      _formatDuration(video.durationSeconds!),
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        height: 1.2,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          // 多图角标（图文类型）
          if (video.isImage && !isAuthorProfile)
            Positioned(
              right: 6,
              bottom: 6,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: Colors.purple.withOpacity(0.85),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.photo_library_rounded, color: Colors.white, size: 10),
                    const SizedBox(width: 2),
                    Text(
                      '${video.imageCount}图',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        height: 1.2,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          // 作者主页标记
          if (isAuthorProfile)
            Positioned(
              left: 6,
              bottom: 6,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: Colors.pink.withOpacity(0.85),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.person_rounded, color: Colors.white, size: 10),
                    SizedBox(width: 2),
                    Text(
                      '作者',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        height: 1.2,
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildAuthorAvatar(bool isDark) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Colors.pink.shade400,
            Colors.purple.shade400,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Center(
        child: Text(
          video.author.isNotEmpty ? video.author.characters.first : '?',
          style: const TextStyle(
            color: Colors.white,
            fontSize: 28,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Widget _buildPlaceholder() {
    return Center(
      child: PlatformBadge(platform: video.platform, size: 32),
    );
  }

  Widget _buildDownloadButton(BuildContext context, Color platformColor) {
    return Container(
      width: 40,
      height: 40,
      decoration: BoxDecoration(
        gradient: AppTheme.primaryGradient,
        borderRadius: BorderRadius.circular(AppTheme.radiusMd),
        boxShadow: [
          BoxShadow(
            color: AppTheme.primaryColor.withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onDownload,
          borderRadius: BorderRadius.circular(AppTheme.radiusMd),
          child: const Icon(
            Icons.download_rounded,
            color: Colors.white,
            size: 20,
          ),
        ),
      ),
    );
  }

  Color _getAccentColor() {
    if (isAuthorProfile) return Colors.pink.shade400;
    if (video.isImage) return Colors.purple.shade400;
    return AppTheme.primaryColor;
  }

  IconData _getTypeIcon() {
    if (video.isImage) return Icons.photo_library_outlined;
    return Icons.play_circle_outline;
  }

  String _getTypeLabel() {
    if (video.isImage) return '图文';
    return '视频';
  }

  String _formatDuration(int seconds) {
    final min = seconds ~/ 60;
    final sec = seconds % 60;
    return '${min.toString().padLeft(2, '0')}:${sec.toString().padLeft(2, '0')}';
  }
}
