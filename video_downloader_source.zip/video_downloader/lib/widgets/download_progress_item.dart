import 'package:flutter/material.dart';
import '../models/download_task.dart';
import '../services/download_manager.dart';
import '../theme/app_theme.dart';
import 'platform_badge.dart';

/// 下载进度项组件（动效升级版）
///
/// 特性：
/// - 渐变进度条 + 微光流动动画（下载中）
/// - 虚线进度条 + 旋转等待图标（等待中）
/// - 完成态绿色进度条 + 对勾缩放弹入动画
/// - 失败态红色进度条 + 感叹号抖动动画
/// - 暂停态半透明进度条 + 暂停图标
class DownloadProgressItem extends StatefulWidget {
  final DownloadTask task;
  final VoidCallback? onPause;
  final VoidCallback? onResume;
  final VoidCallback? onCancel;
  final VoidCallback? onTap;

  const DownloadProgressItem({
    super.key,
    required this.task,
    this.onPause,
    this.onResume,
    this.onCancel,
    this.onTap,
  });

  @override
  State<DownloadProgressItem> createState() => _DownloadProgressItemState();
}

class _DownloadProgressItemState extends State<DownloadProgressItem>
    with TickerProviderStateMixin {
  late AnimationController _shimmerController;
  late AnimationController _successController;
  late AnimationController _shakeController;
  late AnimationController _waitingRotateController;
  bool _wasCompleted = false;
  bool _wasFailed = false;

  @override
  void initState() {
    super.initState();
    _shimmerController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );
    _successController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    _shakeController = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _waitingRotateController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );
    _wasCompleted = widget.task.status == DownloadStatus.completed;
    _wasFailed = widget.task.status == DownloadStatus.failed;

    // 根据初始状态启动动画
    if (widget.task.status == DownloadStatus.downloading) {
      _shimmerController.repeat();
    }
    if (widget.task.status == DownloadStatus.queued) {
      _waitingRotateController.repeat();
    }
    if (_wasCompleted) {
      _successController.value = 1.0;
    }
  }

  @override
  void didUpdateWidget(DownloadProgressItem oldWidget) {
    super.didUpdateWidget(oldWidget);
    // 状态从非完成变为完成时，播放成功动画
    if (oldWidget.task.status != DownloadStatus.completed &&
        widget.task.status == DownloadStatus.completed) {
      _wasCompleted = true;
      _successController.forward(from: 0);
    }
    // 状态从非失败变为失败时，播放抖动动画
    if (oldWidget.task.status != DownloadStatus.failed &&
        widget.task.status == DownloadStatus.failed) {
      _wasFailed = true;
      _shakeController.forward(from: 0);
    }
    // 下载状态变化时控制微光动画
    if (widget.task.status == DownloadStatus.downloading &&
        !_shimmerController.isAnimating) {
      _shimmerController.repeat();
    } else if (widget.task.status != DownloadStatus.downloading &&
        _shimmerController.isAnimating) {
      _shimmerController.stop();
    }
    // 等待状态变化时控制旋转动画
    if (widget.task.status == DownloadStatus.queued &&
        !_waitingRotateController.isAnimating) {
      _waitingRotateController.repeat();
    } else if (widget.task.status != DownloadStatus.queued &&
        _waitingRotateController.isAnimating) {
      _waitingRotateController.stop();
    }
  }

  @override
  void dispose() {
    _shimmerController.dispose();
    _successController.dispose();
    _shakeController.dispose();
    _waitingRotateController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = AppTheme.isDark(context);
    final statusColor = _statusColor;

    return Container(
      decoration: BoxDecoration(
        color: AppTheme.cardBg(context),
        borderRadius: BorderRadius.circular(AppTheme.radiusLg),
        border: Border.all(
          color: isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
          width: 0.5,
        ),
        boxShadow: AppTheme.shadowSm,
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: widget.onTap,
          borderRadius: BorderRadius.circular(AppTheme.radiusLg),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                // 封面
                Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(AppTheme.radiusMd),
                    color: isDark ? const Color(0xFF0F172A) : const Color(0xFFF1F5F9),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: widget.task.videoCover.isNotEmpty
                      ? Image.network(
                          widget.task.videoCover,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => _buildPlaceholder(),
                        )
                      : _buildPlaceholder(),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // 标题 + 状态图标动效
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              widget.task.videoTitle,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                color: AppTheme.textPrimaryColor(context),
                              ),
                            ),
                          ),
                          // 状态图标动效
                          _buildStatusIcon(),
                        ],
                      ),
                      const SizedBox(height: 6),
                      // 平台 + 画质 + 状态
                      Row(
                        children: [
                          PlatformBadge(platform: widget.task.platform, size: 12),
                          const SizedBox(width: 6),
                          Text(
                            widget.task.qualityLabel,
                            style: TextStyle(
                              fontSize: 11,
                              color: AppTheme.textTertiaryColor(context),
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          const Spacer(),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              color: statusColor.withOpacity(isDark ? 0.15 : 0.1),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(
                              widget.task.statusText,
                              style: TextStyle(
                                fontSize: 11,
                                color: statusColor,
                                fontWeight: FontWeight.w600,
                                height: 1.2,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      // 增强版动画进度条
                      AnimatedProgressBar(
                        progress: widget.task.progress > 0 ? widget.task.progress : 0.0,
                        status: widget.task.status,
                        shimmerController: _shimmerController,
                        waitingRotateController: _waitingRotateController,
                        shakeController: _shakeController,
                        successController: _successController,
                      ),
                      const SizedBox(height: 6),
                      Row(
                        children: [
                          Text(
                            '${DownloadManager.formatSize(widget.task.receivedBytes)} / ${widget.task.totalBytes > 0 ? DownloadManager.formatSize(widget.task.totalBytes) : '计算中'}',
                            style: TextStyle(
                              fontSize: 11,
                              color: AppTheme.textTertiaryColor(context),
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          const Spacer(),
                          _buildActionButton(statusColor),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPlaceholder() {
    return Center(
      child: PlatformBadge(platform: widget.task.platform, size: 26),
    );
  }

  /// 构建状态图标（完成对勾/失败感叹号/等待旋转/暂停图标）
  Widget _buildStatusIcon() {
    switch (widget.task.status) {
      case DownloadStatus.completed:
        return ScaleTransition(
          scale: CurvedAnimation(
            parent: _successController,
            curve: Curves.elasticOut,
          ),
          child: Container(
            margin: const EdgeInsets.only(left: 8),
            padding: const EdgeInsets.all(3),
            decoration: BoxDecoration(
              color: AppTheme.successColor,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: AppTheme.successColor.withOpacity(0.4),
                  blurRadius: 6,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: const Icon(
              Icons.check_rounded,
              color: Colors.white,
              size: 14,
            ),
          ),
        );
      case DownloadStatus.failed:
        return _buildShakeAnimation(
          child: Container(
            margin: const EdgeInsets.only(left: 8),
            padding: const EdgeInsets.all(3),
            decoration: BoxDecoration(
              color: AppTheme.errorColor,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: AppTheme.errorColor.withOpacity(0.4),
                  blurRadius: 6,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: const Icon(
              Icons.priority_high_rounded,
              color: Colors.white,
              size: 14,
            ),
          ),
        );
      case DownloadStatus.queued:
        return RotationTransition(
          turns: _waitingRotateController,
          child: Container(
            margin: const EdgeInsets.only(left: 8),
            padding: const EdgeInsets.all(3),
            decoration: BoxDecoration(
              color: AppTheme.primaryColor.withOpacity(0.15),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.sync_rounded,
              color: AppTheme.primaryColor,
              size: 14,
            ),
          ),
        );
      case DownloadStatus.paused:
        return Container(
          margin: const EdgeInsets.only(left: 8),
          padding: const EdgeInsets.all(3),
          decoration: BoxDecoration(
            color: AppTheme.warningColor.withOpacity(0.15),
            shape: BoxShape.circle,
          ),
          child: Icon(
            Icons.pause_rounded,
            color: AppTheme.warningColor,
            size: 14,
          ),
        );
      default:
        return const SizedBox.shrink();
    }
  }

  /// 抖动动画包装器
  Widget _buildShakeAnimation({required Widget child}) {
    return AnimatedBuilder(
      animation: _shakeController,
      builder: (context, child) {
        final shakeOffset = _shakeController.value < 0.25
            ? _shakeController.value * 20
            : _shakeController.value < 0.5
                ? (0.5 - _shakeController.value) * 20
                : _shakeController.value < 0.75
                    ? (_shakeController.value - 0.5) * -20
                    : (1.0 - _shakeController.value) * -20;
        return Transform.translate(
          offset: Offset(shakeOffset, 0),
          child: child,
        );
      },
      child: child,
    );
  }

  Color get _statusColor {
    switch (widget.task.status) {
      case DownloadStatus.downloading:
        return AppTheme.infoColor;
      case DownloadStatus.completed:
        return AppTheme.successColor;
      case DownloadStatus.failed:
        return AppTheme.errorColor;
      case DownloadStatus.paused:
        return AppTheme.warningColor;
      case DownloadStatus.queued:
        return AppTheme.primaryColor;
      default:
        return AppTheme.textTertiary;
    }
  }

  Widget _buildActionButton(Color statusColor) {
    switch (widget.task.status) {
      case DownloadStatus.downloading:
        return _buildIconButton(
          icon: Icons.pause_rounded,
          color: statusColor,
          onTap: widget.onPause,
        );
      case DownloadStatus.paused:
      case DownloadStatus.failed:
      case DownloadStatus.queued:
        return _buildIconButton(
          icon: Icons.play_arrow_rounded,
          color: AppTheme.successColor,
          onTap: widget.onResume,
        );
      default:
        return const SizedBox.shrink();
    }
  }

  Widget _buildIconButton({
    required IconData icon,
    required Color color,
    VoidCallback? onTap,
  }) {
    return Material(
      color: color.withOpacity(0.1),
      borderRadius: BorderRadius.circular(8),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(8),
        child: Padding(
          padding: const EdgeInsets.all(4),
          child: Icon(icon, size: 18, color: color),
        ),
      ),
    );
  }
}

// ============================================================================
//  AnimatedProgressBar - 增强版动画进度条组件
// ============================================================================

/// 增强版动画进度条
///
/// 支持多种状态的动效展示：
/// - downloading：渐变色彩 + 微光流动（shimmer）
/// - queued：虚线样式 + 旋转等待图标
/// - completed：主题绿色 + 对勾缩放弹入
/// - failed：红色 + 感叹号抖动
/// - paused：半透明 + 暂停图标
class AnimatedProgressBar extends StatelessWidget {
  /// 进度值 0.0 ~ 1.0
  final double progress;

  /// 下载状态
  final DownloadStatus status;

  /// 微光动画控制器（下载中状态使用）
  final AnimationController? shimmerController;

  /// 等待旋转动画控制器（queued 状态使用）
  final AnimationController? waitingRotateController;

  /// 抖动动画控制器（failed 状态使用）
  final AnimationController? shakeController;

  /// 成功动画控制器（completed 状态使用）
  final AnimationController? successController;

  /// 进度条高度
  final double height;

  /// 圆角半径
  final double radius;

  const AnimatedProgressBar({
    super.key,
    required this.progress,
    required this.status,
    this.shimmerController,
    this.waitingRotateController,
    this.shakeController,
    this.successController,
    this.height = 6,
    this.radius = 3,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = AppTheme.isDark(context);
    final bgColor = isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0);

    switch (status) {
      case DownloadStatus.downloading:
        return _buildDownloadingBar(bgColor);
      case DownloadStatus.queued:
        return _buildQueuedBar(bgColor);
      case DownloadStatus.completed:
        return _buildCompletedBar(bgColor);
      case DownloadStatus.failed:
        return _buildFailedBar(bgColor);
      case DownloadStatus.paused:
        return _buildPausedBar(bgColor);
      default:
        return _buildDefaultBar(bgColor);
    }
  }

  // ==================== 下载中：渐变 + 微光流动 ====================
  Widget _buildDownloadingBar(Color bgColor) {
    final clampedProgress = progress.clamp(0.0, 1.0);
    final gradientColors = [
      AppTheme.infoColor,
      AppTheme.primaryColor,
      AppTheme.infoColor,
    ];

    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: Stack(
        children: [
          // 背景
          Container(height: height, color: bgColor),
          // 渐变进度
          SizedBox(
            height: height,
            child: FractionallySizedBox(
              widthFactor: clampedProgress,
              alignment: Alignment.centerLeft,
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: gradientColors,
                    stops: const [0.0, 0.5, 1.0],
                  ),
                ),
                child: shimmerController != null
                    ? _buildShimmerEffect()
                    : null,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildShimmerEffect() {
    return AnimatedBuilder(
      animation: shimmerController!,
      builder: (context, child) {
        return FractionallySizedBox(
          widthFactor: 0.4,
          alignment: Alignment(
            shimmerController!.value * 2.5 - 0.5,
            0,
          ),
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.transparent,
                  Colors.white.withOpacity(0.5),
                  Colors.transparent,
                ],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
          ),
        );
      },
    );
  }

  // ==================== 等待中：虚线 + 旋转图标 ====================
  Widget _buildQueuedBar(Color bgColor) {
    return SizedBox(
      height: height,
      child: Row(
        children: [
          Expanded(
            child: _buildDashedLine(
              color: AppTheme.primaryColor.withOpacity(0.6),
              bgColor: bgColor,
            ),
          ),
          const SizedBox(width: 8),
          if (waitingRotateController != null)
            RotationTransition(
              turns: waitingRotateController!,
              child: Icon(
                Icons.sync_rounded,
                size: height + 8,
                color: AppTheme.primaryColor,
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildDashedLine({required Color color, required Color bgColor}) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final dashWidth = 6.0;
        final dashSpace = 4.0;
        final count = (constraints.maxWidth / (dashWidth + dashSpace)).floor();
        return Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: List.generate(count, (_) {
            return Container(
              width: dashWidth,
              height: height,
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(radius),
              ),
            );
          }),
        );
      },
    );
  }

  // ==================== 完成：绿色 + 对勾弹入 ====================
  Widget _buildCompletedBar(Color bgColor) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: Stack(
        children: [
          Container(height: height, color: bgColor),
          Container(
            height: height,
            width: double.infinity,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  AppTheme.successColor,
                  AppTheme.successColor.withOpacity(0.8),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== 失败：红色 + 感叹号抖动 ====================
  Widget _buildFailedBar(Color bgColor) {
    final clampedProgress = progress.clamp(0.0, 1.0);
    final bar = ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: Stack(
        children: [
          Container(height: height, color: bgColor),
          SizedBox(
            height: height,
            child: FractionallySizedBox(
              widthFactor: clampedProgress,
              alignment: Alignment.centerLeft,
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      AppTheme.errorColor,
                      AppTheme.errorColor.withOpacity(0.7),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );

    if (shakeController == null) return bar;

    return AnimatedBuilder(
      animation: shakeController!,
      builder: (context, child) {
        // 快速左右抖动
        final t = shakeController!.value;
        double offset;
        if (t < 0.2) {
          offset = t * 15;
        } else if (t < 0.4) {
          offset = (0.4 - t) * 15;
        } else if (t < 0.6) {
          offset = (t - 0.4) * -15;
        } else if (t < 0.8) {
          offset = (0.8 - t) * -15;
        } else {
          offset = (t - 0.8) * 7.5;
        }
        return Transform.translate(
          offset: Offset(offset, 0),
          child: child,
        );
      },
      child: bar,
    );
  }

  // ==================== 暂停：半透明 + 暂停图标 ====================
  Widget _buildPausedBar(Color bgColor) {
    final clampedProgress = progress.clamp(0.0, 1.0);
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: Stack(
        children: [
          Container(height: height, color: bgColor),
          Opacity(
            opacity: 0.5,
            child: SizedBox(
              height: height,
              child: FractionallySizedBox(
                widthFactor: clampedProgress,
                alignment: Alignment.centerLeft,
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        AppTheme.warningColor,
                        AppTheme.warningColor.withOpacity(0.6),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== 默认状态 ====================
  Widget _buildDefaultBar(Color bgColor) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: Container(height: height, color: bgColor),
    );
  }
}
