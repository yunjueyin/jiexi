import 'dart:ui';
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// 上下文菜单项
class ContextMenuItem {
  /// 唯一标识
  final String id;

  /// 显示文字
  final String label;

  /// 图标
  final IconData icon;

  /// 图标背景色
  final Color? iconColor;

  /// 是否危险操作（红色）
  final bool isDestructive;

  const ContextMenuItem({
    required this.id,
    required this.label,
    required this.icon,
    this.iconColor,
    this.isDestructive = false,
  });
}

/// 长按上下文菜单
///
/// 从底部滑入，带图标和文字的操作菜单。
/// 背景使用 BackdropFilter 实时模糊，模糊程度随弹窗动画渐变。
/// 弹窗进入时带轻微缩放+淡入动画。
/// 使用 [showContextMenu] 静态方法弹出。
class ContextMenu {
  /// 显示上下文菜单
  ///
  /// 返回用户选择的菜单项 ID，如果取消则返回 null。
  static Future<String?> show(
    BuildContext context, {
    required List<ContextMenuItem> items,
    String? title,
  }) async {
    final result = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      barrierColor: Colors.transparent, // 自定义模糊背景
      builder: (context) => _ContextMenuSheet(
        items: items,
        title: title,
      ),
      transitionAnimationController: null,
    );

    return result;
  }
}

class _ContextMenuSheet extends StatefulWidget {
  final List<ContextMenuItem> items;
  final String? title;

  const _ContextMenuSheet({
    required this.items,
    this.title,
  });

  @override
  State<_ContextMenuSheet> createState() => _ContextMenuSheetState();
}

class _ContextMenuSheetState extends State<_ContextMenuSheet>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _fadeAnimation;
  late Animation<double> _scaleAnimation;
  late Animation<double> _blurAnimation;

  /// 目标模糊强度
  static const double _targetBlur = 20.0;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 320),
      vsync: this,
    );

    // 滑动动画：从底部滑入
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 1),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOutCubic,
    ));

    // 淡入动画
    _fadeAnimation = Tween<double>(
      begin: 0,
      end: 1,
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: const Interval(0.0, 0.6, curve: Curves.easeOut),
    ));

    // 缩放动画：从 0.96 缩放至 1.0
    _scaleAnimation = Tween<double>(
      begin: 0.96,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOutCubic,
    ));

    // 模糊动画：从 0 渐变到目标值
    _blurAnimation = Tween<double>(
      begin: 0,
      end: _targetBlur,
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOut,
    ));

    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _closeWithAnimation(String? result) async {
    await _controller.reverse();
    if (mounted) {
      Navigator.pop(context, result);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = AppTheme.isDark(context);
    final isOled = AppTheme.isOledDark(context);

    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return Stack(
          children: [
            // 模糊背景层
            Positioned.fill(
              child: GestureDetector(
                onTap: () => _closeWithAnimation(null),
                child: BackdropFilter(
                  filter: ImageFilter.blur(
                    sigmaX: _blurAnimation.value,
                    sigmaY: _blurAnimation.value,
                  ),
                  child: Container(
                    color: isOled
                        ? Colors.black.withOpacity(0.4 * _fadeAnimation.value)
                        : (isDark
                            ? const Color(0xFF0B1120).withOpacity(0.5 * _fadeAnimation.value)
                            : const Color(0xFF0F172A).withOpacity(0.3 * _fadeAnimation.value)),
                  ),
                ),
              ),
            ),
            // 菜单内容
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: FadeTransition(
                opacity: _fadeAnimation,
                child: SlideTransition(
                  position: _slideAnimation,
                  child: ScaleTransition(
                    scale: _scaleAnimation,
                    alignment: Alignment.bottomCenter,
                    child: _buildMenuContent(context, isDark, isOled),
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildMenuContent(BuildContext context, bool isDark, bool isOled) {
    // 半透明背景（配合模糊效果）
    final bgColor = isOled
        ? const Color(0xFF0A0A0A).withOpacity(0.85)
        : (isDark
            ? const Color(0xFF1E293B).withOpacity(0.85)
            : Colors.white.withOpacity(0.85));

    return ClipRRect(
      borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
      child: BackdropFilter(
        filter: ImageFilter.blur(
          sigmaX: _blurAnimation.value * 0.5,
          sigmaY: _blurAnimation.value * 0.5,
        ),
        child: Container(
          decoration: BoxDecoration(
            color: bgColor,
            border: Border(
              top: BorderSide(
                color: isDark
                    ? const Color(0xFF334155).withOpacity(0.5)
                    : Colors.grey.shade200.withOpacity(0.5),
                width: 0.5,
              ),
            ),
          ),
          child: SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // 顶部拖动条
                  Container(
                    margin: const EdgeInsets.only(top: 10),
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: isDark
                          ? Colors.grey.shade700.withOpacity(0.6)
                          : Colors.grey.shade300.withOpacity(0.6),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  if (widget.title != null) ...[
                    const SizedBox(height: 12),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Text(
                        widget.title!,
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color: AppTheme.textTertiaryColor(context),
                        ),
                      ),
                    ),
                  ],
                  const SizedBox(height: 8),
                  ...List.generate(widget.items.length, (index) {
                    final item = widget.items[index];
                    return _buildMenuItem(item, index);
                  }),
                  const SizedBox(height: 4),
                  // 取消按钮
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: SizedBox(
                      width: double.infinity,
                      child: TextButton(
                        onPressed: () => _closeWithAnimation(null),
                        style: TextButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          backgroundColor: isDark
                              ? const Color(0xFF1E293B).withOpacity(0.8)
                              : const Color(0xFFF1F5F9).withOpacity(0.8),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(AppTheme.radiusMd),
                          ),
                        ),
                        child: Text(
                          '取消',
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                            color: AppTheme.textSecondaryColor(context),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildMenuItem(ContextMenuItem item, int index) {
    final textColor = item.isDestructive
        ? AppTheme.errorColor
        : AppTheme.textPrimaryColor(context);
    final iconBgColor = item.isDestructive
        ? AppTheme.errorColor.withOpacity(0.12)
        : (item.iconColor?.withOpacity(0.12) ??
            AppTheme.primaryColor.withOpacity(0.12));
    final iconColor = item.isDestructive
        ? AppTheme.errorColor
        : (item.iconColor ?? AppTheme.primaryColor);

    return InkWell(
      onTap: () => _closeWithAnimation(item.id),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(AppTheme.radiusMd),
          ),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: iconBgColor,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(
                  item.icon,
                  size: 22,
                  color: iconColor,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Text(
                  item.label,
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w500,
                    color: textColor,
                  ),
                ),
              ),
              Icon(
                Icons.chevron_right,
                size: 20,
                color: AppTheme.textTertiaryColor(context),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
