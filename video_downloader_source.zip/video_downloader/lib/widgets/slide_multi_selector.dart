import 'package:flutter/material.dart';
import '../services/haptic_service.dart';

/// 滑动多选控制器
///
/// 用于外部控制多选模式的进入/退出、选中状态等
class SlideMultiSelectorController extends ChangeNotifier {
  bool _isSelectionMode = false;
  final Set<String> _selectedIds = {};
  bool _initialSelectionValue = true;

  bool get isSelectionMode => _isSelectionMode;
  Set<String> get selectedIds => Set.unmodifiable(_selectedIds);
  int get selectedCount => _selectedIds.length;

  /// 进入多选模式
  void enterSelectionMode([String? firstId]) {
    _isSelectionMode = true;
    _initialSelectionValue = true;
    if (firstId != null) {
      _selectedIds
        ..clear()
        ..add(firstId);
    } else {
      _selectedIds.clear();
    }
    HapticService.selectionClick();
    notifyListeners();
  }

  /// 退出多选模式
  void exitSelectionMode() {
    _isSelectionMode = false;
    _selectedIds.clear();
    notifyListeners();
  }

  /// 切换选中状态
  void toggle(String id) {
    if (_selectedIds.contains(id)) {
      _selectedIds.remove(id);
    } else {
      _selectedIds.add(id);
    }
    HapticService.selectionClick();
    notifyListeners();
  }

  /// 设置选中状态
  void setSelected(String id, bool selected) {
    final changed = selected ? _selectedIds.add(id) : _selectedIds.remove(id);
    if (changed) {
      HapticService.selectionClick();
      notifyListeners();
    }
  }

  /// 批量设置选中（用于滑动连选，不每次触发震动）
  void setSelectedRange(Set<String> ids, bool selected) {
    bool changed = false;
    for (final id in ids) {
      if (selected) {
        if (_selectedIds.add(id)) changed = true;
      } else {
        if (_selectedIds.remove(id)) changed = true;
      }
    }
    if (changed) {
      notifyListeners();
    }
  }

  /// 全选
  void selectAll(List<String> allIds) {
    _selectedIds
      ..clear()
      ..addAll(allIds);
    HapticService.selectionClick();
    notifyListeners();
  }

  /// 反选
  void invertSelection(List<String> allIds) {
    final newSet = <String>{};
    for (final id in allIds) {
      if (!_selectedIds.contains(id)) {
        newSet.add(id);
      }
    }
    _selectedIds
      ..clear()
      ..addAll(newSet);
    HapticService.selectionClick();
    notifyListeners();
  }

  /// 清空选择
  void clearSelection() {
    if (_selectedIds.isNotEmpty) {
      _selectedIds.clear();
      notifyListeners();
    }
  }

  /// 是否全部选中
  bool isAllSelected(List<String> allIds) {
    if (allIds.isEmpty) return false;
    return _selectedIds.length == allIds.length;
  }

  /// 设置滑动时的初始选择方向（true=选中，false=取消选中）
  void setInitialSelectionValue(bool value) {
    _initialSelectionValue = value;
  }

  bool get initialSelectionValue => _initialSelectionValue;
}

/// 滑动多选列表组件
///
/// 支持长按进入多选模式，然后滑动连续选中/取消多项，
/// 类似手机相册的滑动连选手势。
///
/// 使用方式：
/// ```dart
/// SlideMultiSelector(
///   controller: _selectorController,
///   itemCount: items.length,
///   itemIdBuilder: (index) => items[index].id,
///   itemBuilder: (context, index, isSelected, isSelectionMode) {
///     return YourListItem(item: items[index], isSelected: isSelected);
///   },
/// )
/// ```
class SlideMultiSelector extends StatefulWidget {
  /// 控制器
  final SlideMultiSelectorController controller;

  /// 列表项数量
  final int itemCount;

  /// 获取每项的唯一 ID
  final String Function(int index) itemIdBuilder;

  /// 构建列表项
  final Widget Function(
    BuildContext context,
    int index,
    bool isSelected,
    bool isSelectionMode,
  ) itemBuilder;

  /// 列表 padding
  final EdgeInsetsGeometry? padding;

  /// 列表的 physics
  final ScrollPhysics? physics;

  /// 项之间的分隔高度
  final double itemSpacing;

  /// 长按进入多选的延迟时间
  final Duration longPressDelay;

  /// 滑动选择的水平触发区域占项宽度的比例（0.0~1.0）
  /// 设为 1.0 表示整个区域都可以触发滑动选择
  final double slideAreaWidthRatio;

  const SlideMultiSelector({
    super.key,
    required this.controller,
    required this.itemCount,
    required this.itemIdBuilder,
    required this.itemBuilder,
    this.padding,
    this.physics,
    this.itemSpacing = 0,
    this.longPressDelay = const Duration(milliseconds: 500),
    this.slideAreaWidthRatio = 1.0,
  });

  @override
  State<SlideMultiSelector> createState() => _SlideMultiSelectorState();
}

class _SlideMultiSelectorState extends State<SlideMultiSelector> {
  // 滑动选择状态
  bool _isDragging = false;
  int? _dragStartIndex;
  int? _lastDragIndex;
  final Set<String> _dragToggledIds = {};

  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_onControllerChanged);
  }

  @override
  void dispose() {
    widget.controller.removeListener(_onControllerChanged);
    super.dispose();
  }

  void _onControllerChanged() {
    setState(() {});
  }

  /// 获取指定索引位置的渲染对象
  int? _getIndexAtPosition(Offset globalPosition) {
    final RenderBox? box = context.findRenderObject() as RenderBox?;
    if (box == null) return null;

    final localPosition = box.globalToLocal(globalPosition);

    // 计算 padding 的影响
    double topOffset = 0;
    if (widget.padding != null) {
      topOffset = widget.padding!.resolve(Directionality.of(context)).top;
    }

    double adjustedY = localPosition.dy - topOffset;
    if (adjustedY < 0) return null;

    // 简单估算：假设每个 item 的高度约为 80（包含间距）
    // 实际应该通过 Sliver 布局来精确计算，但为了简化，我们用近似方法
    // 更好的实现方式是使用 Listener 包裹每个 item

    // 由于我们在每个 item 上都有 Listener，这里不需要全局计算
    return null;
  }

  /// 处理某一项的指针按下
  void _onItemPointerDown(int index, PointerDownEvent event) {
    // 只有在多选模式下才处理滑动选择
    if (!widget.controller.isSelectionMode) return;

    // 检查是否在滑动区域内（只检查水平方向，垂直方向由 item 本身限制）
    final RenderBox box = context.findRenderObject() as RenderBox;
    final localDx = box.globalToLocal(event.position).dx;
    final width = box.size.width;
    final effectiveWidth = width * widget.slideAreaWidthRatio;
    final startX = (width - effectiveWidth) / 2;

    if (localDx < startX || localDx > width - startX) return;

    _isDragging = true;
    _dragStartIndex = index;
    _lastDragIndex = index;
    _dragToggledIds.clear();

    // 记录初始项的选中状态，作为滑动方向
    final id = widget.itemIdBuilder(index);
    final wasSelected = widget.controller.selectedIds.contains(id);
    widget.controller.setInitialSelectionValue(!wasSelected);

    // 切换初始项
    widget.controller.toggle(id);
    _dragToggledIds.add(id);
  }

  /// 处理滑动
  void _onItemPointerMove(int index, PointerMoveEvent event) {
    if (!_isDragging || !widget.controller.isSelectionMode) return;
    if (_dragStartIndex == null) return;

    if (_lastDragIndex == index) return;

    final start = _dragStartIndex!;
    final previous = _lastDragIndex!;
    final current = index;

    // 计算需要更新的范围
    final minIndex = (previous < current) ? previous : current;
    final maxIndex = (previous > current) ? previous : current;

    final newValue = widget.controller.initialSelectionValue;
    final toggledThisFrame = <String>{};

    for (int i = minIndex; i <= maxIndex; i++) {
      if (i < 0 || i >= widget.itemCount) continue;

      final id = widget.itemIdBuilder(i);

      // 已经在本次拖拽中切换过的项不再处理
      if (_dragToggledIds.contains(id)) continue;

      // 计算该项相对于起点的位置，确定其应该是什么状态
      // 滑动选择的逻辑：从起点向一个方向滑动，经过的项都变成初始选择值
      // 向回滑动时，经过的项恢复原状
      bool shouldBeSelected;

      if (start <= previous && previous <= current) {
        // 向下滑动（索引增大方向）
        if (i >= start && i <= current) {
          shouldBeSelected = newValue;
        } else {
          shouldBeSelected = widget.controller.selectedIds.contains(id);
        }
      } else if (start >= previous && previous >= current) {
        // 向上滑动（索引减小方向）
        if (i <= start && i >= current) {
          shouldBeSelected = newValue;
        } else {
          shouldBeSelected = widget.controller.selectedIds.contains(id);
        }
      } else {
        // 方向变化，需要重新计算
        // 简化处理：只处理当前范围内的项
        if (i >= start.min(current) && i <= start.max(current)) {
          shouldBeSelected = newValue;
        } else {
          shouldBeSelected = widget.controller.selectedIds.contains(id);
        }
      }

      final isCurrentlySelected = widget.controller.selectedIds.contains(id);
      if (shouldBeSelected != isCurrentlySelected) {
        if (shouldBeSelected) {
          widget.controller._selectedIds.add(id);
        } else {
          widget.controller._selectedIds.remove(id);
        }
        toggledThisFrame.add(id);
      }
    }

    _dragToggledIds.addAll(toggledThisFrame);
    _lastDragIndex = index;

    if (toggledThisFrame.isNotEmpty) {
      widget.controller.notifyListeners();
    }
  }

  /// 处理指针抬起
  void _onItemPointerUp(PointerUpEvent event) {
    _isDragging = false;
    _dragStartIndex = null;
    _lastDragIndex = null;
    _dragToggledIds.clear();
  }

  /// 处理指针取消
  void _onItemPointerCancel(PointerCancelEvent event) {
    _isDragging = false;
    _dragStartIndex = null;
    _lastDragIndex = null;
    _dragToggledIds.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Listener(
      onPointerUp: _onItemPointerUp,
      onPointerCancel: _onItemPointerCancel,
      child: ListView.builder(
        padding: widget.padding,
        physics: widget.physics ?? const AlwaysScrollableScrollPhysics(),
        itemCount: widget.itemCount,
        itemBuilder: (context, index) {
          final id = widget.itemIdBuilder(index);
          final isSelected = widget.controller.selectedIds.contains(id);
          final isSelectionMode = widget.controller.isSelectionMode;

          // 用 Listener 包裹每个 item 以检测滑动
          return Listener(
            onPointerDown: (event) => _onItemPointerDown(index, event),
            onPointerMove: (event) => _onItemPointerMove(index, event),
            behavior: HitTestBehavior.opaque,
            child: widget.itemBuilder(
              context,
              index,
              isSelected,
              isSelectionMode,
            ),
          );
        },
      ),
    );
  }
}

/// 多选模式底部操作栏
///
/// 从底部滑入的操作栏，包含全选、删除、收藏、分享、导出等操作按钮
class SelectionBottomActionBar extends StatelessWidget {
  /// 已选中数量
  final int selectedCount;

  /// 总数量
  final int totalCount;

  /// 是否全选
  final bool isAllSelected;

  /// 全选/取消全选回调
  final VoidCallback onToggleSelectAll;

  /// 删除回调
  final VoidCallback? onDelete;

  /// 收藏回调
  final VoidCallback? onFavorite;

  /// 分享回调
  final VoidCallback? onShare;

  /// 导出回调
  final VoidCallback? onExport;

  /// 自定义操作按钮（可选）
  final List<SelectionActionItem>? extraActions;

  const SelectionBottomActionBar({
    super.key,
    required this.selectedCount,
    required this.totalCount,
    required this.isAllSelected,
    required this.onToggleSelectAll,
    this.onDelete,
    this.onFavorite,
    this.onShare,
    this.onExport,
    this.extraActions,
  });

  bool get hasSelection => selectedCount > 0;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeOutCubic,
      builder: (context, value, child) {
        return Transform.translate(
          offset: Offset(0, (1 - value) * 100),
          child: Opacity(
            opacity: value,
            child: child,
          ),
        );
      },
      child: Container(
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.08),
              blurRadius: 10,
              offset: const Offset(0, -2),
            ),
          ],
        ),
        child: SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
            child: Row(
              children: [
                Expanded(
                  child: _buildActionButton(
                    context,
                    icon: isAllSelected
                        ? Icons.deselect
                        : Icons.select_all,
                    label: isAllSelected ? '取消全选' : '全选',
                    onTap: onToggleSelectAll,
                  ),
                ),
                Expanded(
                  child: _buildActionButton(
                    context,
                    icon: Icons.delete_outline,
                    label: '删除',
                    color: Colors.red,
                    onTap: hasSelection ? onDelete : null,
                  ),
                ),
                if (onFavorite != null)
                  Expanded(
                    child: _buildActionButton(
                      context,
                      icon: Icons.favorite_border,
                      label: '收藏',
                      onTap: hasSelection ? onFavorite : null,
                    ),
                  ),
                if (onShare != null)
                  Expanded(
                    child: _buildActionButton(
                      context,
                      icon: Icons.share_outlined,
                      label: '分享',
                      onTap: hasSelection ? onShare : null,
                    ),
                  ),
                if (onExport != null)
                  Expanded(
                    child: _buildActionButton(
                      context,
                      icon: Icons.file_download_outlined,
                      label: '导出',
                      onTap: hasSelection ? onExport : null,
                    ),
                  ),
                ...?(extraActions?.map((a) => Expanded(
                      child: _buildActionButton(
                        context,
                        icon: a.icon,
                        label: a.label,
                        color: a.color,
                        onTap: hasSelection ? a.onTap : null,
                      ),
                    ))),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildActionButton(
    BuildContext context, {
    required IconData icon,
    required String label,
    required VoidCallback? onTap,
    Color? color,
  }) {
    final isEnabled = onTap != null;
    final iconColor = color ??
        (isEnabled
            ? Theme.of(context).textTheme.bodyLarge?.color ?? Colors.black87
            : Colors.grey.shade400);

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 20, color: iconColor),
            const SizedBox(height: 2),
            Text(
              label,
              style: TextStyle(
                fontSize: 11,
                color: iconColor,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// 自定义操作项
class SelectionActionItem {
  final IconData icon;
  final String label;
  final Color? color;
  final VoidCallback onTap;

  const SelectionActionItem({
    required this.icon,
    required this.label,
    required this.onTap,
    this.color,
  });
}

/// 多选模式顶部 AppBar
///
/// 显示已选中数量和关闭按钮
class SelectionModeAppBar extends StatelessWidget implements PreferredSizeWidget {
  /// 已选中数量
  final int selectedCount;

  /// 关闭/退出回调
  final VoidCallback onClose;

  /// 全选回调（可选，右侧显示全选按钮）
  final VoidCallback? onSelectAll;

  /// 是否全选状态
  final bool isAllSelected;

  /// 背景色（默认使用主题主色渐变）
  final List<Color>? gradientColors;

  const SelectionModeAppBar({
    super.key,
    required this.selectedCount,
    required this.onClose,
    this.onSelectAll,
    this.isAllSelected = false,
    this.gradientColors,
  });

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);

  @override
  Widget build(BuildContext context) {
    final colors = gradientColors ??
        [
          Theme.of(context).primaryColor,
          Theme.of(context).primaryColor.withGreen(180),
        ];

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: colors,
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              IconButton(
                icon: const Icon(Icons.close, color: Colors.white, size: 22),
                onPressed: onClose,
                tooltip: '取消',
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(),
              ),
              const SizedBox(width: 8),
              Text(
                '已选 $selectedCount 项',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const Spacer(),
              if (onSelectAll != null)
                TextButton(
                  onPressed: onSelectAll,
                  child: Text(
                    isAllSelected ? '取消全选' : '全选',
                    style: const TextStyle(color: Colors.white, fontSize: 14),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

/// 扩展 num 的 min/max 方法
extension _NumExt on num {
  num min(num other) => this < other ? this : other;
  num max(num other) => this > other ? this : other;
}
