import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// 通用确认弹窗
/// 
/// 比原生 AlertDialog 更美观，支持：
/// - 自定义图标和颜色
/// - 危险操作红色强调
/// - 自定义按钮文案
/// - 内容支持组件或纯文本
class ConfirmDialog extends StatelessWidget {
  /// 标题
  final String title;

  /// 内容（文字）
  final String? content;

  /// 内容组件（优先级高于 content）
  final Widget? contentWidget;

  /// 确认按钮文字
  final String confirmText;

  /// 取消按钮文字
  final String cancelText;

  /// 是否为危险操作（确认按钮变红）
  final bool isDestructive;

  /// 图标（可选）
  final IconData? icon;

  /// 图标颜色
  final Color? iconColor;

  const ConfirmDialog({
    super.key,
    required this.title,
    this.content,
    this.contentWidget,
    this.confirmText = '确定',
    this.cancelText = '取消',
    this.isDestructive = false,
    this.icon,
    this.iconColor,
  });

  /// 危险操作弹窗（删除、清空等）
  factory ConfirmDialog.destructive({
    required String title,
    String? content,
    Widget? contentWidget,
    String confirmText = '删除',
    String cancelText = '取消',
    IconData icon = Icons.warning_amber_rounded,
  }) {
    return ConfirmDialog(
      title: title,
      content: content,
      contentWidget: contentWidget,
      confirmText: confirmText,
      cancelText: cancelText,
      isDestructive: true,
      icon: icon,
      iconColor: Colors.orange,
    );
  }

  /// 成功/确认弹窗
  factory ConfirmDialog.success({
    required String title,
    String? content,
    String confirmText = '好的',
    String cancelText = '取消',
  }) {
    return ConfirmDialog(
      title: title,
      content: content,
      confirmText: confirmText,
      cancelText: cancelText,
      icon: Icons.check_circle_outline,
      iconColor: Colors.green,
    );
  }

  @override
  Widget build(BuildContext context) {
    final confirmColor = isDestructive ? Colors.red : AppTheme.primaryColor;

    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 0,
      backgroundColor: Colors.transparent,
      child: Container(
        decoration: BoxDecoration(
          color: Theme.of(context).dialogBackgroundColor,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 20,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        padding: const EdgeInsets.fromLTRB(24, 24, 24, 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // 图标（可选）
            if (icon != null) ...[
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: (iconColor ?? AppTheme.primaryColor).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(28),
                ),
                child: Icon(icon, size: 28, color: iconColor ?? AppTheme.primaryColor),
              ),
              const SizedBox(height: 16),
            ],
            // 标题
            Text(
              title,
              style: const TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.w700,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 12),
            // 内容
            if (contentWidget != null)
              contentWidget!
            else if (content != null)
              Text(
                content!,
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey.shade600,
                  height: 1.5,
                ),
                textAlign: TextAlign.center,
              ),
            const SizedBox(height: 24),
            // 按钮行
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.of(context).pop(false),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      side: BorderSide(color: Colors.grey.shade300),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      foregroundColor: Colors.grey.shade700,
                    ),
                    child: Text(
                      cancelText,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => Navigator.of(context).pop(true),
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      backgroundColor: confirmColor,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      elevation: 0,
                    ),
                    child: Text(
                      confirmText,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// 显示确认弹窗的便捷方法
/// 
/// 返回 true 表示确认，false 表示取消
Future<bool> showConfirmDialog(
  BuildContext context, {
  required String title,
  String? content,
  Widget? contentWidget,
  String confirmText = '确定',
  String cancelText = '取消',
  bool isDestructive = false,
  IconData? icon,
  Color? iconColor,
}) async {
  final result = await showDialog<bool>(
    context: context,
    barrierDismissible: false,
    builder: (context) => ConfirmDialog(
      title: title,
      content: content,
      contentWidget: contentWidget,
      confirmText: confirmText,
      cancelText: cancelText,
      isDestructive: isDestructive,
      icon: icon,
      iconColor: iconColor,
    ),
  );
  return result ?? false;
}
