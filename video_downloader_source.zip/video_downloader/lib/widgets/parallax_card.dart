import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:sensors_plus/sensors_plus.dart';
import '../theme/app_theme.dart';

/// 3D 视差卡片组件
///
/// 监听设备陀螺仪/加速度传感器，使卡片随设备倾斜产生轻微的 3D 旋转效果。
/// 卡片内的层次元素有不同的位移量，从而产生视差深度感。
///
/// 使用方式：
/// ```dart
/// ParallaxCard(
///   enabled: true,
///   backgroundLayer: Container(color: Colors.blue),
///   middleLayer: Text('Middle'),
///   foregroundLayer: Text('Front'),
/// )
/// ```
class ParallaxCard extends StatefulWidget {
  /// 是否启用视差效果
  final bool enabled;

  /// 背景层（位移最小，最远）
  final Widget backgroundLayer;

  /// 中间层（中等位移）
  final Widget? middleLayer;

  /// 前景层（位移最大，最近）
  final Widget? foregroundLayer;

  /// 卡片整体装饰
  final BoxDecoration? decoration;

  /// 卡片内边距
  final EdgeInsetsGeometry padding;

  /// 最大旋转角度（弧度），默认约 8 度
  final double maxRotation;

  /// 传感器事件节流时间（毫秒）
  final int throttleMs;

  /// 动画平滑度（0-1，值越小越平滑）
  final double smoothing;

  /// 卡片宽度
  final double? width;

  /// 卡片高度
  final double? height;

  const ParallaxCard({
    super.key,
    this.enabled = true,
    required this.backgroundLayer,
    this.middleLayer,
    this.foregroundLayer,
    this.decoration,
    this.padding = const EdgeInsets.all(16),
    this.maxRotation = 0.14,
    this.throttleMs = 32,
    this.smoothing = 0.2,
    this.width,
    this.height,
  });

  @override
  State<ParallaxCard> createState() => _ParallaxCardState();
}

class _ParallaxCardState extends State<ParallaxCard> {
  StreamSubscription<AccelerometerEvent>? _accelSubscription;

  // 目标旋转值（传感器原始值经过滤后）
  double _targetRotationX = 0;
  double _targetRotationY = 0;

  // 当前显示的旋转值（平滑动画用）
  double _currentRotationX = 0;
  double _currentRotationY = 0;

  // 上次传感器事件时间（节流用）
  int _lastEventTime = 0;

  // 动画定时器
  Timer? _animationTimer;

  @override
  void initState() {
    super.initState();
    if (widget.enabled) {
      _initSensors();
      _startAnimationLoop();
    }
  }

  @override
  void didUpdateWidget(covariant ParallaxCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.enabled != oldWidget.enabled) {
      if (widget.enabled) {
        _initSensors();
        _startAnimationLoop();
      } else {
        _disposeSensors();
        _stopAnimationLoop();
        _resetRotation();
      }
    }
  }

  @override
  void dispose() {
    _disposeSensors();
    _stopAnimationLoop();
    super.dispose();
  }

  void _initSensors() {
    _accelSubscription = accelerometerEventStream(
      samplingPeriod: const Duration(milliseconds: 50),
    ).listen(_onAccelerometerEvent);
  }

  void _disposeSensors() {
    _accelSubscription?.cancel();
    _accelSubscription = null;
  }

  void _startAnimationLoop() {
    _animationTimer?.cancel();
    _animationTimer = Timer.periodic(
      const Duration(milliseconds: 16),
      (_) => _smoothAnimation(),
    );
  }

  void _stopAnimationLoop() {
    _animationTimer?.cancel();
    _animationTimer = null;
  }

  void _resetRotation() {
    if (mounted) {
      setState(() {
        _targetRotationX = 0;
        _targetRotationY = 0;
        _currentRotationX = 0;
        _currentRotationY = 0;
      });
    }
  }

  void _onAccelerometerEvent(AccelerometerEvent event) {
    final now = DateTime.now().millisecondsSinceEpoch;
    // 节流
    if (now - _lastEventTime < widget.throttleMs) return;
    _lastEventTime = now;

    // 将加速度转换为倾斜角度
    // x 轴倾斜 → 绕 Y 轴旋转
    // y 轴倾斜 → 绕 X 轴旋转
    final normalizedX = (event.x / 9.8).clamp(-1.0, 1.0);
    final normalizedY = (event.y / 9.8).clamp(-1.0, 1.0);

    // 反方向：设备向左倾 → 卡片向左旋转（绕Y轴负方向）
    // 设备向前倾 → 卡片向后仰（绕X轴正方向）
    _targetRotationY = normalizedX * widget.maxRotation;
    _targetRotationX = -normalizedY * widget.maxRotation;
  }

  void _smoothAnimation() {
    if (!mounted) return;

    final diffX = _targetRotationX - _currentRotationX;
    final diffY = _targetRotationY - _currentRotationY;

    // 差值很小则跳过，避免不必要的重绘
    if (diffX.abs() < 0.0005 && diffY.abs() < 0.0005) return;

    setState(() {
      _currentRotationX += diffX * widget.smoothing;
      _currentRotationY += diffY * widget.smoothing;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.enabled) {
      return _buildStaticCard();
    }

    return Transform(
      alignment: Alignment.center,
      transform: Matrix4.identity()
        ..setEntry(3, 2, 0.001) // 透视效果
        ..rotateX(_currentRotationX)
        ..rotateY(_currentRotationY),
      child: _buildCardContent(),
    );
  }

  Widget _buildStaticCard() {
    return _buildCardContent();
  }

  Widget _buildCardContent() {
    final bgOffset = _calculateLayerOffset(0.3);
    final midOffset = _calculateLayerOffset(0.6);
    final fgOffset = _calculateLayerOffset(1.0);

    return Container(
      width: widget.width,
      height: widget.height,
      decoration: widget.decoration ??
          BoxDecoration(
            color: AppTheme.cardBg(context),
            borderRadius: BorderRadius.circular(AppTheme.radiusLg),
            boxShadow: AppTheme.shadowMd,
          ),
      padding: widget.padding,
      clipBehavior: Clip.antiAlias,
      child: Stack(
        fit: StackFit.expand,
        children: [
          // 背景层（最远，位移最小）
          Transform.translate(
            offset: bgOffset,
            child: widget.backgroundLayer,
          ),
          // 中间层
          if (widget.middleLayer != null)
            Transform.translate(
              offset: midOffset,
              child: widget.middleLayer!,
            ),
          // 前景层（最近，位移最大）
          if (widget.foregroundLayer != null)
            Transform.translate(
              offset: fgOffset,
              child: widget.foregroundLayer!,
            ),
        ],
      ),
    );
  }

  /// 根据当前旋转角度计算某一层的位移偏移
  Offset _calculateLayerOffset(double depthFactor) {
    // 旋转越大，位移越大
    // 绕 X 轴旋转 → 内容在 Y 方向位移
    // 绕 Y 轴旋转 → 内容在 X 方向位移
    final maxShift = 12.0 * depthFactor;
    final dx = -_currentRotationY * maxShift / widget.maxRotation * maxShift;
    final dy = -_currentRotationX * maxShift / widget.maxRotation * maxShift;
    return Offset(dx, dy);
  }
}

/// 视差结果卡片：用于结果展示，带有封面、标题、按钮等多层视差
///
/// 这是一个高度封装的视差卡片，内部包含背景装饰层、封面图层、文字信息层、
/// 操作按钮层等多个层次，产生明显的 3D 深度感。
class ParallaxResultCard extends StatelessWidget {
  final String title;
  final String author;
  final String coverUrl;
  final String platform;
  final bool enabled;
  final VoidCallback? onTap;
  final VoidCallback? onDownload;

  const ParallaxResultCard({
    super.key,
    required this.title,
    required this.author,
    required this.coverUrl,
    required this.platform,
    this.enabled = true,
    this.onTap,
    this.onDownload,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = AppTheme.isDark(context);
    final platformColor = AppTheme.platformPrimaryColor(platform);

    return ParallaxCard(
      enabled: enabled,
      maxRotation: 0.12,
      smoothing: 0.15,
      padding: EdgeInsets.zero,
      decoration: BoxDecoration(
        color: AppTheme.cardBg(context),
        borderRadius: BorderRadius.circular(AppTheme.radiusLg),
        border: Border.all(
          color: isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
          width: 0.5,
        ),
        boxShadow: AppTheme.shadowMd,
      ),
      // 背景层：渐变装饰
      backgroundLayer: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              platformColor.withOpacity(isDark ? 0.08 : 0.04),
              Colors.transparent,
            ],
          ),
        ),
      ),
      // 中间层：封面图 + 主要内容
      middleLayer: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            // 封面
            ClipRRect(
              borderRadius: BorderRadius.circular(AppTheme.radiusMd),
              child: coverUrl.isNotEmpty
                  ? Image.network(
                      coverUrl,
                      width: 88,
                      height: 72,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => _buildCoverPlaceholder(isDark),
                    )
                  : _buildCoverPlaceholder(isDark),
            ),
            const SizedBox(width: 14),
            // 文字信息
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: AppTheme.textPrimaryColor(context),
                      height: 1.35,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: platformColor.withOpacity(isDark ? 0.15 : 0.08),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          platform,
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                            color: platformColor,
                            height: 1.2,
                          ),
                        ),
                      ),
                    ],
                  ),
                  if (author.isNotEmpty) ...[
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        Icon(
                          Icons.person_outline,
                          size: 12,
                          color: AppTheme.textTertiaryColor(context),
                        ),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(
                            author,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 12,
                              color: AppTheme.textTertiaryColor(context),
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
      // 前景层：下载按钮
      foregroundLayer: onDownload != null
          ? Positioned(
              right: 12,
              bottom: 12,
              child: Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  gradient: AppTheme.primaryGradient,
                  borderRadius: BorderRadius.circular(AppTheme.radiusMd),
                  boxShadow: [
                    BoxShadow(
                      color: AppTheme.primaryColor.withOpacity(0.3),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    onTap: onDownload,
                    borderRadius: BorderRadius.circular(AppTheme.radiusMd),
                    child: const Icon(
                      Icons.download_rounded,
                      color: Colors.white,
                      size: 18,
                    ),
                  ),
                ),
              ),
            )
          : null,
    );
  }

  Widget _buildCoverPlaceholder(bool isDark) {
    return Container(
      width: 88,
      height: 72,
      color: isDark ? const Color(0xFF0F172A) : const Color(0xFFF1F5F9),
      child: Icon(
        Icons.play_circle_outline,
        size: 28,
        color: isDark ? Colors.grey.shade600 : Colors.grey.shade400,
      ),
    );
  }
}
