import 'dart:ui';
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// 毛玻璃效果强度
enum FrostedIntensity {
  /// 轻微毛玻璃（用于 SnackBar 等轻量元素）
  light,

  /// 中等毛玻璃（用于底部导航、操作栏）
  medium,

  /// 强毛玻璃（用于 AppBar、底部弹出菜单）
  strong,
}

/// 通用毛玻璃容器组件
///
/// 使用 BackdropFilter + ImageFilter.blur 实现毛玻璃效果，
/// 可用于底部导航栏、底部弹出菜单、操作栏、SnackBar 等各处。
class FrostedContainer extends StatelessWidget {
  /// 子组件
  final Widget child;

  /// 毛玻璃强度
  final FrostedIntensity intensity;

  /// 自定义背景色（覆盖默认）
  final Color? backgroundColor;

  /// 背景透明度
  final double? opacity;

  /// 边框颜色
  final Color? borderColor;

  /// 边框宽度
  final double borderWidth;

  /// 边框位置（top/bottom/all）
  final BorderDirection? borderDirection;

  /// 圆角
  final BorderRadiusGeometry? borderRadius;

  /// 内边距
  final EdgeInsetsGeometry? padding;

  /// 外边距
  final EdgeInsetsGeometry? margin;

  /// 宽度
  final double? width;

  /// 高度
  final double? height;

  const FrostedContainer({
    super.key,
    required this.child,
    this.intensity = FrostedIntensity.medium,
    this.backgroundColor,
    this.opacity,
    this.borderColor,
    this.borderWidth = 0.5,
    this.borderDirection,
    this.borderRadius,
    this.padding,
    this.margin,
    this.width,
    this.height,
  });

  /// 获取模糊强度对应的 sigma 值
  double get _sigma {
    switch (intensity) {
      case FrostedIntensity.light:
        return 10;
      case FrostedIntensity.medium:
        return 20;
      case FrostedIntensity.strong:
        return 30;
    }
  }

  /// 获取默认背景透明度
  double _defaultOpacity(bool isDark, bool isOled) {
    if (opacity != null) return opacity!;
    switch (intensity) {
      case FrostedIntensity.light:
        return isDark ? 0.6 : 0.7;
      case FrostedIntensity.medium:
        return isDark ? 0.75 : 0.8;
      case FrostedIntensity.strong:
        return isDark ? 0.85 : 0.9;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = AppTheme.isDark(context);
    final isOled = AppTheme.isOledDark(context);
    final bgOpacity = _defaultOpacity(isDark, isOled);

    // 背景色
    Color bgColor;
    if (backgroundColor != null) {
      bgColor = backgroundColor!;
    } else if (isOled) {
      bgColor = Colors.black.withOpacity(bgOpacity);
    } else if (isDark) {
      bgColor = const Color(0xFF0B1120).withOpacity(bgOpacity);
    } else {
      bgColor = Colors.white.withOpacity(bgOpacity);
    }

    // 边框色
    final bColor = borderColor ??
        (isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0))
            .withOpacity(0.5);

    // 边框
    BoxBorder? border;
    if (borderDirection != null) {
      switch (borderDirection!) {
        case BorderDirection.top:
          border = Border(top: BorderSide(color: bColor, width: borderWidth));
          break;
        case BorderDirection.bottom:
          border =
              Border(bottom: BorderSide(color: bColor, width: borderWidth));
          break;
        case BorderDirection.horizontal:
          border = Border(
            top: BorderSide(color: bColor, width: borderWidth),
            bottom: BorderSide(color: bColor, width: borderWidth),
          );
          break;
        case BorderDirection.all:
          border = Border.all(color: bColor, width: borderWidth);
          break;
      }
    }

    return Container(
      width: width,
      height: height,
      margin: margin,
      child: ClipRRect(
        borderRadius: borderRadius ?? BorderRadius.zero,
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: _sigma, sigmaY: _sigma),
          child: Container(
            padding: padding,
            decoration: BoxDecoration(
              color: bgColor,
              border: border,
              borderRadius: borderRadius,
            ),
            child: child,
          ),
        ),
      ),
    );
  }
}

/// 边框方向
enum BorderDirection {
  top,
  bottom,
  horizontal,
  all,
}

/// 毛玻璃效果的底部导航栏
///
/// 使用 FrostedContainer 包裹 BottomNavigationBar，实现毛玻璃效果。
class FrostedBottomNavigationBar extends StatelessWidget {
  /// 当前选中的索引
  final int currentIndex;

  /// 点击回调
  final ValueChanged<int>? onTap;

  /// 底部导航项
  final List<BottomNavigationBarItem> items;

  /// 毛玻璃强度
  final FrostedIntensity intensity;

  const FrostedBottomNavigationBar({
    super.key,
    required this.currentIndex,
    required this.onTap,
    required this.items,
    this.intensity = FrostedIntensity.medium,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = AppTheme.isDark(context);
    final isOled = AppTheme.isOledDark(context);

    return FrostedContainer(
      intensity: intensity,
      borderDirection: BorderDirection.top,
      child: SafeArea(
        top: false,
        child: BottomNavigationBar(
          currentIndex: currentIndex,
          onTap: onTap,
          items: items,
          backgroundColor: Colors.transparent,
          elevation: 0,
          type: BottomNavigationBarType.fixed,
          selectedItemColor: AppTheme.primaryColor,
          unselectedItemColor: isDark
              ? (isOled ? const Color(0xFF475569) : const Color(0xFF64748B))
              : AppTheme.textTertiary,
          selectedLabelStyle: const TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w600,
            height: 1.5,
          ),
          unselectedLabelStyle: const TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w500,
            height: 1.5,
          ),
          showSelectedLabels: true,
          showUnselectedLabels: true,
        ),
      ),
    );
  }
}

/// 毛玻璃效果的 SnackBar
///
/// 带有轻微毛玻璃背景的 SnackBar。
class FrostedSnackBar {
  /// 创建毛玻璃效果的 SnackBar
  static SnackBar snackBar({
    required String content,
    String? actionLabel,
    VoidCallback? onAction,
    Duration duration = const Duration(seconds: 3),
  }) {
    return SnackBar(
      duration: duration,
      backgroundColor: Colors.transparent,
      elevation: 0,
      behavior: SnackBarBehavior.floating,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      content: Builder(
        builder: (context) {
          final isDark = AppTheme.isDark(context);
          return FrostedContainer(
            intensity: FrostedIntensity.light,
            borderRadius: BorderRadius.circular(AppTheme.radiusMd),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    content,
                    style: TextStyle(
                      color: isDark ? Colors.white : AppTheme.textPrimary,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                if (actionLabel != null && onAction != null)
                  TextButton(
                    onPressed: onAction,
                    style: TextButton.styleFrom(
                      padding: EdgeInsets.zero,
                      minimumSize: Size.zero,
                      tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    ),
                    child: Text(
                      actionLabel,
                      style: const TextStyle(
                        color: AppTheme.primaryColor,
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }
}
