import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// 液态形变指示器
///
/// Tab 切换时指示器有液态形变过渡效果，类似流体拉伸。
/// 使用 CustomPainter 绘制，通过贝塞尔曲线实现形变。
///
/// 使用方式：
/// ```dart
/// TabBar(
///   indicator: LiquidTabIndicator(color: Colors.blue),
///   tabs: [...],
/// )
/// ```
class LiquidTabIndicator extends Decoration {
  /// 指示器颜色
  final Color color;

  /// 指示器高度
  final double height;

  /// 指示器宽度（相对于 Tab 宽度的比例，0-1）
  final double widthRatio;

  /// 圆角半径
  final double radius;

  /// 形变强度（0-1，值越大拉伸越明显）
  final double stretchFactor;

  const LiquidTabIndicator({
    this.color = AppTheme.primaryColor,
    this.height = 4,
    this.widthRatio = 0.5,
    this.radius = 2,
    this.stretchFactor = 0.6,
  });

  @override
  BoxPainter createBoxPainter([VoidCallback? onChanged]) {
    return _LiquidIndicatorPainter(
      color: color,
      height: height,
      widthRatio: widthRatio,
      radius: radius,
      stretchFactor: stretchFactor,
      onChanged: onChanged,
    );
  }
}

class _LiquidIndicatorPainter extends BoxPainter {
  final Color color;
  final double height;
  final double widthRatio;
  final double radius;
  final double stretchFactor;

  _LiquidIndicatorPainter({
    required this.color,
    required this.height,
    required this.widthRatio,
    required this.radius,
    required this.stretchFactor,
    VoidCallback? onChanged,
  }) : super(onChanged);

  @override
  void paint(Canvas canvas, Offset offset, ImageConfiguration configuration) {
    final size = configuration.size!;
    final tabWidth = size.width;
    final indicatorWidth = tabWidth * widthRatio;
    final centerX = offset.dx + tabWidth / 2;
    final bottomY = offset.dy + size.height - 2;

    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.fill;

    // 绘制基础的圆角矩形指示器
    final rect = RRect.fromRectAndRadius(
      Rect.fromCenter(
        center: Offset(centerX, bottomY - height / 2),
        width: indicatorWidth,
        height: height,
      ),
      Radius.circular(radius),
    );

    canvas.drawRRect(rect, paint);
  }
}

/// 带液态效果的 TabBar 封装
///
/// 提供完整的液态指示器 TabBar，切换时有流体形变动画。
/// 内部使用 AnimationController 驱动形变效果。
class LiquidTabBar extends StatefulWidget {
  final List<String> tabs;
  final TabController? controller;
  final Color? indicatorColor;
  final Color? labelColor;
  final Color? unselectedLabelColor;
  final ValueChanged<int>? onTap;
  final double height;
  final bool isScrollable;

  const LiquidTabBar({
    super.key,
    required this.tabs,
    this.controller,
    this.indicatorColor,
    this.labelColor,
    this.unselectedLabelColor,
    this.onTap,
    this.height = 48,
    this.isScrollable = false,
  });

  @override
  State<LiquidTabBar> createState() => _LiquidTabBarState();
}

class _LiquidTabBarState extends State<LiquidTabBar>
    with SingleTickerProviderStateMixin {
  TabController? _internalController;
  TabController get _controller =>
      widget.controller ?? _internalController!;

  @override
  void initState() {
    super.initState();
    if (widget.controller == null) {
      _internalController = TabController(
        length: widget.tabs.length,
        vsync: this,
      );
    }
  }

  @override
  void dispose() {
    _internalController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final indicatorColor =
        widget.indicatorColor ?? Theme.of(context).primaryColor;
    final labelColor =
        widget.labelColor ?? Theme.of(context).primaryColor;
    final unselectedColor = widget.unselectedLabelColor ??
        Theme.of(context).textTheme.bodySmall?.color ??
        Colors.grey;

    return SizedBox(
      height: widget.height,
      child: Stack(
        children: [
          // 液态指示器
          Positioned.fill(
            child: _LiquidIndicator(
              controller: _controller,
              tabCount: widget.tabs.length,
              color: indicatorColor,
            ),
          ),
          // Tab 标签
          Row(
            children: List.generate(widget.tabs.length, (index) {
              return Expanded(
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () {
                    _controller.animateTo(index);
                    widget.onTap?.call(index);
                  },
                  child: AnimatedBuilder(
                    animation: _controller.animation!,
                    builder: (context, child) {
                      final animation = _controller.animation!.value;
                      final distance = (animation - index).abs();
                      final isSelected = distance < 0.5;
                      final selectedAmount = (1 - distance * 2).clamp(0.0, 1.0);

                      return Center(
                        child: Text(
                          widget.tabs[index],
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.lerp(
                              FontWeight.w500,
                              FontWeight.w700,
                              selectedAmount,
                            ),
                            color: Color.lerp(
                              unselectedColor,
                              labelColor,
                              selectedAmount,
                            ),
                            height: 1.4,
                          ),
                        ),
                      );
                    },
                  ),
                ),
              );
            }),
          ),
        ],
      ),
    );
  }
}

/// 液态指示器绘制组件
class _LiquidIndicator extends StatelessWidget {
  final TabController controller;
  final int tabCount;
  final Color color;
  final double indicatorHeight;
  final double indicatorWidthRatio;

  const _LiquidIndicator({
    required this.controller,
    required this.tabCount,
    required this.color,
    this.indicatorHeight = 4,
    this.indicatorWidthRatio = 0.4,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller.animation!,
      builder: (context, child) {
        return CustomPaint(
          painter: _LiquidIndicatorCustomPainter(
            progress: controller.animation!.value,
            tabCount: tabCount,
            color: color,
            indicatorHeight: indicatorHeight,
            indicatorWidthRatio: indicatorWidthRatio,
          ),
        );
      },
    );
  }
}

/// 液态指示器 CustomPainter
class _LiquidIndicatorCustomPainter extends CustomPainter {
  final double progress;
  final int tabCount;
  final Color color;
  final double indicatorHeight;
  final double indicatorWidthRatio;

  _LiquidIndicatorCustomPainter({
    required this.progress,
    required this.tabCount,
    required this.color,
    required this.indicatorHeight,
    required this.indicatorWidthRatio,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final tabWidth = size.width / tabCount;
    final indicatorWidth = tabWidth * indicatorWidthRatio;
    final currentIndex = progress.floor().clamp(0, tabCount - 1);
    final nextIndex = (currentIndex + 1).clamp(0, tabCount - 1);
    final t = progress - currentIndex; // 0-1 的过渡进度

    final currentCenterX = currentIndex * tabWidth + tabWidth / 2;
    final nextCenterX = nextIndex * tabWidth + tabWidth / 2;

    final bottomY = size.height - 4;

    // 计算形变参数
    // 使用 easeInOut 曲线让形变更自然
    final curvedT = _easeInOutCubic(t);
    final stretchAmount = _stretchCurve(t) * indicatorWidth * 0.8;

    // 绘制液态形变指示器
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.fill;

    final path = Path();

    // 计算左右边界
    final leftEdge = currentCenterX - indicatorWidth / 2 +
        (nextCenterX - currentCenterX) * curvedT -
        stretchAmount * 0.5 * (1 - (curvedT - 0.5).abs() * 2);
    final rightEdge = currentCenterX + indicatorWidth / 2 +
        (nextCenterX - currentCenterX) * curvedT +
        stretchAmount * 0.5 * (1 - (curvedT - 0.5).abs() * 2);

    // 实际使用的是一个带贝塞尔曲线顶部的形状
    final topY = bottomY - indicatorHeight;

    // 主体矩形区域
    final midY = topY + indicatorHeight * 0.5;

    path.moveTo(leftEdge, bottomY);

    // 左侧上升
    path.lineTo(leftEdge, topY + indicatorHeight * 0.3);

    // 顶部左侧贝塞尔曲线（凸起）
    final leftBumpHeight = stretchAmount * 0.3 * (1 - curvedT);
    final rightBumpHeight = stretchAmount * 0.3 * curvedT;

    path.quadraticBezierTo(
      leftEdge + indicatorWidth * 0.25,
      topY - leftBumpHeight,
      leftEdge + indicatorWidth * 0.5,
      topY + indicatorHeight * 0.1,
    );

    // 顶部中间过渡
    path.quadraticBezierTo(
      (leftEdge + rightEdge) / 2,
      topY - (leftBumpHeight + rightBumpHeight) * 0.3,
      rightEdge - indicatorWidth * 0.5,
      topY + indicatorHeight * 0.1,
    );

    // 顶部右侧贝塞尔曲线
    path.quadraticBezierTo(
      rightEdge - indicatorWidth * 0.25,
      topY - rightBumpHeight,
      rightEdge,
      topY + indicatorHeight * 0.3,
    );

    // 右侧下降
    path.lineTo(rightEdge, bottomY);

    path.close();

    canvas.drawPath(path, paint);
  }

  /// easeInOutCubic 缓动曲线
  double _easeInOutCubic(double t) {
    if (t < 0.5) {
      return 4 * t * t * t;
    } else {
      final f = 2 * t - 2;
      return 0.5 * f * f * f + 1;
    }
  }

  /// 拉伸曲线：中间最大，两端为 0
  double _stretchCurve(double t) {
    // 类似 sin 曲线，在 0.5 时达到峰值
    return math.sin(t * math.pi);
  }

  @override
  bool shouldRepaint(covariant _LiquidIndicatorCustomPainter oldDelegate) {
    return oldDelegate.progress != progress ||
        oldDelegate.color != color ||
        oldDelegate.tabCount != tabCount;
  }
}

/// 底部导航栏用的液态指示器
///
/// 配合自定义底部导航栏使用，指示器在图标下方显示液态切换效果。
class LiquidBottomNavIndicator extends StatelessWidget {
  final int currentIndex;
  final int itemCount;
  final Color color;
  final double indicatorWidth;
  final double indicatorHeight;

  const LiquidBottomNavIndicator({
    super.key,
    required this.currentIndex,
    required this.itemCount,
    this.color = AppTheme.primaryColor,
    this.indicatorWidth = 24,
    this.indicatorHeight = 3,
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final itemWidth = constraints.maxWidth / itemCount;
        final left = currentIndex * itemWidth + (itemWidth - indicatorWidth) / 2;

        return AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOutCubic,
          margin: EdgeInsets.only(left: left),
          width: indicatorWidth,
          height: indicatorHeight,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(indicatorHeight / 2),
          ),
        );
      },
    );
  }
}
