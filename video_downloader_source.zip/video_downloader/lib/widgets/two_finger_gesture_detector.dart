import 'package:flutter/material.dart';

/// 双指手势回调
typedef TwoFingerScaleCallback = void Function(double scale);
typedef TwoFingerSwipeDownCallback = void Function();

/// 双指手势检测器
///
/// 支持：
/// - 双指缩放切换布局密度（紧凑/标准/长辈版）
/// - 双指下滑快速进入搜索模式
///
/// 只在首页和列表页生效
class TwoFingerGestureDetector extends StatefulWidget {
  final Widget child;

  /// 双指缩放回调，返回缩放比例变化
  final TwoFingerScaleCallback? onScale;

  /// 双指下滑回调
  final TwoFingerSwipeDownCallback? onSwipeDown;

  /// 是否启用
  final bool enabled;

  const TwoFingerGestureDetector({
    super.key,
    required this.child,
    this.onScale,
    this.onSwipeDown,
    this.enabled = true,
  });

  @override
  State<TwoFingerGestureDetector> createState() => _TwoFingerGestureDetectorState();
}

class _TwoFingerGestureDetectorState extends State<TwoFingerGestureDetector> {
  // 缩放相关
  double _currentScale = 1.0;
  double _baseScale = 1.0;
  bool _isScaling = false;
  int _pointersDown = 0;

  // 下滑相关
  Offset? _twoFingerStartPos;
  double _twoFingerTotalDy = 0;
  static const double _swipeThreshold = 100; // 下滑触发阈值
  static const double _scaleThreshold = 0.15; // 缩放触发阈值

  void _handleScaleStart(ScaleStartDetails details) {
    if (!widget.enabled) return;
    _baseScale = _currentScale;
    _isScaling = true;
  }

  void _handleScaleUpdate(ScaleUpdateDetails details) {
    if (!widget.enabled) return;
    if (!_isScaling) return;

    final newScale = (_baseScale * details.scale).clamp(0.5, 2.0);
    final scaleDiff = newScale - _baseScale;

    // 检测缩放方向变化，超过阈值触发回调
    if (scaleDiff.abs() > _scaleThreshold) {
      widget.onScale?.call(scaleDiff > 0 ? 1.0 : -1.0);
      _baseScale = newScale; // 重置基准，避免连续触发
    }

    _currentScale = newScale;
  }

  void _handleScaleEnd(ScaleEndDetails details) {
    _isScaling = false;
    _currentScale = 1.0;
    _baseScale = 1.0;
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.enabled) {
      return widget.child;
    }

    return Listener(
      onPointerDown: (_) {
        _pointersDown++;
        if (_pointersDown == 2) {
          _twoFingerStartPos = null;
          _twoFingerTotalDy = 0;
        }
      },
      onPointerUp: (_) {
        _pointersDown--;
        if (_pointersDown < 2) {
          // 双指抬起，检查是否触发下滑
          if (_twoFingerTotalDy > _swipeThreshold) {
            widget.onSwipeDown?.call();
          }
          _twoFingerStartPos = null;
          _twoFingerTotalDy = 0;
        }
      },
      child: GestureDetector(
        onScaleStart: _handleScaleStart,
        onScaleUpdate: _handleScaleUpdate,
        onScaleEnd: _handleScaleEnd,
        child: widget.child,
      ),
    );
  }
}

/// 双指缩放手势密度切换器
///
/// 包装子组件，监听双指缩放手势，切换 UI 密度。
/// 密度有三档：compact -> standard -> large
class DensityScaleGesture extends StatefulWidget {
  final Widget child;
  final String currentDensity;
  final ValueChanged<String> onDensityChanged;
  final bool enabled;

  const DensityScaleGesture({
    super.key,
    required this.child,
    required this.currentDensity,
    required this.onDensityChanged,
    this.enabled = true,
  });

  @override
  State<DensityScaleGesture> createState() => _DensityScaleGestureState();
}

class _DensityScaleGestureState extends State<DensityScaleGesture> {
  static const List<String> _densities = ['compact', 'standard', 'large'];

  void _handleScale(double direction) {
    final currentIndex = _densities.indexOf(widget.currentDensity);
    if (currentIndex < 0) return;

    int newIndex;
    if (direction > 0) {
      // 放大 -> 更大密度
      newIndex = (currentIndex + 1).clamp(0, _densities.length - 1);
    } else {
      // 缩小 -> 更紧凑
      newIndex = (currentIndex - 1).clamp(0, _densities.length - 1);
    }

    if (newIndex != currentIndex) {
      widget.onDensityChanged(_densities[newIndex]);
    }
  }

  @override
  Widget build(BuildContext context) {
    return TwoFingerGestureDetector(
      enabled: widget.enabled,
      onScale: _handleScale,
      child: widget.child,
    );
  }
}
