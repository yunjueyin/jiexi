import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../services/parser/base_parser.dart';

/// 错误详情分类
enum ErrorCategory {
  /// 网络问题
  network,

  /// 链接无效
  invalidUrl,

  /// Cookie 失效
  cookieExpired,

  /// 内容已删除/私密
  contentUnavailable,

  /// 平台风控限制
  rateLimited,

  /// 其他错误
  unknown,
}

/// 错误分类工具
class ErrorCategorizer {
  /// 根据错误信息和类型分类
  static ErrorCategory categorize(ParseErrorType type, String message) {
    final msg = message.toLowerCase();

    switch (type) {
      case ParseErrorType.networkError:
        return ErrorCategory.network;
      case ParseErrorType.invalidUrl:
        return ErrorCategory.invalidUrl;
      case ParseErrorType.contentUnavailable:
        return ErrorCategory.contentUnavailable;
      case ParseErrorType.unsupportedPlatform:
        return ErrorCategory.invalidUrl;
      case ParseErrorType.parseFailed:
        // 进一步根据错误信息判断
        if (msg.contains('cookie') || msg.contains('登录') || msg.contains('session')) {
          return ErrorCategory.cookieExpired;
        }
        if (msg.contains('频率') || msg.contains('限制') || msg.contains('风控') || msg.contains('rate')) {
          return ErrorCategory.rateLimited;
        }
        if (msg.contains('删除') || msg.contains('私密') || msg.contains('不存在') || msg.contains('404')) {
          return ErrorCategory.contentUnavailable;
        }
        if (msg.contains('网络') || msg.contains('timeout') || msg.contains('连接')) {
          return ErrorCategory.network;
        }
        return ErrorCategory.unknown;
    }
  }
}

/// 错误分类扩展
extension ErrorCategoryX on ErrorCategory {
  /// 错误图标
  IconData get icon {
    switch (this) {
      case ErrorCategory.network:
        return Icons.wifi_off_rounded;
      case ErrorCategory.invalidUrl:
        return Icons.link_off_rounded;
      case ErrorCategory.cookieExpired:
        return Icons.cookie_outlined;
      case ErrorCategory.contentUnavailable:
        return Icons.visibility_off_rounded;
      case ErrorCategory.rateLimited:
        return Icons.timer_off_rounded;
      case ErrorCategory.unknown:
        return Icons.error_outline_rounded;
    }
  }

  /// 错误标题
  String get title {
    switch (this) {
      case ErrorCategory.network:
        return '网络连接异常';
      case ErrorCategory.invalidUrl:
        return '链接无效';
      case ErrorCategory.cookieExpired:
        return '登录状态已失效';
      case ErrorCategory.contentUnavailable:
        return '内容不可访问';
      case ErrorCategory.rateLimited:
        return '访问过于频繁';
      case ErrorCategory.unknown:
        return '解析失败';
    }
  }

  /// 错误描述/建议
  String get suggestion {
    switch (this) {
      case ErrorCategory.network:
        return '请检查网络连接是否正常，或切换网络后重试。';
      case ErrorCategory.invalidUrl:
        return '请确认链接是否正确，是否复制完整。';
      case ErrorCategory.cookieExpired:
        return '请前往设置更新抖音 Cookie 后重新解析。';
      case ErrorCategory.contentUnavailable:
        return '该内容可能已被删除、设为私密或仅作者可见。';
      case ErrorCategory.rateLimited:
        return '平台风控限制，请稍后再试，或降低解析频率。';
      case ErrorCategory.unknown:
        return '解析过程中出现未知错误，请稍后重试。';
    }
  }

  /// 图标颜色
  Color get color {
    switch (this) {
      case ErrorCategory.network:
        return Colors.orange;
      case ErrorCategory.invalidUrl:
        return Colors.grey;
      case ErrorCategory.cookieExpired:
        return Colors.amber;
      case ErrorCategory.contentUnavailable:
        return Colors.purple;
      case ErrorCategory.rateLimited:
        return Colors.redAccent;
      case ErrorCategory.unknown:
        return AppTheme.errorColor;
    }
  }
}

/// 友好化错误展示组件
///
/// 根据错误类型显示不同的图标、标题、建议和操作按钮。
class FriendlyErrorWidget extends StatelessWidget {
  /// 错误类型
  final ParseErrorType errorType;

  /// 错误信息
  final String errorMessage;

  /// 重试回调
  final VoidCallback? onRetry;

  /// 反馈回调
  final VoidCallback? onFeedback;

  /// 是否显示为紧凑模式（用于列表中）
  final bool compact;

  const FriendlyErrorWidget({
    super.key,
    required this.errorType,
    required this.errorMessage,
    this.onRetry,
    this.onFeedback,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    final category = ErrorCategorizer.categorize(errorType, errorMessage);
    final isDark = AppTheme.isDark(context);

    if (compact) {
      return _buildCompact(context, category, isDark);
    }

    return _buildFull(context, category, isDark);
  }

  Widget _buildFull(BuildContext context, ErrorCategory category, bool isDark) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AppTheme.cardBg(context),
        borderRadius: BorderRadius.circular(AppTheme.radiusXl),
        border: Border.all(
          color: isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
          width: 0.5,
        ),
        boxShadow: AppTheme.shadowMd,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // 图标
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              color: category.color.withOpacity(0.12),
              shape: BoxShape.circle,
            ),
            child: Icon(
              category.icon,
              size: 32,
              color: category.color,
            ),
          ),
          const SizedBox(height: 16),
          // 标题
          Text(
            category.title,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: AppTheme.textPrimaryColor(context),
            ),
          ),
          const SizedBox(height: 8),
          // 建议
          Text(
            category.suggestion,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 14,
              color: AppTheme.textSecondaryColor(context),
              height: 1.5,
            ),
          ),
          const SizedBox(height: 12),
          // 原始错误信息（可展开）
          if (errorMessage.isNotEmpty)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: isDark ? const Color(0xFF0F172A) : const Color(0xFFF1F5F9),
                borderRadius: BorderRadius.circular(AppTheme.radiusMd),
              ),
              child: Text(
                errorMessage,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 12,
                  color: AppTheme.textTertiaryColor(context),
                  fontFamily: 'monospace',
                ),
              ),
            ),
          const SizedBox(height: 20),
          // 操作按钮
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: onFeedback,
                  icon: const Icon(Icons.feedback_outlined, size: 18),
                  label: const Text('反馈问题'),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(AppTheme.radiusMd),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                flex: 2,
                child: ElevatedButton.icon(
                  onPressed: onRetry,
                  icon: const Icon(Icons.refresh_rounded, size: 18),
                  label: const Text('重试'),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(AppTheme.radiusMd),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildCompact(BuildContext context, ErrorCategory category, bool isDark) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: category.color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(AppTheme.radiusMd),
        border: Border.all(
          color: category.color.withOpacity(0.2),
          width: 0.5,
        ),
      ),
      child: Row(
        children: [
          Icon(
            category.icon,
            size: 20,
            color: category.color,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  category.title,
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: category.color,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  category.suggestion,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 11,
                    color: AppTheme.textSecondaryColor(context),
                  ),
                ),
              ],
            ),
          ),
          if (onRetry != null)
            TextButton(
              onPressed: onRetry,
              child: const Text('重试'),
            ),
        ],
      ),
    );
  }
}
