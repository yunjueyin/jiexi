import 'package:flutter/material.dart';

/// 左滑操作列表项
///
/// 支持左滑显示操作按钮（删除、分享等），类似 iOS 列表的左滑操作。
///
/// 使用方式：
/// ```dart
/// SlideActionItem(
///   actions: [
///     SlideAction(
///       icon: Icons.delete,
///       label: '删除',
///       color: Colors.red,
///       onTap: () => _handleDelete(),
///     ),
///     SlideAction(
///       icon: Icons.share,
///       label: '分享',
///       color: Colors.blue,
///       onTap: () => _handleShare(),
///     ),
///   ],
///   child: YourListItem(),
/// )
/// ```
class SlideActionItem extends StatefulWidget {
  /// 操作按钮列表（从右到左排列）
  final List<SlideAction> actions;

  /// 子组件
  final Widget child;

  /// 滑动阈值（超过这个比例则自动展开/收起）
  final double dragThreshold;

  /// 每个操作按钮的宽度
  final double actionWidth;

  const SlideActionItem({
    super.key,
    required this.actions,
    required this.child,
    this.dragThreshold = 0.3,
    this.actionWidth = 80,
  });

  @override
  State<SlideActionItem> createState() => _SlideActionItemState();
}

class _SlideActionItemState extends State<SlideActionItem>
    with SingleTickerProviderStateMixin {
  double _dragOffset = 0;
  double _maxDragOffset = 0;
  bool _isOpen = false;

  @override
  void initState() {
    super.initState();
    _maxDragOffset = widget.actionWidth * widget.actions.length;
  }

  @override
  void didUpdateWidget(SlideActionItem oldWidget) {
    super.didUpdateWidget(oldWidget);
    _maxDragOffset = widget.actionWidth * widget.actions.length;
  }

  void _handleHorizontalDragUpdate(DragUpdateDetails details) {
    setState(() {
      _dragOffset -= details.delta.dx;
      // 限制滑动范围
      if (_dragOffset < 0) _dragOffset = 0;
      if (_dragOffset > _maxDragOffset * 1.2) {
        _dragOffset = _maxDragOffset * 1.2;
      }
    });
  }

  void _handleHorizontalDragEnd(DragEndDetails details) {
    final velocity = details.primaryVelocity ?? 0;
    final threshold = _maxDragOffset * widget.dragThreshold;

    setState(() {
      if (velocity < -500) {
        // 快速左滑，展开
        _dragOffset = _maxDragOffset;
        _isOpen = true;
      } else if (velocity > 500) {
        // 快速右滑，收起
        _dragOffset = 0;
        _isOpen = false;
      } else if (_isOpen) {
        // 已展开状态
        if (_dragOffset < _maxDragOffset - threshold) {
          _dragOffset = 0;
          _isOpen = false;
        } else {
          _dragOffset = _maxDragOffset;
        }
      } else {
        // 未展开状态
        if (_dragOffset > threshold) {
          _dragOffset = _maxDragOffset;
          _isOpen = true;
        } else {
          _dragOffset = 0;
        }
      }
    });
  }

  /// 关闭操作面板
  void close() {
    if (_isOpen) {
      setState(() {
        _dragOffset = 0;
        _isOpen = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // 背景：操作按钮
        Positioned.fill(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: widget.actions.map((action) {
              return SizedBox(
                width: widget.actionWidth,
                height: double.infinity,
                child: Material(
                  color: action.color,
                  child: InkWell(
                    onTap: () {
                      close();
                      action.onTap?.call();
                    },
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(action.icon, color: Colors.white, size: 22),
                        const SizedBox(height: 4),
                        Text(
                          action.label,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
        // 前景：内容（宽度占满、高度自适应，用于决定 Stack 的高度；左滑露出背景按钮）
        SizedBox(
          width: double.infinity,
          child: GestureDetector(
            onHorizontalDragUpdate: _handleHorizontalDragUpdate,
            onHorizontalDragEnd: _handleHorizontalDragEnd,
            onTap: _isOpen ? close : null,
            child: Transform.translate(
              offset: Offset(-_dragOffset, 0),
              child: widget.child,
            ),
          ),
        ),
      ],
    );
  }
}

/// 滑动操作项配置
class SlideAction {
  /// 图标
  final IconData icon;

  /// 文字标签
  final String label;

  /// 背景颜色
  final Color color;

  /// 点击回调
  final VoidCallback? onTap;

  const SlideAction({
    required this.icon,
    required this.label,
    required this.color,
    this.onTap,
  });
}
