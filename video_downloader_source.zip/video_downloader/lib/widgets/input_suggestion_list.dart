import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../models/video_info.dart';
import '../utils/platform_detector.dart';

/// 联想项数据
class SuggestionItem {
  /// 完整 URL
  final String url;

  /// 平台类型
  final VideoPlatform platform;

  /// 标题（可选，来自历史记录）
  final String? title;

  /// 时间描述（如 "2小时前"）
  final String? timeLabel;

  const SuggestionItem({
    required this.url,
    this.platform = VideoPlatform.unknown,
    this.title,
    this.timeLabel,
  });
}

/// 输入联想补全列表
///
/// 在输入框下方显示，根据输入内容联想历史记录。
/// 点击某项可快速填入输入框。
class InputSuggestionList extends StatelessWidget {
  /// 联想项列表
  final List<SuggestionItem> suggestions;

  /// 点击联想项回调
  final void Function(SuggestionItem item)? onSelect;

  /// 最大显示条数
  final int maxItems;

  const InputSuggestionList({
    super.key,
    required this.suggestions,
    this.onSelect,
    this.maxItems = 5,
  });

  @override
  Widget build(BuildContext context) {
    if (suggestions.isEmpty) {
      return const SizedBox.shrink();
    }

    final isDark = AppTheme.isDark(context);
    final displayItems = suggestions.take(maxItems).toList();

    return Container(
      margin: const EdgeInsets.only(top: 6),
      decoration: BoxDecoration(
        color: AppTheme.cardBg(context),
        borderRadius: BorderRadius.circular(AppTheme.radiusMd),
        border: Border.all(
          color: isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
          width: 0.5,
        ),
        boxShadow: AppTheme.shadowMd,
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: List.generate(displayItems.length * 2 - 1, (index) {
          if (index.isEven) {
            final item = displayItems[index ~/ 2];
            return _buildSuggestionItem(context, item, isDark);
          } else {
            return Divider(
              height: 0.5,
              thickness: 0.5,
              indent: 56,
              color: isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
            );
          }
        }),
      ),
    );
  }

  Widget _buildSuggestionItem(BuildContext context, SuggestionItem item, bool isDark) {
    final platform = item.platform;
    final themeColor = platform.themeColor;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () => onSelect?.call(item),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          child: Row(
            children: [
              // 平台图标
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  color: themeColor.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Center(
                  child: Text(
                    platform.icon,
                    style: const TextStyle(fontSize: 14),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              // 内容
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (item.title != null && item.title!.isNotEmpty)
                      Text(
                        item.title!,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color: AppTheme.textPrimaryColor(context),
                        ),
                      ),
                    const SizedBox(height: 2),
                    Text(
                      item.url,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 11,
                        color: AppTheme.textTertiaryColor(context),
                        fontFamily: 'monospace',
                      ),
                    ),
                  ],
                ),
              ),
              // 时间标签
              if (item.timeLabel != null)
                Text(
                  item.timeLabel!,
                  style: TextStyle(
                    fontSize: 11,
                    color: AppTheme.textTertiaryColor(context),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
