import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../providers/settings_provider.dart';
import '../theme/app_theme.dart';
import '../utils/platform_detector.dart';
import 'gradient_button.dart';

/// 操作按钮配置
class LinkInputAction {
  /// 唯一标识
  final String id;

  /// 显示文字
  final String label;

  /// 图标
  final IconData icon;

  /// 是否为主按钮（渐变样式），否则为描边按钮
  final bool isPrimary;

  /// 点击回调，返回当前输入的所有 URL 列表
  final void Function(List<String> urls)? onTap;

  /// 长按回调
  final void Function()? onLongPress;

  const LinkInputAction({
    required this.id,
    required this.label,
    required this.icon,
    this.isPrimary = false,
    this.onTap,
    this.onLongPress,
  });
}

/// 通用链接输入卡片
///
/// 特性：
/// - 粘贴链接后自动识别平台，显示平台徽标
/// - 默认支持多条链接输入，每行一个，粘贴分享文案自动识别
/// - 可配置操作按钮（解析、下载、抓取、转换等）
/// - 行数/链接数统计
/// - 加载状态显示
class LinkInputCard extends StatefulWidget {
  /// 控制器（外部传入，便于父组件获取输入内容）
  final TextEditingController controller;

  /// 标题文字
  final String title;

  /// 标题图标
  final IconData titleIcon;

  /// 占位文字
  final String hintText;

  /// 操作按钮列表
  final List<LinkInputAction> actions;

  /// 正在加载的操作 ID（显示 loading 状态）
  final String? loadingActionId;

  /// 加载进度文字（如 "3/10"）
  final String? loadingProgressText;

  /// 平台识别回调
  final void Function(PlatformDetectionResult result)? onPlatformDetected;

  /// 输入文本变化回调
  final void Function(String text)? onChanged;

  /// 清空输入回调
  final void Function()? onClear;

  /// 是否显示粘贴按钮
  final bool showPasteButton;

  /// 输入框最大行数
  final int maxLines;

  /// 子组件（显示在操作按钮上方，如字段选择器等）
  final Widget? child;

  const LinkInputCard({
    super.key,
    required this.controller,
    this.title = '粘贴链接',
    this.titleIcon = Icons.link,
    this.hintText = '每行一个链接，粘贴分享文案自动识别',
    this.actions = const [],
    this.loadingActionId,
    this.loadingProgressText,
    this.onPlatformDetected,
    this.onChanged,
    this.onClear,
    this.showPasteButton = true,
    this.maxLines = 10,
    this.child,
  });

  @override
  State<LinkInputCard> createState() => _LinkInputCardState();
}

class _LinkInputCardState extends State<LinkInputCard> {
  bool _clipboardHasUrl = false;
  PlatformDetectionResult? _detectionResult;
  List<PlatformDetectionResult> _allDetectionResults = [];

  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_onTextChanged);
    _checkClipboard();
  }

  @override
  void dispose() {
    widget.controller.removeListener(_onTextChanged);
    super.dispose();
  }

  void _onTextChanged() {
    final text = widget.controller.text;
    widget.onChanged?.call(text);

    // 检测所有 URL 的平台
    final urls = PlatformDetector.extractAllUrls(text);
    if (urls.isNotEmpty) {
      final results = urls.map((url) => PlatformDetector.detect(url)).toList();
      final firstResult = results.first;
      setState(() {
        _detectionResult = firstResult;
        _allDetectionResults = results;
      });
      widget.onPlatformDetected?.call(firstResult);
    } else if (_detectionResult != null) {
      setState(() {
        _detectionResult = null;
        _allDetectionResults = [];
      });
      widget.onPlatformDetected?.call(
        const PlatformDetectionResult(
          platform: VideoPlatform.unknown,
          linkType: LinkType.unknown,
          isShortLink: false,
        ),
      );
    }

    // 检查剪贴板
    _checkClipboard();
  }

  Future<void> _checkClipboard() async {
    if (!widget.showPasteButton) return;
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    final text = data?.text ?? '';
    final hasUrl = PlatformDetector.extractUrl(text) != null;
    if (hasUrl != _clipboardHasUrl) {
      if (mounted) {
        setState(() {
          _clipboardHasUrl = hasUrl;
        });
      }
    }
  }

  Future<void> _pasteFromClipboard() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    final text = data?.text ?? '';
    if (text.isEmpty) return;

    // 读取智能粘贴设置
    final settings = context.read<SettingsProvider>();
    final smartMode = settings.smartPasteAppendMode;
    final currentText = widget.controller.text;

    String newText;
    if (!smartMode || currentText.isEmpty || currentText.trim() == text.trim()) {
      // 非智能模式 / 输入框为空 / 内容相同 → 直接覆盖
      newText = text;
    } else {
      // 智能模式 + 内容不同 → 换行追加
      newText = '${currentText.trim()}\n${text.trim()}';
    }

    widget.controller.text = newText;
    widget.controller.selection = TextSelection.fromPosition(
      TextPosition(offset: newText.length),
    );
  }

  void _clearInput() {
    widget.controller.clear();
    widget.onClear?.call();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = AppTheme.isDark(context);
    final inputBgColor = isDark ? const Color(0xFF0F172A) : const Color(0xFFF6FAF8);
    final inputBorderColor = isDark ? Colors.grey.shade700 : const Color(0xFFE0EDE5);
    final hintColor = isDark ? Colors.grey.shade500 : Colors.grey.shade500;
    final iconMuted = isDark ? Colors.grey.shade400 : Colors.grey.shade400;

    final isLoading = widget.loadingActionId != null;

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(AppTheme.radiusXl),
        boxShadow: AppTheme.shadowMd,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 标题栏
          Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  gradient: AppTheme.primaryGradient,
                  borderRadius: BorderRadius.circular(AppTheme.radiusMd),
                ),
                child: Icon(widget.titleIcon, color: Colors.white, size: 18),
              ),
              const SizedBox(width: 10),
              Text(
                widget.title,
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          // 智能识别标签
          _buildDetectionChips(),
          const SizedBox(height: 10),
          // 输入框
          Container(
            decoration: BoxDecoration(
              color: inputBgColor,
              borderRadius: BorderRadius.circular(AppTheme.radiusLg),
              border: Border.all(
                color: _detectionResult?.isRecognized ?? false
                    ? (_detectionResult!.platform.themeColor).withOpacity(0.5)
                    : inputBorderColor,
              ),
            ),
            child: GestureDetector(
              onLongPress: _showContextMenu,
              child: TextField(
                controller: widget.controller,
                maxLines: widget.maxLines,
                minLines: 6,
                style: const TextStyle(fontSize: 14, height: 1.4),
                decoration: InputDecoration(
                  hintText: widget.hintText,
                  hintStyle: TextStyle(
                    fontSize: 13,
                    color: hintColor,
                  ),
                  border: InputBorder.none,
                  enabledBorder: InputBorder.none,
                  focusedBorder: InputBorder.none,
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  suffixIcon: widget.controller.text.isNotEmpty
                      ? Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            if (_clipboardHasUrl && widget.showPasteButton)
                              Padding(
                                padding: const EdgeInsets.only(right: 4),
                                child: _buildPasteButton(),
                              ),
                            IconButton(
                              icon: Icon(Icons.cancel, size: 18, color: iconMuted),
                              onPressed: isLoading ? null : _clearInput,
                            ),
                          ],
                        )
                      : _clipboardHasUrl && widget.showPasteButton
                          ? Padding(
                              padding: const EdgeInsets.only(right: 8),
                              child: _buildPasteButton(),
                            )
                          : null,
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          // 行数/链接数统计
          _buildInputStats(),
          // 自定义子组件
          if (widget.child != null) ...[
            const SizedBox(height: 12),
            widget.child!,
          ],
          const SizedBox(height: 14),
          // 操作按钮
          if (widget.actions.isNotEmpty) _buildActions(isLoading),
        ],
      ),
    );
  }

  /// 构建智能识别标签（Chip）
  Widget _buildDetectionChips() {
    final urlCount = _allDetectionResults.length;
    final isDark = AppTheme.isDark(context);

    // 没有 URL 时不显示
    if (urlCount == 0) {
      return const SizedBox.shrink();
    }

    // 多条链接时，显示"已识别 N 条链接"标签
    if (urlCount > 1) {
      // 统计识别到的平台数量
      final recognizedCount =
          _allDetectionResults.where((r) => r.isRecognized).length;
      return Row(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: AppTheme.primaryColor.withOpacity(0.12),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.link,
                  size: 13,
                  color: AppTheme.primaryColor,
                ),
                const SizedBox(width: 4),
                Text(
                  '已识别 $urlCount 条链接',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.primaryColor,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 6),
          if (recognizedCount < urlCount)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
              decoration: BoxDecoration(
                color: Colors.grey.withOpacity(isDark ? 0.2 : 0.15),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                '${urlCount - recognizedCount} 条未识别',
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w500,
                  color: isDark ? Colors.grey.shade400 : Colors.grey.shade600,
                ),
              ),
            ),
        ],
      );
    }

    // 单条链接时，显示平台和类型标签
    final result = _allDetectionResults.first;
    if (!result.isRecognized) {
      // 未识别平台
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          color: Colors.grey.withOpacity(isDark ? 0.2 : 0.15),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.help_outline,
              size: 13,
              color: isDark ? Colors.grey.shade400 : Colors.grey.shade600,
            ),
            const SizedBox(width: 4),
            Text(
              '未识别',
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w500,
                color: isDark ? Colors.grey.shade400 : Colors.grey.shade600,
              ),
            ),
          ],
        ),
      );
    }

    // 已识别平台，显示 "平台 · 类型" 标签
    final platform = result.platform;
    final themeColor = platform.themeColor;

    // 确定链接类型文字
    String typeText;
    if (result.isShortLink) {
      typeText = '短链';
    } else if (result.isAuthor) {
      typeText = '作者';
    } else if (result.isVideo) {
      typeText = '视频';
    } else {
      typeText = '链接';
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: themeColor.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            platform.icon,
            style: const TextStyle(fontSize: 12),
          ),
          const SizedBox(width: 4),
          Text(
            '${platform.name} · $typeText',
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: themeColor,
            ),
          ),
        ],
      ),
    );
  }

  /// 显示长按上下文菜单
  Future<void> _showContextMenu() async {
    final isDark = AppTheme.isDark(context);
    final hasText = widget.controller.text.isNotEmpty;

    final result = await showModalBottomSheet<int>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // 顶部拖动条
              Container(
                margin: const EdgeInsets.only(top: 10),
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: isDark ? Colors.grey.shade700 : Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 8),
              _buildContextMenuItem(
                icon: Icons.content_paste,
                label: '粘贴',
                color: AppTheme.primaryColor,
                onTap: () => Navigator.pop(context, 0),
              ),
              _buildContextMenuItem(
                icon: Icons.copy,
                label: '复制',
                color: Colors.blue,
                enabled: hasText,
                onTap: () => Navigator.pop(context, 1),
              ),
              _buildContextMenuItem(
                icon: Icons.select_all,
                label: '全选',
                color: Colors.green,
                enabled: hasText,
                onTap: () => Navigator.pop(context, 2),
              ),
              _buildContextMenuItem(
                icon: Icons.delete_outline,
                label: '清空',
                color: Colors.red,
                enabled: hasText,
                onTap: () => Navigator.pop(context, 3),
              ),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );

    if (result == null) return;

    switch (result) {
      case 0: // 粘贴
        _pasteFromClipboard();
        break;
      case 1: // 复制
        if (widget.controller.text.isNotEmpty) {
          Clipboard.setData(ClipboardData(text: widget.controller.text));
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('已复制到剪贴板'), duration: Duration(seconds: 1)),
            );
          }
        }
        break;
      case 2: // 全选
        widget.controller.selection = TextSelection(
          baseOffset: 0,
          extentOffset: widget.controller.text.length,
        );
        break;
      case 3: // 清空
        _clearInput();
        break;
    }
  }

  /// 构建上下文菜单项
  Widget _buildContextMenuItem({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
    bool enabled = true,
  }) {
    final isDark = AppTheme.isDark(context);
    return ListTile(
      leading: Container(
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          color: color.withOpacity(enabled ? 0.12 : 0.06),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(
          icon,
          size: 20,
          color: enabled ? color : (isDark ? Colors.grey.shade700 : Colors.grey.shade400),
        ),
      ),
      title: Text(
        label,
        style: TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w500,
          color: enabled
              ? (isDark ? Colors.white : Colors.black87)
              : (isDark ? Colors.grey.shade700 : Colors.grey.shade400),
        ),
      ),
      trailing: Icon(
        Icons.chevron_right,
        size: 20,
        color: isDark ? Colors.grey.shade600 : Colors.grey.shade400,
      ),
      onTap: enabled ? onTap : null,
    );
  }

  Widget _buildPasteButton() {
    return GestureDetector(
      onTap: widget.loadingActionId != null ? null : _pasteFromClipboard,
      child: Container(
        width: 32,
        height: 32,
        decoration: BoxDecoration(
          gradient: AppTheme.primaryGradient,
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: AppTheme.primaryColor.withOpacity(0.3),
              blurRadius: 6,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: const Icon(
          Icons.content_paste,
          size: 16,
          color: Colors.white,
        ),
      ),
    );
  }

  Widget _buildInputStats() {
    final isDark = AppTheme.isDark(context);
    final text = widget.controller.text;
    final urlCount = PlatformDetector.extractAllUrls(text).length;
    final lineCount =
        text.isEmpty ? 0 : text.split('\n').where((l) => l.trim().isNotEmpty).length;

    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Text(
          '$lineCount 行 · $urlCount 个链接',
          style: TextStyle(
            fontSize: 11,
            color: isDark ? Colors.grey.shade500 : Colors.grey.shade400,
          ),
        ),
      ],
    );
  }

  Widget _buildActions(bool isLoading) {
    final primaryActions = widget.actions.where((a) => a.isPrimary).toList();
    final secondaryActions = widget.actions.where((a) => !a.isPrimary).toList();

    if (primaryActions.isEmpty && secondaryActions.isEmpty) {
      return const SizedBox.shrink();
    }

    // 如果只有一个主按钮，全宽显示
    if (widget.actions.length == 1 && primaryActions.length == 1) {
      final action = primaryActions.first;
      final isThisLoading = widget.loadingActionId == action.id;
      return SizedBox(
        width: double.infinity,
        child: GradientButton(
          text: isThisLoading
              ? (widget.loadingProgressText != null
                  ? '处理中... (${widget.loadingProgressText})'
                  : '处理中...')
              : action.label,
          icon: action.icon,
          loading: isThisLoading,
          onPressed: isLoading
              ? null
              : () {
                  final urls = PlatformDetector.extractAllUrls(widget.controller.text);
                  action.onTap?.call(urls);
                },
          onLongPress: isLoading ? null : action.onLongPress,
        ),
      );
    }

    // 多个按钮：按主次排列
    final children = <Widget>[];

    // 次按钮（描边）
    for (var i = 0; i < secondaryActions.length; i++) {
      final action = secondaryActions[i];
      final isThisLoading = widget.loadingActionId == action.id;
      children.add(
        Expanded(
          flex: 2,
          child: OutlinedButton.icon(
            onPressed: isLoading
                ? null
                : () {
                    final urls =
                        PlatformDetector.extractAllUrls(widget.controller.text);
                    action.onTap?.call(urls);
                  },
            onLongPress: isLoading ? null : action.onLongPress,
            icon: isThisLoading
                ? SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      valueColor:
                          AlwaysStoppedAnimation<Color>(AppTheme.primaryColor),
                    ),
                  )
                : Icon(action.icon, size: 18, color: AppTheme.primaryColor),
            label: Text(
              isThisLoading
                  ? (widget.loadingProgressText != null
                      ? '处理中 ${widget.loadingProgressText}'
                      : '处理中...')
                  : action.label,
              style: TextStyle(
                color: AppTheme.primaryColor,
                fontWeight: FontWeight.w600,
                fontSize: 14,
              ),
            ),
            style: OutlinedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 14),
              side: BorderSide(color: AppTheme.primaryColor, width: 1.5),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(AppTheme.radiusMd),
              ),
              backgroundColor: AppTheme.primaryColor.withOpacity(0.05),
            ),
          ),
        ),
      );
      if (i < secondaryActions.length - 1 || primaryActions.isNotEmpty) {
        children.add(const SizedBox(width: 12));
      }
    }

    // 主按钮（渐变）
    for (var i = 0; i < primaryActions.length; i++) {
      final action = primaryActions[i];
      final isThisLoading = widget.loadingActionId == action.id;
      children.add(
        Expanded(
          flex: 3,
          child: GradientButton(
            text: isThisLoading
                ? (widget.loadingProgressText != null
                    ? '处理中 ${widget.loadingProgressText}'
                    : '处理中...')
                : action.label,
            icon: action.icon,
            loading: isThisLoading,
            height: 48,
            onPressed: isLoading
                ? null
                : () {
                    final urls =
                        PlatformDetector.extractAllUrls(widget.controller.text);
                    action.onTap?.call(urls);
                  },
            onLongPress: isLoading ? null : action.onLongPress,
          ),
        ),
      );
    }

    return Row(
      children: children,
    );
  }
}
