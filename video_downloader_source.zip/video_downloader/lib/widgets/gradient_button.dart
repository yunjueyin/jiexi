import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class GradientButton extends StatelessWidget {
  final String text;
  final VoidCallback? onPressed;
  final VoidCallback? onLongPress;
  final bool loading;
  final IconData? icon;
  final double? width;
  final double height;
  /// 自定义渐变（为空时使用默认主渐变）
  final Gradient? gradient;
  /// 自定义阴影颜色
  final Color? shadowColor;

  const GradientButton({
    super.key,
    required this.text,
    this.onPressed,
    this.onLongPress,
    this.loading = false,
    this.icon,
    this.width,
    this.height = 48,
    this.gradient,
    this.shadowColor,
  });

  @override
  Widget build(BuildContext context) {
    final btnGradient = gradient ?? AppTheme.primaryGradient;
    final btnShadowColor = shadowColor ?? AppTheme.primaryColor;

    return Container(
      width: width ?? double.infinity,
      height: height,
      decoration: BoxDecoration(
        gradient: btnGradient,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: btnShadowColor.withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: loading ? null : onPressed,
          onLongPress: loading ? null : onLongPress,
          borderRadius: BorderRadius.circular(12),
          child: Center(
            child: loading
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                    ),
                  )
                : Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (icon != null) ...[
                        Icon(icon, size: 18, color: Colors.white),
                        const SizedBox(width: 8),
                      ],
                      Text(
                        text,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
          ),
        ),
      ),
    );
  }
}
