import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../models/video_info.dart';
import '../widgets/video_card.dart';

/// 结果卡片横滑组件
///
/// 批量解析结果支持左右滑动切换上一条/下一条，
/// 使用 PageView 实现，带指示器，滑动时有平滑过渡动画。
class ResultCardSwiper extends StatefulWidget {
  /// 视频结果列表
  final List<VideoInfo> videos;

  /// 当前索引
  final int currentIndex;

  /// 索引变化回调
  final ValueChanged<int>? onIndexChanged;

  /// 卡片点击回调
  final void Function(VideoInfo video)? onCardTap;

  /// 下载按钮回调
  final void Function(VideoInfo video)? onDownload;

  const ResultCardSwiper({
    super.key,
    required this.videos,
    this.currentIndex = 0,
    this.onIndexChanged,
    this.onCardTap,
    this.onDownload,
  });

  @override
  State<ResultCardSwiper> createState() => _ResultCardSwiperState();
}

class _ResultCardSwiperState extends State<ResultCardSwiper> {
  late PageController _pageController;
  late int _currentIndex;

  @override
  void initState() {
    super.initState();
    _currentIndex = widget.currentIndex;
    _pageController = PageController(
      initialPage: _currentIndex,
      viewportFraction: 0.85,
    );
  }

  @override
  void didUpdateWidget(covariant ResultCardSwiper oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.currentIndex != oldWidget.currentIndex &&
        widget.currentIndex != _currentIndex) {
      _currentIndex = widget.currentIndex;
      _pageController.animateToPage(
        _currentIndex,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOutCubic,
      );
    }
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.videos.isEmpty) {
      return const SizedBox.shrink();
    }

    // 只有一条时不显示 PageView
    if (widget.videos.length == 1) {
      return VideoCard(
        video: widget.videos.first,
        onTap: () => widget.onCardTap?.call(widget.videos.first),
        onDownload: () => widget.onDownload?.call(widget.videos.first),
      );
    }

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // PageView
        SizedBox(
          height: 120,
          child: PageView.builder(
            controller: _pageController,
            itemCount: widget.videos.length,
            onPageChanged: (index) {
              setState(() {
                _currentIndex = index;
              });
              widget.onIndexChanged?.call(index);
            },
            itemBuilder: (context, index) {
              final video = widget.videos[index];
              return AnimatedBuilder(
                animation: _pageController,
                builder: (context, child) {
                  double value = 1.0;
                  if (_pageController.position.haveDimensions) {
                    value = _pageController.page! - index;
                    value = (1 - (value.abs() * 0.15)).clamp(0.85, 1.0);
                  }
                  return Center(
                    child: SizedBox(
                      height: Curves.easeOut.transform(value) * 110 + 10,
                      child: child,
                    ),
                  );
                },
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6),
                  child: VideoCard(
                    video: video,
                    onTap: () => widget.onCardTap?.call(video),
                    onDownload: () => widget.onDownload?.call(video),
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 12),
        // 指示器
        _buildIndicator(context),
        const SizedBox(height: 8),
        // 数量提示
        Text(
          '${_currentIndex + 1} / ${widget.videos.length}',
          style: TextStyle(
            fontSize: 12,
            color: AppTheme.textTertiaryColor(context),
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  Widget _buildIndicator(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(widget.videos.length, (index) {
        final isActive = index == _currentIndex;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          margin: const EdgeInsets.symmetric(horizontal: 3),
          width: isActive ? 20 : 6,
          height: 6,
          decoration: BoxDecoration(
            color: isActive
                ? AppTheme.primaryColor
                : AppTheme.textTertiaryColor(context).withOpacity(0.3),
            borderRadius: BorderRadius.circular(3),
          ),
        );
      }),
    );
  }
}
