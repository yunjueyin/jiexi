import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// 空状态预设类型枚举
enum EmptyStateType {
  /// 自定义（完全由参数控制）
  custom,

  /// 通用无数据
  noData,

  /// 无下载任务
  noDownloads,

  /// 无已完成下载
  noCompleted,

  /// 无历史记录
  noHistory,

  /// 无收藏内容
  noFavorites,

  /// 无抓取记录
  noCrawl,

  /// 无搜索结果
  noResults,

  /// 无网络连接
  noInternet,

  /// 加载失败
  error,

  /// 空列表
  emptyList,

  /// 无转换记录
  noConvert,
}

/// 通用空状态组件（统一设计版）
///
/// 统一的图标风格、文字样式、按钮样式和间距布局，
/// 支持多种预设类型，带动画效果。
class EmptyState extends StatefulWidget {
  // ==================== 基础参数 ====================

  /// 标题文字
  final String title;

  /// 副标题/说明文字（可选）
  final String? subtitle;

  /// 自定义图标 Widget（优先级高于 [iconData]）
  final Widget? icon;

  /// 图标数据（与 [icon] 二选一）
  final IconData? iconData;

  // ==================== 按钮参数 ====================

  /// 按钮文字（可选）
  final String? buttonText;

  /// 按钮点击回调
  final VoidCallback? onButtonTap;

  /// 操作回调（与 onButtonTap 同义，便于语义化使用）
  final VoidCallback? onAction;

  // ==================== 样式参数 ====================

  /// 图标背景渐变色
  final List<Color>? gradientColors;

  /// 图标颜色
  final Color? iconColor;

  /// 旧版图标背景色（向后兼容）
  @Deprecated('Use gradientColors instead')
  final Color? iconBgColor;

  // ==================== 预设类型 ====================

  /// 预设类型，用于快速切换不同场景的空状态
  final EmptyStateType type;

  const EmptyState({
    super.key,
    required this.title,
    this.subtitle,
    this.icon,
    this.iconData,
    this.buttonText,
    this.onButtonTap,
    this.onAction,
    this.gradientColors,
    this.iconColor,
    this.iconBgColor,
    this.type = EmptyStateType.custom,
  });

  // ============================================================
  //  工厂构造函数 - 各种预设类型（统一样式）
  // ============================================================

  /// 通用无数据
  factory EmptyState.noData({String? title, String? subtitle, VoidCallback? onAction}) {
    return EmptyState(
      title: title ?? '暂无数据',
      subtitle: subtitle ?? '还没有任何内容，快去添加吧',
      iconData: Icons.inbox_outlined,
      gradientColors: [
        AppTheme.primaryColor.withOpacity(0.9),
        AppTheme.secondaryColor.withOpacity(0.9),
      ],
      iconColor: Colors.white,
      onAction: onAction,
      type: EmptyStateType.noData,
    );
  }

  /// 空列表
  factory EmptyState.emptyList({String? title, String? subtitle, VoidCallback? onAction}) {
    return EmptyState(
      title: title ?? '列表为空',
      subtitle: subtitle ?? '暂时没有内容',
      iconData: Icons.list_alt_outlined,
      gradientColors: [
        Colors.blueGrey.withOpacity(0.8),
        Colors.grey.withOpacity(0.8),
      ],
      iconColor: Colors.white,
      onAction: onAction,
      type: EmptyStateType.emptyList,
    );
  }

  /// 无下载任务
  factory EmptyState.noDownloads({VoidCallback? onTap}) {
    return EmptyState(
      title: '暂无下载',
      subtitle: '快去解析视频，开始下载吧',
      iconData: Icons.download_outlined,
      gradientColors: [
        AppTheme.infoColor.withOpacity(0.9),
        AppTheme.primaryColor.withOpacity(0.9),
      ],
      iconColor: Colors.white,
      buttonText: '去解析下载',
      onButtonTap: onTap,
      type: EmptyStateType.noDownloads,
    );
  }

  /// 无已完成下载
  factory EmptyState.noCompleted() {
    return EmptyState(
      title: '暂无已完成的下载',
      subtitle: '下载完成的视频会显示在这里',
      iconData: Icons.check_circle_outline,
      gradientColors: [
        AppTheme.successColor.withOpacity(0.9),
        AppTheme.secondaryColor.withOpacity(0.9),
      ],
      iconColor: Colors.white,
      type: EmptyStateType.noCompleted,
    );
  }

  /// 无历史记录
  factory EmptyState.noHistory({VoidCallback? onTap}) {
    return EmptyState(
      title: '暂无历史记录',
      subtitle: '解析过的视频会自动保存在这里',
      iconData: Icons.history_outlined,
      gradientColors: [
        const Color(0xFF6366F1).withOpacity(0.9),
        const Color(0xFF8B5CF6).withOpacity(0.9),
      ],
      iconColor: Colors.white,
      buttonText: onTap != null ? '去解析' : null,
      onButtonTap: onTap,
      type: EmptyStateType.noHistory,
    );
  }

  /// 无收藏内容
  factory EmptyState.noFavorites({VoidCallback? onTap}) {
    return EmptyState(
      title: '暂无收藏',
      subtitle: '去收藏喜欢的视频吧',
      iconData: Icons.favorite_border,
      gradientColors: [
        AppTheme.accentColor.withOpacity(0.9),
        const Color(0xFFF97316).withOpacity(0.9),
      ],
      iconColor: Colors.white,
      buttonText: onTap != null ? '去添加收藏' : null,
      onButtonTap: onTap,
      type: EmptyStateType.noFavorites,
    );
  }

  /// 无抓取记录
  factory EmptyState.noCrawlHistory({VoidCallback? onTap}) {
    return EmptyState(
      title: '暂无抓取记录',
      subtitle: '批量抓取的结果会显示在这里',
      iconData: Icons.data_array_outlined,
      gradientColors: [
        Colors.purple.withOpacity(0.9),
        Colors.deepPurple.withOpacity(0.9),
      ],
      iconColor: Colors.white,
      buttonText: onTap != null ? '去抓取' : null,
      onButtonTap: onTap,
      type: EmptyStateType.noCrawl,
    );
  }

  /// 搜索无结果
  factory EmptyState.noResults({String? keyword}) {
    return EmptyState(
      title: '没有找到相关内容',
      subtitle: keyword != null ? '试试其他关键词吧' : '换个条件试试看',
      iconData: Icons.search_off_outlined,
      gradientColors: [
        AppTheme.warningColor.withOpacity(0.9),
        Colors.orange.withOpacity(0.9),
      ],
      iconColor: Colors.white,
      type: EmptyStateType.noResults,
    );
  }

  /// 无网络连接
  factory EmptyState.noInternet({VoidCallback? onRetry}) {
    return EmptyState(
      title: '网络连接失败',
      subtitle: '请检查网络设置后重试',
      iconData: Icons.wifi_off_outlined,
      gradientColors: [
        AppTheme.errorColor.withOpacity(0.9),
        Colors.redAccent.withOpacity(0.9),
      ],
      iconColor: Colors.white,
      buttonText: '重新加载',
      onButtonTap: onRetry,
      type: EmptyStateType.noInternet,
    );
  }

  /// 网络错误（向后兼容，同 noInternet）
  factory EmptyState.networkError({VoidCallback? onRetry}) {
    return EmptyState.noInternet(onRetry: onRetry);
  }

  /// 加载失败
  factory EmptyState.error({String? title, String? subtitle, VoidCallback? onRetry}) {
    return EmptyState(
      title: title ?? '加载失败',
      subtitle: subtitle ?? '出了点小问题，请稍后再试',
      iconData: Icons.error_outline,
      gradientColors: [
        AppTheme.errorColor.withOpacity(0.9),
        Colors.deepOrangeAccent.withOpacity(0.9),
      ],
      iconColor: Colors.white,
      buttonText: onRetry != null ? '重试' : null,
      onButtonTap: onRetry,
      type: EmptyStateType.error,
    );
  }

  /// 无转换记录
  factory EmptyState.noConvert({VoidCallback? onTap}) {
    return EmptyState(
      title: '暂无转换记录',
      subtitle: '链接转换结果会显示在这里',
      iconData: Icons.swap_horiz_outlined,
      gradientColors: [
        const Color(0xFF8B5CF6).withOpacity(0.9),
        const Color(0xFFEC4899).withOpacity(0.9),
      ],
      iconColor: Colors.white,
      buttonText: onTap != null ? '去转换' : null,
      onButtonTap: onTap,
      type: EmptyStateType.noConvert,
    );
  }

  @override
  State<EmptyState> createState() => _EmptyStateState();
}

class _EmptyStateState extends State<EmptyState> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _iconScale;
  late Animation<double> _fadeIn;
  late Animation<Offset> _slideUp;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    // 图标缩放弹出
    _iconScale = Tween<double>(begin: 0.6, end: 1.0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.0, 0.5, curve: Curves.elasticOut),
      ),
    );

    // 整体淡入
    _fadeIn = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.1, 0.5, curve: Curves.easeOut),
      ),
    );

    // 文字和按钮上浮
    _slideUp = Tween<Offset>(begin: const Offset(0, 12), end: Offset.zero).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.2, 0.6, curve: Curves.easeOutCubic),
      ),
    );

    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = AppTheme.isDark(context);
    final icColor = widget.iconColor ?? AppTheme.textTertiaryColor(context);
    final defaultGradients = [
      AppTheme.primaryColor.withOpacity(isDark ? 0.7 : 0.5),
      AppTheme.secondaryColor.withOpacity(isDark ? 0.7 : 0.5),
    ];

    // 向后兼容：如果提供了 iconBgColor，转为单色调渐变
    List<Color> gradColors;
    if (widget.gradientColors != null) {
      gradColors = widget.gradientColors!;
    } else if (widget.iconBgColor != null) {
      final baseColor = widget.iconBgColor!;
      gradColors = [baseColor, baseColor.withOpacity(0.8)];
    } else {
      gradColors = defaultGradients;
    }

    // 按钮回调优先级：onAction > onButtonTap
    final buttonCallback = widget.onAction ?? widget.onButtonTap;

    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // 图标容器（渐变背景）
            AnimatedBuilder(
              animation: _controller,
              builder: (context, child) {
                return Transform.scale(
                  scale: _iconScale.value,
                  child: child,
                );
              },
              child: _buildIconContainer(gradColors, icColor),
            ),
            const SizedBox(height: 20),
            // 文字区域（淡入 + 上浮）
            FadeTransition(
              opacity: _fadeIn,
              child: SlideTransition(
                position: _slideUp,
                child: Column(
                  children: [
                    // 标题 - 统一 14px 粗体
                    Text(
                      widget.title,
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.textPrimaryColor(context),
                        height: 1.4,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 8),
                    // 副标题 - 统一 12px 灰色
                    if (widget.subtitle != null)
                      Text(
                        widget.subtitle!,
                        style: TextStyle(
                          fontSize: 12,
                          color: AppTheme.textSecondaryColor(context),
                          height: 1.5,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    // 操作按钮 - 统一圆角按钮
                    if (widget.buttonText != null && buttonCallback != null) ...[
                      const SizedBox(height: 20),
                      _buildActionButton(buttonCallback, gradColors),
                    ],
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ==================== 图标容器 ====================

  Widget _buildIconContainer(List<Color> gradColors, Color icColor) {
    return Container(
      width: 72,
      height: 72,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          colors: gradColors,
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: gradColors.first.withOpacity(0.3),
            blurRadius: 12,
            spreadRadius: 1,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: widget.icon ??
          Icon(
            widget.iconData ?? Icons.inbox_outlined,
            size: 32,
            color: icColor,
          ),
    );
  }

  // ==================== 操作按钮（统一圆角样式） ====================

  Widget _buildActionButton(VoidCallback onTap, List<Color> gradColors) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: gradColors,
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
        borderRadius: BorderRadius.circular(AppTheme.radiusFull),
        boxShadow: [
          BoxShadow(
            color: gradColors.first.withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(AppTheme.radiusFull),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  widget.buttonText!,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(width: 6),
                const Icon(
                  Icons.arrow_forward_rounded,
                  size: 14,
                  color: Colors.white,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
