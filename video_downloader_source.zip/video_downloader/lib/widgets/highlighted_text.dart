import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// 高亮文字组件
///
/// 搜索结果中关键词高亮显示，支持多个关键词同时高亮。
/// 高亮颜色使用主题主色，带轻微背景色，高亮文字有平滑的渐入效果。
///
/// 使用方式：
/// ```dart
/// HighlightedText(
///   text: '这是一段搜索结果文字',
///   keywords: ['搜索', '结果'],
///   style: TextStyle(fontSize: 14),
/// )
/// ```
class HighlightedText extends StatefulWidget {
  /// 完整文本
  final String text;

  /// 需要高亮的关键词列表
  final List<String> keywords;

  /// 普通文字样式
  final TextStyle style;

  /// 高亮文字样式（为空则使用主色 + 加粗）
  final TextStyle? highlightStyle;

  /// 高亮背景色（为空则使用主色的淡色背景）
  final Color? highlightBgColor;

  /// 是否启用渐入动画
  final bool withFadeIn;

  /// 渐入动画时长（毫秒）
  final int fadeInDurationMs;

  /// 最大行数
  final int? maxLines;

  /// 文字溢出处理
  final TextOverflow? overflow;

  const HighlightedText({
    super.key,
    required this.text,
    required this.keywords,
    this.style = const TextStyle(fontSize: 14, color: Colors.black),
    this.highlightStyle,
    this.highlightBgColor,
    this.withFadeIn = true,
    this.fadeInDurationMs = 400,
    this.maxLines,
    this.overflow,
  });

  @override
  State<HighlightedText> createState() => _HighlightedTextState();
}

class _HighlightedTextState extends State<HighlightedText>
    with SingleTickerProviderStateMixin {
  AnimationController? _controller;
  Animation<double>? _opacityAnimation;

  @override
  void initState() {
    super.initState();
    if (widget.withFadeIn && widget.keywords.isNotEmpty) {
      _controller = AnimationController(
        duration: Duration(milliseconds: widget.fadeInDurationMs),
        vsync: this,
      );
      _opacityAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(parent: _controller!, curve: Curves.easeOut),
      );
      // 延迟一小段时间再开始动画，让用户注意到
      Future.delayed(const Duration(milliseconds: 100), () {
        if (mounted) _controller?.forward();
      });
    }
  }

  @override
  void didUpdateWidget(covariant HighlightedText oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.keywords.join(',') != oldWidget.keywords.join(',')) {
      // 关键词变化时重新播放动画
      if (_controller != null && widget.withFadeIn) {
        _controller!.reset();
        Future.delayed(const Duration(milliseconds: 100), () {
          if (mounted) _controller?.forward();
        });
      }
    }
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.text.isEmpty) {
      return Text('', style: widget.style);
    }

    // 没有关键词时直接返回普通文本
    if (widget.keywords.isEmpty ||
        widget.keywords.every((k) => k.trim().isEmpty)) {
      return Text(
        widget.text,
        style: widget.style,
        maxLines: widget.maxLines,
        overflow: widget.overflow,
      );
    }

    final spans = _buildTextSpans(context);

    final textWidget = RichText(
      text: TextSpan(children: spans, style: widget.style),
      maxLines: widget.maxLines,
      overflow: widget.overflow ?? TextOverflow.clip,
    );

    if (_opacityAnimation != null && widget.withFadeIn) {
      return AnimatedBuilder(
        animation: _opacityAnimation!,
        builder: (context, child) {
          return Opacity(
            opacity: _opacityAnimation!.value,
            child: child,
          );
        },
        child: textWidget,
      );
    }

    return textWidget;
  }

  /// 构建带高亮的 TextSpan 列表
  List<TextSpan> _buildTextSpans(BuildContext context) {
    final primaryColor = Theme.of(context).primaryColor;
    final highlightBg = widget.highlightBgColor ??
        primaryColor.withOpacity(0.12);

    final highlightStyle = widget.highlightStyle?.copyWith(
          background: Paint()
            ..color = highlightBg
            ..style = PaintingStyle.fill,
        ) ??
        widget.style.copyWith(
          color: primaryColor,
          fontWeight: FontWeight.w700,
          background: Paint()
            ..color = highlightBg
            ..style = PaintingStyle.fill,
        );

    // 过滤空关键词
    final validKeywords = widget.keywords
        .where((k) => k.trim().isNotEmpty)
        .map((k) => k.toLowerCase())
        .toList();

    if (validKeywords.isEmpty) {
      return [TextSpan(text: widget.text, style: widget.style)];
    }

    final textLower = widget.text.toLowerCase();
    final spans = <TextSpan>[];

    // 找到所有匹配的位置
    final matches = <_HighlightMatch>[];
    for (final keyword in validKeywords) {
      int startIndex = 0;
      while (true) {
        final index = textLower.indexOf(keyword, startIndex);
        if (index == -1) break;
        matches.add(_HighlightMatch(
          start: index,
          end: index + keyword.length,
        ));
        startIndex = index + keyword.length;
      }
    }

    if (matches.isEmpty) {
      return [TextSpan(text: widget.text, style: widget.style)];
    }

    // 按起始位置排序
    matches.sort((a, b) => a.start.compareTo(b.start));

    // 合并重叠的匹配
    final merged = <_HighlightMatch>[];
    for (final match in matches) {
      if (merged.isEmpty) {
        merged.add(match);
      } else {
        final last = merged.last;
        if (match.start <= last.end) {
          // 重叠，合并
          merged.last = _HighlightMatch(
            start: last.start,
            end: match.end > last.end ? match.end : last.end,
          );
        } else {
          merged.add(match);
        }
      }
    }

    // 构建 span
    int currentIndex = 0;
    for (final match in merged) {
      // 添加普通文本
      if (match.start > currentIndex) {
        spans.add(TextSpan(
          text: widget.text.substring(currentIndex, match.start),
          style: widget.style,
        ));
      }
      // 添加高亮文本
      final highlightText = widget.text.substring(match.start, match.end);
      spans.add(TextSpan(
        text: highlightText,
        style: highlightStyle,
      ));
      currentIndex = match.end;
    }

    // 添加剩余文本
    if (currentIndex < widget.text.length) {
      spans.add(TextSpan(
        text: widget.text.substring(currentIndex),
        style: widget.style,
      ));
    }

    return spans;
  }
}

/// 高亮匹配信息
class _HighlightMatch {
  final int start;
  final int end;

  const _HighlightMatch({
    required this.start,
    required this.end,
  });
}

/// 搜索高亮标题行
///
/// 在列表项中使用的搜索高亮组件，包含标题和副标题的高亮。
class SearchHighlightItem extends StatelessWidget {
  final String title;
  final String? subtitle;
  final List<String> keywords;
  final TextStyle? titleStyle;
  final TextStyle? subtitleStyle;

  const SearchHighlightItem({
    super.key,
    required this.title,
    this.subtitle,
    required this.keywords,
    this.titleStyle,
    this.subtitleStyle,
  });

  @override
  Widget build(BuildContext context) {
    final defaultTitleStyle = TextStyle(
      fontSize: 14,
      fontWeight: FontWeight.w600,
      color: AppTheme.textPrimaryColor(context),
      height: 1.35,
    );

    final defaultSubtitleStyle = TextStyle(
      fontSize: 12,
      color: AppTheme.textTertiaryColor(context),
      fontWeight: FontWeight.w500,
      height: 1.2,
    );

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        HighlightedText(
          text: title,
          keywords: keywords,
          style: titleStyle ?? defaultTitleStyle,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
        ),
        if (subtitle != null && subtitle!.isNotEmpty) ...[
          const SizedBox(height: 6),
          HighlightedText(
            text: subtitle!,
            keywords: keywords,
            style: subtitleStyle ?? defaultSubtitleStyle,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ],
    );
  }
}
