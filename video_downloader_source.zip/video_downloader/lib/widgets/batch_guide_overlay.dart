import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// 引导步骤
class GuideStep {
  /// 高亮区域的全局 key（用于定位）
  final GlobalKey? targetKey;

  /// 高亮区域（如果没有 key，直接指定 rect）
  final Rect? targetRect;

  /// 引导标题
  final String title;

  /// 引导描述
  final String description;

  /// 箭头方向
  final ArrowDirection arrowDirection;

  const GuideStep({
    this.targetKey,
    this.targetRect,
    required this.title,
    required this.description,
    this.arrowDirection = ArrowDirection.down,
  });
}

/// 箭头方向
enum ArrowDirection {
  up,
  down,
  left,
  right,
}

/// 批量操作引导蒙层
///
/// 首次使用批量模式时显示，高亮关键操作区域，多步骤引导。
class BatchGuideOverlay extends StatefulWidget {
  /// 引导步骤列表
  final List<GuideStep> steps;

  /// 完成回调
  final VoidCallback onComplete;

  /// 跳过回调
  final VoidCallback? onSkip;

  const BatchGuideOverlay({
    super.key,
    required this.steps,
    required this.onComplete,
    this.onSkip,
  });

  @override
  State<BatchGuideOverlay> createState() => _BatchGuideOverlayState();
}

class _BatchGuideOverlayState extends State<BatchGuideOverlay> {
  int _currentStep = 0;
  bool _visible = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      setState(() {
        _visible = true;
      });
    });
  }

  void _next() {
    if (_currentStep < widget.steps.length - 1) {
      setState(() {
        _currentStep++;
      });
    } else {
      _finish();
    }
  }

  void _finish() {
    setState(() {
      _visible = false;
    });
    Future.delayed(const Duration(milliseconds: 200), () {
      widget.onComplete();
    });
  }

  void _skip() {
    setState(() {
      _visible = false;
    });
    Future.delayed(const Duration(milliseconds: 200), () {
      widget.onSkip?.call();
      widget.onComplete();
    });
  }

  Rect? _getTargetRect(GuideStep step) {
    if (step.targetRect != null) return step.targetRect;
    if (step.targetKey?.currentContext != null) {
      final renderBox = step.targetKey!.currentContext!.findRenderObject() as RenderBox?;
      if (renderBox != null) {
        final position = renderBox.localToGlobal(Offset.zero);
        return position & renderBox.size;
      }
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final step = widget.steps[_currentStep];
    final targetRect = _getTargetRect(step);

    return AnimatedOpacity(
      opacity: _visible ? 1.0 : 0.0,
      duration: const Duration(milliseconds: 200),
      child: Stack(
        children: [
          // 半透明黑色背景 + 挖空高亮
          Positioned.fill(
            child: CustomPaint(
              painter: _HolePainter(
                holeRect: targetRect,
                holeRadius: 12,
                bgColor: Colors.black.withOpacity(0.7),
              ),
            ),
          ),
          // 引导提示卡片
          _buildTipCard(step, targetRect),
          // 跳过按钮
          Positioned(
            top: MediaQuery.of(context).padding.top + 16,
            right: 16,
            child: TextButton(
              onPressed: _skip,
              style: TextButton.styleFrom(
                foregroundColor: Colors.white,
                backgroundColor: Colors.white.withOpacity(0.15),
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
              child: const Text('跳过', style: TextStyle(fontSize: 13)),
            ),
          ),
          // 步骤指示器
          Positioned(
            bottom: MediaQuery.of(context).padding.bottom + 40,
            left: 0,
            right: 0,
            child: Row(
              mainAxisAlignment: center,
              children: List.generate(widget.steps.length, (index) {
                return Container(
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  width: index == _currentStep ? 20 : 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: index == _currentStep
                        ? AppTheme.primaryColor
                        : Colors.white.withOpacity(0.4),
                    borderRadius: BorderRadius.circular(4),
                  ),
                );
              }),
            ),
          ),
        ],
      ),
    );
  }

  MainAxisAlignment get center => MainAxisAlignment.center;

  Widget _buildTipCard(GuideStep step, Rect? targetRect) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;

    // 计算提示卡片位置
    double top;
    double left;
    ArrowDirection arrowDir = step.arrowDirection;

    if (targetRect != null) {
      // 根据目标位置决定卡片位置
      final targetCenter = targetRect.center;

      if (arrowDir == ArrowDirection.down) {
        // 卡片在目标上方
        top = targetRect.top - 140;
        left = (targetCenter.dx - 140).clamp(20.0, screenWidth - 300.0);
      } else if (arrowDir == ArrowDirection.up) {
        // 卡片在目标下方
        top = targetRect.bottom + 20;
        left = (targetCenter.dx - 140).clamp(20.0, screenWidth - 300.0);
      } else if (arrowDir == ArrowDirection.right) {
        // 卡片在目标左侧
        top = (targetCenter.dy - 60).clamp(80.0, screenHeight - 200.0);
        left = targetRect.left - 300;
        if (left < 20) {
          left = targetRect.right + 20;
          arrowDir = ArrowDirection.left;
        }
      } else {
        // 卡片在目标右侧
        top = (targetCenter.dy - 60).clamp(80.0, screenHeight - 200.0);
        left = targetRect.right + 20;
        if (left + 280 > screenWidth - 20) {
          left = targetRect.left - 300;
          arrowDir = ArrowDirection.right;
        }
      }
    } else {
      // 没有目标区域，居中显示
      top = screenHeight * 0.35;
      left = 20;
    }

    return Positioned(
      top: top,
      left: left,
      width: 280,
      child: _TipCard(
        title: step.title,
        description: step.description,
        arrowDirection: arrowDir,
        stepLabel: '${_currentStep + 1}/${widget.steps.length}',
        isLast: _currentStep == widget.steps.length - 1,
        onNext: _next,
      ),
    );
  }
}

/// 提示卡片
class _TipCard extends StatelessWidget {
  final String title;
  final String description;
  final ArrowDirection arrowDirection;
  final String stepLabel;
  final bool isLast;
  final VoidCallback onNext;

  const _TipCard({
    required this.title,
    required this.description,
    required this.arrowDirection,
    required this.stepLabel,
    required this.isLast,
    required this.onNext,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (arrowDirection == ArrowDirection.down) _buildArrow(arrowDirection),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.2),
                blurRadius: 20,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      title,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF0F172A),
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: AppTheme.primaryColor.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      stepLabel,
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: AppTheme.primaryColor,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                description,
                style: TextStyle(
                  fontSize: 13,
                  color: Colors.grey.shade600,
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: onNext,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.primaryColor,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  child: Text(isLast ? '开始使用' : '下一步'),
                ),
              ),
            ],
          ),
        ),
        if (arrowDirection == ArrowDirection.up) _buildArrow(arrowDirection),
      ],
    );
  }

  Widget _buildArrow(ArrowDirection direction) {
    return CustomPaint(
      size: const Size(20, 10),
      painter: _ArrowPainter(direction: direction),
    );
  }
}

/// 箭头绘制
class _ArrowPainter extends CustomPainter {
  final ArrowDirection direction;

  _ArrowPainter({required this.direction});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.fill;

    final path = Path();

    if (direction == ArrowDirection.down) {
      path.moveTo(size.width / 2, size.height);
      path.lineTo(0, 0);
      path.lineTo(size.width, 0);
    } else if (direction == ArrowDirection.up) {
      path.moveTo(size.width / 2, 0);
      path.lineTo(0, size.height);
      path.lineTo(size.width, size.height);
    }

    path.close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

/// 挖空高亮绘制
class _HolePainter extends CustomPainter {
  final Rect? holeRect;
  final double holeRadius;
  final Color bgColor;

  _HolePainter({
    required this.holeRect,
    required this.holeRadius,
    required this.bgColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    // 绘制背景
    final bgPaint = Paint()..color = bgColor;

    if (holeRect == null) {
      canvas.drawRect(Offset.zero & size, bgPaint);
      return;
    }

    // 使用 Path 绘制带孔的背景
    final path = Path()
      ..fillType = PathFillType.evenOdd
      ..addRect(Offset.zero & size)
      ..addRRect(RRect.fromRectAndRadius(
        holeRect!.inflate(6),
        Radius.circular(holeRadius),
      ));

    canvas.drawPath(path, bgPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
