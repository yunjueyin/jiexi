import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// 下拉快捷菜单项
class QuickMenuItem {
  final String id;
  final String label;
  final IconData icon;
  final Color color;

  const QuickMenuItem({
    required this.id,
    required this.label,
    required this.icon,
    required this.color,
  });
}

/// 下拉快捷菜单
///
/// 在首页下拉刷新区域增加快捷操作，
/// 下拉超过一定距离时展示快捷菜单，松手后根据释放位置执行对应操作。
class PullDownQuickMenu extends StatefulWidget {
  /// 子组件（通常是可滚动内容）
  final Widget child;

  /// 菜单项
  final List<QuickMenuItem> items;

  /// 选择菜单项回调
  final void Function(String itemId)? onMenuItemSelected;

  /// 触发距离（下拉多少像素后显示菜单）
  final double triggerDistance;

  const PullDownQuickMenu({
    super.key,
    required this.child,
    required this.items,
    this.onMenuItemSelected,
    this.triggerDistance = 120,
  });

  @override
  State<PullDownQuickMenu> createState() => _PullDownQuickMenuState();
}

class _PullDownQuickMenuState extends State<PullDownQuickMenu> {
  double _pullDistance = 0;
  bool _isPulling = false;
  int _selectedIndex = -1;
  bool _menuVisible = false;

  double get _menuProgress {
    if (_pullDistance < 60) return 0;
    final progress = (_pullDistance - 60) / (widget.triggerDistance - 60);
    return progress.clamp(0.0, 1.0);
  }

  bool get _isAtTop {
    // 简化判断：通过 ScrollController 等方式更好，这里用 _pullDistance > 0 表示已下拉
    return true;
  }

  void _handlePullUpdate(DragUpdateDetails details) {
    if (!_isAtTop && _pullDistance == 0) return;

    setState(() {
      _pullDistance += details.delta.dy;
      if (_pullDistance < 0) _pullDistance = 0;
      _isPulling = true;
      _menuVisible = _menuProgress > 0.3;

      // 根据水平位置计算选中的菜单项
      if (_menuVisible && details.globalPosition.dx > 0) {
        final screenWidth = MediaQuery.of(context).size.width;
        final itemWidth = screenWidth / widget.items.length;
        final x = details.globalPosition.dx;
        final index = (x / itemWidth).floor();
        _selectedIndex = index.clamp(0, widget.items.length - 1);
      }
    });
  }

  void _handlePullEnd(DragEndDetails details) {
    if (_isPulling && _menuVisible && _selectedIndex >= 0) {
      // 触发菜单项
      widget.onMenuItemSelected?.call(widget.items[_selectedIndex].id);
    }

    setState(() {
      _pullDistance = 0;
      _isPulling = false;
      _menuVisible = false;
      _selectedIndex = -1;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // 快捷菜单（在内容上方）
        if (_menuVisible) _buildQuickMenu(),

        // 内容区域
        GestureDetector(
          onVerticalDragUpdate: _handlePullUpdate,
          onVerticalDragEnd: _handlePullEnd,
          onHorizontalDragUpdate: (details) {
            // 水平拖动时更新选中项
            if (_menuVisible) {
              setState(() {
                final screenWidth = MediaQuery.of(context).size.width;
                final itemWidth = screenWidth / widget.items.length;
                final x = details.globalPosition.dx;
                final index = (x / itemWidth).floor();
                _selectedIndex = index.clamp(0, widget.items.length - 1);
              });
            }
          },
          child: Transform.translate(
            offset: Offset(0, _pullDistance * 0.3),
            child: widget.child,
          ),
        ),

        // 下拉指示器
        if (_pullDistance > 10 && !_menuVisible)
          Positioned(
            top: 60 + _pullDistance * 0.2,
            left: 0,
            right: 0,
            child: Center(
              child: Opacity(
                opacity: _menuProgress,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    color: AppTheme.primaryColor.withOpacity(0.9),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        _pullDistance < widget.triggerDistance
                            ? Icons.arrow_downward
                            : Icons.touch_app_rounded,
                        size: 16,
                        color: Colors.white,
                      ),
                      const SizedBox(width: 6),
                      Text(
                        _pullDistance < widget.triggerDistance ? '继续下拉打开快捷菜单' : '松手选择操作',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildQuickMenu() {
    final progress = _menuProgress;
    final itemCount = widget.items.length;

    return Positioned(
      top: 0,
      left: 0,
      right: 0,
      child: Container(
        height: 120 + MediaQuery.of(context).padding.top,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppTheme.primaryColor.withOpacity(0.95),
              AppTheme.primaryColor.withOpacity(0.7),
            ],
          ),
        ),
        child: SafeArea(
          bottom: false,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              const SizedBox(height: 8),
              // 提示文字
              Text(
                '选择快捷操作',
                style: TextStyle(
                  color: Colors.white.withOpacity(0.8),
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 12),
              // 菜单项
              Expanded(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: List.generate(itemCount, (index) {
                    final item = widget.items[index];
                    final isSelected = _selectedIndex == index;

                    return _buildMenuItem(item, isSelected, progress);
                  }),
                ),
              ),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMenuItem(QuickMenuItem item, bool isSelected, double progress) {
    final scale = isSelected ? 1.2 : 1.0;
    final opacity = isSelected ? 1.0 : 0.8;

    return AnimatedScale(
      duration: const Duration(milliseconds: 150),
      scale: scale,
      child: Opacity(
        opacity: opacity,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: isSelected ? Colors.white : Colors.white.withOpacity(0.2),
                shape: BoxShape.circle,
                boxShadow: isSelected
                    ? [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.2),
                          blurRadius: 10,
                          offset: const Offset(0, 4),
                        ),
                      ]
                    : null,
              ),
              child: Icon(
                item.icon,
                color: isSelected ? item.color : Colors.white,
                size: 24,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              item.label,
              style: TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
