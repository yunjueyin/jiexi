import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

// ============================================================
// 基础骨架单元
// ============================================================

/// 骨架屏基础组件 - 带微光流动动画（shimmer effect）
///
/// 所有骨架样式的基础构建块，提供线性渐变的微光流动效果。
class Skeleton extends StatefulWidget {
  final double width;
  final double height;
  final BorderRadiusGeometry? borderRadius;
  final EdgeInsetsGeometry? padding;
  final Color? baseColor;
  final Color? highlightColor;

  const Skeleton({
    super.key,
    required this.width,
    required this.height,
    this.borderRadius,
    this.padding,
    this.baseColor,
    this.highlightColor,
  });

  /// 圆形骨架
  factory Skeleton.circle({
    required double size,
    Color? baseColor,
    Color? highlightColor,
  }) {
    return Skeleton(
      width: size,
      height: size,
      borderRadius: BorderRadius.circular(size / 2),
      baseColor: baseColor,
      highlightColor: highlightColor,
    );
  }

  /// 矩形骨架（带圆角）
  factory Skeleton.rect({
    required double width,
    required double height,
    double radius = AppTheme.radiusSm,
    Color? baseColor,
    Color? highlightColor,
  }) {
    return Skeleton(
      width: width,
      height: height,
      borderRadius: BorderRadius.circular(radius),
      baseColor: baseColor,
      highlightColor: highlightColor,
    );
  }

  /// 一行文字骨架
  factory Skeleton.textLine({
    double width = double.infinity,
    double height = 14,
    double radius = 4,
    EdgeInsetsGeometry? padding,
    Color? baseColor,
    Color? highlightColor,
  }) {
    return Skeleton(
      width: width,
      height: height,
      borderRadius: BorderRadius.circular(radius),
      padding: padding,
      baseColor: baseColor,
      highlightColor: highlightColor,
    );
  }

  @override
  State<Skeleton> createState() => _SkeletonState();
}

class _SkeletonState extends State<Skeleton>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    );
    _animation = Tween<double>(begin: -1.0, end: 2.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOutSine),
    );
    _controller.repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final base = widget.baseColor ??
        (isDark ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0));
    final highlight = widget.highlightColor ??
        (isDark ? const Color(0xFF334155) : const Color(0xFFF1F5F9));

    return Padding(
      padding: widget.padding ?? EdgeInsets.zero,
      child: SizedBox(
        width: widget.width,
        height: widget.height,
        child: AnimatedBuilder(
          animation: _animation,
          builder: (context, child) {
            return DecoratedBox(
              decoration: BoxDecoration(
                borderRadius: widget.borderRadius ?? BorderRadius.circular(4),
                gradient: LinearGradient(
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                  colors: [base, highlight, base],
                  stops: [
                    (_animation.value - 0.3).clamp(0.0, 1.0),
                    _animation.value.clamp(0.0, 1.0),
                    (_animation.value + 0.3).clamp(0.0, 1.0),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

// ============================================================
// 列表项骨架（统一样式）
// ============================================================

/// 标准列表项骨架屏
///
/// 左侧缩略图 + 右侧文字信息，统一用于历史、收藏、抓取等列表。
class ListItemSkeleton extends StatelessWidget {
  final bool hasThumbnail;
  final double thumbnailWidth;
  final double thumbnailHeight;

  const ListItemSkeleton({
    super.key,
    this.hasThumbnail = true,
    this.thumbnailWidth = 70,
    this.thumbnailHeight = 56,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = AppTheme.isDark(context);
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppTheme.cardBg(context),
        borderRadius: BorderRadius.circular(AppTheme.radiusMd),
        border: Border.all(
          color: isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
          width: 0.5,
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (hasThumbnail) ...[
            Skeleton.rect(
              width: thumbnailWidth,
              height: thumbnailHeight,
              radius: AppTheme.radiusSm,
            ),
            const SizedBox(width: 12),
          ],
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Skeleton.textLine(width: double.infinity, height: 14),
                const SizedBox(height: 8),
                Skeleton.textLine(width: 120, height: 12),
                const SizedBox(height: 6),
                Skeleton.textLine(width: 80, height: 10),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// 列表骨架屏容器（多个列表项）
class ListSkeleton extends StatelessWidget {
  final int count;
  final bool hasThumbnail;
  final double thumbnailWidth;
  final double thumbnailHeight;

  const ListSkeleton({
    super.key,
    this.count = 6,
    this.hasThumbnail = true,
    this.thumbnailWidth = 70,
    this.thumbnailHeight = 56,
  });

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      padding: const EdgeInsets.all(12),
      physics: const NeverScrollableScrollPhysics(),
      itemCount: count,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (_, __) => ListItemSkeleton(
        hasThumbnail: hasThumbnail,
        thumbnailWidth: thumbnailWidth,
        thumbnailHeight: thumbnailHeight,
      ),
    );
  }
}

// ============================================================
// 下载项骨架
// ============================================================

/// 下载项骨架屏
///
/// 进度条占位 + 文件信息 + 操作按钮，模拟下载列表项。
class DownloadItemSkeleton extends StatelessWidget {
  const DownloadItemSkeleton({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = AppTheme.isDark(context);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.cardBg(context),
        borderRadius: BorderRadius.circular(AppTheme.radiusLg),
        border: Border.all(
          color: isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
          width: 0.5,
        ),
        boxShadow: AppTheme.shadowSm,
      ),
      child: Column(
        children: [
          Row(
            children: [
              Skeleton.circle(size: 48),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Skeleton.textLine(width: double.infinity, height: 14),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Skeleton.rect(width: 40, height: 16, radius: 4),
                        const SizedBox(width: 8),
                        Skeleton.rect(width: 50, height: 16, radius: 4),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          // 进度条
          Skeleton.textLine(width: double.infinity, height: 4, radius: 2),
          const SizedBox(height: 8),
          Row(
            children: [
              Skeleton.rect(width: 80, height: 10, radius: 2),
              const Spacer(),
              Skeleton.rect(width: 60, height: 10, radius: 2),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: Skeleton.rect(
                  width: double.infinity,
                  height: 36,
                  radius: AppTheme.radiusMd,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Skeleton.rect(
                  width: double.infinity,
                  height: 36,
                  radius: AppTheme.radiusMd,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// 下载列表骨架屏
class DownloadListSkeleton extends StatelessWidget {
  final int count;

  const DownloadListSkeleton({super.key, this.count = 3});

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      physics: const NeverScrollableScrollPhysics(),
      itemCount: count,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (_, __) => const DownloadItemSkeleton(),
    );
  }
}

// ============================================================
// 视频卡片骨架
// ============================================================

/// 视频卡片骨架屏
///
/// 矩形图片占位 + 文字行占位，模拟视频卡片布局。
class VideoCardSkeleton extends StatelessWidget {
  final bool hasDownloadButton;

  const VideoCardSkeleton({
    super.key,
    this.hasDownloadButton = true,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = AppTheme.isDark(context);

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppTheme.cardBg(context),
        borderRadius: BorderRadius.circular(AppTheme.radiusLg),
        border: Border.all(
          color: isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
          width: 0.5,
        ),
        boxShadow: AppTheme.shadowSm,
      ),
      child: Row(
        children: [
          // 封面占位
          Skeleton.rect(
            width: 88,
            height: 72,
            radius: AppTheme.radiusMd,
          ),
          const SizedBox(width: 14),
          // 文字信息
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Skeleton.textLine(width: double.infinity, height: 14),
                const SizedBox(height: 6),
                Skeleton.textLine(width: 120, height: 12),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Skeleton.rect(width: 50, height: 18, radius: 6),
                    const SizedBox(width: 8),
                    Skeleton.rect(width: 40, height: 18, radius: 6),
                  ],
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Skeleton.circle(size: 10),
                    const SizedBox(width: 4),
                    Skeleton.textLine(width: 80, height: 10),
                  ],
                ),
              ],
            ),
          ),
          // 下载按钮占位
          if (hasDownloadButton) ...[
            const SizedBox(width: 8),
            Skeleton.rect(
              width: 40,
              height: 40,
              radius: AppTheme.radiusMd,
            ),
          ],
        ],
      ),
    );
  }
}

/// 视频列表骨架屏
class VideoListSkeleton extends StatelessWidget {
  final int count;

  const VideoListSkeleton({super.key, this.count = 5});

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      padding: const EdgeInsets.all(12),
      physics: const NeverScrollableScrollPhysics(),
      itemCount: count,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (_, __) => const VideoCardSkeleton(),
    );
  }
}

// ============================================================
// 作者信息骨架
// ============================================================

/// 作者信息骨架屏
class AuthorSkeleton extends StatelessWidget {
  final bool compact;

  const AuthorSkeleton({
    super.key,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = AppTheme.isDark(context);
    final avatarSize = compact ? 48.0 : 64.0;

    return Container(
      padding: EdgeInsets.all(compact ? 12 : 16),
      decoration: BoxDecoration(
        color: AppTheme.cardBg(context),
        borderRadius: BorderRadius.circular(AppTheme.radiusLg),
        border: Border.all(
          color: isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
          width: 0.5,
        ),
        boxShadow: AppTheme.shadowSm,
      ),
      child: Row(
        children: [
          // 头像
          Skeleton.circle(size: avatarSize),
          const SizedBox(width: 14),
          // 作者信息
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Skeleton.textLine(width: 100, height: 16),
                const SizedBox(height: 8),
                Skeleton.textLine(width: 140, height: 12),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Skeleton.rect(width: 36, height: 16, radius: 4),
                    const SizedBox(width: 8),
                    Skeleton.rect(width: 36, height: 16, radius: 4),
                    const SizedBox(width: 8),
                    Skeleton.rect(width: 36, height: 16, radius: 4),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// 设置列表骨架
// ============================================================

/// 带图标的设置列表骨架
class SettingsListSkeleton extends StatelessWidget {
  final int count;

  const SettingsListSkeleton({
    super.key,
    this.count = 6,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = AppTheme.isDark(context);

    return Container(
      decoration: BoxDecoration(
        color: AppTheme.cardBg(context),
        borderRadius: BorderRadius.circular(AppTheme.radiusLg),
        border: Border.all(
          color: isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
          width: 0.5,
        ),
        boxShadow: AppTheme.shadowSm,
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        children: List.generate(count, (index) {
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            child: Row(
              children: [
                Skeleton.circle(size: 32),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Skeleton.textLine(width: 100, height: 14),
                      const SizedBox(height: 6),
                      Skeleton.textLine(width: 140, height: 11),
                    ],
                  ),
                ),
                Skeleton.circle(size: 20),
              ],
            ),
          );
        }),
      ),
    );
  }
}

// ============================================================
// 视频解析结果骨架
// ============================================================

/// 视频解析结果骨架屏
class VideoParseSkeleton extends StatelessWidget {
  const VideoParseSkeleton({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = AppTheme.isDark(context);
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppTheme.cardBg(context),
        borderRadius: BorderRadius.circular(AppTheme.radiusXl),
        border: Border.all(
          color: isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
          width: 0.5,
        ),
        boxShadow: AppTheme.shadowMd,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 顶部状态条
          Row(
            children: [
              Skeleton.rect(width: 80, height: 24, radius: 12),
              const SizedBox(width: 10),
              Skeleton.rect(width: 60, height: 20, radius: 6),
            ],
          ),
          const SizedBox(height: 16),
          // 封面 + 标题信息
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Skeleton.rect(width: 100, height: 100, radius: AppTheme.radiusMd),
              const SizedBox(width: 14),
              Expanded(
                child: SizedBox(
                  height: 100,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Skeleton.textLine(width: double.infinity, height: 14),
                      Skeleton.textLine(width: double.infinity, height: 14),
                      Skeleton.textLine(width: 150, height: 12),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Skeleton.textLine(width: 100, height: 12),
                          const SizedBox(height: 4),
                          Skeleton.textLine(width: 80, height: 12),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          // 下载按钮骨架
          Skeleton.rect(width: double.infinity, height: 50, radius: AppTheme.radiusMd),
          const SizedBox(height: 10),
          Skeleton.rect(width: double.infinity, height: 44, radius: AppTheme.radiusMd),
          const SizedBox(height: 14),
          // 次要操作
          Row(
            children: [
              Expanded(
                child: Skeleton.rect(
                  width: double.infinity,
                  height: 36,
                  radius: AppTheme.radiusMd,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Skeleton.rect(
                  width: double.infinity,
                  height: 36,
                  radius: AppTheme.radiusMd,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ============================================================
// 页面级骨架容器
// ============================================================

/// 骨架屏类型枚举
enum SkeletonType {
  /// 视频卡片列表
  videoList,

  /// 作者信息列表
  authorList,

  /// 下载列表
  downloadList,

  /// 通用列表（历史/收藏/抓取）
  list,

  /// 设置列表
  settingsList,

  /// 解析结果卡片
  parseResult,
}

/// 页面级骨架屏容器
///
/// 根据类型自动选择对应的骨架屏样式，简化页面调用。
class PageSkeleton extends StatelessWidget {
  final SkeletonType type;
  final int itemCount;

  const PageSkeleton({
    super.key,
    required this.type,
    this.itemCount = 6,
  });

  @override
  Widget build(BuildContext context) {
    switch (type) {
      case SkeletonType.videoList:
        return VideoListSkeleton(count: itemCount);
      case SkeletonType.authorList:
        return _buildAuthorListSkeleton();
      case SkeletonType.downloadList:
        return DownloadListSkeleton(count: itemCount);
      case SkeletonType.list:
        return ListSkeleton(count: itemCount);
      case SkeletonType.settingsList:
        return Padding(
          padding: const EdgeInsets.all(16),
          child: SettingsListSkeleton(count: itemCount),
        );
      case SkeletonType.parseResult:
        return const Padding(
          padding: EdgeInsets.all(16),
          child: VideoParseSkeleton(),
        );
    }
  }

  Widget _buildAuthorListSkeleton() {
    return ListView.separated(
      padding: const EdgeInsets.all(12),
      physics: const NeverScrollableScrollPhysics(),
      itemCount: itemCount,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (_, __) => const AuthorSkeleton(compact: true),
    );
  }
}
