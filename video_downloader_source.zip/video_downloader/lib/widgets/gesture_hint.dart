import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../providers/settings_provider.dart';

/// 手势提示类型
enum GestureHintType {
  /// 上下滑动提示（列表页）
  verticalSwipe,

  /// 左右滑动提示（结果页/卡片）
  horizontalSwipe,

  /// 长按提示
  longPress,
}

/// 手势提示组件
///
/// 首次进入各页面时，显示微动效暗示可用手势。
/// 提示半透明，不遮挡核心内容，1.5 秒后自动消失。
/// 使用 SettingsProvider 记录是否已展示过。
///
/// 使用方式：
/// ```dart
/// GestureHint(
///   pageKey: 'home_list',
///   type: GestureHintType.verticalSwipe,
///   child: ListView(...),
/// )
/// ```
class GestureHint extends StatefulWidget {
  /// 页面唯一标识，用于记录是否已展示过
  final String pageKey;

  /// 手势提示类型
  final GestureHintType type;

  /// 子组件
  final Widget child;

  /// 提示显示时长（毫秒），默认 1500ms
  final int durationMs;

  /// 提示文字
  final String? hintText;

  /// 是否强制显示（忽略已展示记录）
  final bool forceShow;

  const GestureHint({
    super.key,
    required this.pageKey,
    required this.type,
    required this.child,
    this.durationMs = 1500,
    this.hintText,
    this.forceShow = false,
  });

  @override
  State<GestureHint> createState() => _GestureHintState();
}

class _GestureHintState extends State<GestureHint>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fadeAnimation;
  bool _showing = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOut),
    );

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _checkAndShow();
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _checkAndShow() {
    final settings = context.read<SettingsProvider>();

    if (widget.forceShow || !settings.gestureHintsShown.contains(widget.pageKey)) {
      setState(() {
        _showing = true;
      });
      _controller.forward();

      // 标记为已展示
      if (!widget.forceShow) {
        settings.markGestureHintShown(widget.pageKey);
      }

      // 自动消失
      Future.delayed(Duration(milliseconds: widget.durationMs), () {
        if (mounted && _showing) {
          _controller.reverse().then((_) {
            if (mounted) {
              setState(() {
                _showing = false;
              });
            }
          });
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        widget.child,
        if (_showing)
          Positioned.fill(
            child: IgnorePointer(
              child: FadeTransition(
                opacity: _fadeAnimation,
                child: _buildHintOverlay(),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildHintOverlay() {
    switch (widget.type) {
      case GestureHintType.verticalSwipe:
        return _buildVerticalSwipeHint();
      case GestureHintType.horizontalSwipe:
        return _buildHorizontalSwipeHint();
      case GestureHintType.longPress:
        return _buildLongPressHint();
    }
  }

  /// 上下滑动提示
  Widget _buildVerticalSwipeHint() {
    final hintText = widget.hintText ?? '上下滑动浏览';
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          _VerticalSwipeArrows(),
          const SizedBox(height: 12),
          _buildHintLabel(hintText),
        ],
      ),
    );
  }

  /// 左右滑动提示
  Widget _buildHorizontalSwipeHint() {
    final hintText = widget.hintText ?? '左右滑动切换';
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          _HorizontalSwipeArrows(),
          const SizedBox(height: 12),
          _buildHintLabel(hintText),
        ],
      ),
    );
  }

  /// 长按提示
  Widget _buildLongPressHint() {
    final hintText = widget.hintText ?? '长按查看更多操作';
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          _LongPressHint(),
          const SizedBox(height: 12),
          _buildHintLabel(hintText),
        ],
      ),
    );
  }

  /// 提示文字标签
  Widget _buildHintLabel(String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.6),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        text,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 13,
          fontWeight: FontWeight.w500,
          height: 1.3,
        ),
      ),
    );
  }
}

// ============================================================
// 上下滑动箭头动画
// ============================================================

class _VerticalSwipeArrows extends StatefulWidget {
  @override
  State<_VerticalSwipeArrows> createState() => _VerticalSwipeArrowsState();
}

class _VerticalSwipeArrowsState extends State<_VerticalSwipeArrows>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    )..repeat(reverse: true);

    _animation = Tween<double>(begin: -8, end: 8).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _animation,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(0, _animation.value),
          child: child,
        );
      },
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.keyboard_arrow_up_rounded,
            color: Colors.white.withOpacity(0.9),
            size: 32,
          ),
          Icon(
            Icons.keyboard_arrow_down_rounded,
            color: Colors.white.withOpacity(0.9),
            size: 32,
          ),
        ],
      ),
    );
  }
}

// ============================================================
// 左右滑动箭头动画
// ============================================================

class _HorizontalSwipeArrows extends StatefulWidget {
  @override
  State<_HorizontalSwipeArrows> createState() =>
      _HorizontalSwipeArrowsState();
}

class _HorizontalSwipeArrowsState extends State<_HorizontalSwipeArrows>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    )..repeat(reverse: true);

    _animation = Tween<double>(begin: -10, end: 10).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _animation,
      builder: (context, child) {
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Transform.translate(
              offset: Offset(_animation.value, 0),
              child: Icon(
                Icons.keyboard_arrow_left_rounded,
                color: Colors.white.withOpacity(0.9),
                size: 36,
              ),
            ),
            const SizedBox(width: 20),
            Transform.translate(
              offset: Offset(-_animation.value, 0),
              child: Icon(
                Icons.keyboard_arrow_right_rounded,
                color: Colors.white.withOpacity(0.9),
                size: 36,
              ),
            ),
          ],
        );
      },
    );
  }
}

// ============================================================
// 长按提示动画
// ============================================================

class _LongPressHint extends StatefulWidget {
  @override
  State<_LongPressHint> createState() => _LongPressHintState();
}

class _LongPressHintState extends State<_LongPressHint>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  late Animation<double> _ringAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    )..repeat(reverse: true);

    _scaleAnimation = Tween<double>(begin: 0.9, end: 1.1).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );

    _ringAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return Stack(
          alignment: Alignment.center,
          children: [
            // 扩散圆环
            Opacity(
              opacity: (1 - _ringAnimation.value) * 0.5,
              child: Container(
                width: 60 + _ringAnimation.value * 30,
                height: 60 + _ringAnimation.value * 30,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: Colors.white.withOpacity(0.6),
                    width: 2,
                  ),
                ),
              ),
            ),
            // 手指图标
            Transform.scale(
              scale: _scaleAnimation.value,
              child: Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.5),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.touch_app_rounded,
                  color: Colors.white,
                  size: 28,
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

// ============================================================
// 手势提示管理工具
// ============================================================

/// 手势提示管理工具
///
/// 提供检查、重置手势提示状态的便捷方法。
class GestureHintManager {
  /// 检查指定页面是否已展示过手势提示
  static bool hasShown(BuildContext context, String pageKey) {
    return context.read<SettingsProvider>().gestureHintsShown.contains(pageKey);
  }

  /// 重置所有手势提示
  static Future<void> resetAll(BuildContext context) async {
    await context.read<SettingsProvider>().resetGestureHints();
  }

  /// 常用页面 key 常量
  static const String homeList = 'home_list';
  static const String resultCard = 'result_card';
  static const String historyList = 'history_list';
  static const String favoritesList = 'favorites_list';
  static const String downloadList = 'download_list';
  static const String videoCardLongPress = 'video_card_long_press';
}
