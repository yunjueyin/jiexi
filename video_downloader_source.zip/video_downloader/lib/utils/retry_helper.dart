import 'dart:math';

/// 重试配置
class RetryConfig {
  /// 最大重试次数（不含首次）
  /// 例如 maxRetries=2 表示总共尝试 3 次（1次初始 + 2次重试）
  final int maxRetries;

  /// 初始延迟
  final Duration initialDelay;

  /// 退避因子（如 2.0 表示每次延迟翻倍）
  final double backoffFactor;

  /// 最大延迟
  final Duration maxDelay;

  const RetryConfig({
    this.maxRetries = 2,
    this.initialDelay = const Duration(milliseconds: 500),
    this.backoffFactor = 2.0,
    this.maxDelay = const Duration(seconds: 5),
  });

  /// 不重试配置
  static const RetryConfig none = RetryConfig(maxRetries: 0);

  /// 轻量重试（1次，快速）
  static const RetryConfig quick = RetryConfig(
    maxRetries: 1,
    initialDelay: Duration(milliseconds: 300),
    backoffFactor: 1.5,
    maxDelay: Duration(seconds: 2),
  );

  /// 标准重试（2次，指数退避）
  static const RetryConfig standard = RetryConfig(
    maxRetries: 2,
    initialDelay: Duration(milliseconds: 500),
    backoffFactor: 2.0,
    maxDelay: Duration(seconds: 5),
  );

  /// 重度重试（3次，较长延迟）
  static const RetryConfig heavy = RetryConfig(
    maxRetries: 3,
    initialDelay: Duration(seconds: 1),
    backoffFactor: 2.0,
    maxDelay: Duration(seconds: 10),
  );

  /// 计算第几次重试的延迟
  Duration delayForAttempt(int attempt) {
    if (attempt <= 0) return Duration.zero;
    final delayMs =
        (initialDelay.inMilliseconds * pow(backoffFactor, attempt - 1))
            .toInt();
    return Duration(
      milliseconds: delayMs.clamp(0, maxDelay.inMilliseconds),
    );
  }

  RetryConfig copyWith({
    int? maxRetries,
    Duration? initialDelay,
    double? backoffFactor,
    Duration? maxDelay,
  }) {
    return RetryConfig(
      maxRetries: maxRetries ?? this.maxRetries,
      initialDelay: initialDelay ?? this.initialDelay,
      backoffFactor: backoffFactor ?? this.backoffFactor,
      maxDelay: maxDelay ?? this.maxDelay,
    );
  }
}

/// 重试结果
class RetryResult<T> {
  final T result;
  final int attemptCount;
  final Duration totalDuration;
  final List<Exception> failures;

  RetryResult({
    required this.result,
    required this.attemptCount,
    required this.totalDuration,
    required this.failures,
  });
}

/// 重试工具类
class RetryHelper {
  /// 带重试的执行
  ///
  /// [action] 要执行的异步操作
  /// [config] 重试配置
  /// [shouldRetry] 判断是否应该重试（默认所有异常都重试）
  /// [onRetry] 每次重试时的回调（attempt 是第几次重试，从 1 开始）
  static Future<T> execute<T>(
    Future<T> Function() action, {
    RetryConfig config = RetryConfig.standard,
    bool Function(Exception e)? shouldRetry,
    void Function(int attempt, Exception e, Duration nextDelay)? onRetry,
  }) async {
    final result = await executeWithResult(
      action,
      config: config,
      shouldRetry: shouldRetry,
      onRetry: onRetry,
    );
    return result.result;
  }

  /// 带重试的执行（返回详细结果，含尝试次数、总耗时、失败列表等）
  ///
  /// 与 [executeWithResult] 功能相同，提供更明确的命名以便调用方获取完整重试信息。
  static Future<RetryResult<T>> executeWithDetails<T>(
    Future<T> Function() action, {
    RetryConfig config = RetryConfig.standard,
    bool Function(Exception e)? shouldRetry,
    void Function(int attempt, Exception e, Duration nextDelay)? onRetry,
  }) async {
    return executeWithResult(
      action,
      config: config,
      shouldRetry: shouldRetry,
      onRetry: onRetry,
    );
  }

  /// 带重试的执行（返回完整结果，含尝试次数等信息）
  static Future<RetryResult<T>> executeWithResult<T>(
    Future<T> Function() action, {
    RetryConfig config = RetryConfig.standard,
    bool Function(Exception e)? shouldRetry,
    void Function(int attempt, Exception e, Duration nextDelay)? onRetry,
  }) async {
    final stopwatch = Stopwatch()..start();
    final failures = <Exception>[];
    int attempt = 0;

    while (true) {
      try {
        final result = await action();
        stopwatch.stop();
        return RetryResult(
          result: result,
          attemptCount: attempt + 1,
          totalDuration: stopwatch.elapsed,
          failures: failures,
        );
      } on Exception catch (e) {
        failures.add(e);
        attempt++;

        // 超过最大重试次数，抛出最后一个异常
        if (attempt > config.maxRetries) {
          stopwatch.stop();
          rethrow;
        }

        // 判断是否应该重试
        if (shouldRetry != null && !shouldRetry(e)) {
          stopwatch.stop();
          // 通知最后一次失败（因条件不满足而不再重试）
          onRetry?.call(attempt, e, Duration.zero);
          rethrow;
        }

        // 计算延迟
        final delay = config.delayForAttempt(attempt);

        // 通知重试回调
        onRetry?.call(attempt, e, delay);

        // 等待后重试
        await Future.delayed(delay);
      }
    }
  }

  /// 判断是否为网络错误（用于 shouldRetry 判断）
  static bool isNetworkError(Exception e) {
    final msg = e.toString().toLowerCase();
    return msg.contains('dio') ||
        msg.contains('timeout') ||
        msg.contains('socket') ||
        msg.contains('network') ||
        msg.contains('连接') ||
        msg.contains('网络') ||
        msg.contains('failed') ||
        msg.contains('unable');
  }

  /// 判断是否为内容错误（不应重试）
  static bool isContentError(Exception e) {
    final msg = e.toString().toLowerCase();
    return msg.contains('删除') ||
        msg.contains('私密') ||
        msg.contains('不存在') ||
        msg.contains('已下架') ||
        msg.contains('不可见') ||
        msg.contains('404') ||
        msg.contains('not found') ||
        msg.contains('contentunavailable');
  }
}
