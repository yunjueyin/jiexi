import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

/// 自定义页面路由工具
///
/// 提供右滑入的平滑过渡动画效果，统一页面跳转体验。
class AppPageRoute {
  /// 右滑入页面路由
  ///
  /// 新页面从右侧滑入，旧页面向左滑出，带有淡出和缩放效果。
  /// 手势返回时，上一页内容实时跟随手势移动，当前页面有淡出和缩放效果。
  /// 动画时长 300ms，使用 Curves.easeOutCubic 缓动曲线。
  static PageRoute<T> slideRight<T>(Widget page) {
    return PageRouteBuilder<T>(
      pageBuilder: (context, animation, secondaryAnimation) => page,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        const curve = Curves.easeOutCubic;

        // 新页面从右侧滑入
        var tween = Tween(begin: const Offset(1.0, 0.0), end: Offset.zero).chain(
          CurveTween(curve: curve),
        );
        var offsetAnimation = animation.drive(tween);

        // 新页面淡入效果
        var fadeTween = Tween(begin: 0.85, end: 1.0).chain(
          CurveTween(curve: Curves.easeOut),
        );

        // 旧页面：向左移动 + 淡出 + 缩放
        final secondaryOffset = Tween<Offset>(
          begin: Offset.zero,
          end: const Offset(-0.3, 0.0),
        ).animate(CurvedAnimation(
          parent: secondaryAnimation,
          curve: Curves.easeIn,
        ));

        final secondaryFade = Tween<double>(
          begin: 1.0,
          end: 0.4,
        ).animate(CurvedAnimation(
          parent: secondaryAnimation,
          curve: Curves.easeIn,
        ));

        final secondaryScale = Tween<double>(
          begin: 1.0,
          end: 0.92,
        ).animate(CurvedAnimation(
          parent: secondaryAnimation,
          curve: Curves.easeIn,
        ));

        return Stack(
          children: [
            // 旧页面：左移 + 淡出 + 缩放
            SlideTransition(
              position: secondaryOffset,
              child: FadeTransition(
                opacity: secondaryFade,
                child: ScaleTransition(
                  scale: secondaryScale,
                  // 旧页面内容由系统提供，这里用 Container 占位
                  // 实际使用中 secondaryAnimation 驱动的是上一页
                  child: Container(
                    color: Theme.of(context).scaffoldBackgroundColor,
                  ),
                ),
              ),
            ),
            // 新页面：右滑入 + 淡入
            SlideTransition(
              position: offsetAnimation,
              child: FadeTransition(
                opacity: animation.drive(fadeTween),
                child: child,
              ),
            ),
          ],
        );
      },
      transitionDuration: const Duration(milliseconds: 300),
      reverseTransitionDuration: const Duration(milliseconds: 300),
      fullscreenDialog: false,
    );
  }

  /// 支持右滑返回的 Cupertino 风格路由（推荐）
  ///
  /// 使用 CupertinoPageRoute 的手势返回效果，
  /// 上一页内容实时跟随手势移动，带有缩放和淡出效果。
  static PageRoute<T> cupertinoSlide<T>(Widget page) {
    return CupertinoPageRoute<T>(
      builder: (context) => page,
    );
  }

  /// 从底部弹出的页面路由
  static PageRoute<T> slideUp<T>(Widget page) {
    return PageRouteBuilder<T>(
      pageBuilder: (context, animation, secondaryAnimation) => page,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        const begin = Offset(0.0, 1.0);
        const end = Offset.zero;
        const curve = Curves.easeOutCubic;

        var tween = Tween(begin: begin, end: end).chain(
          CurveTween(curve: curve),
        );

        var offsetAnimation = animation.drive(tween);

        return SlideTransition(
          position: offsetAnimation,
          child: child,
        );
      },
      transitionDuration: const Duration(milliseconds: 300),
      reverseTransitionDuration: const Duration(milliseconds: 250),
      fullscreenDialog: true,
    );
  }

  /// 渐变淡入页面路由
  static PageRoute<T> fadeIn<T>(Widget page) {
    return PageRouteBuilder<T>(
      pageBuilder: (context, animation, secondaryAnimation) => page,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        return FadeTransition(
          opacity: animation.drive(
            Tween(begin: 0.0, end: 1.0).chain(
              CurveTween(curve: Curves.easeOut),
            ),
          ),
          child: child,
        );
      },
      transitionDuration: const Duration(milliseconds: 250),
      reverseTransitionDuration: const Duration(milliseconds: 200),
    );
  }
}
