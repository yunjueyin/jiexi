import 'dart:core';

import 'package:flutter/material.dart';

/// 视频平台枚举
enum VideoPlatform {
  /// 抖音
  douyin,

  /// 快手
  kuaishou,

  /// 小红书
  xiaohongshu,

  /// 未知平台
  unknown,
}

/// 链接类型
enum LinkType {
  /// 视频/作品链接
  video,

  /// 作者主页链接
  author,

  /// 未知类型
  unknown,
}

/// 平台支持的功能集
///
/// 用于声明每个平台当前支持哪些能力，
/// 方便 UI 层根据平台特性展示不同的操作按钮。
class PlatformCapabilities {
  /// 是否支持解析单个视频
  final bool canParseVideo;

  /// 是否支持解析作者主页
  final bool canParseAuthor;

  /// 是否支持抓取（批量下载）
  final bool canCrawl;

  /// 是否支持格式转换
  final bool canConvert;

  /// 是否支持去水印
  final bool canRemoveWatermark;

  const PlatformCapabilities({
    this.canParseVideo = false,
    this.canParseAuthor = false,
    this.canCrawl = false,
    this.canConvert = false,
    this.canRemoveWatermark = false,
  });
}

/// 平台元数据扩展
extension VideoPlatformX on VideoPlatform {
  /// 平台 ID（字符串标识）
  String get id {
    switch (this) {
      case VideoPlatform.douyin:
        return 'douyin';
      case VideoPlatform.kuaishou:
        return 'kuaishou';
      case VideoPlatform.xiaohongshu:
        return 'xiaohongshu';
      case VideoPlatform.unknown:
        return 'unknown';
    }
  }

  /// 中文名称
  String get name {
    switch (this) {
      case VideoPlatform.douyin:
        return '抖音';
      case VideoPlatform.kuaishou:
        return '快手';
      case VideoPlatform.xiaohongshu:
        return '小红书';
      case VideoPlatform.unknown:
        return '未知';
    }
  }

  /// 图标（emoji）
  String get icon {
    switch (this) {
      case VideoPlatform.douyin:
        return '🎵';
      case VideoPlatform.kuaishou:
        return '⚡';
      case VideoPlatform.xiaohongshu:
        return '📕';
      case VideoPlatform.unknown:
        return '📹';
    }
  }

  /// 主题色（品牌色）
  Color get themeColor {
    switch (this) {
      case VideoPlatform.douyin:
        return const Color(0xFFFE2C55);
      case VideoPlatform.kuaishou:
        return const Color(0xFFFF6600);
      case VideoPlatform.xiaohongshu:
        return const Color(0xFFFF2442);
      case VideoPlatform.unknown:
        return Colors.grey;
    }
  }

  /// 平台支持的功能集
  PlatformCapabilities get capabilities {
    switch (this) {
      case VideoPlatform.douyin:
        return const PlatformCapabilities(
          canParseVideo: true,
          canParseAuthor: true,
          canCrawl: true,
          canConvert: true,
          canRemoveWatermark: true,
        );
      case VideoPlatform.kuaishou:
        return const PlatformCapabilities(
          canParseVideo: true,
          canParseAuthor: true,
          canCrawl: true,
          canConvert: true,
          canRemoveWatermark: true,
        );
      case VideoPlatform.xiaohongshu:
        return const PlatformCapabilities(
          canParseVideo: true,
          canParseAuthor: true,
          canCrawl: true,
          canConvert: false,
          canRemoveWatermark: true,
        );
      case VideoPlatform.unknown:
        return const PlatformCapabilities();
    }
  }

  /// 从字符串 ID 解析
  static VideoPlatform fromId(String? id) {
    switch (id) {
      case 'douyin':
        return VideoPlatform.douyin;
      case 'kuaishou':
        return VideoPlatform.kuaishou;
      case 'xiaohongshu':
      case 'xhs':
        return VideoPlatform.xiaohongshu;
      default:
        return VideoPlatform.unknown;
    }
  }
}

/// 统一的平台检测工具类
///
/// 所有平台识别、URL 提取、短链判断、链接类型判断都集中在这里，
/// 供解析服务、抓取服务、转换服务及各页面统一调用。
///
/// ## 测试用例
///
/// ### URL 提取（extractUrl / extractAllUrls / normalizeUrl）
/// - `"复制这条链接 https://v.douyin.com/abc123/ 在抖音打开"` → `https://v.douyin.com/abc123/`
/// - `"https://www.kuaishou.com/short-video/xxx，快来看看"` → `https://www.kuaishou.com/short-video/xxx`
/// - `"分享小红书链接：https://www.xiaohongshu.com/explore/xxxxxxxxxxxxxxxxxxxxxxxx。"` → `https://www.xiaohongshu.com/explore/xxxxxxxxxxxxxxxxxxxxxxxx`
/// - `"链接后面跟emoji https://v.douyin.com/abc/🎉"` → `https://v.douyin.com/abc/`
/// - `"多个URL https://a.com 和 https://b.com"` → 提取两个
/// - `"纯中文无链接"` → `null`
/// - 空字符串 → `null`
///
/// ### 平台检测（detectPlatform）
/// - `https://www.douyin.com/video/123` → douyin
/// - `https://v.douyin.com/abc` → douyin
/// - `https://www.iesdouyin.com/share/video/xxx` → douyin
/// - `https://aweme.snssdk.com/aweme/v1/...` → douyin
/// - `https://www.kuaishou.com/short-video/xxx` → kuaishou
/// - `https://v.kuaishou.com/abc` → kuaishou
/// - `https://gifshow.com/s/xxx` → kuaishou
/// - `https://www.xiaohongshu.com/explore/xxx` → xiaohongshu
/// - `https://xhslink.com/abc` → xiaohongshu
/// - `https://www.baidu.com` → unknown
///
/// ### 短链判断（isShortLink）
/// - `https://v.douyin.com/abc/` → true
/// - `https://v.douyin.cn/abc` → true
/// - `https://www.douyin.com/video/123` → false
/// - `https://v.kuaishou.com/abc` → true
/// - `https://xhslink.com/abc` → true
/// - `https://xhs.cn/abc` → true
///
/// ### 链接类型检测（detectLinkType）
/// - 抖音 `/video/1234567890123456789` → video
/// - 抖音 `/note/1234567890123456789` → video
/// - 抖音 `/user/MS4wLjAB...` → author
/// - 抖音 `/share/user/xxx` → author
/// - 抖音 `?sec_uid=xxx` → author
/// - 抖音短链 `v.douyin.com/abc` → unknown
/// - 快手 `/short-video/xxx` → video
/// - 快手 `/photo/xxx` → video
/// - 快手 `/profile/xxx` → author
/// - 快手 `/u/xxx` → author
/// - 快手短链 `v.kuaishou.com/abc` → unknown
/// - 小红书 `/explore/24位ID` → video
/// - 小红书 `/user/profile/xxx` → author
/// - 小红书短链 `xhslink.com/abc` → unknown
class PlatformDetector {
  // ======================================================
  // 各平台域名配置
  // ======================================================

  /// 抖音主域名（用于 endsWith 匹配，自动覆盖 www 等子域名）
  static const List<String> _douyinBaseDomains = [
    'douyin.com',
    'douyin.cn',
    'iesdouyin.com',
    'snssdk.com', // aweme.snssdk.com
  ];

  /// 快手主域名（用于 endsWith 匹配）
  static const List<String> _kuaishouBaseDomains = [
    'kuaishou.com',
    'kuaishou.cn',
    'chenzhongtech.com',
    'gifshow.com',
  ];

  /// 小红书主域名（用于 endsWith 匹配）
  static const List<String> _xiaohongshuBaseDomains = [
    'xiaohongshu.com',
    'xhslink.com',
    'xhslink.cn',
    'hongshu.com',
    'xhs.cn',
  ];

  /// 抖音短链域名（完整 host 匹配）
  static const List<String> _douyinShortDomains = [
    'v.douyin.com',
    'v.douyin.cn',
  ];

  /// 快手短链域名（完整 host 匹配）
  static const List<String> _kuaishouShortDomains = [
    'v.kuaishou.com',
    'v.kuaishou.cn',
  ];

  /// 小红书短链域名（完整 host 匹配）
  static const List<String> _xiaohongshuShortDomains = [
    'xhslink.com',
    'xhslink.cn',
    'xhs.cn',
  ];

  // ======================================================
  // 各平台视频/作品路径特征
  // ======================================================

  /// 抖音视频/图文路径特征（用于判断视频链接）
  static const List<String> _douyinVideoPaths = [
    '/video/',
    '/note/',
    '/slides/',
    '/share/video/',
    '/share/note/',
  ];

  /// 抖音视频 ID 参数特征
  static const List<String> _douyinVideoParams = [
    'item_id=',
    'aweme_id=',
    'modal_id=',
  ];

  /// 抖音作者主页路径特征
  static const List<String> _douyinAuthorPaths = [
    '/user/',
    '/share/user/',
    '/m/user/',
    '/user/profile',
  ];

  /// 抖音作者 ID 参数特征
  static const List<String> _douyinAuthorParams = [
    'sec_uid=',
  ];

  /// 快手视频路径特征
  static const List<String> _kuaishouVideoPaths = [
    '/short-video/',
    '/fw/photo/',
    '/photo/',
    '/long-video/',
  ];

  /// 快手视频 ID 参数特征
  static const List<String> _kuaishouVideoParams = [
    'photoId=',
    'objectId=',
  ];

  /// 快手作者主页路径特征
  static const List<String> _kuaishouAuthorPaths = [
    '/profile/',
    '/user/',
    '/u/',
    '/fw/user/',
    '/share/user/',
  ];

  /// 快手作者 ID 参数特征
  static const List<String> _kuaishouAuthorParams = [
    'userId=',
    'principalId=',
  ];

  /// 小红书笔记路径特征
  static const List<String> _xiaohongshuVideoPaths = [
    '/explore/',
    '/discovery/item/',
    '/discovery/explore/',
    '/note/',
  ];

  /// 小红书笔记 ID 参数特征
  static const List<String> _xiaohongshuVideoParams = [
    'note_id=',
  ];

  /// 小红书作者主页路径特征
  static const List<String> _xiaohongshuAuthorPaths = [
    '/user/profile/',
    '/profile/',
    '/user/',
  ];

  /// 小红书作者 ID 参数特征
  static const List<String> _xiaohongshuAuthorParams = [
    'user_id=',
    'uid=',
  ];

  // ======================================================
  // URL 合法字符正则
  // ======================================================

  /// URL 中允许出现的合法 ASCII 字符
  ///
  /// 包含：
  /// - 字母数字（a-z, A-Z, 0-9）
  /// - 通用分隔符：:/?#[]@
  /// - 子分隔符：!$&'()*+,;=
  /// - 其他：.-_%~
  ///
  /// 注意：不包含空格、中文、emoji、中文标点等非 ASCII 字符。
  /// 当 URL 后面跟着这些字符时会自动截断。
  static final RegExp _urlCharRegex = RegExp(
    r'''https?://[a-zA-Z0-9:/?#\[\]@!$&'()*+,;=._%~-]+''',
    caseSensitive: false,
  );

  // ======================================================
  // URL 提取与清理
  // ======================================================

  /// 从文本中提取第一个 URL
  ///
  /// 支持粘贴的带文字内容（如"复制这条链接 xxx https://... 在抖音打开"）。
  ///
  /// 改进说明：
  /// - URL 只匹配合法的 ASCII 可打印字符
  /// - 遇到中文、emoji、中文标点等非 ASCII 字符时自动截断
  /// - 自动去除 URL 末尾多余的标点符号
  ///
  /// 示例：
  /// ```
  /// extractUrl('复制打开抖音 https://v.douyin.com/abc/ 看看吧')
  /// // => 'https://v.douyin.com/abc/'
  ///
  /// extractUrl('https://www.kuaishou.com/xxx，快来看看')
  /// // => 'https://www.kuaishou.com/xxx'
  /// ```
  static String? extractUrl(String text) {
    if (text.isEmpty) return null;
    final match = _urlCharRegex.firstMatch(text);
    if (match == null) return null;
    return _cleanUrlTail(match.group(0)!);
  }

  /// 从文本中提取所有 URL
  ///
  /// 返回所有匹配到的合法 URL 列表。
  static List<String> extractAllUrls(String text) {
    if (text.isEmpty) return [];
    return _urlCharRegex
        .allMatches(text)
        .map((m) => _cleanUrlTail(m.group(0)!))
        .toList();
  }

  /// 从分享文案中提取并规范化 URL
  ///
  /// 这是一个便捷方法，等价于先 extractUrl 再做基础规范化。
  /// 如果文本中没有 URL，返回 null。
  ///
  /// 规范化内容：
  /// 1. 从分享文案中提取 URL（自动截断中文/emoji）
  /// 2. 去除首尾空白
  /// 3. 去除 URL 末尾多余的标点（，。！？、等）
  /// 4. 确保 URL 以 http 开头
  static String? normalizeUrl(String text) {
    final url = extractUrl(text.trim());
    if (url == null) return null;
    // 确保是小写的 http/https 开头（host 部分不强制小写，由 Uri.parse 处理）
    return url;
  }

  /// 清理 URL 末尾可能跟着的多余字符
  ///
  /// URL 正则匹配后，末尾可能还包含一些虽然是 ASCII 但不应属于 URL 的字符，
  /// 比如末尾的句号、逗号、右括号等。此方法进行二次清理。
  static String _cleanUrlTail(String url) {
    // 去除末尾常见的不属于 URL 的标点
    final trailingToRemove = RegExp(r'[.,;:!?)）】」』，。！？；：、）】」』]+$');
    return url.replaceAll(trailingToRemove, '');
  }

  // ======================================================
  // 辅助：从 URL 中提取 host
  // ======================================================

  /// 从 URL 字符串中安全提取 host（小写）
  ///
  /// 如果 URL 格式不正确或无法解析，返回 null。
  static String? _extractHost(String url) {
    try {
      final uri = Uri.parse(url.trim());
      final host = uri.host;
      if (host.isEmpty) return null;
      return host.toLowerCase();
    } catch (_) {
      // Uri.parse 可能在非法 URL 时抛出异常
      return null;
    }
  }

  /// 判断 host 是否匹配任一基础域名（使用 endsWith）
  ///
  /// 例如 host = 'www.douyin.com' 匹配 baseDomain = 'douyin.com'。
  /// 为了避免误匹配（如 'fakedouyin.com' 匹配到 'douyin.com'），
  /// 要求 host 等于 baseDomain，或以 '.' + baseDomain 结尾。
  static bool _hostMatchesBase(String host, String baseDomain) {
    if (host == baseDomain) return true;
    if (host.endsWith('.$baseDomain')) return true;
    return false;
  }

  /// 判断 host 是否在域名列表中（完整匹配）
  static bool _hostInList(String host, List<String> domains) {
    return domains.any((d) => d.toLowerCase() == host);
  }

  /// 判断 host 是否匹配任一基础域名
  static bool _hostMatchesAnyBase(String host, List<String> baseDomains) {
    return baseDomains.any((d) => _hostMatchesBase(host, d));
  }

  // ======================================================
  // 平台检测
  // ======================================================

  /// 检测链接所属平台
  ///
  /// 改进说明：
  /// - 使用 [Uri.parse] 提取 host，而不是简单的 contains
  /// - 使用 endsWith 匹配基础域名，自动覆盖 www 等子域名前缀
  /// - 减少误判风险（如包含域名关键词的其他网站）
  static VideoPlatform detectPlatform(String url) {
    final cleanUrl = url.trim();
    if (cleanUrl.isEmpty) return VideoPlatform.unknown;

    final host = _extractHost(cleanUrl);
    if (host == null) return VideoPlatform.unknown;

    // 抖音
    if (_hostMatchesAnyBase(host, _douyinBaseDomains)) {
      // 额外验证：snssdk.com 下只有 aweme 子域名属于抖音
      if (host.endsWith('.snssdk.com') || host == 'snssdk.com') {
        if (host == 'aweme.snssdk.com' || host.endsWith('.aweme.snssdk.com')) {
          return VideoPlatform.douyin;
        }
        // 其他 snssdk 子域名不确定，不返回抖音
      } else {
        return VideoPlatform.douyin;
      }
    }

    // 快手
    if (_hostMatchesAnyBase(host, _kuaishouBaseDomains)) {
      return VideoPlatform.kuaishou;
    }

    // 小红书
    if (_hostMatchesAnyBase(host, _xiaohongshuBaseDomains)) {
      return VideoPlatform.xiaohongshu;
    }

    return VideoPlatform.unknown;
  }

  /// 检测平台（返回字符串 ID，兼容旧接口）
  static String detectPlatformId(String url) {
    return detectPlatform(url).id;
  }

  /// 判断给定平台是否为受支持的平台
  static bool isSupportedPlatform(VideoPlatform platform) {
    return platform != VideoPlatform.unknown;
  }

  /// 判断给定 URL 是否属于受支持的平台
  static bool isSupportedUrl(String url) {
    return isSupportedPlatform(detectPlatform(url));
  }

  // ======================================================
  // 短链判断
  // ======================================================

  /// 判断是否为短链接
  static bool isShortLink(String url) {
    final platform = detectPlatform(url);
    return isShortLinkForPlatform(url, platform);
  }

  /// 判断指定平台的链接是否为短链
  ///
  /// 改进说明：使用 host 精确匹配短链域名，而不是 contains。
  static bool isShortLinkForPlatform(String url, VideoPlatform platform) {
    final host = _extractHost(url);
    if (host == null) return false;

    switch (platform) {
      case VideoPlatform.douyin:
        return _hostInList(host, _douyinShortDomains);
      case VideoPlatform.kuaishou:
        return _hostInList(host, _kuaishouShortDomains);
      case VideoPlatform.xiaohongshu:
        return _hostInList(host, _xiaohongshuShortDomains);
      case VideoPlatform.unknown:
        return false;
    }
  }

  // ======================================================
  // 链接类型检测（视频 / 作者主页）
  // ======================================================

  /// 检测链接类型：视频 / 作者主页 / 未知
  static LinkType detectLinkType(String url) {
    final platform = detectPlatform(url);
    return detectLinkTypeForPlatform(url, platform);
  }

  /// 检测指定平台的链接类型
  ///
  /// 改进说明：
  /// 1. 先判断是否为短链，短链无法通过路径判断类型时返回 [LinkType.unknown]
  /// 2. 增加视频路径特征的正向判断（而不是"非作者即视频"）
  /// 3. 同时支持路径匹配和查询参数匹配
  /// 4. 只有明确匹配到视频或作者特征时才返回对应类型
  static LinkType detectLinkTypeForPlatform(String url, VideoPlatform platform) {
    if (platform == VideoPlatform.unknown) return LinkType.unknown;

    final lowerUrl = url.toLowerCase();
    final uriPath = _extractPathAndQuery(lowerUrl);

    // 如果是短链且路径信息不足以判断类型，返回 unknown
    final isShort = isShortLinkForPlatform(url, platform);
    if (isShort) {
      // 短链通常路径很短（如 /abc），无法判断类型
      return LinkType.unknown;
    }

    switch (platform) {
      case VideoPlatform.douyin:
        return _detectDouyinLinkType(uriPath);
      case VideoPlatform.kuaishou:
        return _detectKuaishouLinkType(uriPath);
      case VideoPlatform.xiaohongshu:
        return _detectXiaohongshuLinkType(uriPath);
      case VideoPlatform.unknown:
        return LinkType.unknown;
    }
  }

  /// 提取 URL 的 path + query 部分（小写），用于路径匹配
  static String _extractPathAndQuery(String url) {
    try {
      final uri = Uri.parse(url.trim());
      final path = uri.path;
      final query = uri.query;
      if (query.isEmpty) return path.toLowerCase();
      return '${path.toLowerCase()}?${query.toLowerCase()}';
    } catch (_) {
      // 解析失败时回退到直接使用 url 本身做匹配
      return url.toLowerCase();
    }
  }

  /// 判断路径或查询参数中是否包含列表中的任一特征
  static bool _containsAny(String pathAndQuery, List<String> features) {
    return features.any((f) => pathAndQuery.contains(f));
  }

  /// 抖音链接类型检测
  static LinkType _detectDouyinLinkType(String pathAndQuery) {
    // 作者特征（参数优先判断，因为 sec_uid 可能出现在各种路径下）
    if (_containsAny(pathAndQuery, _douyinAuthorParams)) {
      return LinkType.author;
    }
    // 作者路径
    if (_containsAny(pathAndQuery, _douyinAuthorPaths)) {
      return LinkType.author;
    }

    // 视频/图文路径
    if (_containsAny(pathAndQuery, _douyinVideoPaths)) {
      return LinkType.video;
    }
    // 视频参数
    if (_containsAny(pathAndQuery, _douyinVideoParams)) {
      return LinkType.video;
    }

    // 都匹配不到，返回未知
    return LinkType.unknown;
  }

  /// 快手链接类型检测
  static LinkType _detectKuaishouLinkType(String pathAndQuery) {
    // 作者参数
    if (_containsAny(pathAndQuery, _kuaishouAuthorParams)) {
      return LinkType.author;
    }
    // 作者路径
    if (_containsAny(pathAndQuery, _kuaishouAuthorPaths)) {
      return LinkType.author;
    }

    // 视频路径
    if (_containsAny(pathAndQuery, _kuaishouVideoPaths)) {
      return LinkType.video;
    }
    // 视频参数
    if (_containsAny(pathAndQuery, _kuaishouVideoParams)) {
      return LinkType.video;
    }

    return LinkType.unknown;
  }

  /// 小红书链接类型检测
  static LinkType _detectXiaohongshuLinkType(String pathAndQuery) {
    // 作者参数
    if (_containsAny(pathAndQuery, _xiaohongshuAuthorParams)) {
      return LinkType.author;
    }
    // 作者路径
    if (_containsAny(pathAndQuery, _xiaohongshuAuthorPaths)) {
      return LinkType.author;
    }

    // 笔记路径
    if (_containsAny(pathAndQuery, _xiaohongshuVideoPaths)) {
      return LinkType.video;
    }
    // 笔记参数
    if (_containsAny(pathAndQuery, _xiaohongshuVideoParams)) {
      return LinkType.video;
    }

    return LinkType.unknown;
  }

  // ======================================================
  // 综合检测
  // ======================================================

  /// 一次性检测平台和链接类型
  static PlatformDetectionResult detect(String url) {
    final cleanUrl = url.trim();
    if (cleanUrl.isEmpty) {
      return PlatformDetectionResult(
        platform: VideoPlatform.unknown,
        linkType: LinkType.unknown,
        isShortLink: false,
      );
    }
    final platform = detectPlatform(cleanUrl);
    final linkType = detectLinkTypeForPlatform(cleanUrl, platform);
    final shortLink = isShortLinkForPlatform(cleanUrl, platform);
    return PlatformDetectionResult(
      platform: platform,
      linkType: linkType,
      isShortLink: shortLink,
    );
  }

  /// 获取支持的平台列表
  static List<VideoPlatform> get supportedPlatforms => [
        VideoPlatform.douyin,
        VideoPlatform.kuaishou,
        VideoPlatform.xiaohongshu,
      ];
}

/// 平台检测结果
class PlatformDetectionResult {
  /// 所属平台
  final VideoPlatform platform;

  /// 链接类型（视频/作者/未知）
  final LinkType linkType;

  /// 是否为短链
  final bool isShortLink;

  /// 是否识别成功
  bool get isRecognized => platform != VideoPlatform.unknown;

  /// 是否为作者主页
  bool get isAuthor => linkType == LinkType.author;

  /// 是否为视频/作品链接
  bool get isVideo => linkType == LinkType.video;

  /// 是否类型未知
  bool get isTypeUnknown => linkType == LinkType.unknown;

  /// 平台支持的功能集
  PlatformCapabilities get capabilities => platform.capabilities;

  const PlatformDetectionResult({
    required this.platform,
    required this.linkType,
    required this.isShortLink,
  });

  @override
  String toString() =>
      'PlatformDetectionResult(platform: ${platform.name}, linkType: $linkType, isShortLink: $isShortLink)';
}
