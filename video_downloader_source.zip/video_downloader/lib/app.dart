import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'theme/app_theme.dart';
import 'theme/app_colors.dart';
import 'providers/settings_provider.dart';
import 'providers/privacy_lock_provider.dart';
import 'services/haptic_service.dart';
import 'services/advanced_haptic_service.dart';
import 'services/force_touch_service.dart';
import 'services/theme_manager.dart';
import 'services/proxy_service.dart';
import 'services/quick_actions_service.dart';
import 'pages/home/home_page.dart';
import 'pages/splash/splash_page.dart';
import 'pages/lock/lock_page.dart';

/// 全局 Navigator Key
///
/// 供无 BuildContext 的服务（如 WebView 隐藏抓取器）访问 Overlay，
/// 以挂载不可见的 WebView 悬浮层。
final GlobalKey<NavigatorState> appNavigatorKey = GlobalKey<NavigatorState>();

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> with WidgetsBindingObserver {
  // 缓存字段，用于检测设置变化，避免 build 中执行副作用
  String? _lastThemeMode;
  String? _lastThemeColor;
  String? _lastSunset;
  String? _lastSunrise;
  bool? _lastHapticEnabled;
  String? _lastHapticLevel;
  bool? _lastForceTouch;
  bool? _lastProxyEnabled;
  String? _lastProxyType;
  String? _lastProxyHost;
  int? _lastProxyPort;
  String? _lastProxyUsername;
  String? _lastProxyPassword;
  List<String>? _lastProxyBypassDomains;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    // 延迟初始化快捷方式监听（等待 Provider 可用）
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _setupQuickActions();
    });
  }

  /// 设置桌面快捷方式监听
  void _setupQuickActions() {
    try {
      final quickActionsService = context.read<QuickActionsService>();
      // 监听快捷方式事件流
      quickActionsService.onActionStream.listen((action) {
        _handleShortcutAction(action);
      });
    } catch (e) {
      debugPrint('Setup quick actions failed: $e');
    }
  }

  /// 处理快捷方式点击
  void _handleShortcutAction(ShortcutAction action) {
    final navigatorState = appNavigatorKey.currentState;
    if (navigatorState == null) return;

    switch (action) {
      case ShortcutAction.parse:
        // 一键解析：跳转到首页（首页默认就是解析页面）
        navigatorState.popUntil((route) => route.isFirst);
        break;
      case ShortcutAction.crawl:
        // 批量抓取：跳转到抓取页
        navigatorState.popUntil((route) => route.isFirst);
        break;
      case ShortcutAction.downloads:
        // 下载管理：跳转到下载页
        navigatorState.popUntil((route) => route.isFirst);
        break;
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    ThemeManager.stopScheduledCheck();
    super.dispose();
  }

  @override
  void didChangePlatformBrightness() {
    super.didChangePlatformBrightness();
    // 系统主题变化时，如果设置为跟随系统，触发重建
    final settings = context.read<SettingsProvider>();
    if (settings.themeMode == 'system') {
      setState(() {});
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    final privacyLock = context.read<PrivacyLockProvider>();

    switch (state) {
      case AppLifecycleState.paused:
      case AppLifecycleState.inactive:
        privacyLock.onAppBackground();
        break;
      case AppLifecycleState.resumed:
        privacyLock.onAppForeground();
        break;
      default:
        break;
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // 使用 watch 建立依赖，设置变化时触发
    final settings = context.watch<SettingsProvider>();
    final proxyService = context.watch<ProxyService>();

    // 震动反馈配置变化检测
    if (_lastHapticEnabled != settings.hapticFeedbackEnabled ||
        _lastHapticLevel != settings.hapticFeedbackLevel) {
      HapticService.setSettings(
        enabled: settings.hapticFeedbackEnabled,
        level: settings.hapticFeedbackLevel,
      );
      // 同步高级震动服务开关
      AdvancedHapticService.setEnabled(settings.hapticFeedbackEnabled);
      _lastHapticEnabled = settings.hapticFeedbackEnabled;
      _lastHapticLevel = settings.hapticFeedbackLevel;
    }

    // 重压快捷菜单配置变化检测
    if (_lastForceTouch != settings.forceTouchEnabled) {
      ForceTouchService.setEnabled(settings.forceTouchEnabled);
      _lastForceTouch = settings.forceTouchEnabled;
    }

    // 代理配置变化检测
    if (_lastProxyEnabled != settings.proxyEnabled ||
        _lastProxyType != settings.proxyType ||
        _lastProxyHost != settings.proxyHost ||
        _lastProxyPort != settings.proxyPort ||
        _lastProxyUsername != settings.proxyUsername ||
        _lastProxyPassword != settings.proxyPassword ||
        _lastProxyBypassDomains != settings.proxyBypassDomains) {
      proxyService.updateConfig(
        enabled: settings.proxyEnabled,
        type: settings.proxyType,
        host: settings.proxyHost,
        port: settings.proxyPort,
        username: settings.proxyUsername,
        password: settings.proxyPassword,
        bypassDomains: settings.proxyBypassDomains,
      );
      _lastProxyEnabled = settings.proxyEnabled;
      _lastProxyType = settings.proxyType;
      _lastProxyHost = settings.proxyHost;
      _lastProxyPort = settings.proxyPort;
      _lastProxyUsername = settings.proxyUsername;
      _lastProxyPassword = settings.proxyPassword;
      _lastProxyBypassDomains = settings.proxyBypassDomains;
    }

    // 定时主题配置变化检测
    if (_lastThemeMode != settings.themeMode ||
        _lastSunset != settings.themeSunsetTime ||
        _lastSunrise != settings.themeSunriseTime) {
      _updateScheduledTheme(settings);
      _lastThemeMode = settings.themeMode;
      _lastSunset = settings.themeSunsetTime;
      _lastSunrise = settings.themeSunriseTime;
    }
  }

  void _updateScheduledTheme(SettingsProvider settings) {
    ThemeManager.startScheduledCheck(
      themeMode: settings.themeMode,
      sunsetTime: settings.themeSunsetTime,
      sunriseTime: settings.themeSunriseTime,
      onThemeChanged: (_) {
        if (mounted) setState(() {});
      },
    );
  }

  /// 计算当前是否使用深色模式
  bool _computeDarkMode(SettingsProvider settings) {
    return ThemeManager.computeDarkMode(
      themeMode: settings.themeMode,
      sunsetTime: settings.themeSunsetTime,
      sunriseTime: settings.themeSunriseTime,
    );
  }

  /// 判断是否使用 OLED 纯黑主题
  bool _useOledTheme(SettingsProvider settings) {
    return settings.themeMode == 'oled';
  }

  @override
  Widget build(BuildContext context) {
    return Consumer3<SettingsProvider, PrivacyLockProvider, ProxyService>(
      builder: (context, settings, privacyLock, proxyService, child) {
        // 计算当前是否深色模式
        final isDarkMode = _computeDarkMode(settings);
        ThemeManager.updateDarkMode(isDarkMode);

        // 当前主题色
        final themeColorData = AppThemeColorX.fromKey(settings.themeColor).data;

        // UI 密度级别
        final density = DensityLevelX.fromString(settings.uiDensity);
        double textScale = density.textScale;
        double iconScale = density.iconScale;

        // 大字体模式：额外放大 15%
        if (settings.largeFontMode) {
          textScale *= 1.15;
          iconScale *= 1.1;
        }

        // 大字体模式下的按钮最小尺寸（无障碍标准 48dp）
        final ButtonStyle? buttonStyle = settings.largeFontMode
            ? ButtonStyle(
                minimumSize: WidgetStateProperty.all(const Size(64, 48)),
              )
            : null;

        // 辅助函数：为主题应用按钮最小尺寸
        ThemeData applyButtonStyle(ThemeData theme) {
          if (buttonStyle == null) return theme;
          return theme.copyWith(
            elevatedButtonTheme: ElevatedButtonThemeData(
              style: theme.elevatedButtonTheme.style?.merge(buttonStyle) ?? buttonStyle,
            ),
            textButtonTheme: TextButtonThemeData(
              style: theme.textButtonTheme.style?.merge(buttonStyle) ?? buttonStyle,
            ),
            outlinedButtonTheme: OutlinedButtonThemeData(
              style: theme.outlinedButtonTheme.style?.merge(buttonStyle) ?? buttonStyle,
            ),
          );
        }

        // 浅色主题（应用图标缩放 + 动态主题色）
        ThemeData lightTheme = AppTheme.lightThemeOf(themeColorData).copyWith(
          iconTheme: AppTheme.lightThemeOf(themeColorData).iconTheme.copyWith(
            size: (AppTheme.lightThemeOf(themeColorData).iconTheme.size ?? 24) * iconScale,
          ),
          appBarTheme: AppTheme.lightThemeOf(themeColorData).appBarTheme.copyWith(
            iconTheme: (AppTheme.lightThemeOf(themeColorData).appBarTheme.iconTheme ?? const IconThemeData()).copyWith(
              size: ((AppTheme.lightThemeOf(themeColorData).appBarTheme.iconTheme?.size) ?? 24) * iconScale,
            ),
            actionsIconTheme: (AppTheme.lightThemeOf(themeColorData).appBarTheme.actionsIconTheme ?? const IconThemeData()).copyWith(
              size: ((AppTheme.lightThemeOf(themeColorData).appBarTheme.actionsIconTheme?.size) ?? 22) * iconScale,
            ),
          ),
          // iOS 风格页面过渡，支持右滑返回
          pageTransitionsTheme: const PageTransitionsTheme(
            builders: {
              TargetPlatform.android: CupertinoPageTransitionsBuilder(),
              TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
              TargetPlatform.macOS: CupertinoPageTransitionsBuilder(),
            },
          ),
        );
        lightTheme = applyButtonStyle(lightTheme);

        // 深色主题（应用图标缩放 + 动态主题色）
        ThemeData darkTheme = AppTheme.darkThemeOf(themeColorData).copyWith(
          iconTheme: AppTheme.darkThemeOf(themeColorData).iconTheme.copyWith(
            size: (AppTheme.darkThemeOf(themeColorData).iconTheme.size ?? 24) * iconScale,
          ),
          appBarTheme: AppTheme.darkThemeOf(themeColorData).appBarTheme.copyWith(
            iconTheme: (AppTheme.darkThemeOf(themeColorData).appBarTheme.iconTheme ?? const IconThemeData()).copyWith(
              size: ((AppTheme.darkThemeOf(themeColorData).appBarTheme.iconTheme?.size) ?? 24) * iconScale,
            ),
            actionsIconTheme: (AppTheme.darkThemeOf(themeColorData).appBarTheme.actionsIconTheme ?? const IconThemeData()).copyWith(
              size: ((AppTheme.darkThemeOf(themeColorData).appBarTheme.actionsIconTheme?.size) ?? 22) * iconScale,
            ),
          ),
          // iOS 风格页面过渡，支持右滑返回
          pageTransitionsTheme: const PageTransitionsTheme(
            builders: {
              TargetPlatform.android: CupertinoPageTransitionsBuilder(),
              TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
              TargetPlatform.macOS: CupertinoPageTransitionsBuilder(),
            },
          ),
        );
        darkTheme = applyButtonStyle(darkTheme);

        // OLED 纯黑主题（应用图标缩放 + 动态主题色）
        ThemeData oledTheme = AppTheme.oledDarkThemeOf(themeColorData).copyWith(
          iconTheme: AppTheme.oledDarkThemeOf(themeColorData).iconTheme.copyWith(
            size: (AppTheme.oledDarkThemeOf(themeColorData).iconTheme.size ?? 24) * iconScale,
          ),
          appBarTheme: AppTheme.oledDarkThemeOf(themeColorData).appBarTheme.copyWith(
            iconTheme: (AppTheme.oledDarkThemeOf(themeColorData).appBarTheme.iconTheme ?? const IconThemeData()).copyWith(
              size: ((AppTheme.oledDarkThemeOf(themeColorData).appBarTheme.iconTheme?.size) ?? 24) * iconScale,
            ),
            actionsIconTheme: (AppTheme.oledDarkThemeOf(themeColorData).appBarTheme.actionsIconTheme ?? const IconThemeData()).copyWith(
              size: ((AppTheme.oledDarkThemeOf(themeColorData).appBarTheme.actionsIconTheme?.size) ?? 22) * iconScale,
            ),
          ),
          pageTransitionsTheme: const PageTransitionsTheme(
            builders: {
              TargetPlatform.android: CupertinoPageTransitionsBuilder(),
              TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
              TargetPlatform.macOS: CupertinoPageTransitionsBuilder(),
            },
          ),
        );
        oledTheme = applyButtonStyle(oledTheme);

        // 计算 ThemeMode 和实际使用的深色主题
        ThemeMode themeMode;
        ThemeData effectiveDarkTheme;
        final mode = settings.themeMode;
        final useOled = _useOledTheme(settings);
        effectiveDarkTheme = useOled ? oledTheme : darkTheme;

        switch (mode) {
          case 'dark':
          case 'oled':
            themeMode = ThemeMode.dark;
            break;
          case 'system':
            themeMode = ThemeMode.system;
            break;
          case 'scheduled':
            themeMode = isDarkMode ? ThemeMode.dark : ThemeMode.light;
            break;
          case 'light':
          default:
            themeMode = ThemeMode.light;
            break;
        }

        return MaterialApp(
          navigatorKey: appNavigatorKey,
          title: '无水印下载',
          debugShowCheckedModeBanner: false,
          theme: lightTheme,
          darkTheme: effectiveDarkTheme,
          themeMode: themeMode,
          // 使用 AnimatedTheme 实现主题切换平滑过渡
          themeAnimationDuration: const Duration(milliseconds: 300),
          themeAnimationCurve: Curves.easeInOut,
          // 使用 builder 注入文字缩放和全局文字选择
          builder: (context, child) {
            return MediaQuery(
              data: MediaQuery.of(context).copyWith(
                textScaler: TextScaler.linear(textScale),
              ),
              child: SelectionArea(
                child: child ?? const SizedBox.shrink(),
              ),
            );
          },
          home: privacyLock.shouldShowGlobalLock
              ? LockPage(
                  onUnlocked: () {
                    // 解锁成功后状态会自动更新，由 Consumer 触发重建
                  },
                )
              : const SplashPage(),
        );
      },
    );
  }
}
