import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:window_manager/window_manager.dart';
import 'app.dart';
import 'models/download_task.dart';
import 'models/video_info.dart';
import 'models/crawl_record.dart';
import 'models/crawl_checkpoint.dart';
import 'models/convert_record.dart';
import 'models/cookie_profile.dart';
import 'models/custom_api_source.dart';
import 'models/source_stats.dart';
import 'models/top10_works_result.dart';
import 'models/transcode_task.dart';
import 'models/favorite_folder.dart';
import 'models/convert_queue_item.dart';
import 'providers/download_provider.dart';
import 'providers/history_provider.dart';
import 'providers/crawl_history_provider.dart';
import 'providers/convert_history_provider.dart';
import 'providers/settings_provider.dart';
import 'providers/privacy_lock_provider.dart';
import 'providers/cookie_provider.dart';
import 'providers/custom_source_provider.dart';
import 'providers/source_stats_provider.dart';
import 'providers/transcode_provider.dart';
import 'providers/favorite_folder_provider.dart';
import 'services/download_manager.dart';
import 'services/history_service.dart';
import 'services/crawl_history_service.dart';
import 'services/crawl_checkpoint_service.dart';
import 'services/convert_history_service.dart';
import 'services/settings_service.dart';
import 'services/share_service.dart';
import 'services/notification_service.dart';
import 'services/cookie_service.dart';
import 'services/custom_source_service.dart';
import 'services/source_stats_service.dart';
import 'services/parser/parser_service.dart';
import 'services/proxy_service.dart';
import 'services/transcode_service.dart';
import 'services/favorite_folder_service.dart';
import 'services/convert_queue_service.dart';
import 'services/quick_actions_service.dart';

/// 桌面端窗口初始化
Future<void> _initDesktopWindow() async {
  await windowManager.ensureInitialized();

  const windowOptions = WindowOptions(
    size: Size(1200, 800),
    minimumSize: Size(900, 600),
    center: true,
    title: '无水印视频下载器',
    backgroundColor: Colors.transparent,
    skipTaskbar: false,
    titleBarStyle: TitleBarStyle.normal,
  );

  await windowManager.waitUntilReadyToShow(windowOptions, () async {
    await windowManager.show();
    await windowManager.focus();
  });
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // 桌面端窗口管理器初始化
  if (!kIsWeb && (Platform.isLinux || Platform.isWindows || Platform.isMacOS)) {
    await _initDesktopWindow();
  }

  // 初始化 Hive
  try {
    await Hive.initFlutter();
  } catch (e) {
    debugPrint('Hive init failed: $e');
  }
  try {
    Hive.registerAdapter(VideoInfoAdapter());
  } catch (_) {}
  try {
    Hive.registerAdapter(DownloadTaskAdapter());
  } catch (_) {}
  try {
    Hive.registerAdapter(DownloadStatusAdapter());
  } catch (_) {}
  try {
    Hive.registerAdapter(CrawlRecordAdapter());
  } catch (_) {}
  try {
    Hive.registerAdapter(CrawlCheckpointAdapter());
  } catch (_) {}
  try {
    Hive.registerAdapter(ConvertRecordAdapter());
  } catch (_) {}
  try {
    Hive.registerAdapter(CookieProfileAdapter());
  } catch (_) {}
  try {
    Hive.registerAdapter(CookieStatusAdapter());
  } catch (_) {}
  try {
    Hive.registerAdapter(CustomApiSourceAdapter());
  } catch (_) {}
  try {
    Hive.registerAdapter(HttpRequestMethodAdapter());
  } catch (_) {}
  try {
    Hive.registerAdapter(SourceStatsAdapter());
  } catch (_) {}
  try {
    Hive.registerAdapter(TranscodeTaskAdapter());
  } catch (_) {}
  try {
    Hive.registerAdapter(TranscodeStatusAdapter());
  } catch (_) {}
  try {
    Hive.registerAdapter(TranscodeTypeAdapter());
  } catch (_) {}
  try {
    Hive.registerAdapter(Top10WorkAdapter());
  } catch (_) {}
  try {
    Hive.registerAdapter(Top10WorksResultAdapter());
  } catch (_) {}
  try {
    Hive.registerAdapter(FavoriteFolderAdapter());
  } catch (_) {}
  try {
    Hive.registerAdapter(ConvertQueueStatusAdapter());
  } catch (_) {}
  try {
    Hive.registerAdapter(ConvertQueueTypeAdapter());
  } catch (_) {}
  try {
    Hive.registerAdapter(ConvertQueueItemAdapter());
  } catch (_) {}

  // 初始化服务
  final settingsService = SettingsService();
  try {
    await settingsService.init();
  } catch (e) {
    debugPrint('SettingsService init failed: $e');
  }
  final initialSettings = settingsService.getSettings();

  final historyService = HistoryService();
  try {
    await historyService.init();
  } catch (e) {
    debugPrint('HistoryService init failed: $e');
    // 打开失败时尝试删除旧 box 重新初始化
    try {
      await Hive.deleteBoxFromDisk('video_history');
      await historyService.init();
    } catch (_) {}
  }

  final crawlHistoryService = CrawlHistoryService();
  try {
    await crawlHistoryService.init();
  } catch (e) {
    debugPrint('CrawlHistoryService init failed: $e');
    try {
      await Hive.deleteBoxFromDisk('crawl_history');
      await crawlHistoryService.init();
    } catch (_) {}
  }

  final crawlCheckpointService = CrawlCheckpointService();
  try {
    await crawlCheckpointService.init();
  } catch (e) {
    debugPrint('CrawlCheckpointService init failed: $e');
    try {
      await Hive.deleteBoxFromDisk('crawl_checkpoints');
      await crawlCheckpointService.init();
    } catch (_) {}
  }

  final convertHistoryService = ConvertHistoryService();
  try {
    await convertHistoryService.init();
  } catch (e) {
    debugPrint('ConvertHistoryService init failed: $e');
    try {
      await Hive.deleteBoxFromDisk('convert_history');
      await convertHistoryService.init();
    } catch (_) {}
  }

  // 初始化通知服务
  final notificationService = NotificationService();
  try {
    await notificationService.init();
  } catch (e) {
    debugPrint('NotificationService init failed: $e');
  }

  // 初始化分享服务
  final shareService = ShareService();
  try {
    await shareService.init();
  } catch (e) {
    debugPrint('ShareService init failed: $e');
  }

  // 初始化下载管理器（加载持久化的下载记录）
  final downloadManager = DownloadManager();
  try {
    await downloadManager.init();
  } catch (e) {
    debugPrint('DownloadManager init failed: $e');
    try {
      await Hive.deleteBoxFromDisk('download_tasks');
      await downloadManager.init();
    } catch (_) {}
  }

  // 同步下载设置到下载管理器
  downloadManager.organizeByPlatform = initialSettings.organizeByPlatform;
  downloadManager.downloadNotificationEnabled = initialSettings.downloadNotificationEnabled;
  downloadManager.setMaxConcurrency(initialSettings.downloadConcurrency);
  downloadManager.hapticOnComplete = initialSettings.hapticOnDownloadComplete;
  downloadManager.hapticOnFailed = initialSettings.hapticOnDownloadFailed;
  // 同步智能分类存储设置
  downloadManager.storageOrganizeMode = initialSettings.storageOrganizeMode;
  downloadManager.storageDateFormat = initialSettings.storageDateFormat;
  downloadManager.storageNamingRule = initialSettings.storageNamingRule;

  // 同步自动清理下载记录设置
  downloadManager.autoCleanDownloadsEnabled = initialSettings.autoCleanDownloadsEnabled;
  downloadManager.autoCleanMode = initialSettings.autoCleanMode;
  downloadManager.autoCleanDays = initialSettings.autoCleanDays;
  downloadManager.autoCleanMaxCount = initialSettings.autoCleanMaxCount;
  downloadManager.autoCleanDeleteFiles = initialSettings.autoCleanDeleteFiles;

  // 同步下载完成自动保存到相册设置
  downloadManager.autoSaveToGallery = initialSettings.autoSaveToGallery;

  // 初始化 Cookie 管理服务
  final cookieService = CookieService();
  try {
    await cookieService.init();
  } catch (e) {
    debugPrint('CookieService init failed: $e');
    try {
      await Hive.deleteBoxFromDisk('cookie_profiles');
      await cookieService.init();
    } catch (_) {}
  }

  // 初始化自定义解析源服务
  final customSourceService = CustomSourceService();
  try {
    await customSourceService.init();
  } catch (e) {
    debugPrint('CustomSourceService init failed: $e');
    try {
      await Hive.deleteBoxFromDisk('custom_api_sources');
      await customSourceService.init();
    } catch (_) {}
  }

  // 初始化解析源统计服务
  final sourceStatsService = SourceStatsService();
  try {
    await sourceStatsService.init();
  } catch (e) {
    debugPrint('SourceStatsService init failed: $e');
    try {
      await Hive.deleteBoxFromDisk('source_stats');
      await sourceStatsService.init();
    } catch (_) {}
  }

  // 初始化解析服务（连接统计）
  final parserService = ParserService(statsService: sourceStatsService);

  // 初始化转码服务
  final transcodeService = TranscodeService();
  try {
    await transcodeService.init();
  } catch (e) {
    debugPrint('TranscodeService init failed: $e');
    try {
      await Hive.deleteBoxFromDisk('transcode_tasks');
      await transcodeService.init();
    } catch (_) {}
  }

  // 初始化收藏夹分组服务
  final favoriteFolderService = FavoriteFolderService();
  try {
    await favoriteFolderService.init();
  } catch (e) {
    debugPrint('FavoriteFolderService init failed: $e');
    try {
      await Hive.deleteBoxFromDisk('favorite_folders');
      await favoriteFolderService.init();
    } catch (_) {}
  }

  // 初始化转换队列服务
  final convertQueueService = ConvertQueueService();
  try {
    await convertQueueService.init();
    // App 重启后自动恢复处理队列中的待处理任务
    if (convertQueueService.pendingCount > 0) {
      convertQueueService.startProcessing();
    }
  } catch (e) {
    debugPrint('ConvertQueueService init failed: $e');
    try {
      await Hive.deleteBoxFromDisk('convert_queue');
      await convertQueueService.init();
    } catch (_) {}
  }

  // 初始化桌面快捷方式服务
  final quickActionsService = QuickActionsService();
  try {
    await quickActionsService.init();
    await quickActionsService.setShortcuts();
  } catch (e) {
    debugPrint('QuickActionsService init failed: $e');
  }

  // 初始化代理服务
  final proxyService = ProxyService();
  proxyService.updateConfig(
    enabled: initialSettings.proxyEnabled,
    type: initialSettings.proxyType,
    host: initialSettings.proxyHost,
    port: initialSettings.proxyPort,
    username: initialSettings.proxyUsername,
    password: initialSettings.proxyPassword,
    bypassDomains: initialSettings.proxyBypassDomains,
  );

  // 将代理服务注入到下载管理器
  downloadManager.setProxyService(proxyService);
  // 将代理服务注入到自定义源服务
  customSourceService.setProxyService(proxyService);

  runApp(
    MultiProvider(
      providers: [
        Provider<HistoryService>.value(
          value: historyService,
        ),
        Provider<CrawlHistoryService>.value(
          value: crawlHistoryService,
        ),
        Provider<CrawlCheckpointService>.value(
          value: crawlCheckpointService,
        ),
        Provider<ConvertHistoryService>.value(
          value: convertHistoryService,
        ),
        ChangeNotifierProvider(
          create: (_) => SettingsProvider(settingsService),
        ),
        ChangeNotifierProxyProvider<SettingsProvider, PrivacyLockProvider>(
          create: (context) => PrivacyLockProvider(context.read<SettingsProvider>()),
          update: (context, settings, previous) =>
              previous ?? PrivacyLockProvider(settings),
        ),
        ChangeNotifierProvider(
          create: (_) => HistoryProvider(historyService),
        ),
        ChangeNotifierProvider(
          create: (_) => CrawlHistoryProvider(crawlHistoryService),
        ),
        ChangeNotifierProvider(
          create: (_) => ConvertHistoryProvider(convertHistoryService),
        ),
        ChangeNotifierProvider(
          create: (_) => DownloadProvider(manager: downloadManager)
            ..setDownloadPath(
              initialSettings.downloadPath.isEmpty
                  ? null
                  : initialSettings.downloadPath,
            ),
        ),
        Provider<ShareService>.value(
          value: shareService,
        ),
        Provider<NotificationService>.value(
          value: notificationService,
        ),
        Provider<CookieService>.value(
          value: cookieService,
        ),
        Provider<CustomSourceService>.value(
          value: customSourceService,
        ),
        Provider<SourceStatsService>.value(
          value: sourceStatsService,
        ),
        Provider<ParserService>.value(
          value: parserService,
        ),
        ChangeNotifierProvider<ProxyService>.value(
          value: proxyService,
        ),
        ChangeNotifierProvider(
          create: (_) => CookieProvider(cookieService),
        ),
        ChangeNotifierProvider(
          create: (_) => CustomSourceProvider(customSourceService),
        ),
        ChangeNotifierProvider(
          create: (_) => SourceStatsProvider(sourceStatsService),
        ),
        ChangeNotifierProvider(
          create: (_) => TranscodeProvider(service: transcodeService),
        ),
        Provider<FavoriteFolderService>.value(
          value: favoriteFolderService,
        ),
        ChangeNotifierProvider(
          create: (_) => FavoriteFolderProvider(favoriteFolderService),
        ),
        ChangeNotifierProvider<ConvertQueueService>.value(
          value: convertQueueService,
        ),
        Provider<QuickActionsService>.value(
          value: quickActionsService,
        ),
      ],
      child: const MyApp(),
    ),
  );
}
