import 'package:flutter/foundation.dart';
import '../models/cookie_profile.dart';
import '../services/cookie_service.dart';

/// Cookie 管理 Provider
class CookieProvider extends ChangeNotifier {
  final CookieService _service;

  CookieProvider(this._service);

  /// 获取所有 Cookie 档案
  List<CookieProfile> get profiles => _service.getAll();

  /// 获取各状态数量
  Map<CookieStatus, int> get statusCounts => _service.getStatusCounts();

  /// 总数
  int get totalCount => profiles.length;

  /// 有效数量
  int get activeCount => statusCounts[CookieStatus.active] ?? 0;

  /// 即将过期数量
  int get expiringSoonCount => statusCounts[CookieStatus.expiringSoon] ?? 0;

  /// 已失效数量
  int get expiredCount => statusCounts[CookieStatus.expired] ?? 0;

  /// 按平台获取
  List<CookieProfile> getByPlatform(String platform) {
    return _service.getByPlatform(platform);
  }

  /// 获取指定平台的有效 Cookie
  CookieProfile? getActiveForPlatform(String platform) {
    return _service.getActiveForPlatform(platform);
  }

  /// 添加 Cookie
  Future<void> add(CookieProfile profile) async {
    await _service.add(profile);
    notifyListeners();
  }

  /// 更新 Cookie
  Future<void> update(CookieProfile profile) async {
    await _service.update(profile);
    notifyListeners();
  }

  /// 删除 Cookie
  Future<void> remove(String id) async {
    await _service.remove(id);
    notifyListeners();
  }

  /// 清除所有
  Future<void> clear() async {
    await _service.clear();
    notifyListeners();
  }

  /// 刷新状态（检查过期）
  void refreshStatus() {
    _service.checkExpirations();
    notifyListeners();
  }

  /// 标记使用
  Future<void> markUsed(String id) async {
    await _service.markUsed(id);
    notifyListeners();
  }

  /// 导入 JSON
  Future<int> importFromJson(String jsonStr) async {
    final count = await _service.importFromJson(jsonStr);
    if (count > 0) notifyListeners();
    return count;
  }

  /// 导出 JSON
  String exportAllJson() {
    return _service.exportAllJson();
  }

  /// 从 Cookie 字符串解析并创建新档案
  Future<CookieProfile?> createFromString({
    required String platform,
    required String name,
    required String cookieString,
    DateTime? expiresAt,
    String? remark,
  }) async {
    if (cookieString.trim().isEmpty) return null;
    final id = 'cookie_${DateTime.now().millisecondsSinceEpoch}';
    final profile = CookieProfile(
      id: id,
      platform: platform,
      name: name,
      cookieString: cookieString.trim(),
      createdAt: DateTime.now(),
      expiresAt: expiresAt,
      remark: remark,
    );
    await add(profile);
    return profile;
  }

  /// 从 Cookie Map 创建
  Future<CookieProfile?> createFromMap({
    required String platform,
    required String name,
    required Map<String, String> cookies,
    DateTime? expiresAt,
    String? remark,
  }) async {
    final cookieStr = CookieProfile.mapToString(cookies);
    return createFromString(
      platform: platform,
      name: name,
      cookieString: cookieStr,
      expiresAt: expiresAt,
      remark: remark,
    );
  }
}
