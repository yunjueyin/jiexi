import 'package:flutter/foundation.dart';
import '../models/source_stats.dart';
import '../services/source_stats_service.dart';

/// 解析源统计 Provider
class SourceStatsProvider extends ChangeNotifier {
  final SourceStatsService _service;

  SourceStatsProvider(this._service);

  /// 获取所有统计
  List<SourceStats> get allStats => _service.getAll();

  /// 总请求数
  int get totalRequests => _service.totalRequests;

  /// 总成功数
  int get totalSuccess => _service.totalSuccess;

  /// 总体成功率
  double get overallSuccessRate => _service.overallSuccessRate;

  /// 成功率排行榜
  List<SourceStats> get successRanking => _service.getSuccessRanking();

  /// 速度排行榜
  List<SourceStats> get speedRanking => _service.getSpeedRanking();

  /// 所有失败原因汇总
  Map<String, int> get allFailureReasons => _service.getAllFailureReasons();

  /// 获取指定源的统计
  SourceStats? getStats(String sourceId, {String? sourceName}) {
    return _service.getStats(sourceId, sourceName: sourceName);
  }

  /// 记录结果
  Future<void> recordResult({
    required String sourceId,
    required String sourceName,
    required bool success,
    required int durationMs,
    String? failureReason,
  }) async {
    await _service.recordResult(
      sourceId: sourceId,
      sourceName: sourceName,
      success: success,
      durationMs: durationMs,
      failureReason: failureReason,
    );
    notifyListeners();
  }

  /// 记录成功
  Future<void> recordSuccess({
    required String sourceId,
    required String sourceName,
    required int durationMs,
  }) async {
    await _service.recordSuccess(
      sourceId: sourceId,
      sourceName: sourceName,
      durationMs: durationMs,
    );
    notifyListeners();
  }

  /// 记录失败
  Future<void> recordFailure({
    required String sourceId,
    required String sourceName,
    required int durationMs,
    String? reason,
  }) async {
    await _service.recordFailure(
      sourceId: sourceId,
      sourceName: sourceName,
      durationMs: durationMs,
      reason: reason,
    );
    notifyListeners();
  }

  /// 重置单个源
  Future<void> reset(String sourceId) async {
    await _service.reset(sourceId);
    notifyListeners();
  }

  /// 重置所有
  Future<void> resetAll() async {
    await _service.resetAll();
    notifyListeners();
  }

  /// 删除统计
  Future<void> remove(String sourceId) async {
    await _service.remove(sourceId);
    notifyListeners();
  }

  /// 清除所有
  Future<void> clear() async {
    await _service.clear();
    notifyListeners();
  }

  /// 刷新
  void refresh() {
    notifyListeners();
  }
}
