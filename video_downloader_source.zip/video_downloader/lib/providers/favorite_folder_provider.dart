import 'package:flutter/foundation.dart';
import '../models/favorite_folder.dart';
import '../services/favorite_folder_service.dart';

/// 收藏夹分组状态管理
class FavoriteFolderProvider extends ChangeNotifier {
  final FavoriteFolderService _service;
  List<FavoriteFolder> _folders = [];
  bool _loading = false;

  FavoriteFolderProvider(this._service);

  List<FavoriteFolder> get folders => List.unmodifiable(_folders);
  bool get loading => _loading;

  /// 加载分组列表
  Future<void> loadFolders() async {
    if (_loading) return;

    _loading = true;
    notifyListeners();

    try {
      await _service.init();
      _folders = _service.getAll();
    } catch (e) {
      debugPrint('加载收藏夹分组失败: $e');
      _folders = [];
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  /// 刷新分组列表
  Future<void> refresh() async {
    await loadFolders();
  }

  /// 创建新分组
  Future<FavoriteFolder?> createFolder(String name) async {
    try {
      final folder = await _service.createFolder(name);
      _folders = _service.getAll();
      notifyListeners();
      return folder;
    } catch (e) {
      debugPrint('创建收藏夹分组失败: $e');
      return null;
    }
  }

  /// 重命名分组
  Future<bool> renameFolder(String id, String newName) async {
    try {
      await _service.renameFolder(id, newName);
      _folders = _service.getAll();
      notifyListeners();
      return true;
    } catch (e) {
      debugPrint('重命名收藏夹分组失败: $e');
      return false;
    }
  }

  /// 删除分组
  ///
  /// 注意：调用方需要负责处理组内收藏记录
  Future<bool> deleteFolder(String id) async {
    try {
      await _service.deleteFolder(id);
      _folders = _service.getAll();
      notifyListeners();
      return true;
    } catch (e) {
      debugPrint('删除收藏夹分组失败: $e');
      return false;
    }
  }

  /// 检查分组名称是否已存在
  bool nameExists(String name, {String? excludeId}) {
    return _service.nameExists(name, excludeId: excludeId);
  }

  /// 根据 ID 获取分组
  FavoriteFolder? getById(String id) {
    return _service.getById(id);
  }

  /// 获取默认分组
  FavoriteFolder get defaultFolder => _service.defaultFolder;

  /// 获取分组数量
  int get count => _folders.length;
}
