import 'package:flutter/foundation.dart';
import '../models/convert_record.dart';
import '../services/convert_history_service.dart';

/// 转换历史记录状态管理
class ConvertHistoryProvider extends ChangeNotifier {
  final ConvertHistoryService _service;
  List<ConvertRecord> _records = [];
  bool _loading = false;
  bool _loadingMore = false;
  bool _hasMore = true;
  int _currentPage = 0;
  static const int _pageSize = 20;

  ConvertHistoryProvider(this._service);

  List<ConvertRecord> get records => List.unmodifiable(_records);
  List<ConvertRecord> get shortRecords =>
      _records.where((r) => r.isToShort).toList();
  List<ConvertRecord> get longRecords =>
      _records.where((r) => r.isToLong).toList();
  bool get loading => _loading;
  bool get loadingMore => _loadingMore;
  bool get hasMore => _hasMore;
  int get count => _records.length;

  /// 加载历史记录（第一页）
  Future<void> loadHistory() async {
    if (_loading) return;

    _loading = true;
    notifyListeners();

    try {
      await _service.init();
      final list = _service.getPage(0, pageSize: _pageSize);
      _records
        ..clear()
        ..addAll(list);
      _currentPage = 0;
      _hasMore = list.length >= _pageSize;
    } catch (e) {
      debugPrint('加载转换历史失败: $e');
      _records.clear();
      _hasMore = false;
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  /// 加载更多（下一页）
  Future<void> loadMore() async {
    if (_loadingMore || !_hasMore || _loading) return;

    _loadingMore = true;
    notifyListeners();

    try {
      final nextPage = _currentPage + 1;
      final list = _service.getPage(nextPage, pageSize: _pageSize);
      if (list.isNotEmpty) {
        _records.addAll(list);
        _currentPage = nextPage;
      }
      // 如果返回数量少于 pageSize，说明没有更多了
      if (list.length < _pageSize) {
        _hasMore = false;
      }
    } catch (e) {
      debugPrint('加载更多转换历史失败: $e');
    } finally {
      _loadingMore = false;
      notifyListeners();
    }
  }

  /// 刷新历史记录（重新从第 1 页开始加载）
  Future<void> refresh() async {
    _hasMore = true;
    await loadHistory();
  }

  /// 添加转换记录
  Future<void> addRecord(ConvertRecord record) async {
    await _service.addRecord(record);
    // 添加后刷新第一页，保持列表最新
    final list = _service.getPage(0, pageSize: _pageSize);
    _records
      ..clear()
      ..addAll(list);
    _currentPage = 0;
    _hasMore = _service.count > _pageSize;
    notifyListeners();
  }

  /// 批量添加转换记录
  Future<void> addRecords(List<ConvertRecord> records) async {
    await _service.addRecords(records);
    // 添加后刷新第一页
    final list = _service.getPage(0, pageSize: _pageSize);
    _records
      ..clear()
      ..addAll(list);
    _currentPage = 0;
    _hasMore = _service.count > _pageSize;
    notifyListeners();
  }

  /// 删除单条记录
  Future<void> removeRecord(String id) async {
    await _service.removeRecord(id);
    // 删除后重新加载当前所有已加载的数据
    final loadedCount = _records.length;
    final list = _service.getPage(0, pageSize: loadedCount);
    _records
      ..clear()
      ..addAll(list);
    _hasMore = _service.count > loadedCount;
    notifyListeners();
  }

  /// 清空历史
  Future<void> clearHistory() async {
    await _service.clearAll();
    _records.clear();
    _currentPage = 0;
    _hasMore = false;
    notifyListeners();
  }

  /// 清空转短链历史
  Future<void> clearShortHistory() async {
    await _service.clearShortRecords();
    // 重新加载当前页
    final loadedCount = _records.length;
    final list = _service.getPage(0, pageSize: loadedCount);
    _records
      ..clear()
      ..addAll(list);
    _hasMore = _service.count > loadedCount;
    _currentPage = 0;
    notifyListeners();
  }

  /// 清空转长链历史
  Future<void> clearLongHistory() async {
    await _service.clearLongRecords();
    // 重新加载当前页
    final loadedCount = _records.length;
    final list = _service.getPage(0, pageSize: loadedCount);
    _records
      ..clear()
      ..addAll(list);
    _hasMore = _service.count > loadedCount;
    _currentPage = 0;
    notifyListeners();
  }
}
