import 'package:flutter/foundation.dart';
import '../models/custom_api_source.dart';
import '../services/custom_source_service.dart';

/// 自定义解析源 Provider
class CustomSourceProvider extends ChangeNotifier {
  final CustomSourceService _service;

  CustomSourceProvider(this._service);

  /// 获取所有自定义源（按优先级排序）
  List<CustomApiSource> get sources => _service.getAll();

  /// 获取启用的源
  List<CustomApiSource> get enabledSources => _service.getEnabled();

  /// 总数
  int get totalCount => _service.totalCount;

  /// 启用数量
  int get enabledCount => _service.enabledCount;

  /// 根据 ID 获取
  CustomApiSource? getById(String id) => _service.getById(id);

  /// 按平台获取启用的源
  List<CustomApiSource> getEnabledForPlatform(String platform) {
    return _service.getEnabledForPlatform(platform);
  }

  /// 添加
  Future<void> add(CustomApiSource source) async {
    await _service.add(source);
    notifyListeners();
  }

  /// 更新
  Future<void> update(CustomApiSource source) async {
    await _service.update(source);
    notifyListeners();
  }

  /// 删除
  Future<void> remove(String id) async {
    await _service.remove(id);
    notifyListeners();
  }

  /// 清除所有
  Future<void> clear() async {
    await _service.clear();
    notifyListeners();
  }

  /// 切换启用状态
  Future<void> toggleEnabled(String id) async {
    await _service.toggleEnabled(id);
    notifyListeners();
  }

  /// 重新排序
  Future<void> reorder(List<String> orderedIds) async {
    await _service.reorder(orderedIds);
    notifyListeners();
  }

  /// 上移
  Future<void> moveUp(String id) async {
    await _service.moveUp(id);
    notifyListeners();
  }

  /// 下移
  Future<void> moveDown(String id) async {
    await _service.moveDown(id);
    notifyListeners();
  }

  /// 测试连通性
  Future<(bool, String, int)> testConnection(CustomApiSource source) {
    return _service.testConnection(source);
  }

  /// 创建新的自定义源
  Future<CustomApiSource> create({
    required String name,
    required String apiUrl,
    HttpRequestMethod method = HttpRequestMethod.get,
    List<String> supportedPlatforms = const ['douyin', 'kuaishou'],
    String? apiKeyParam,
    String? apiKey,
    String? headersTemplate,
    String? bodyTemplate,
    String? responsePath,
    String? remark,
  }) async {
    final id = 'custom_${DateTime.now().millisecondsSinceEpoch}';
    final currentCount = totalCount;
    final source = CustomApiSource(
      id: id,
      name: name,
      apiUrl: apiUrl,
      method: method,
      priority: currentCount,
      weight: 1,
      supportedPlatforms: supportedPlatforms,
      enabled: true,
      apiKeyParam: apiKeyParam,
      apiKey: apiKey,
      headersTemplate: headersTemplate,
      bodyTemplate: bodyTemplate,
      responsePath: responsePath,
      remark: remark,
    );
    await add(source);
    return source;
  }

  /// 更新源的上次使用时间
  Future<void> updateLastUsed(String id) async {
    await _service.updateLastUsed(id);
    notifyListeners();
  }

  /// 导出所有自定义源为 JSON 字符串
  String exportToJson() {
    return _service.exportToJson();
  }

  /// 从 JSON 字符串导入自定义源
  Future<int> importFromJson(String jsonStr) async {
    final count = await _service.importFromJson(jsonStr);
    if (count > 0) {
      notifyListeners();
    }
    return count;
  }
}
