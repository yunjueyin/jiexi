import 'dart:convert';
import 'package:flutter/foundation.dart';
import '../models/app_settings.dart';
import '../services/settings_service.dart';

class SettingsProvider extends ChangeNotifier {
  final SettingsService _service;
  late AppSettings _settings;

  SettingsProvider(this._service) {
    _settings = _service.getSettings();
    // 初始化时确保互斥：自动粘贴解析下载 和 自动解析剪贴板 不能同时开启
    _ensureMutualExclusion();
  }

  /// 确保自动粘贴解析下载和自动解析剪贴板互斥
  /// 
  /// 如果两者都开启，保留自动粘贴解析下载，关闭自动解析剪贴板
  Future<void> _ensureMutualExclusion() async {
    if (_settings.autoPasteAndDownload && _settings.autoParseClipboard) {
      _settings = _settings.copyWith(autoParseClipboard: false);
      await _service.setAutoParseClipboard(false);
      // 通知 UI 刷新，确保互斥修复后的状态正确显示
      notifyListeners();
    }
  }

  AppSettings get settings => _settings;
  String get themeMode => _settings.themeMode;
  String get themeColor => _settings.themeColor;
  String get defaultQuality => _settings.defaultQuality;
  String? get customApiUrl => _settings.customApiUrl;
  String get apiSourceId => _settings.apiSourceId;
  String get downloadPath => _settings.downloadPath;
  bool get wifiOnly => _settings.wifiOnly;
  bool get autoParseClipboard => _settings.autoParseClipboard;
  bool get autoDownloadOnShare => _settings.autoDownloadOnShare;
  bool get autoPasteAndDownload => _settings.autoPasteAndDownload;
  bool get clipboardDetectionEnabled => _settings.clipboardDetectionEnabled;
  String? get uidResolveServiceUrl => _settings.uidResolveServiceUrl;
  Map<String, String> get apiKeys => _settings.apiKeys;
  bool get downloadSoundEnabled => _settings.downloadSoundEnabled;
  String get downloadSoundType => _settings.downloadSoundType;
  String get downloadCompleteAction => _settings.downloadCompleteAction;
  bool get organizeByPlatform => _settings.organizeByPlatform;
  Map<String, String> get douyinCookies => _settings.douyinCookies;
  bool get hapticFeedbackEnabled => _settings.hapticFeedbackEnabled;
  String get hapticFeedbackLevel => _settings.hapticFeedbackLevel;
  bool get downloadNotificationEnabled => _settings.downloadNotificationEnabled;
  int get crawlIntervalMs => _settings.crawlIntervalMs;
  int get crawlJitterMs => _settings.crawlJitterMs;
  String get uiDensity => _settings.uiDensity;
  int get parseRetryCount => _settings.parseRetryCount;
  int get crawlRetryCount => _settings.crawlRetryCount;
  int get downloadConcurrency => _settings.downloadConcurrency;
  bool get shakeToParseEnabled => _settings.shakeToParseEnabled;
  bool get privacyLockEnabled => _settings.privacyLockEnabled;
  String get privacyLockScope => _settings.privacyLockScope;
  String get privacyUnlockMethod => _settings.privacyUnlockMethod;
  String? get privacyPasswordHash => _settings.privacyPasswordHash;
  int get privacyAutoLockDelay => _settings.privacyAutoLockDelay;
  bool get hasPrivacyPassword => _settings.privacyPasswordHash != null && _settings.privacyPasswordHash!.isNotEmpty;
  String get themeSunsetTime => _settings.themeSunsetTime;
  String get themeSunriseTime => _settings.themeSunriseTime;
  bool get twoFingerGestureEnabled => _settings.twoFingerGestureEnabled;
  bool get batchGuideShown => _settings.batchGuideShown;
  bool get disclaimerShown => _settings.disclaimerShown;
  bool get hapticOnDownloadComplete => _settings.hapticOnDownloadComplete;
  bool get hapticOnDownloadFailed => _settings.hapticOnDownloadFailed;
  String get defaultAudioFormat => _settings.defaultAudioFormat;

  // ==================== 智能分类存储 ====================
  String get storageOrganizeMode => _settings.storageOrganizeMode;
  String get storageDateFormat => _settings.storageDateFormat;
  String get storageNamingRule => _settings.storageNamingRule;

  // ==================== 代理设置 ====================
  bool get proxyEnabled => _settings.proxyEnabled;
  String get proxyType => _settings.proxyType;
  String get proxyHost => _settings.proxyHost;
  int get proxyPort => _settings.proxyPort;
  String? get proxyUsername => _settings.proxyUsername;
  String? get proxyPassword => _settings.proxyPassword;
  List<String> get proxyBypassDomains => _settings.proxyBypassDomains;

  // ==================== UI 动效与提示 ====================
  bool get parallaxEnabled => _settings.parallaxEnabled;
  Set<String> get gestureHintsShown => _settings.gestureHintsShown;
  String get fontSizeScale => _settings.fontSizeScale;

  // ==================== 手势交互 ====================
  bool get forceTouchEnabled => _settings.forceTouchEnabled;
  String get bottomNavConfigJson => _settings.bottomNavConfigJson;

  // ==================== 自动清理下载记录 ====================
  bool get autoCleanDownloadsEnabled => _settings.autoCleanDownloadsEnabled;
  String get autoCleanMode => _settings.autoCleanMode;
  int get autoCleanDays => _settings.autoCleanDays;
  int get autoCleanMaxCount => _settings.autoCleanMaxCount;
  bool get autoCleanDeleteFiles => _settings.autoCleanDeleteFiles;

  // ==================== 下载失败自动重试 ====================
  bool get autoRetryOnFailure => _settings.autoRetryOnFailure;
  int get maxRetryCount => _settings.maxRetryCount;

  // ==================== 列表紧凑模式 ====================
  bool get compactListMode => _settings.compactListMode;

  // ==================== 下载完成自动保存到相册 ====================
  bool get autoSaveToGallery => _settings.autoSaveToGallery;

  // ==================== 大字体模式 ====================
  bool get largeFontMode => _settings.largeFontMode;

  // ==================== 新手引导 ====================
  bool get guideShown => _settings.guideShown;

  // ==================== 智能粘贴模式 ====================
  bool get smartPasteAppendMode => _settings.smartPasteAppendMode;

  /// 获取底部导航配置
  Map<String, dynamic> get bottomNavConfig {
    if (_settings.bottomNavConfigJson.isEmpty) return {};
    try {
      final decoded = jsonDecode(_settings.bottomNavConfigJson);
      if (decoded is Map<String, dynamic>) return decoded;
    } catch (_) {}
    return {};
  }

  /// 获取指定 API 源的 Key
  String? getApiKey(String sourceId) => _settings.getApiKey(sourceId);

  Future<void> setDefaultQuality(String quality) async {
    _settings = _settings.copyWith(defaultQuality: quality);
    await _service.setDefaultQuality(quality);
    notifyListeners();
  }

  Future<void> setCustomApiUrl(String? url) async {
    _settings = _settings.copyWith(customApiUrl: url);
    await _service.setCustomApiUrl(url);
    notifyListeners();
  }

  Future<void> setApiSourceId(String id) async {
    _settings = _settings.copyWith(apiSourceId: id);
    await _service.setApiSourceId(id);
    notifyListeners();
  }

  Future<void> setDownloadPath(String path) async {
    _settings = _settings.copyWith(downloadPath: path);
    await _service.setDownloadPath(path);
    notifyListeners();
  }

  Future<void> setWifiOnly(bool value) async {
    _settings = _settings.copyWith(wifiOnly: value);
    await _service.setWifiOnly(value);
    notifyListeners();
  }

  Future<void> setThemeMode(String mode) async {
    _settings = _settings.copyWith(themeMode: mode);
    await _service.setThemeMode(mode);
    notifyListeners();
  }

  Future<void> setThemeColor(String color) async {
    _settings = _settings.copyWith(themeColor: color);
    await _service.setThemeColor(color);
    notifyListeners();
  }

  Future<void> setAutoParseClipboard(bool value, {bool mutualExclusion = true}) async {
    final needMutex = value && mutualExclusion && _settings.autoPasteAndDownload;
    _settings = _settings.copyWith(
      autoParseClipboard: value,
      autoPasteAndDownload: needMutex ? false : _settings.autoPasteAndDownload,
    );
    await _service.setAutoParseClipboard(value);
    if (needMutex) {
      await _service.setAutoPasteAndDownload(false);
    }
    notifyListeners();
  }

  Future<void> setAutoDownloadOnShare(bool value) async {
    _settings = _settings.copyWith(autoDownloadOnShare: value);
    await _service.setAutoDownloadOnShare(value);
    notifyListeners();
  }

  Future<void> setAutoPasteAndDownload(bool value, {bool mutualExclusion = true}) async {
    final needMutex = value && mutualExclusion && _settings.autoParseClipboard;
    _settings = _settings.copyWith(
      autoPasteAndDownload: value,
      autoParseClipboard: needMutex ? false : _settings.autoParseClipboard,
    );
    await _service.setAutoPasteAndDownload(value);
    if (needMutex) {
      await _service.setAutoParseClipboard(false);
    }
    notifyListeners();
  }

  Future<void> setClipboardDetectionEnabled(bool value) async {
    _settings = _settings.copyWith(clipboardDetectionEnabled: value);
    await _service.setClipboardDetectionEnabled(value);
    notifyListeners();
  }

  Future<void> setUidResolveServiceUrl(String? url) async {
    _settings = _settings.copyWith(uidResolveServiceUrl: url);
    await _service.setUidResolveServiceUrl(url);
    notifyListeners();
  }

  Future<void> setApiKey(String sourceId, String? key) async {
    final newKeys = Map<String, String>.from(_settings.apiKeys);
    if (key == null || key.isEmpty) {
      newKeys.remove(sourceId);
    } else {
      newKeys[sourceId] = key;
    }
    _settings = _settings.copyWith(apiKeys: newKeys);
    await _service.setApiKey(sourceId, key);
    notifyListeners();
  }

  Future<void> setDownloadSoundEnabled(bool value) async {
    _settings = _settings.copyWith(downloadSoundEnabled: value);
    await _service.setDownloadSoundEnabled(value);
    notifyListeners();
  }

  Future<void> setDownloadSoundType(String type) async {
    _settings = _settings.copyWith(downloadSoundType: type);
    await _service.setDownloadSoundType(type);
    notifyListeners();
  }

  Future<void> setDownloadCompleteAction(String action) async {
    _settings = _settings.copyWith(downloadCompleteAction: action);
    await _service.setDownloadCompleteAction(action);
    notifyListeners();
  }

  Future<void> setOrganizeByPlatform(bool value) async {
    _settings = _settings.copyWith(organizeByPlatform: value);
    await _service.setOrganizeByPlatform(value);
    notifyListeners();
  }

  Future<void> setDouyinCookies(Map<String, String> cookies) async {
    _settings = _settings.copyWith(douyinCookies: cookies);
    await _service.setDouyinCookies(cookies);
    notifyListeners();
  }

  Future<void> clearDouyinCookies() async {
    _settings = _settings.copyWith(douyinCookies: <String, String>{});
    await _service.clearDouyinCookies();
    notifyListeners();
  }

  /// 手动导入 Cookie（支持完整 cookie 字符串或 JSON 格式）
  Future<bool> importDouyinCookiesFromString(String input) async {
    final Map<String, String> cookieMap = {};

    // 尝试 JSON 格式解析
    try {
      final decoded = jsonDecode(input.trim());
      if (decoded is Map) {
        decoded.forEach((k, v) {
          cookieMap[k.toString()] = v.toString();
        });
      }
    } catch (_) {
      // 不是 JSON，按 cookie 字符串解析
      if (input.contains('=')) {
        final pairs = input.split(';');
        for (final pair in pairs) {
          final trimmed = pair.trim();
          final idx = trimmed.indexOf('=');
          if (idx > 0) {
            final name = trimmed.substring(0, idx).trim();
            final value = trimmed.substring(idx + 1).trim();
            if (name.isNotEmpty) {
              cookieMap[name] = value;
            }
          }
        }
      }
    }

    if (cookieMap.isEmpty) return false;

    _settings = _settings.copyWith(douyinCookies: cookieMap);
    await _service.setDouyinCookies(cookieMap);
    notifyListeners();
    return true;
  }

  /// 备份当前 Cookie（清除前自动调用）
  Future<void> backupDouyinCookies() async {
    if (_settings.douyinCookies.isNotEmpty) {
      await _service.setDouyinCookiesBackup(_settings.douyinCookies);
    }
  }

  /// 从备份恢复 Cookie
  Future<bool> restoreDouyinCookies() async {
    final backup = await _service.getDouyinCookiesBackup();
    if (backup != null && backup.isNotEmpty) {
      _settings = _settings.copyWith(douyinCookies: backup);
      await _service.setDouyinCookies(backup);
      notifyListeners();
      return true;
    }
    return false;
  }

  /// 是否有备份的 Cookie
  Future<bool> hasDouyinCookiesBackup() async {
    return _service.hasDouyinCookiesBackup();
  }

  /// 清除备份的 Cookie
  Future<void> clearDouyinCookiesBackup() async {
    await _service.clearDouyinCookiesBackup();
  }

  /// 导出当前 Cookie 为字符串
  String exportDouyinCookiesAsString() {
    if (_settings.douyinCookies.isEmpty) return '';
    return _settings.douyinCookies.entries
        .map((e) => '${e.key}=${e.value}')
        .join('; ');
  }

  Future<void> setHapticFeedbackEnabled(bool value) async {
    _settings = _settings.copyWith(hapticFeedbackEnabled: value);
    await _service.setHapticFeedbackEnabled(value);
    notifyListeners();
  }

  Future<void> setHapticFeedbackLevel(String level) async {
    _settings = _settings.copyWith(hapticFeedbackLevel: level);
    await _service.setHapticFeedbackLevel(level);
    notifyListeners();
  }

  Future<void> setDownloadNotificationEnabled(bool value) async {
    _settings = _settings.copyWith(downloadNotificationEnabled: value);
    await _service.setDownloadNotificationEnabled(value);
    notifyListeners();
  }

  Future<void> setCrawlIntervalMs(int ms) async {
    _settings = _settings.copyWith(crawlIntervalMs: ms);
    await _service.setCrawlIntervalMs(ms);
    notifyListeners();
  }

  Future<void> setCrawlJitterMs(int ms) async {
    _settings = _settings.copyWith(crawlJitterMs: ms);
    await _service.setCrawlJitterMs(ms);
    notifyListeners();
  }

  Future<void> setParseRetryCount(int count) async {
    _settings = _settings.copyWith(parseRetryCount: count);
    await _service.setParseRetryCount(count);
    notifyListeners();
  }

  Future<void> setCrawlRetryCount(int count) async {
    _settings = _settings.copyWith(crawlRetryCount: count);
    await _service.setCrawlRetryCount(count);
    notifyListeners();
  }

  Future<void> setDownloadConcurrency(int concurrency) async {
    _settings = _settings.copyWith(downloadConcurrency: concurrency);
    await _service.setDownloadConcurrency(concurrency);
    notifyListeners();
  }

  Future<void> setUiDensity(String density) async {
    _settings = _settings.copyWith(uiDensity: density);
    await _service.setUiDensity(density);
    notifyListeners();
  }

  Future<void> setShakeToParseEnabled(bool value) async {
    _settings = _settings.copyWith(shakeToParseEnabled: value);
    await _service.setShakeToParseEnabled(value);
    notifyListeners();
  }

  Future<void> setPrivacyLockEnabled(bool value) async {
    _settings = _settings.copyWith(privacyLockEnabled: value);
    await _service.setPrivacyLockEnabled(value);
    notifyListeners();
  }

  Future<void> setPrivacyLockScope(String scope) async {
    _settings = _settings.copyWith(privacyLockScope: scope);
    await _service.setPrivacyLockScope(scope);
    notifyListeners();
  }

  Future<void> setPrivacyUnlockMethod(String method) async {
    _settings = _settings.copyWith(privacyUnlockMethod: method);
    await _service.setPrivacyUnlockMethod(method);
    notifyListeners();
  }

  /// 设置隐私锁密码
  Future<void> setPrivacyPassword(String password) async {
    _settings = _settings.copyWith(privacyPasswordHash: null); // 临时占位，实际由 service 哈希
    await _service.setPrivacyPassword(password);
    // 重新读取以获取正确的哈希值
    _settings = _service.getSettings();
    notifyListeners();
  }

  /// 清除隐私锁密码
  Future<void> clearPrivacyPassword() async {
    _settings = _settings.copyWith(clearPrivacyPasswordHash: true);
    await _service.clearPrivacyPassword();
    notifyListeners();
  }

  /// 验证隐私锁密码
  bool verifyPrivacyPassword(String password) {
    return _service.verifyPrivacyPassword(password);
  }

  Future<void> setPrivacyAutoLockDelay(int delaySeconds) async {
    _settings = _settings.copyWith(privacyAutoLockDelay: delaySeconds);
    await _service.setPrivacyAutoLockDelay(delaySeconds);
    notifyListeners();
  }

  Future<void> setThemeSunsetTime(String time) async {
    _settings = _settings.copyWith(themeSunsetTime: time);
    await _service.setThemeSunsetTime(time);
    notifyListeners();
  }

  Future<void> setThemeSunriseTime(String time) async {
    _settings = _settings.copyWith(themeSunriseTime: time);
    await _service.setThemeSunriseTime(time);
    notifyListeners();
  }

  Future<void> setTwoFingerGestureEnabled(bool value) async {
    _settings = _settings.copyWith(twoFingerGestureEnabled: value);
    await _service.setTwoFingerGestureEnabled(value);
    notifyListeners();
  }

  Future<void> setBatchGuideShown(bool value) async {
    _settings = _settings.copyWith(batchGuideShown: value);
    await _service.setBatchGuideShown(value);
    notifyListeners();
  }

  Future<void> setDisclaimerShown(bool value) async {
    _settings = _settings.copyWith(disclaimerShown: value);
    await _service.setDisclaimerShown(value);
    notifyListeners();
  }

  Future<void> setHapticOnDownloadComplete(bool value) async {
    _settings = _settings.copyWith(hapticOnDownloadComplete: value);
    await _service.setHapticOnDownloadComplete(value);
    notifyListeners();
  }

  Future<void> setHapticOnDownloadFailed(bool value) async {
    _settings = _settings.copyWith(hapticOnDownloadFailed: value);
    await _service.setHapticOnDownloadFailed(value);
    notifyListeners();
  }

  Future<void> setDefaultAudioFormat(String format) async {
    _settings = _settings.copyWith(defaultAudioFormat: format);
    await _service.setDefaultAudioFormat(format);
    notifyListeners();
  }

  // ==================== 智能分类存储 ====================

  Future<void> setStorageOrganizeMode(String mode) async {
    _settings = _settings.copyWith(storageOrganizeMode: mode);
    await _service.setStorageOrganizeMode(mode);
    notifyListeners();
  }

  Future<void> setStorageDateFormat(String format) async {
    _settings = _settings.copyWith(storageDateFormat: format);
    await _service.setStorageDateFormat(format);
    notifyListeners();
  }

  Future<void> setStorageNamingRule(String rule) async {
    _settings = _settings.copyWith(storageNamingRule: rule);
    await _service.setStorageNamingRule(rule);
    notifyListeners();
  }

  // ==================== 代理设置 ====================

  Future<void> setProxyEnabled(bool value) async {
    _settings = _settings.copyWith(proxyEnabled: value);
    await _service.setProxyEnabled(value);
    notifyListeners();
  }

  Future<void> setProxyType(String type) async {
    _settings = _settings.copyWith(proxyType: type);
    await _service.setProxyType(type);
    notifyListeners();
  }

  Future<void> setProxyHost(String host) async {
    _settings = _settings.copyWith(proxyHost: host);
    await _service.setProxyHost(host);
    notifyListeners();
  }

  Future<void> setProxyPort(int port) async {
    _settings = _settings.copyWith(proxyPort: port);
    await _service.setProxyPort(port);
    notifyListeners();
  }

  Future<void> setProxyUsername(String? username) async {
    _settings = _settings.copyWith(
      proxyUsername: username,
      clearProxyUsername: username == null || username.isEmpty,
    );
    await _service.setProxyUsername(username);
    notifyListeners();
  }

  Future<void> setProxyPassword(String? password) async {
    _settings = _settings.copyWith(
      proxyPassword: password,
      clearProxyPassword: password == null || password.isEmpty,
    );
    await _service.setProxyPassword(password);
    notifyListeners();
  }

  Future<void> setProxyBypassDomains(List<String> domains) async {
    _settings = _settings.copyWith(proxyBypassDomains: domains);
    await _service.setProxyBypassDomains(domains);
    notifyListeners();
  }

  // ==================== UI 动效与提示 ====================

  Future<void> setParallaxEnabled(bool value) async {
    _settings = _settings.copyWith(parallaxEnabled: value);
    await _service.setParallaxEnabled(value);
    notifyListeners();
  }

  Future<void> markGestureHintShown(String pageKey) async {
    final newSet = Set<String>.from(_settings.gestureHintsShown);
    newSet.add(pageKey);
    _settings = _settings.copyWith(gestureHintsShown: newSet);
    await _service.setGestureHintShown(pageKey);
    notifyListeners();
  }

  Future<void> resetGestureHints() async {
    _settings = _settings.copyWith(gestureHintsShown: <String>{});
    await _service.resetGestureHints();
    notifyListeners();
  }

  Future<void> setFontSizeScale(String scale) async {
    _settings = _settings.copyWith(fontSizeScale: scale);
    await _service.setFontSizeScale(scale);
    notifyListeners();
  }

  // ==================== 手势交互 ====================

  Future<void> setForceTouchEnabled(bool value) async {
    _settings = _settings.copyWith(forceTouchEnabled: value);
    await _service.setForceTouchEnabled(value);
    notifyListeners();
  }

  Future<void> setBottomNavConfig(String configJson) async {
    _settings = _settings.copyWith(bottomNavConfigJson: configJson);
    await _service.setBottomNavConfig(configJson);
    notifyListeners();
  }

  // ==================== 自动清理下载记录 ====================

  Future<void> setAutoCleanDownloadsEnabled(bool value) async {
    _settings = _settings.copyWith(autoCleanDownloadsEnabled: value);
    await _service.setAutoCleanDownloadsEnabled(value);
    notifyListeners();
  }

  Future<void> setAutoCleanMode(String mode) async {
    _settings = _settings.copyWith(autoCleanMode: mode);
    await _service.setAutoCleanMode(mode);
    notifyListeners();
  }

  Future<void> setAutoCleanDays(int days) async {
    _settings = _settings.copyWith(autoCleanDays: days);
    await _service.setAutoCleanDays(days);
    notifyListeners();
  }

  Future<void> setAutoCleanMaxCount(int count) async {
    _settings = _settings.copyWith(autoCleanMaxCount: count);
    await _service.setAutoCleanMaxCount(count);
    notifyListeners();
  }

  Future<void> setAutoCleanDeleteFiles(bool value) async {
    _settings = _settings.copyWith(autoCleanDeleteFiles: value);
    await _service.setAutoCleanDeleteFiles(value);
    notifyListeners();
  }

  // ==================== 下载失败自动重试 ====================

  Future<void> setAutoRetryOnFailure(bool value) async {
    _settings = _settings.copyWith(autoRetryOnFailure: value);
    await _service.setAutoRetryOnFailure(value);
    notifyListeners();
  }

  Future<void> setMaxRetryCount(int count) async {
    _settings = _settings.copyWith(maxRetryCount: count);
    await _service.setMaxRetryCount(count);
    notifyListeners();
  }

  // ==================== 列表紧凑模式 ====================

  Future<void> setCompactListMode(bool value) async {
    _settings = _settings.copyWith(compactListMode: value);
    await _service.setCompactListMode(value);
    notifyListeners();
  }

  // ==================== 下载完成自动保存到相册 ====================

  Future<void> setAutoSaveToGallery(bool value) async {
    _settings = _settings.copyWith(autoSaveToGallery: value);
    await _service.setAutoSaveToGallery(value);
    notifyListeners();
  }

  // ==================== 大字体模式 ====================

  Future<void> setLargeFontMode(bool value) async {
    _settings = _settings.copyWith(largeFontMode: value);
    await _service.setLargeFontMode(value);
    notifyListeners();
  }

  // ==================== 新手引导 ====================

  Future<void> setGuideShown(bool value) async {
    _settings = _settings.copyWith(guideShown: value);
    await _service.setGuideShown(value);
    notifyListeners();
  }

  Future<void> setSmartPasteAppendMode(bool value) async {
    _settings = _settings.copyWith(smartPasteAppendMode: value);
    await _service.setSmartPasteAppendMode(value);
    notifyListeners();
  }

  // ==================== 常用设置点击统计 ====================

  /// 获取常用设置点击次数字典
  Map<String, int> get quickSettingClickCounts => _service.getQuickSettingClickCounts();

  /// 增加指定设置项的点击次数（不触发 notifyListeners，避免频繁刷新）
  Future<void> incrementQuickSettingClick(String sectionKey) async {
    await _service.incrementQuickSettingClick(sectionKey);
  }
}
