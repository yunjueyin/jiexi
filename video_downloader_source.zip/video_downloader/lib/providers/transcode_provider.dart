import 'package:flutter/foundation.dart';
import '../models/transcode_task.dart';
import '../services/transcode_service.dart';

class TranscodeProvider extends ChangeNotifier {
  final TranscodeService _service;

  TranscodeProvider({TranscodeService? service})
      : _service = service ?? TranscodeService() {
    _service.onProgress = (task) {
      notifyListeners();
    };
    _service.onComplete = (task) {
      notifyListeners();
    };
    _service.onError = (task, error) {
      notifyListeners();
    };
  }

  TranscodeService get service => _service;
  List<TranscodeTask> get tasks => _service.tasks;

  List<TranscodeTask> get processingTasks =>
      _service.tasks.where((t) =>
          t.status == TranscodeStatus.processing ||
          t.status == TranscodeStatus.queued).toList();

  List<TranscodeTask> get completedTasks =>
      _service.tasks.where((t) => t.status == TranscodeStatus.completed).toList();

  /// 初始化
  Future<void> init() async {
    await _service.init();
    notifyListeners();
  }

  /// 创建视频格式转换任务
  Future<TranscodeTask> createVideoConvertTask({
    required String sourcePath,
    required String outputDir,
    required String targetFormat,
    String? videoCover,
    String? videoTitle,
  }) async {
    final task = await _service.createVideoConvertTask(
      sourcePath: sourcePath,
      outputDir: outputDir,
      targetFormat: targetFormat,
      videoCover: videoCover,
      videoTitle: videoTitle,
    );
    notifyListeners();
    return task;
  }

  /// 创建音频格式转换任务
  Future<TranscodeTask> createAudioConvertTask({
    required String sourcePath,
    required String outputDir,
    required String targetFormat,
    String? videoCover,
    String? videoTitle,
  }) async {
    final task = await _service.createAudioConvertTask(
      sourcePath: sourcePath,
      outputDir: outputDir,
      targetFormat: targetFormat,
      videoCover: videoCover,
      videoTitle: videoTitle,
    );
    notifyListeners();
    return task;
  }

  /// 创建视频压缩任务
  Future<TranscodeTask> createVideoCompressTask({
    required String sourcePath,
    required String outputDir,
    required String targetFormat,
    String resolution = '720p',
    int? bitrate,
    String? videoCover,
    String? videoTitle,
  }) async {
    final task = await _service.createVideoCompressTask(
      sourcePath: sourcePath,
      outputDir: outputDir,
      targetFormat: targetFormat,
      resolution: resolution,
      bitrate: bitrate,
      videoCover: videoCover,
      videoTitle: videoTitle,
    );
    notifyListeners();
    return task;
  }

  /// 取消任务
  void cancelTask(String taskId) {
    _service.cancelTask(taskId);
    notifyListeners();
  }

  /// 删除任务
  void removeTask(String taskId, {bool deleteFile = false}) {
    _service.removeTask(taskId, deleteFile: deleteFile);
    notifyListeners();
  }

  /// 清空已完成
  void clearCompleted() {
    _service.clearCompleted();
    notifyListeners();
  }
}
