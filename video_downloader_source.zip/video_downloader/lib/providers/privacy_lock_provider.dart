import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import '../services/biometric_service.dart';
import '../providers/settings_provider.dart';

/// 解锁方式
enum UnlockMethod {
  /// 仅生物识别
  biometric,

  /// 仅密码
  password,

  /// 两者都可以（生物识别优先）
  both,
}

/// 解锁方式扩展
extension UnlockMethodX on UnlockMethod {
  String get label {
    switch (this) {
      case UnlockMethod.biometric:
        return '生物识别';
      case UnlockMethod.password:
        return '应用密码';
      case UnlockMethod.both:
        return '生物识别 + 密码';
    }
  }

  String get description {
    switch (this) {
      case UnlockMethod.biometric:
        return '使用指纹或面容解锁';
      case UnlockMethod.password:
        return '使用6位数字密码解锁';
      case UnlockMethod.both:
        return '生物识别优先，失败后可使用密码';
    }
  }

  static UnlockMethod fromString(String? value) {
    switch (value) {
      case 'password':
        return UnlockMethod.password;
      case 'both':
        return UnlockMethod.both;
      case 'biometric':
      default:
        return UnlockMethod.biometric;
    }
  }

  String get storageValue {
    switch (this) {
      case UnlockMethod.biometric:
        return 'biometric';
      case UnlockMethod.password:
        return 'password';
      case UnlockMethod.both:
        return 'both';
    }
  }
}

/// 自动锁定时长选项
enum AutoLockDelay {
  immediate(0, '立即'),
  oneMinute(60, '1分钟后'),
  fiveMinutes(300, '5分钟后'),
  thirtyMinutes(1800, '30分钟后'),
  never(-1, '从不');

  final int seconds;
  final String label;

  const AutoLockDelay(this.seconds, this.label);

  static AutoLockDelay fromSeconds(int seconds) {
    return AutoLockDelay.values.firstWhere(
      (e) => e.seconds == seconds,
      orElse: () => AutoLockDelay.immediate,
    );
  }
}

/// 隐私锁状态
enum LockStatus {
  /// 已解锁
  unlocked,

  /// 已锁定
  locked,

  /// 正在验证
  authenticating,
}

/// 隐私锁范围
enum PrivacyLockScope {
  /// 收藏夹
  favorites,

  /// 历史记录
  history,

  /// 全部
  all,
}

/// 隐私锁范围扩展
extension PrivacyLockScopeX on PrivacyLockScope {
  String get label {
    switch (this) {
      case PrivacyLockScope.favorites:
        return '收藏夹';
      case PrivacyLockScope.history:
        return '历史记录';
      case PrivacyLockScope.all:
        return '全部';
    }
  }

  static PrivacyLockScope fromString(String? value) {
    switch (value) {
      case 'history':
        return PrivacyLockScope.history;
      case 'all':
        return PrivacyLockScope.all;
      case 'favorites':
      default:
        return PrivacyLockScope.favorites;
    }
  }

  String get storageValue {
    switch (this) {
      case PrivacyLockScope.favorites:
        return 'favorites';
      case PrivacyLockScope.history:
        return 'history';
      case PrivacyLockScope.all:
        return 'all';
    }
  }
}

/// 隐私锁 Provider
///
/// 管理隐私锁的状态，支持生物识别和密码解锁，支持锁定收藏夹、历史记录或全部内容。
/// App 从后台切回前台时根据设置自动锁定。
class PrivacyLockProvider extends ChangeNotifier {
  final SettingsProvider _settings;

  LockStatus _status = LockStatus.unlocked;
  DateTime? _lastBackgroundTime;
  bool _isLocked = false;

  /// 锁定状态
  LockStatus get status => _status;

  /// 是否已锁定
  bool get isLocked => _isLocked;

  /// 是否正在验证
  bool get isAuthenticating => _status == LockStatus.authenticating;

  /// 当前解锁方式
  UnlockMethod get unlockMethod => UnlockMethodX.fromString(_settings.privacyUnlockMethod);

  /// 自动锁定时长（秒）
  int get autoLockDelay => _settings.privacyAutoLockDelay;

  /// 是否支持生物识别
  bool _biometricAvailable = false;
  bool get biometricAvailable => _biometricAvailable;

  PrivacyLockProvider(this._settings) {
    _checkBiometricAvailability();
  }

  /// 检查生物识别可用性
  Future<void> _checkBiometricAvailability() async {
    _biometricAvailable = await BiometricService.canCheckBiometrics() &&
        await BiometricService.hasBiometrics();
    notifyListeners();
  }

  /// 刷新生物识别可用性（设置页面可能需要）
  Future<void> refreshBiometricAvailability() async {
    await _checkBiometricAvailability();
  }

  /// 检查指定页面是否需要锁定
  bool shouldLockPage(String page) {
    if (!_settings.privacyLockEnabled) return false;
    if (!_isLocked) return false;

    final scope = PrivacyLockScopeX.fromString(_settings.privacyLockScope);
    switch (scope) {
      case PrivacyLockScope.favorites:
        return page == 'favorites';
      case PrivacyLockScope.history:
        return page == 'history';
      case PrivacyLockScope.all:
        return true;
    }
  }

  /// 是否需要显示全局解锁页面（锁定范围为全部时）
  bool get shouldShowGlobalLock {
    if (!_settings.privacyLockEnabled) return false;
    if (!_isLocked) return false;
    final scope = PrivacyLockScopeX.fromString(_settings.privacyLockScope);
    return scope == PrivacyLockScope.all;
  }

  /// 立即锁定
  void lock() {
    if (!_settings.privacyLockEnabled) return;
    _isLocked = true;
    _status = LockStatus.locked;
    notifyListeners();
  }

  /// 使用生物识别解锁
  Future<bool> unlockWithBiometric() async {
    if (!_settings.privacyLockEnabled) {
      _isLocked = false;
      _status = LockStatus.unlocked;
      return true;
    }

    _status = LockStatus.authenticating;
    notifyListeners();

    final success = await BiometricService.authenticate(
      reason: '请验证身份以解锁',
    );

    if (success) {
      _isLocked = false;
      _status = LockStatus.unlocked;
    } else {
      _status = LockStatus.locked;
    }
    notifyListeners();

    return success;
  }

  /// 使用密码解锁
  bool unlockWithPassword(String password) {
    if (!_settings.privacyLockEnabled) {
      _isLocked = false;
      _status = LockStatus.unlocked;
      return true;
    }

    _status = LockStatus.authenticating;
    notifyListeners();

    final success = _settings.verifyPrivacyPassword(password);

    if (success) {
      _isLocked = false;
      _status = LockStatus.unlocked;
    } else {
      _status = LockStatus.locked;
    }
    notifyListeners();

    return success;
  }

  /// 解锁（自动选择可用的方式）
  /// 
  /// 如果支持生物识别且解锁方式允许，优先使用生物识别
  /// 否则返回 false，由 UI 决定使用密码解锁
  Future<bool> unlock() async {
    if (!_settings.privacyLockEnabled) {
      _isLocked = false;
      _status = LockStatus.unlocked;
      return true;
    }

    final method = unlockMethod;

    // 如果支持生物识别且方式允许，尝试生物识别
    if (_biometricAvailable && (method == UnlockMethod.biometric || method == UnlockMethod.both)) {
      return await unlockWithBiometric();
    }

    // 否则需要密码（由 UI 处理输入）
    return false;
  }

  /// App 进入后台
  void onAppBackground() {
    if (!_settings.privacyLockEnabled) return;
    _lastBackgroundTime = DateTime.now();
  }

  /// App 回到前台
  void onAppForeground() {
    if (!_settings.privacyLockEnabled) return;

    final delay = _settings.privacyAutoLockDelay;

    // 从不自动锁定
    if (delay < 0) {
      _lastBackgroundTime = null;
      return;
    }

    // 立即锁定
    if (delay == 0) {
      lock();
      _lastBackgroundTime = null;
      return;
    }

    // 延迟锁定：检查后台时间是否超过设定值
    final now = DateTime.now();
    if (_lastBackgroundTime != null) {
      final diff = now.difference(_lastBackgroundTime!).inSeconds;
      if (diff >= delay) {
        lock();
      }
    }
    _lastBackgroundTime = null;
  }

  /// 检查设备是否支持生物识别
  Future<bool> isBiometricAvailable() async {
    return await BiometricService.canCheckBiometrics() &&
        await BiometricService.hasBiometrics();
  }
}
