import 'package:flutter/foundation.dart';
import '../models/video_info.dart';
import '../services/history_service.dart';

class HistoryProvider extends ChangeNotifier {
  final HistoryService _service;
  final List<VideoInfo> _videos = [];
  bool _loading = false;
  bool _loadingMore = false;
  bool _hasMore = true;
  int _currentPage = 0;
  static const int _pageSize = 20;

  HistoryProvider(this._service);

  List<VideoInfo> get videos => List.unmodifiable(_videos);
  List<VideoInfo> get recentVideos => _videos.take(10).toList();
  bool get loading => _loading;
  bool get loadingMore => _loadingMore;
  bool get hasMore => _hasMore;
  int get totalCount => _service.totalCount;

  /// 加载历史记录（第一页）
  /// 
  /// 包含异常保护，确保 loading 状态始终能复位，
  /// 即使 Hive 初始化失败也不会导致 UI 永远卡在加载状态
  Future<void> loadHistory() async {
    if (_loading) return; // 避免重复加载

    _loading = true;
    notifyListeners();

    try {
      // 兜底：如果 service 未初始化，尝试初始化
      try {
        final list = _service.getPage(0, pageSize: _pageSize);
        _videos
          ..clear()
          ..addAll(list);
        _currentPage = 0;
        _hasMore = list.length >= _pageSize;
      } catch (_) {
        // 如果 getPage 失败（可能是 box 未初始化），尝试重新初始化
        await _service.init();
        final list = _service.getPage(0, pageSize: _pageSize);
        _videos
          ..clear()
          ..addAll(list);
        _currentPage = 0;
        _hasMore = list.length >= _pageSize;
      }
    } catch (e) {
      debugPrint('加载解析历史失败: $e');
      _videos.clear();
      _hasMore = false;
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  /// 加载更多（下一页）
  Future<void> loadMore() async {
    if (_loadingMore || !_hasMore || _loading) return;

    _loadingMore = true;
    notifyListeners();

    try {
      final nextPage = _currentPage + 1;
      final list = _service.getPage(nextPage, pageSize: _pageSize);
      if (list.isNotEmpty) {
        _videos.addAll(list);
        _currentPage = nextPage;
      }
      // 如果返回数量少于 pageSize，说明没有更多了
      if (list.length < _pageSize) {
        _hasMore = false;
      }
    } catch (e) {
      debugPrint('加载更多解析历史失败: $e');
    } finally {
      _loadingMore = false;
      notifyListeners();
    }
  }

  /// 刷新历史记录（重新从第 1 页开始加载）
  Future<void> refresh() async {
    _hasMore = true;
    await loadHistory();
  }

  Future<void> addVideo(VideoInfo video) async {
    await _service.add(video);
    // 添加后刷新第一页，保持列表最新
    final list = _service.getPage(0, pageSize: _pageSize);
    _videos
      ..clear()
      ..addAll(list);
    _currentPage = 0;
    _hasMore = _service.totalCount > _pageSize;
    notifyListeners();
  }

  Future<void> removeVideo(String id) async {
    await _service.remove(id);
    // 删除后重新加载当前所有已加载的数据
    final loadedCount = _videos.length;
    final list = _service.getPage(0, pageSize: loadedCount);
    _videos
      ..clear()
      ..addAll(list);
    _hasMore = _service.totalCount > loadedCount;
    notifyListeners();
  }

  /// 批量删除记录
  Future<void> removeVideos(List<String> ids) async {
    for (final id in ids) {
      await _service.remove(id);
    }
    // 删除后重新加载
    final loadedCount = _videos.length;
    final list = _service.getPage(0, pageSize: loadedCount);
    _videos
      ..clear()
      ..addAll(list);
    _hasMore = _service.totalCount > loadedCount;
    notifyListeners();
  }

  Future<void> clearHistory() async {
    await _service.clear();
    _videos.clear();
    _currentPage = 0;
    _hasMore = false;
    notifyListeners();
  }

  /// 切换收藏状态
  Future<void> toggleFavorite(String id, {String? folderId}) async {
    await _service.toggleFavorite(id, folderId: folderId);
    // 更新本地列表中的对应记录
    final index = _videos.indexWhere((v) => v.id == id);
    if (index != -1) {
      final updated = _service.getById(id);
      if (updated != null) {
        _videos[index] = updated;
      }
    }
    notifyListeners();
  }

  /// 添加到收藏（指定分组）
  Future<void> addToFavorites(String id, {String? folderId}) async {
    await _service.addToFavorites(id, folderId: folderId);
    final index = _videos.indexWhere((v) => v.id == id);
    if (index != -1) {
      final updated = _service.getById(id);
      if (updated != null) {
        _videos[index] = updated;
      }
    }
    notifyListeners();
  }

  /// 移动收藏到指定分组
  Future<void> moveToFolder(String id, String? folderId) async {
    await _service.moveToFolder(id, folderId);
    final index = _videos.indexWhere((v) => v.id == id);
    if (index != -1) {
      final updated = _service.getById(id);
      if (updated != null) {
        _videos[index] = updated;
      }
    }
    notifyListeners();
  }

  /// 批量移动收藏到指定分组
  Future<void> moveBatchToFolder(List<String> ids, String? folderId) async {
    await _service.moveBatchToFolder(ids, folderId);
    // 刷新列表
    final loadedCount = _videos.length;
    final list = _service.getPage(0, pageSize: loadedCount);
    _videos
      ..clear()
      ..addAll(list);
    notifyListeners();
  }

  /// 按分组获取收藏列表
  List<VideoInfo> getFavoritesByFolder(String? folderId) {
    return _service.getFavoritesByFolder(folderId);
  }

  /// 清除分组关联（删除分组时调用）
  Future<void> clearFolderAssociation(String folderId,
      {bool deleteFavorites = false}) async {
    await _service.clearFolderAssociation(folderId,
        deleteFavorites: deleteFavorites);
    // 刷新列表
    final loadedCount = _videos.length;
    final list = _service.getPage(0, pageSize: loadedCount);
    _videos
      ..clear()
      ..addAll(list);
    notifyListeners();
  }

  /// 判断是否已收藏
  bool isFavorite(String id) {
    return _service.isFavorite(id);
  }

  /// 批量导出为 JSON
  String exportBatch(List<String> ids) {
    return _service.exportBatch(ids);
  }

  /// 批量收藏/取消收藏
  Future<void> toggleFavoriteBatch(List<String> ids) async {
    await _service.toggleFavoriteBatch(ids);
    // 刷新列表
    final loadedCount = _videos.length;
    final list = _service.getPage(0, pageSize: loadedCount);
    _videos
      ..clear()
      ..addAll(list);
    notifyListeners();
  }
}
