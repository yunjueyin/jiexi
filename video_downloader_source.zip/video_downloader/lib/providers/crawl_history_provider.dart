import 'dart:convert';
import 'package:flutter/foundation.dart';
import '../models/crawl_record.dart';
import '../services/crawl_history_service.dart';

/// 抓取历史记录状态管理
class CrawlHistoryProvider extends ChangeNotifier {
  final CrawlHistoryService _service;
  List<CrawlRecord> _records = [];
  bool _loading = false;
  bool _loadingMore = false;
  bool _hasMore = true;
  int _currentPage = 0;
  static const int _pageSize = 20;

  CrawlHistoryProvider(this._service);

  List<CrawlRecord> get records => List.unmodifiable(_records);
  List<CrawlRecord> get authorRecords =>
      _records.where((r) => r.isAuthor).toList();
  List<CrawlRecord> get videoRecords =>
      _records.where((r) => r.isVideo).toList();
  bool get loading => _loading;
  bool get loadingMore => _loadingMore;
  bool get hasMore => _hasMore;
  int get count => _records.length;

  /// 加载历史记录（第一页）
  Future<void> loadHistory() async {
    if (_loading) return;

    _loading = true;
    notifyListeners();

    try {
      await _service.init();
      final list = _service.getPage(0, pageSize: _pageSize);
      _records
        ..clear()
        ..addAll(list);
      _currentPage = 0;
      _hasMore = list.length >= _pageSize;
    } catch (e) {
      debugPrint('加载抓取历史失败: $e');
      _records.clear();
      _hasMore = false;
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  /// 加载更多（下一页）
  Future<void> loadMore() async {
    if (_loadingMore || !_hasMore || _loading) return;

    _loadingMore = true;
    notifyListeners();

    try {
      final nextPage = _currentPage + 1;
      final list = _service.getPage(nextPage, pageSize: _pageSize);
      if (list.isNotEmpty) {
        _records.addAll(list);
        _currentPage = nextPage;
      }
      // 如果返回数量少于 pageSize，说明没有更多了
      if (list.length < _pageSize) {
        _hasMore = false;
      }
    } catch (e) {
      debugPrint('加载更多抓取历史失败: $e');
    } finally {
      _loadingMore = false;
      notifyListeners();
    }
  }

  /// 刷新历史记录（重新从第 1 页开始加载）
  Future<void> refresh() async {
    _hasMore = true;
    await loadHistory();
  }

  /// 添加抓取记录
  Future<void> addRecord(CrawlRecord record) async {
    await _service.addRecord(record);
    // 添加后刷新第一页，保持列表最新
    final list = _service.getPage(0, pageSize: _pageSize);
    _records
      ..clear()
      ..addAll(list);
    _currentPage = 0;
    _hasMore = _service.count > _pageSize;
    notifyListeners();
  }

  /// 删除单条记录
  Future<void> removeRecord(String id) async {
    await _service.removeRecord(id);
    // 删除后重新加载当前所有已加载的数据
    final loadedCount = _records.length;
    final list = _service.getPage(0, pageSize: loadedCount);
    _records
      ..clear()
      ..addAll(list);
    _hasMore = _service.count > loadedCount;
    notifyListeners();
  }

  /// 清空历史
  Future<void> clearHistory() async {
    await _service.clearAll();
    _records.clear();
    _currentPage = 0;
    _hasMore = false;
    notifyListeners();
  }

  /// 清空作者抓取历史
  Future<void> clearAuthorHistory() async {
    await _service.clearAuthorRecords();
    // 重新加载当前页
    final loadedCount = _records.length;
    final list = _service.getPage(0, pageSize: loadedCount);
    _records
      ..clear()
      ..addAll(list);
    _hasMore = _service.count > loadedCount;
    _currentPage = 0;
    notifyListeners();
  }

  /// 清空视频抓取历史
  Future<void> clearVideoHistory() async {
    await _service.clearVideoRecords();
    // 重新加载当前页
    final loadedCount = _records.length;
    final list = _service.getPage(0, pageSize: loadedCount);
    _records
      ..clear()
      ..addAll(list);
    _hasMore = _service.count > loadedCount;
    _currentPage = 0;
    notifyListeners();
  }

  /// 清空前10作品历史
  Future<void> clearTop10History() async {
    await _service.clearTop10Records();
    final loadedCount = _records.length;
    final list = _service.getPage(0, pageSize: loadedCount);
    _records
      ..clear()
      ..addAll(list);
    _hasMore = _service.count > loadedCount;
    _currentPage = 0;
    notifyListeners();
  }

  /// 批量删除记录
  Future<void> removeRecords(List<String> ids) async {
    await _service.removeBatch(ids);
    // 删除后重新加载当前所有已加载的数据
    final loadedCount = _records.length;
    final list = _service.getPage(0, pageSize: loadedCount);
    _records
      ..clear()
      ..addAll(list);
    _hasMore = _service.count > loadedCount;
    notifyListeners();
  }

  /// 判断指定记录是否已收藏
  bool isFavorite(String id) {
    return _service.isFavorite(id);
  }

  /// 切换单条记录的收藏状态
  Future<void> toggleFavorite(String id, {String? folderId}) async {
    await _service.toggleFavorite(id, folderId: folderId);
    // 更新本地列表中的对应记录
    final index = _records.indexWhere((r) => r.id == id);
    if (index != -1) {
      final updated = _service.getById(id);
      if (updated != null) {
        _records[index] = updated;
      }
    }
    notifyListeners();
  }

  /// 添加到收藏（指定分组）
  Future<void> addToFavorites(String id, {String? folderId}) async {
    await _service.addToFavorites(id, folderId: folderId);
    final index = _records.indexWhere((r) => r.id == id);
    if (index != -1) {
      final updated = _service.getById(id);
      if (updated != null) {
        _records[index] = updated;
      }
    }
    notifyListeners();
  }

  /// 移动收藏到指定分组
  Future<void> moveToFolder(String id, String? folderId) async {
    await _service.moveToFolder(id, folderId);
    final index = _records.indexWhere((r) => r.id == id);
    if (index != -1) {
      final updated = _service.getById(id);
      if (updated != null) {
        _records[index] = updated;
      }
    }
    notifyListeners();
  }

  /// 批量移动收藏到指定分组
  Future<void> moveBatchToFolder(List<String> ids, String? folderId) async {
    await _service.moveBatchToFolder(ids, folderId);
    // 刷新列表
    final loadedCount = _records.length;
    final list = _service.getPage(0, pageSize: loadedCount);
    _records
      ..clear()
      ..addAll(list);
    notifyListeners();
  }

  /// 按分组获取收藏列表
  List<CrawlRecord> getFavoritesByFolder(String? folderId) {
    return _service.getFavoritesByFolder(folderId);
  }

  /// 清除分组关联（删除分组时调用）
  Future<void> clearFolderAssociation(String folderId,
      {bool deleteFavorites = false}) async {
    await _service.clearFolderAssociation(folderId,
        deleteFavorites: deleteFavorites);
    // 刷新列表
    final loadedCount = _records.length;
    final list = _service.getPage(0, pageSize: loadedCount);
    _records
      ..clear()
      ..addAll(list);
    notifyListeners();
  }

  /// 批量收藏/取消收藏
  Future<void> toggleFavoriteBatch(List<String> ids) async {
    await _service.toggleFavoriteBatch(ids);
    // 操作后重新加载当前页
    final loadedCount = _records.length;
    final list = _service.getPage(0, pageSize: loadedCount);
    _records
      ..clear()
      ..addAll(list);
    _hasMore = _service.count > loadedCount;
    notifyListeners();
  }

  /// 批量导出为 JSON
  String exportBatch(List<String> ids) {
    final records = _records.where((r) => ids.contains(r.id)).toList();
    if (records.isEmpty) return '';
    final jsonList = records
        .map((r) => {
              'id': r.id,
              'url': r.url,
              'platform': r.platform,
              'crawlType': r.crawlType,
              'crawledAt': r.crawledAt.toIso8601String(),
              'data': r.data,
              'isFavorite': r.isFavorite,
              'favoritedAt': r.favoritedAt?.toIso8601String(),
            })
        .toList();
    return jsonEncode(jsonList);
  }

  // ==================== 断点续传相关 ====================

  /// 获取所有未完成的批次进度
  List<CrawlRecord> get incompleteBatches =>
      _service.getAllIncompleteBatchProgress();

  /// 获取未完成的作者批次数量
  int get incompleteAuthorBatchCount {
    return _service
        .getAllIncompleteBatchProgress()
        .where((r) => r.batchIsAuthor == true)
        .length;
  }

  /// 获取未完成的视频批次数量
  int get incompleteVideoBatchCount {
    return _service
        .getAllIncompleteBatchProgress()
        .where((r) => r.batchIsAuthor == false)
        .length;
  }

  /// 获取指定类型的未完成批次
  List<CrawlRecord> getIncompleteBatchesByType(bool isAuthor) {
    return _service
        .getAllIncompleteBatchProgress()
        .where((r) => r.batchIsAuthor == isAuthor)
        .toList();
  }

  /// 按 ID 获取批次进度
  CrawlRecord? getBatchProgress(String batchId) {
    return _service.getBatchProgress(batchId);
  }

  /// 清除批次进度
  Future<void> clearBatchProgress(String batchId) async {
    await _service.clearBatchProgress(batchId);
    notifyListeners();
  }
}
