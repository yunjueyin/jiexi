import 'package:flutter/foundation.dart';
import '../models/download_task.dart';
import '../models/video_info.dart';
import '../services/download_manager.dart';
import '../services/notification_service.dart';

class DownloadProvider extends ChangeNotifier {
  final DownloadManager _manager;

  DownloadProvider({DownloadManager? manager})
      : _manager = manager ?? DownloadManager() {
    _manager.onProgress = (task) {
      notifyListeners();
    };
    _manager.onComplete = (task) async {
      notifyListeners();
    };
    _manager.onError = (task, error) async {
      notifyListeners();
    };
  }

  DownloadManager get manager => _manager;
  List<DownloadTask> get tasks => _manager.tasks;
  List<DownloadTask> get downloadingTasks => _manager.downloadingTasks;
  List<DownloadTask> get completedTasks => _manager.completedTasks;
  int get activeCount => _manager.downloadingTasks.length;

  /// 获取显示的下载路径
  String get downloadPath => _manager.displayDownloadPath;

  /// 是否使用自定义路径
  bool get useCustomPath => _manager.useCustomPath;

  /// 检查存储权限
  /// 只有使用自定义路径时才需要申请权限
  Future<bool> checkPermission() {
    return _manager.checkStoragePermission();
  }

  /// 打开系统文件管理器选择目录
  Future<String?> pickDirectory() async {
    return await _manager.pickDirectory();
  }

  /// 设置自定义下载路径
  void setDownloadPath(String? path) {
    _manager.setCustomDownloadPath(path);
    notifyListeners();
  }

  /// 是否已经请求过通知权限
  bool _hasRequestedNotificationPermission = false;

  /// 添加下载任务
  Future<DownloadTask> addDownload(VideoInfo video, String quality) async {
    // 第一次下载时请求通知权限（Android 13+ 需要）
    if (!_hasRequestedNotificationPermission) {
      _hasRequestedNotificationPermission = true;
      // 不阻塞下载流程，后台请求
      NotificationService.instance.requestPermission();
    }

    final task = await _manager.createTask(video, quality);
    notifyListeners();
    return task;
  }

  /// 添加纯音频下载任务
  Future<DownloadTask> addAudioDownload(
    VideoInfo video,
    String quality, {
    String audioFormat = 'mp3',
  }) async {
    if (!_hasRequestedNotificationPermission) {
      _hasRequestedNotificationPermission = true;
      NotificationService.instance.requestPermission();
    }

    final task = await _manager.createAudioTask(
      video,
      quality,
      audioFormat: audioFormat,
    );
    notifyListeners();
    return task;
  }

  /// 从已下载的视频中提取音频
  Future<String> extractAudio({
    required String videoPath,
    required String outputDir,
    String audioFormat = 'mp3',
  }) async {
    return await _manager.extractAudio(
      videoPath: videoPath,
      outputDir: outputDir,
      audioFormat: audioFormat,
    );
  }

  void pauseTask(String taskId) {
    _manager.pauseTask(taskId);
    notifyListeners();
  }

  void resumeTask(String taskId) {
    _manager.resumeTask(taskId);
    notifyListeners();
  }

  void cancelTask(String taskId) {
    _manager.cancelTask(taskId);
    notifyListeners();
  }

  void removeTask(String taskId, {bool deleteFile = false}) {
    _manager.removeTask(taskId, deleteFile: deleteFile);
    notifyListeners();
  }

  /// 撤销最后一次删除
  DownloadTask? undoLastRemove() {
    final task = _manager.undoLastRemove();
    if (task != null) {
      notifyListeners();
    }
    return task;
  }

  /// 根据视频 ID 列表删除相关下载任务和文件
  int removeTasksByVideoIds(List<String> videoIds, {bool deleteFile = false}) {
    final count = _manager.removeTasksByVideoIds(videoIds, deleteFile: deleteFile);
    if (count > 0) {
      notifyListeners();
    }
    return count;
  }

  void clearCompleted() {
    _manager.clearCompleted();
    notifyListeners();
  }
}
