// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'video_info.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class VideoInfoAdapter extends TypeAdapter<VideoInfo> {
  @override
  final int typeId = 0;

  @override
  VideoInfo read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return VideoInfo(
      id: fields[0] as String,
      url: fields[1] as String,
      platform: fields[2] as String,
      title: fields[3] as String,
      author: fields[4] as String,
      cover: fields[5] as String,
      videoUrl: fields[6] as String?,
      videoUrlHd: fields[7] as String?,
      durationSeconds: fields[8] as int?,
      parsedAt: fields[9] as DateTime,
      type: fields[10] as String,
      images: (fields[11] as List?)?.cast<String>(),
      isFavorite: fields[20] as bool? ?? false,
      favoritedAt: fields[21] as DateTime?,
      favoriteFolderId: fields[22] as String?,
    );
  }

  @override
  void write(BinaryWriter writer, VideoInfo obj) {
    writer
      ..writeByte(15)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.url)
      ..writeByte(2)
      ..write(obj.platform)
      ..writeByte(3)
      ..write(obj.title)
      ..writeByte(4)
      ..write(obj.author)
      ..writeByte(5)
      ..write(obj.cover)
      ..writeByte(6)
      ..write(obj.videoUrl)
      ..writeByte(7)
      ..write(obj.videoUrlHd)
      ..writeByte(8)
      ..write(obj.durationSeconds)
      ..writeByte(9)
      ..write(obj.parsedAt)
      ..writeByte(10)
      ..write(obj.type)
      ..writeByte(11)
      ..write(obj.images)
      ..writeByte(20)
      ..write(obj.isFavorite)
      ..writeByte(21)
      ..write(obj.favoritedAt)
      ..writeByte(22)
      ..write(obj.favoriteFolderId);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is VideoInfoAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
