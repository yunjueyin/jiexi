import 'package:hive/hive.dart';

part 'convert_queue_item.g.dart';

/// 转换任务状态
@HiveType(typeId: 14)
enum ConvertQueueStatus {
  /// 等待中
  @HiveField(0)
  pending,

  /// 转换中
  @HiveField(1)
  processing,

  /// 已完成
  @HiveField(2)
  completed,

  /// 失败
  @HiveField(3)
  failed,
}

/// 转换类型
@HiveType(typeId: 15)
enum ConvertQueueType {
  /// 转短链
  @HiveField(0)
  toShort,

  /// 转长链
  @HiveField(1)
  toLong,
}

/// 转换队列项
@HiveType(typeId: 16)
class ConvertQueueItem extends HiveObject {
  /// 唯一标识
  @HiveField(0)
  final String id;

  /// 原始 URL
  @HiveField(1)
  String originalUrl;

  /// 结果 URL
  @HiveField(2)
  String? resultUrl;

  /// 平台
  @HiveField(3)
  String? platform;

  /// 转换类型
  @HiveField(4)
  ConvertQueueType convertType;

  /// 状态
  @HiveField(5)
  ConvertQueueStatus status;

  /// 错误信息
  @HiveField(6)
  String? errorMessage;

  /// 创建时间
  @HiveField(7)
  DateTime createdAt;

  /// 开始时间
  @HiveField(8)
  DateTime? startedAt;

  /// 完成时间
  @HiveField(9)
  DateTime? completedAt;

  /// 视频标题（从下载记录添加时使用）
  @HiveField(10)
  String? videoTitle;

  /// 来源（如 'download' 表示从下载记录添加）
  @HiveField(11)
  String? source;

  ConvertQueueItem({
    required this.id,
    required this.originalUrl,
    this.resultUrl,
    this.platform,
    required this.convertType,
    this.status = ConvertQueueStatus.pending,
    this.errorMessage,
    DateTime? createdAt,
    this.startedAt,
    this.completedAt,
    this.videoTitle,
    this.source,
  }) : createdAt = createdAt ?? DateTime.now();

  /// 状态显示文本
  String get statusLabel {
    switch (status) {
      case ConvertQueueStatus.pending:
        return '等待中';
      case ConvertQueueStatus.processing:
        return '转换中';
      case ConvertQueueStatus.completed:
        return '已完成';
      case ConvertQueueStatus.failed:
        return '失败';
    }
  }

  /// 转换类型显示文本
  String get typeLabel {
    switch (convertType) {
      case ConvertQueueType.toShort:
        return '转短链';
      case ConvertQueueType.toLong:
        return '转长链';
    }
  }
}
