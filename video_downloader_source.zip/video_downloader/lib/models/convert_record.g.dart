// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'convert_record.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class ConvertRecordAdapter extends TypeAdapter<ConvertRecord> {
  @override
  final int typeId = 4;

  @override
  ConvertRecord read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return ConvertRecord(
      id: fields[0] as String,
      originalUrl: fields[1] as String,
      resultUrl: fields[2] as String,
      platform: fields[3] as String,
      convertType: fields[4] as String,
      convertedAt: fields[5] as DateTime,
      batchId: fields[6] as String?,
      success: fields[7] as bool,
      errorMessage: fields[8] as String?,
    );
  }

  @override
  void write(BinaryWriter writer, ConvertRecord obj) {
    writer
      ..writeByte(9)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.originalUrl)
      ..writeByte(2)
      ..write(obj.resultUrl)
      ..writeByte(3)
      ..write(obj.platform)
      ..writeByte(4)
      ..write(obj.convertType)
      ..writeByte(5)
      ..write(obj.convertedAt)
      ..writeByte(6)
      ..write(obj.batchId)
      ..writeByte(7)
      ..write(obj.success)
      ..writeByte(8)
      ..write(obj.errorMessage);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ConvertRecordAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
