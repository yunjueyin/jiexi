import 'package:hive/hive.dart';

part 'custom_api_source.g.dart';

/// 请求方式
@HiveType(typeId: 11)
enum HttpRequestMethod {
  @HiveField(0)
  get,
  @HiveField(1)
  post,
}

/// 自定义解析源
@HiveType(typeId: 8)
class CustomApiSource extends HiveObject {
  /// 唯一标识
  @HiveField(0)
  final String id;

  /// 名称
  @HiveField(1)
  String name;

  /// API URL
  @HiveField(2)
  String apiUrl;

  /// 请求方式
  @HiveField(3)
  HttpRequestMethod method;

  /// 请求头模板（JSON 字符串，支持占位符如 {{url}}、{{key}}）
  @HiveField(4)
  String? headersTemplate;

  /// 请求体模板（POST 时使用，支持占位符）
  @HiveField(5)
  String? bodyTemplate;

  /// 优先级（数字越小优先级越高，从 0 开始）
  @HiveField(6)
  int priority;

  /// 权重（用于加权随机选择，值越大选中概率越高）
  @HiveField(7)
  int weight;

  /// 支持的平台
  @HiveField(8)
  List<String> supportedPlatforms;

  /// 是否启用
  @HiveField(9)
  bool enabled;

  /// API Key 参数名
  @HiveField(10)
  String? apiKeyParam;

  /// API Key
  @HiveField(11)
  String? apiKey;

  /// 响应解析路径（JSON path，如 data.videoUrl）
  @HiveField(12)
  String? responsePath;

  /// 备注
  @HiveField(13)
  String? remark;

  /// 创建时间
  @HiveField(14)
  DateTime createdAt;

  /// 是否为内置源（false 表示用户自定义）
  @HiveField(15)
  bool isBuiltIn;

  /// 上次使用时间
  @HiveField(16)
  DateTime? lastUsedAt;

  CustomApiSource({
    required this.id,
    required this.name,
    required this.apiUrl,
    this.method = HttpRequestMethod.get,
    this.headersTemplate,
    this.bodyTemplate,
    this.priority = 100,
    this.weight = 1,
    this.supportedPlatforms = const ['douyin', 'kuaishou'],
    this.enabled = true,
    this.apiKeyParam,
    this.apiKey,
    this.responsePath,
    this.remark,
    DateTime? createdAt,
    this.isBuiltIn = false,
    this.lastUsedAt,
  }) : createdAt = createdAt ?? DateTime.now();

  /// 显示名称（带状态）
  String get displayName => name;

  /// 请求方式显示文本
  String get methodLabel {
    switch (method) {
      case HttpRequestMethod.get:
        return 'GET';
      case HttpRequestMethod.post:
        return 'POST';
    }
  }

  /// 支持的平台显示文本
  String get platformsLabel {
    const labels = {
      'douyin': '抖音',
      'kuaishou': '快手',
      'xiaohongshu': '小红书',
    };
    return supportedPlatforms
        .map((p) => labels[p] ?? p)
        .join('、');
  }

  /// 复制
  CustomApiSource copyWith({
    String? id,
    String? name,
    String? apiUrl,
    HttpRequestMethod? method,
    String? headersTemplate,
    String? bodyTemplate,
    int? priority,
    int? weight,
    List<String>? supportedPlatforms,
    bool? enabled,
    String? apiKeyParam,
    String? apiKey,
    String? responsePath,
    String? remark,
    DateTime? createdAt,
    bool? isBuiltIn,
    DateTime? lastUsedAt,
  }) {
    return CustomApiSource(
      id: id ?? this.id,
      name: name ?? this.name,
      apiUrl: apiUrl ?? this.apiUrl,
      method: method ?? this.method,
      headersTemplate: headersTemplate ?? this.headersTemplate,
      bodyTemplate: bodyTemplate ?? this.bodyTemplate,
      priority: priority ?? this.priority,
      weight: weight ?? this.weight,
      supportedPlatforms: supportedPlatforms ?? List.from(this.supportedPlatforms),
      enabled: enabled ?? this.enabled,
      apiKeyParam: apiKeyParam ?? this.apiKeyParam,
      apiKey: apiKey ?? this.apiKey,
      responsePath: responsePath ?? this.responsePath,
      remark: remark ?? this.remark,
      createdAt: createdAt ?? this.createdAt,
      isBuiltIn: isBuiltIn ?? this.isBuiltIn,
      lastUsedAt: lastUsedAt ?? this.lastUsedAt,
    );
  }
}
