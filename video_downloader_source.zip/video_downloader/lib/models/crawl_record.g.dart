// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'crawl_record.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class CrawlRecordAdapter extends TypeAdapter<CrawlRecord> {
  @override
  final int typeId = 3;

  @override
  CrawlRecord read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return CrawlRecord(
      id: fields[0] as String,
      url: fields[1] as String,
      platform: fields[2] as String,
      crawlType: fields[3] as String,
      crawledAt: fields[4] as DateTime,
      data: (fields[5] as Map).cast<String, dynamic>(),
      rawData: (fields[6] as Map?)?.cast<String, dynamic>(),
      batchId: fields[7] as String?,
      batchTotal: fields[8] as int,
      batchCompleted: fields[9] as int,
      batchCursor: fields[10] as String?,
      batchUrls: (fields[11] as List?)?.cast<String>(),
      batchCurrentIndex: fields[12] as int,
      batchFields: (fields[13] as List?)?.cast<String>(),
      batchIsAuthor: fields[14] as bool?,
      batchStatus: fields[15] as String?,
      isFavorite: fields[16] as bool? ?? false,
      favoritedAt: fields[17] as DateTime?,
      favoriteFolderId: fields[18] as String?,
    );
  }

  @override
  void write(BinaryWriter writer, CrawlRecord obj) {
    writer
      ..writeByte(19)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.url)
      ..writeByte(2)
      ..write(obj.platform)
      ..writeByte(3)
      ..write(obj.crawlType)
      ..writeByte(4)
      ..write(obj.crawledAt)
      ..writeByte(5)
      ..write(obj.data)
      ..writeByte(6)
      ..write(obj.rawData)
      ..writeByte(7)
      ..write(obj.batchId)
      ..writeByte(8)
      ..write(obj.batchTotal)
      ..writeByte(9)
      ..write(obj.batchCompleted)
      ..writeByte(10)
      ..write(obj.batchCursor)
      ..writeByte(11)
      ..write(obj.batchUrls)
      ..writeByte(12)
      ..write(obj.batchCurrentIndex)
      ..writeByte(13)
      ..write(obj.batchFields)
      ..writeByte(14)
      ..write(obj.batchIsAuthor)
      ..writeByte(15)
      ..write(obj.batchStatus)
      ..writeByte(16)
      ..write(obj.isFavorite)
      ..writeByte(17)
      ..write(obj.favoritedAt)
      ..writeByte(18)
      ..write(obj.favoriteFolderId);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is CrawlRecordAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
