// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'transcode_task.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class TranscodeTaskAdapter extends TypeAdapter<TranscodeTask> {
  @override
  final int typeId = 5;

  @override
  TranscodeTask read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return TranscodeTask(
      id: fields[0] as String,
      sourcePath: fields[1] as String,
      outputPath: fields[2] as String,
      sourceFileName: fields[3] as String,
      outputFileName: fields[4] as String,
      transcodeType: fields[5] as String,
      targetFormat: fields[6] as String,
      targetResolution: fields[7] as String?,
      targetBitrate: fields[8] as int?,
      status: fields[9] as TranscodeStatus,
      progress: fields[10] as double,
      createdAt: fields[11] as DateTime,
      completedAt: fields[12] as DateTime?,
      errorMessage: fields[13] as String?,
      sourceSizeBytes: fields[14] as int,
      outputSizeBytes: fields[15] as int?,
      videoCover: fields[16] as String?,
      videoTitle: fields[17] as String?,
    );
  }

  @override
  void write(BinaryWriter writer, TranscodeTask obj) {
    writer
      ..writeByte(18)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.sourcePath)
      ..writeByte(2)
      ..write(obj.outputPath)
      ..writeByte(3)
      ..write(obj.sourceFileName)
      ..writeByte(4)
      ..write(obj.outputFileName)
      ..writeByte(5)
      ..write(obj.transcodeType)
      ..writeByte(6)
      ..write(obj.targetFormat)
      ..writeByte(7)
      ..write(obj.targetResolution)
      ..writeByte(8)
      ..write(obj.targetBitrate)
      ..writeByte(9)
      ..write(obj.status)
      ..writeByte(10)
      ..write(obj.progress)
      ..writeByte(11)
      ..write(obj.createdAt)
      ..writeByte(12)
      ..write(obj.completedAt)
      ..writeByte(13)
      ..write(obj.errorMessage)
      ..writeByte(14)
      ..write(obj.sourceSizeBytes)
      ..writeByte(15)
      ..write(obj.outputSizeBytes)
      ..writeByte(16)
      ..write(obj.videoCover)
      ..writeByte(17)
      ..write(obj.videoTitle);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is TranscodeTaskAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class TranscodeStatusAdapter extends TypeAdapter<TranscodeStatus> {
  @override
  final int typeId = 10;

  @override
  TranscodeStatus read(BinaryReader reader) {
    switch (reader.readByte()) {
      case 0:
        return TranscodeStatus.queued;
      case 1:
        return TranscodeStatus.processing;
      case 2:
        return TranscodeStatus.completed;
      case 3:
        return TranscodeStatus.failed;
      case 4:
        return TranscodeStatus.canceled;
      default:
        return TranscodeStatus.queued;
    }
  }

  @override
  void write(BinaryWriter writer, TranscodeStatus obj) {
    switch (obj) {
      case TranscodeStatus.queued:
        writer.writeByte(0);
        break;
      case TranscodeStatus.processing:
        writer.writeByte(1);
        break;
      case TranscodeStatus.completed:
        writer.writeByte(2);
        break;
      case TranscodeStatus.failed:
        writer.writeByte(3);
        break;
      case TranscodeStatus.canceled:
        writer.writeByte(4);
        break;
    }
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is TranscodeStatusAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class TranscodeTypeAdapter extends TypeAdapter<TranscodeType> {
  @override
  final int typeId = 11;

  @override
  TranscodeType read(BinaryReader reader) {
    switch (reader.readByte()) {
      case 0:
        return TranscodeType.video;
      case 1:
        return TranscodeType.audio;
      case 2:
        return TranscodeType.videoCompress;
      default:
        return TranscodeType.video;
    }
  }

  @override
  void write(BinaryWriter writer, TranscodeType obj) {
    switch (obj) {
      case TranscodeType.video:
        writer.writeByte(0);
        break;
      case TranscodeType.audio:
        writer.writeByte(1);
        break;
      case TranscodeType.videoCompress:
        writer.writeByte(2);
        break;
    }
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is TranscodeTypeAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
