// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'download_task.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class DownloadTaskAdapter extends TypeAdapter<DownloadTask> {
  @override
  final int typeId = 2;

  @override
  DownloadTask read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return DownloadTask(
      id: fields[0] as String,
      videoId: fields[1] as String,
      videoUrl: fields[2] as String,
      savePath: fields[3] as String,
      fileName: fields[4] as String,
      totalBytes: fields[5] as int,
      receivedBytes: fields[6] as int,
      status: fields[7] as DownloadStatus,
      progress: fields[8] as double,
      createdAt: fields[9] as DateTime,
      completedAt: fields[10] as DateTime?,
      quality: fields[11] as String,
      videoTitle: fields[12] as String,
      videoCover: fields[13] as String,
      platform: fields[14] as String,
      errorMessage: fields[15] as String?,
      groupId: fields[16] as String?,
      isImage: fields[17] as bool,
      groupTotal: fields[18] as int?,
      groupIndex: fields[19] as int?,
      speedBytesPerSecond: fields[20] as int,
      remainingSeconds: fields[21] as int,
    );
  }

  @override
  void write(BinaryWriter writer, DownloadTask obj) {
    writer
      ..writeByte(22)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.videoId)
      ..writeByte(2)
      ..write(obj.videoUrl)
      ..writeByte(3)
      ..write(obj.savePath)
      ..writeByte(4)
      ..write(obj.fileName)
      ..writeByte(5)
      ..write(obj.totalBytes)
      ..writeByte(6)
      ..write(obj.receivedBytes)
      ..writeByte(7)
      ..write(obj.status)
      ..writeByte(8)
      ..write(obj.progress)
      ..writeByte(9)
      ..write(obj.createdAt)
      ..writeByte(10)
      ..write(obj.completedAt)
      ..writeByte(11)
      ..write(obj.quality)
      ..writeByte(12)
      ..write(obj.videoTitle)
      ..writeByte(13)
      ..write(obj.videoCover)
      ..writeByte(14)
      ..write(obj.platform)
      ..writeByte(15)
      ..write(obj.errorMessage)
      ..writeByte(16)
      ..write(obj.groupId)
      ..writeByte(17)
      ..write(obj.isImage)
      ..writeByte(18)
      ..write(obj.groupTotal)
      ..writeByte(19)
      ..write(obj.groupIndex)
      ..writeByte(20)
      ..write(obj.speedBytesPerSecond)
      ..writeByte(21)
      ..write(obj.remainingSeconds);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is DownloadTaskAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class DownloadStatusAdapter extends TypeAdapter<DownloadStatus> {
  @override
  final int typeId = 1;

  @override
  DownloadStatus read(BinaryReader reader) {
    switch (reader.readByte()) {
      case 0:
        return DownloadStatus.queued;
      case 1:
        return DownloadStatus.downloading;
      case 2:
        return DownloadStatus.paused;
      case 3:
        return DownloadStatus.completed;
      case 4:
        return DownloadStatus.failed;
      case 5:
        return DownloadStatus.canceled;
      default:
        return DownloadStatus.queued;
    }
  }

  @override
  void write(BinaryWriter writer, DownloadStatus obj) {
    switch (obj) {
      case DownloadStatus.queued:
        writer.writeByte(0);
        break;
      case DownloadStatus.downloading:
        writer.writeByte(1);
        break;
      case DownloadStatus.paused:
        writer.writeByte(2);
        break;
      case DownloadStatus.completed:
        writer.writeByte(3);
        break;
      case DownloadStatus.failed:
        writer.writeByte(4);
        break;
      case DownloadStatus.canceled:
        writer.writeByte(5);
        break;
    }
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is DownloadStatusAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
