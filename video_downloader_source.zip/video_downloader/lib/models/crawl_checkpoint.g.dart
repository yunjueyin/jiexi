// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'crawl_checkpoint.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class CrawlCheckpointAdapter extends TypeAdapter<CrawlCheckpoint> {
  @override
  final int typeId = 6;

  @override
  CrawlCheckpoint read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return CrawlCheckpoint(
      authorKey: fields[0] as String,
      platform: fields[1] as String,
      authorId: fields[2] as String,
      nickname: fields[3] as String?,
      lastCrawlAt: fields[4] as DateTime,
      lastVideoPublishTime: fields[5] as DateTime?,
      lastVideoId: fields[6] as String?,
      totalVideoCount: fields[7] as int,
      cursor: fields[8] as String?,
    );
  }

  @override
  void write(BinaryWriter writer, CrawlCheckpoint obj) {
    writer
      ..writeByte(9)
      ..writeByte(0)
      ..write(obj.authorKey)
      ..writeByte(1)
      ..write(obj.platform)
      ..writeByte(2)
      ..write(obj.authorId)
      ..writeByte(3)
      ..write(obj.nickname)
      ..writeByte(4)
      ..write(obj.lastCrawlAt)
      ..writeByte(5)
      ..write(obj.lastVideoPublishTime)
      ..writeByte(6)
      ..write(obj.lastVideoId)
      ..writeByte(7)
      ..write(obj.totalVideoCount)
      ..writeByte(8)
      ..write(obj.cursor);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is CrawlCheckpointAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
