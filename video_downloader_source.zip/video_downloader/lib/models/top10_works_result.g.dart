// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'top10_works_result.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class Top10WorkAdapter extends TypeAdapter<Top10Work> {
  @override
  final int typeId = 13;

  @override
  Top10Work read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return Top10Work(
      videoId: fields[0] as String,
      title: fields[1] as String,
      cover: fields[2] as String,
      likeCount: fields[3] as int,
      collectCount: fields[4] as int,
      commentCount: fields[5] as int,
      publishTime: fields[6] as DateTime,
      shareCount: fields[7] as int?,
      playCount: fields[8] as int?,
    );
  }

  @override
  void write(BinaryWriter writer, Top10Work obj) {
    writer
      ..writeByte(9)
      ..writeByte(0)
      ..write(obj.videoId)
      ..writeByte(1)
      ..write(obj.title)
      ..writeByte(2)
      ..write(obj.cover)
      ..writeByte(3)
      ..write(obj.likeCount)
      ..writeByte(4)
      ..write(obj.collectCount)
      ..writeByte(5)
      ..write(obj.commentCount)
      ..writeByte(6)
      ..write(obj.publishTime)
      ..writeByte(7)
      ..write(obj.shareCount)
      ..writeByte(8)
      ..write(obj.playCount);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Top10WorkAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class Top10WorksResultAdapter extends TypeAdapter<Top10WorksResult> {
  @override
  final int typeId = 12;

  @override
  Top10WorksResult read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return Top10WorksResult(
      id: fields[0] as String,
      url: fields[1] as String,
      platform: fields[2] as String,
      authorId: fields[3] as String,
      authorName: fields[4] as String,
      authorAvatar: fields[5] as String?,
      works: (fields[6] as List).cast<Top10Work>(),
      totalLikes: fields[7] as int,
      totalCollects: fields[8] as int,
      totalComments: fields[9] as int,
      avgLikes: fields[10] as double,
      avgCollects: fields[11] as double,
      avgComments: fields[12] as double,
      medianLikes: fields[13] as double,
      medianCollects: fields[14] as double,
      medianComments: fields[15] as double,
      crawledAt: fields[16] as DateTime,
    );
  }

  @override
  void write(BinaryWriter writer, Top10WorksResult obj) {
    writer
      ..writeByte(17)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.url)
      ..writeByte(2)
      ..write(obj.platform)
      ..writeByte(3)
      ..write(obj.authorId)
      ..writeByte(4)
      ..write(obj.authorName)
      ..writeByte(5)
      ..write(obj.authorAvatar)
      ..writeByte(6)
      ..write(obj.works)
      ..writeByte(7)
      ..write(obj.totalLikes)
      ..writeByte(8)
      ..write(obj.totalCollects)
      ..writeByte(9)
      ..write(obj.totalComments)
      ..writeByte(10)
      ..write(obj.avgLikes)
      ..writeByte(11)
      ..write(obj.avgCollects)
      ..writeByte(12)
      ..write(obj.avgComments)
      ..writeByte(13)
      ..write(obj.medianLikes)
      ..writeByte(14)
      ..write(obj.medianCollects)
      ..writeByte(15)
      ..write(obj.medianComments)
      ..writeByte(16)
      ..write(obj.crawledAt);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Top10WorksResultAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
