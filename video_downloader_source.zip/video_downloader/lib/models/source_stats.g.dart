// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'source_stats.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class SourceStatsAdapter extends TypeAdapter<SourceStats> {
  @override
  final int typeId = 9;

  @override
  SourceStats read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return SourceStats(
      sourceId: fields[0] as String,
      sourceName: fields[1] as String,
      totalRequests: fields[2] as int,
      successCount: fields[3] as int,
      failureCount: fields[4] as int,
      totalDurationMs: fields[5] as int,
      lastUsedAt: fields[6] as DateTime?,
      failureReasons: (fields[7] as Map).cast<String, int>(),
      recentDurations: (fields[8] as List).cast<int>(),
    );
  }

  @override
  void write(BinaryWriter writer, SourceStats obj) {
    writer
      ..writeByte(9)
      ..writeByte(0)
      ..write(obj.sourceId)
      ..writeByte(1)
      ..write(obj.sourceName)
      ..writeByte(2)
      ..write(obj.totalRequests)
      ..writeByte(3)
      ..write(obj.successCount)
      ..writeByte(4)
      ..write(obj.failureCount)
      ..writeByte(5)
      ..write(obj.totalDurationMs)
      ..writeByte(6)
      ..write(obj.lastUsedAt)
      ..writeByte(7)
      ..write(obj.failureReasons)
      ..writeByte(8)
      ..write(obj.recentDurations);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is SourceStatsAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
