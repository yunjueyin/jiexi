// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'custom_api_source.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class CustomApiSourceAdapter extends TypeAdapter<CustomApiSource> {
  @override
  final int typeId = 8;

  @override
  CustomApiSource read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return CustomApiSource(
      id: fields[0] as String,
      name: fields[1] as String,
      apiUrl: fields[2] as String,
      method: fields[3] as HttpRequestMethod,
      headersTemplate: fields[4] as String?,
      bodyTemplate: fields[5] as String?,
      priority: fields[6] as int,
      weight: fields[7] as int,
      supportedPlatforms: (fields[8] as List).cast<String>(),
      enabled: fields[9] as bool,
      apiKeyParam: fields[10] as String?,
      apiKey: fields[11] as String?,
      responsePath: fields[12] as String?,
      remark: fields[13] as String?,
      createdAt: fields[14] as DateTime,
      isBuiltIn: fields[15] as bool,
      lastUsedAt: fields[16] as DateTime?,
    );
  }

  @override
  void write(BinaryWriter writer, CustomApiSource obj) {
    writer
      ..writeByte(17)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.name)
      ..writeByte(2)
      ..write(obj.apiUrl)
      ..writeByte(3)
      ..write(obj.method)
      ..writeByte(4)
      ..write(obj.headersTemplate)
      ..writeByte(5)
      ..write(obj.bodyTemplate)
      ..writeByte(6)
      ..write(obj.priority)
      ..writeByte(7)
      ..write(obj.weight)
      ..writeByte(8)
      ..write(obj.supportedPlatforms)
      ..writeByte(9)
      ..write(obj.enabled)
      ..writeByte(10)
      ..write(obj.apiKeyParam)
      ..writeByte(11)
      ..write(obj.apiKey)
      ..writeByte(12)
      ..write(obj.responsePath)
      ..writeByte(13)
      ..write(obj.remark)
      ..writeByte(14)
      ..write(obj.createdAt)
      ..writeByte(15)
      ..write(obj.isBuiltIn)
      ..writeByte(16)
      ..write(obj.lastUsedAt);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is CustomApiSourceAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class HttpRequestMethodAdapter extends TypeAdapter<HttpRequestMethod> {
  @override
  final int typeId = 11;

  @override
  HttpRequestMethod read(BinaryReader reader) {
    switch (reader.readByte()) {
      case 0:
        return HttpRequestMethod.get;
      case 1:
        return HttpRequestMethod.post;
      default:
        return HttpRequestMethod.get;
    }
  }

  @override
  void write(BinaryWriter writer, HttpRequestMethod obj) {
    switch (obj) {
      case HttpRequestMethod.get:
        writer.writeByte(0);
        break;
      case HttpRequestMethod.post:
        writer.writeByte(1);
        break;
    }
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is HttpRequestMethodAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
