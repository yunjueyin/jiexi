import 'package:hive/hive.dart';

part 'convert_record.g.dart';

/// 转换类型
enum ConvertType {
  /// 转短链（干净的视频ID链接）
  toShort,
  /// 转长链（完整带参数）
  toLong,
}

/// 转换记录（Hive 持久化）
@HiveType(typeId: 4)
class ConvertRecord extends HiveObject {
  /// 唯一 ID
  @HiveField(0)
  final String id;

  /// 原始链接
  @HiveField(1)
  final String originalUrl;

  /// 转换结果链接
  @HiveField(2)
  final String resultUrl;

  /// 平台（douyin / kuaishou）
  @HiveField(3)
  final String platform;

  /// 转换类型（toShort / toLong）
  @HiveField(4)
  final String convertType;

  /// 转换时间
  @HiveField(5)
  final DateTime convertedAt;

  /// 批次 ID（批量转换时同一批次共享）
  @HiveField(6)
  final String? batchId;

  /// 是否成功
  @HiveField(7)
  final bool success;

  /// 错误信息（失败时）
  @HiveField(8)
  final String? errorMessage;

  ConvertRecord({
    required this.id,
    required this.originalUrl,
    required this.resultUrl,
    required this.platform,
    required this.convertType,
    required this.convertedAt,
    this.batchId,
    this.success = true,
    this.errorMessage,
  });

  /// 是否为转短链
  bool get isToShort => convertType == 'toShort';

  /// 是否为转长链
  bool get isToLong => convertType == 'toLong';

  String get platformName {
    switch (platform) {
      case 'douyin':
        return '抖音';
      case 'kuaishou':
        return '快手';
      default:
        return '未知';
    }
  }

  String get typeLabel {
    switch (convertType) {
      case 'toShort':
        return '转短链';
      case 'toLong':
        return '转长链';
      default:
        return '未知';
    }
  }

  /// 获取显示用的简短标题
  String get displayTitle {
    if (success) {
      // 从结果链接中提取视频ID作为标题
      final videoId = _extractVideoId(resultUrl);
      return videoId ?? '转换成功';
    } else {
      return '转换失败';
    }
  }

  String? _extractVideoId(String url) {
    // 抖音 video/xxx
    final douyinMatch = RegExp(r'video\/(\d+)').firstMatch(url);
    if (douyinMatch != null) {
      return douyinMatch.group(1);
    }
    // 快手 short-video/xxx
    final kuaishouMatch = RegExp(r'short-video\/([a-zA-Z0-9]+)').firstMatch(url);
    if (kuaishouMatch != null) {
      return kuaishouMatch.group(1);
    }
    return null;
  }
}
