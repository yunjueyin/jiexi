class AppSettings {
  final String defaultQuality;
  final String? customApiUrl;
  final String apiSourceId;
  final String downloadPath;
  final bool wifiOnly;
  final bool autoParseClipboard;
  final bool autoDownloadOnShare;
  /// UID 补全服务 URL（如 Supabase Edge Function）
  /// 配置后，作者 uid 抓不到纯数字时会调用该服务补全
  final String? uidResolveServiceUrl;

  /// 各 API 源的 API Key（key 为 sourceId）
  final Map<String, String> apiKeys;

  /// 下载完成后是否播放音效
  final bool downloadSoundEnabled;

  /// 下载完成音效类型：'ding'、'chime'、'success'、'pop'
  final String downloadSoundType;

  /// 下载完成后的默认行为：'none'（无）、'open'（自动打开）、'share'（自动分享）
  final String downloadCompleteAction;

  /// 是否按平台分类保存（在下载目录下创建平台子文件夹）
  final bool organizeByPlatform;

  /// 抖音网页版 Cookie（用于需要登录态的解析场景）
  final Map<String, String> douyinCookies;

  /// 触觉反馈是否开启
  final bool hapticFeedbackEnabled;

  /// 触觉反馈强度：'light'、'medium'、'heavy'
  final String hapticFeedbackLevel;

  /// 下载完成通知是否开启
  final bool downloadNotificationEnabled;

  /// 自动粘贴剪贴板并解析下载（默认关闭）
  final bool autoPasteAndDownload;

  /// 剪贴板检测是否开启（默认开启）
  /// 开启后首页会检测剪贴板中的可解析链接并显示提示条
  final bool clipboardDetectionEnabled;

  /// 批量抓取间隔时间（毫秒），默认 1000ms
  final int crawlIntervalMs;

  /// 抓取间隔随机抖动范围（毫秒），默认 500ms
  /// 实际间隔 = crawlIntervalMs ± 随机值(0 ~ crawlJitterMs)
  final int crawlJitterMs;

  /// UI 密度级别：'compact'（紧凑）、'standard'（标准）、'large'（长辈）
  final String uiDensity;

  /// 解析重试次数（不含首次），默认 2 次
  final int parseRetryCount;

  /// 抓取重试次数（不含首次），默认 2 次
  final int crawlRetryCount;

  /// 同时下载的最大任务数，默认 2，范围 1-5
  final int downloadConcurrency;

  /// 摇一摇解析是否开启（默认关闭）
  final bool shakeToParseEnabled;

  /// 隐私锁是否开启
  final bool privacyLockEnabled;

  /// 隐私锁范围：'favorites'（收藏夹）、'history'（历史记录）、'all'（全部）
  final String privacyLockScope;

  /// 解锁方式：'biometric'（仅生物识别）、'password'（仅密码）、'both'（两者都可以）
  final String privacyUnlockMethod;

  /// 应用密码哈希（SHA256），仅当使用密码解锁时有效
  final String? privacyPasswordHash;

  /// 自动锁定时长（秒）：0=立即，60=1分钟，300=5分钟，1800=30分钟，-1=从不
  final int privacyAutoLockDelay;

  /// 主题模式：'light'（浅色）、'dark'（深色）、'system'（跟随系统）、'scheduled'（定时切换）
  final String themeMode;

  /// 主题色标识：'cyan'（青色）、'blue'（蓝色）、'purple'（紫色）、'green'（绿色）、'orange'（橙色）、'pink'（粉色）
  final String themeColor;

  /// 定时主题日落实例（24小时制，如 "18:30"）
  final String themeSunsetTime;

  /// 定时主题日出时间（24小时制，如 "06:30"）
  final String themeSunriseTime;

  /// 双指手势是否开启
  final bool twoFingerGestureEnabled;

  /// 批量操作引导是否已展示
  final bool batchGuideShown;

  /// 使用声明是否已确认
  final bool disclaimerShown;

  /// 下载完成时是否触发触感反馈
  final bool hapticOnDownloadComplete;

  /// 下载失败时是否触发触感反馈
  final bool hapticOnDownloadFailed;

  /// 默认音频格式（mp3 / aac / m4a）
  final String defaultAudioFormat;

  // ==================== 智能分类存储 ====================

  /// 存储组织模式：flat（平铺）/ platform（按平台）/ author（按作者）/ date（按日期）/ platform_author（平台+作者）
  final String storageOrganizeMode;

  /// 日期格式：yyyyMMdd / yyyy-MM / yyyy-MM-dd（仅 date 模式时使用）
  final String storageDateFormat;

  /// 文件命名规则：title / platform_title / date_title / id_title
  final String storageNamingRule;

  // ==================== 代理设置 ====================

  /// 代理开关
  final bool proxyEnabled;

  /// 代理类型：http / https / socks5
  final String proxyType;

  /// 代理地址
  final String proxyHost;

  /// 代理端口
  final int proxyPort;

  /// 代理用户名（可选）
  final String? proxyUsername;

  /// 代理密码（可选）
  final String? proxyPassword;

  /// 绕过代理的域名列表
  final List<String> proxyBypassDomains;

  /// 3D 视差效果是否开启
  final bool parallaxEnabled;

  /// 已展示过手势提示的页面 key 集合
  final Set<String> gestureHintsShown;

  /// 字体大小缩放（独立于密度级别）：'small'、'medium'、'large'、'xlarge'
  final String fontSizeScale;

  // ==================== 手势交互 ====================

  /// 重压快捷菜单是否开启
  final bool forceTouchEnabled;

  /// 底部导航配置 JSON 字符串
  final String bottomNavConfigJson;

  // ==================== 自动清理下载记录 ====================

  /// 是否开启自动清理已完成下载记录
  final bool autoCleanDownloadsEnabled;

  /// 清理策略：'days'（按保留天数）/ 'count'（按保留数量）
  final String autoCleanMode;

  /// 按天数保留时的保留天数（7/15/30/90）
  final int autoCleanDays;

  /// 按数量保留时的最大保留条数（50/100/200/500）
  final int autoCleanMaxCount;

  /// 清理时是否同时删除文件（true：记录+文件，false：仅清理记录）
  final bool autoCleanDeleteFiles;

  /// 下载失败是否自动重试
  final bool autoRetryOnFailure;

  /// 下载失败最大重试次数（1-5次）
  final int maxRetryCount;

  /// 列表紧凑模式（默认关闭）
  /// 开启后，下载列表、收藏列表、历史列表、抓取列表的行高减少约 20%，
  /// 图片缩略图缩小，文字间距压缩，一屏可显示更多条目。
  final bool compactListMode;

  /// 下载完成后自动保存到系统相册（默认开启）
  /// 仅对视频和图片类型的下载生效，音频不添加
  final bool autoSaveToGallery;

  /// 大字体模式（默认关闭）
  /// 开启后全局字体放大约 15%，按钮、输入框等交互元素也相应放大
  final bool largeFontMode;

  /// 新手引导是否已展示（默认 false）
  /// 首次启动后展示过新手引导后设为 true
  final bool guideShown;

  /// 智能粘贴模式（默认 true）
  /// 开启时：粘贴内容与输入框已有内容不同则追加到下方，相同则覆盖
  /// 关闭时：粘贴始终覆盖输入框原有内容
  final bool smartPasteAppendMode;

  AppSettings({
    this.defaultQuality = 'original',
    this.customApiUrl,
    this.apiSourceId = 'builtIn',
    this.downloadPath = '',
    this.wifiOnly = false,
    this.autoParseClipboard = true,
    this.autoDownloadOnShare = false,
    this.uidResolveServiceUrl,
    this.apiKeys = const {},
    this.downloadSoundEnabled = true,
    this.downloadSoundType = 'ding',
    this.downloadCompleteAction = 'none',
    this.organizeByPlatform = true,
    this.douyinCookies = const {},
    this.hapticFeedbackEnabled = false,
    this.hapticFeedbackLevel = 'medium',
    this.downloadNotificationEnabled = true,
    this.autoPasteAndDownload = false,
    this.clipboardDetectionEnabled = true,
    this.crawlIntervalMs = 1000,
    this.crawlJitterMs = 500,
    this.uiDensity = 'standard',
    this.parseRetryCount = 2,
    this.crawlRetryCount = 2,
    this.downloadConcurrency = 2,
    this.shakeToParseEnabled = false,
    this.privacyLockEnabled = false,
    this.privacyLockScope = 'favorites',
    this.privacyUnlockMethod = 'biometric',
    this.privacyPasswordHash,
    this.privacyAutoLockDelay = 0,
    this.themeMode = 'light',
    this.themeColor = 'cyan',
    this.themeSunsetTime = '18:30',
    this.themeSunriseTime = '06:30',
    this.twoFingerGestureEnabled = false,
    this.batchGuideShown = false,
    this.disclaimerShown = false,
    this.hapticOnDownloadComplete = true,
    this.hapticOnDownloadFailed = true,
    this.defaultAudioFormat = 'mp3',
    // 智能分类存储
    this.storageOrganizeMode = 'flat',
    this.storageDateFormat = 'yyyyMMdd',
    this.storageNamingRule = 'title',
    // 代理设置
    this.proxyEnabled = false,
    this.proxyType = 'http',
    this.proxyHost = '',
    this.proxyPort = 8080,
    this.proxyUsername,
    this.proxyPassword,
    this.proxyBypassDomains = const [],
    // UI 动效与提示
    this.parallaxEnabled = true,
    this.gestureHintsShown = const {},
    this.fontSizeScale = 'medium',
    // 手势交互
    this.forceTouchEnabled = true,
    this.bottomNavConfigJson = '',
    // 自动清理下载记录
    this.autoCleanDownloadsEnabled = false,
    this.autoCleanMode = 'days',
    this.autoCleanDays = 30,
    this.autoCleanMaxCount = 200,
    this.autoCleanDeleteFiles = false,
    // 下载失败自动重试
    this.autoRetryOnFailure = true,
    this.maxRetryCount = 3,
    // 列表紧凑模式
    this.compactListMode = false,
    // 下载完成自动保存到相册
    this.autoSaveToGallery = true,
    // 大字体模式
    this.largeFontMode = false,
    // 新手引导已展示
    this.guideShown = false,
    // 智能粘贴模式
    this.smartPasteAppendMode = true,
  });

  AppSettings copyWith({
    String? defaultQuality,
    String? customApiUrl,
    String? apiSourceId,
    String? downloadPath,
    bool? wifiOnly,
    bool? autoParseClipboard,
    bool? autoDownloadOnShare,
    String? uidResolveServiceUrl,
    Map<String, String>? apiKeys,
    bool? downloadSoundEnabled,
    String? downloadSoundType,
    String? downloadCompleteAction,
    bool? organizeByPlatform,
    Map<String, String>? douyinCookies,
    bool? hapticFeedbackEnabled,
    String? hapticFeedbackLevel,
    bool? downloadNotificationEnabled,
    bool? autoPasteAndDownload,
    bool? clipboardDetectionEnabled,
    int? crawlIntervalMs,
    int? crawlJitterMs,
    String? uiDensity,
    int? parseRetryCount,
    int? crawlRetryCount,
    int? downloadConcurrency,
    bool? shakeToParseEnabled,
    bool? privacyLockEnabled,
    String? privacyLockScope,
    String? privacyUnlockMethod,
    String? privacyPasswordHash,
    bool clearPrivacyPasswordHash = false,
    int? privacyAutoLockDelay,
    String? themeMode,
    String? themeColor,
    String? themeSunsetTime,
    String? themeSunriseTime,
    bool? twoFingerGestureEnabled,
    bool? batchGuideShown,
    bool? disclaimerShown,
    bool? hapticOnDownloadComplete,
    bool? hapticOnDownloadFailed,
    String? defaultAudioFormat,
    String? storageOrganizeMode,
    String? storageDateFormat,
    String? storageNamingRule,
    bool? proxyEnabled,
    String? proxyType,
    String? proxyHost,
    int? proxyPort,
    String? proxyUsername,
    String? proxyPassword,
    List<String>? proxyBypassDomains,
    bool clearProxyUsername = false,
    bool clearProxyPassword = false,
    // UI 动效与提示
    bool? parallaxEnabled,
    Set<String>? gestureHintsShown,
    String? fontSizeScale,
    // 手势交互
    bool? forceTouchEnabled,
    String? bottomNavConfigJson,
    // 自动清理下载记录
    bool? autoCleanDownloadsEnabled,
    String? autoCleanMode,
    int? autoCleanDays,
    int? autoCleanMaxCount,
    bool? autoCleanDeleteFiles,
    // 下载失败自动重试
    bool? autoRetryOnFailure,
    int? maxRetryCount,
    // 列表紧凑模式
    bool? compactListMode,
    // 下载完成自动保存到相册
    bool? autoSaveToGallery,
    // 大字体模式
    bool? largeFontMode,
    // 新手引导已展示
    bool? guideShown,
    // 智能粘贴模式
    bool? smartPasteAppendMode,
  }) {
    return AppSettings(
      defaultQuality: defaultQuality ?? this.defaultQuality,
      customApiUrl: customApiUrl ?? this.customApiUrl,
      apiSourceId: apiSourceId ?? this.apiSourceId,
      downloadPath: downloadPath ?? this.downloadPath,
      wifiOnly: wifiOnly ?? this.wifiOnly,
      autoParseClipboard: autoParseClipboard ?? this.autoParseClipboard,
      autoDownloadOnShare: autoDownloadOnShare ?? this.autoDownloadOnShare,
      uidResolveServiceUrl: uidResolveServiceUrl ?? this.uidResolveServiceUrl,
      apiKeys: apiKeys ?? this.apiKeys,
      downloadSoundEnabled: downloadSoundEnabled ?? this.downloadSoundEnabled,
      downloadSoundType: downloadSoundType ?? this.downloadSoundType,
      downloadCompleteAction: downloadCompleteAction ?? this.downloadCompleteAction,
      organizeByPlatform: organizeByPlatform ?? this.organizeByPlatform,
      douyinCookies: douyinCookies ?? this.douyinCookies,
      hapticFeedbackEnabled: hapticFeedbackEnabled ?? this.hapticFeedbackEnabled,
      hapticFeedbackLevel: hapticFeedbackLevel ?? this.hapticFeedbackLevel,
      downloadNotificationEnabled: downloadNotificationEnabled ?? this.downloadNotificationEnabled,
      autoPasteAndDownload: autoPasteAndDownload ?? this.autoPasteAndDownload,
      clipboardDetectionEnabled: clipboardDetectionEnabled ?? this.clipboardDetectionEnabled,
      crawlIntervalMs: crawlIntervalMs ?? this.crawlIntervalMs,
      crawlJitterMs: crawlJitterMs ?? this.crawlJitterMs,
      uiDensity: uiDensity ?? this.uiDensity,
      parseRetryCount: parseRetryCount ?? this.parseRetryCount,
      crawlRetryCount: crawlRetryCount ?? this.crawlRetryCount,
      downloadConcurrency: downloadConcurrency ?? this.downloadConcurrency,
      shakeToParseEnabled: shakeToParseEnabled ?? this.shakeToParseEnabled,
      privacyLockEnabled: privacyLockEnabled ?? this.privacyLockEnabled,
      privacyLockScope: privacyLockScope ?? this.privacyLockScope,
      privacyUnlockMethod: privacyUnlockMethod ?? this.privacyUnlockMethod,
      privacyPasswordHash: clearPrivacyPasswordHash ? null : (privacyPasswordHash ?? this.privacyPasswordHash),
      privacyAutoLockDelay: privacyAutoLockDelay ?? this.privacyAutoLockDelay,
      themeMode: themeMode ?? this.themeMode,
      themeColor: themeColor ?? this.themeColor,
      themeSunsetTime: themeSunsetTime ?? this.themeSunsetTime,
      themeSunriseTime: themeSunriseTime ?? this.themeSunriseTime,
      twoFingerGestureEnabled: twoFingerGestureEnabled ?? this.twoFingerGestureEnabled,
      batchGuideShown: batchGuideShown ?? this.batchGuideShown,
      disclaimerShown: disclaimerShown ?? this.disclaimerShown,
      hapticOnDownloadComplete: hapticOnDownloadComplete ?? this.hapticOnDownloadComplete,
      hapticOnDownloadFailed: hapticOnDownloadFailed ?? this.hapticOnDownloadFailed,
      defaultAudioFormat: defaultAudioFormat ?? this.defaultAudioFormat,
      storageOrganizeMode: storageOrganizeMode ?? this.storageOrganizeMode,
      storageDateFormat: storageDateFormat ?? this.storageDateFormat,
      storageNamingRule: storageNamingRule ?? this.storageNamingRule,
      proxyEnabled: proxyEnabled ?? this.proxyEnabled,
      proxyType: proxyType ?? this.proxyType,
      proxyHost: proxyHost ?? this.proxyHost,
      proxyPort: proxyPort ?? this.proxyPort,
      proxyUsername: clearProxyUsername ? null : (proxyUsername ?? this.proxyUsername),
      proxyPassword: clearProxyPassword ? null : (proxyPassword ?? this.proxyPassword),
      proxyBypassDomains: proxyBypassDomains ?? this.proxyBypassDomains,
      parallaxEnabled: parallaxEnabled ?? this.parallaxEnabled,
      gestureHintsShown: gestureHintsShown ?? this.gestureHintsShown,
      fontSizeScale: fontSizeScale ?? this.fontSizeScale,
      forceTouchEnabled: forceTouchEnabled ?? this.forceTouchEnabled,
      bottomNavConfigJson: bottomNavConfigJson ?? this.bottomNavConfigJson,
      // 自动清理下载记录
      autoCleanDownloadsEnabled: autoCleanDownloadsEnabled ?? this.autoCleanDownloadsEnabled,
      autoCleanMode: autoCleanMode ?? this.autoCleanMode,
      autoCleanDays: autoCleanDays ?? this.autoCleanDays,
      autoCleanMaxCount: autoCleanMaxCount ?? this.autoCleanMaxCount,
      autoCleanDeleteFiles: autoCleanDeleteFiles ?? this.autoCleanDeleteFiles,
      // 下载失败自动重试
        autoRetryOnFailure: autoRetryOnFailure ?? this.autoRetryOnFailure,
        maxRetryCount: maxRetryCount ?? this.maxRetryCount,
        // 列表紧凑模式
        compactListMode: compactListMode ?? this.compactListMode,
        // 下载完成自动保存到相册
        autoSaveToGallery: autoSaveToGallery ?? this.autoSaveToGallery,
        // 大字体模式
        largeFontMode: largeFontMode ?? this.largeFontMode,
        // 新手引导已展示
        guideShown: guideShown ?? this.guideShown,
        // 智能粘贴模式
        smartPasteAppendMode: smartPasteAppendMode ?? this.smartPasteAppendMode,
      );
    }

  /// 获取指定源的 API Key
  String? getApiKey(String sourceId) => apiKeys[sourceId];
}
