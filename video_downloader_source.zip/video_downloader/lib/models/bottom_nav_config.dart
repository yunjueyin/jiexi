import 'dart:convert';
import 'package:flutter/material.dart';

/// 底部导航 Tab 项定义
enum BottomNavTab {
  /// 首页
  home(
    id: 'home',
    label: '首页',
    icon: Icons.home_outlined,
    activeIcon: Icons.home,
    defaultIndex: 0,
  ),

  /// 抓取
  crawl(
    id: 'crawl',
    label: '抓取',
    icon: Icons.search_outlined,
    activeIcon: Icons.search,
    defaultIndex: 1,
  ),

  /// 转换
  convert(
    id: 'convert',
    label: '转换',
    icon: Icons.swap_horiz_outlined,
    activeIcon: Icons.swap_horiz,
    defaultIndex: 2,
  ),

  /// 历史
  history(
    id: 'history',
    label: '历史',
    icon: Icons.history_outlined,
    activeIcon: Icons.history,
    defaultIndex: 3,
  ),

  /// 下载
  downloads(
    id: 'downloads',
    label: '下载',
    icon: Icons.download_outlined,
    activeIcon: Icons.download,
    defaultIndex: 4,
  ),

  /// 收藏
  favorites(
    id: 'favorites',
    label: '收藏',
    icon: Icons.favorite_border,
    activeIcon: Icons.favorite,
    defaultIndex: 5,
  ),

  /// 设置
  settings(
    id: 'settings',
    label: '设置',
    icon: Icons.settings_outlined,
    activeIcon: Icons.settings,
    defaultIndex: 6,
  );

  /// 唯一标识
  final String id;

  /// 显示名称
  final String label;

  /// 未选中图标
  final IconData icon;

  /// 选中图标
  final IconData activeIcon;

  /// 默认排序索引
  final int defaultIndex;

  const BottomNavTab({
    required this.id,
    required this.label,
    required this.icon,
    required this.activeIcon,
    required this.defaultIndex,
  });

  /// 根据 ID 获取枚举值
  static BottomNavTab? fromId(String id) {
    for (final tab in BottomNavTab.values) {
      if (tab.id == id) return tab;
    }
    return null;
  }
}

/// 底部导航配置
///
/// 包含 Tab 的显示顺序和显示/隐藏状态
class BottomNavConfig {
  /// 当前显示的 Tab 列表（按顺序排列）
  final List<BottomNavTab> visibleTabs;

  /// 隐藏的 Tab 列表
  final List<BottomNavTab> hiddenTabs;

  /// 最少 Tab 数量
  static const int minTabCount = 2;

  /// 最多 Tab 数量
  static const int maxTabCount = 6;

  /// 默认配置
  static const BottomNavConfig defaultConfig = BottomNavConfig(
    visibleTabs: [
      BottomNavTab.home,
      BottomNavTab.crawl,
      BottomNavTab.convert,
      BottomNavTab.history,
      BottomNavTab.settings,
    ],
    hiddenTabs: [
      BottomNavTab.downloads,
      BottomNavTab.favorites,
    ],
  );

  const BottomNavConfig({
    required this.visibleTabs,
    required this.hiddenTabs,
  });

  /// Tab 总数
  int get totalTabCount => BottomNavTab.values.length;

  /// 可见 Tab 数量
  int get visibleCount => visibleTabs.length;

  /// 隐藏 Tab 数量
  int get hiddenCount => hiddenTabs.length;

  /// 是否可以隐藏更多 Tab
  bool get canHideMore => visibleCount > minTabCount;

  /// 是否可以显示更多 Tab
  bool get canShowMore => visibleCount < maxTabCount && hiddenTabs.isNotEmpty;

  /// 获取指定索引的可见 Tab
  BottomNavTab tabAt(int index) {
    return visibleTabs[index];
  }

  /// 获取 Tab 在可见列表中的索引，不存在返回 -1
  int indexOf(BottomNavTab tab) {
    return visibleTabs.indexOf(tab);
  }

  /// 检查 Tab 是否可见
  bool isVisible(BottomNavTab tab) {
    return visibleTabs.contains(tab);
  }

  /// 移动 Tab 位置（拖拽排序）
  BottomNavConfig moveTab(int fromIndex, int toIndex) {
    if (fromIndex < 0 || fromIndex >= visibleTabs.length) return this;
    if (toIndex < 0 || toIndex >= visibleTabs.length) return this;
    if (fromIndex == toIndex) return this;

    final newVisible = List<BottomNavTab>.from(visibleTabs);
    final tab = newVisible.removeAt(fromIndex);
    newVisible.insert(toIndex, tab);

    return BottomNavConfig(
      visibleTabs: newVisible,
      hiddenTabs: hiddenTabs,
    );
  }

  /// 隐藏 Tab
  BottomNavConfig hideTab(BottomNavTab tab) {
    if (!canHideMore) return this;
    if (!visibleTabs.contains(tab)) return this;

    final newVisible = List<BottomNavTab>.from(visibleTabs)..remove(tab);
    final newHidden = List<BottomNavTab>.from(hiddenTabs)..add(tab);

    return BottomNavConfig(
      visibleTabs: newVisible,
      hiddenTabs: newHidden,
    );
  }

  /// 显示 Tab
  BottomNavConfig showTab(BottomNavTab tab) {
    if (!canShowMore) return this;
    if (!hiddenTabs.contains(tab)) return this;

    final newHidden = List<BottomNavTab>.from(hiddenTabs)..remove(tab);
    final newVisible = List<BottomNavTab>.from(visibleTabs)..add(tab);

    return BottomNavConfig(
      visibleTabs: newVisible,
      hiddenTabs: newHidden,
    );
  }

  /// 切换 Tab 显示/隐藏
  BottomNavConfig toggleTab(BottomNavTab tab) {
    if (isVisible(tab)) {
      return hideTab(tab);
    } else {
      return showTab(tab);
    }
  }

  /// 重置为默认配置
  BottomNavConfig reset() {
    return defaultConfig;
  }

  /// 序列化为 JSON（用于持久化存储）
  Map<String, dynamic> toJson() {
    return {
      'visibleTabs': visibleTabs.map((t) => t.id).toList(),
      'hiddenTabs': hiddenTabs.map((t) => t.id).toList(),
    };
  }

  /// 从 JSON 反序列化
  factory BottomNavConfig.fromJson(Map<String, dynamic> json) {
    final visibleIds = (json['visibleTabs'] as List?)?.cast<String>() ?? [];
    final hiddenIds = (json['hiddenTabs'] as List?)?.cast<String>() ?? [];

    final visibleTabs = <BottomNavTab>[];
    final hiddenTabs = <BottomNavTab>[];

    for (final id in visibleIds) {
      final tab = BottomNavTab.fromId(id);
      if (tab != null) visibleTabs.add(tab);
    }

    for (final id in hiddenIds) {
      final tab = BottomNavTab.fromId(id);
      if (tab != null) hiddenTabs.add(tab);
    }

    // 验证：确保所有 Tab 都在可见或隐藏列表中
    final allTabs = {...visibleTabs, ...hiddenTabs};
    for (final tab in BottomNavTab.values) {
      if (!allTabs.contains(tab)) {
        hiddenTabs.add(tab);
      }
    }

    // 验证数量限制
    if (visibleTabs.length < minTabCount) {
      // 从隐藏列表中补充
      while (visibleTabs.length < minTabCount && hiddenTabs.isNotEmpty) {
        visibleTabs.add(hiddenTabs.removeAt(0));
      }
    }
    if (visibleTabs.length > maxTabCount) {
      // 超出部分移到隐藏列表
      while (visibleTabs.length > maxTabCount) {
        hiddenTabs.add(visibleTabs.removeLast());
      }
    }

    return BottomNavConfig(
      visibleTabs: visibleTabs,
      hiddenTabs: hiddenTabs,
    );
  }

  /// 序列化为 JSON 字符串
  String toJsonString() {
    return jsonEncode(toJson());
  }

  /// 从 JSON 字符串反序列化
  factory BottomNavConfig.fromJsonString(String jsonStr) {
    try {
      final json = jsonDecode(jsonStr) as Map<String, dynamic>;
      return BottomNavConfig.fromJson(json);
    } catch (_) {
      return BottomNavConfig.defaultConfig;
    }
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    if (other is! BottomNavConfig) return false;
    if (visibleTabs.length != other.visibleTabs.length) return false;
    for (int i = 0; i < visibleTabs.length; i++) {
      if (visibleTabs[i] != other.visibleTabs[i]) return false;
    }
    return true;
  }

  @override
  int get hashCode => Object.hashAll(visibleTabs);
}
