import 'package:hive/hive.dart';

part 'download_task.g.dart';

@HiveType(typeId: 1)
enum DownloadStatus {
  @HiveField(0)
  queued,
  @HiveField(1)
  downloading,
  @HiveField(2)
  paused,
  @HiveField(3)
  completed,
  @HiveField(4)
  failed,
  @HiveField(5)
  canceled,
}

@HiveType(typeId: 2)
class DownloadTask extends HiveObject {
  @HiveField(0)
  final String id;

  @HiveField(1)
  final String videoId;

  @HiveField(2)
  final String videoUrl;

  @HiveField(3)
  String savePath;

  @HiveField(4)
  String fileName;

  @HiveField(5)
  int totalBytes;

  @HiveField(6)
  int receivedBytes;

  @HiveField(7)
  DownloadStatus status;

  @HiveField(8)
  double progress;

  @HiveField(9)
  DateTime createdAt;

  @HiveField(10)
  DateTime? completedAt;

  @HiveField(11)
  final String quality;

  @HiveField(12)
  final String videoTitle;

  @HiveField(13)
  final String videoCover;

  @HiveField(14)
  final String platform;

  @HiveField(15)
  String? errorMessage;

  /// 组 ID（同一图集的多张图片共享同一个 groupId，
  /// 用于在 UI 中把它们显示为一个图集条目）
  @HiveField(16)
  String? groupId;

  /// 是否为图文类型的图片
  @HiveField(17)
  bool isImage;

  /// 图集总张数（仅组内第一张有效，用于 UI 显示）
  @HiveField(18)
  int? groupTotal;

  /// 组内序号（第几张，从 1 开始）
  @HiveField(19)
  int? groupIndex;

  /// 当前下载速度（字节/秒），仅下载中有效
  @HiveField(20)
  int speedBytesPerSecond;

  /// 预计剩余时间（秒），仅下载中有效，-1 表示未知
  @HiveField(21)
  int remainingSeconds;

  /// 是否为纯音频下载
  @HiveField(22)
  bool isAudioOnly;

  /// 音频格式（mp3 / aac / m4a），仅纯音频下载时有效
  @HiveField(23)
  String? audioFormat;

  /// 已重试次数（下载失败时自动重试的次数）
  @HiveField(24)
  int retryCount;

  DownloadTask({
    required this.id,
    required this.videoId,
    required this.videoUrl,
    required this.savePath,
    required this.fileName,
    this.totalBytes = 0,
    this.receivedBytes = 0,
    this.status = DownloadStatus.queued,
    this.progress = 0.0,
    required this.createdAt,
    this.completedAt,
    required this.quality,
    required this.videoTitle,
    required this.videoCover,
    required this.platform,
    this.errorMessage,
    this.groupId,
    this.isImage = false,
    this.groupTotal,
    this.groupIndex,
    this.speedBytesPerSecond = 0,
    this.remainingSeconds = -1,
    this.isAudioOnly = false,
    this.audioFormat,
    this.retryCount = 0,
  });

  String get qualityLabel {
    switch (quality) {
      case 'original':
        return '原画';
      case 'hd':
        return '高清';
      default:
        return '标清';
    }
  }

  String get statusText {
    switch (status) {
      case DownloadStatus.queued:
        return '等待中';
      case DownloadStatus.downloading:
        return '下载中';
      case DownloadStatus.paused:
        return '已暂停';
      case DownloadStatus.completed:
        return '已完成';
      case DownloadStatus.failed:
        return '失败';
      case DownloadStatus.canceled:
        return '已取消';
    }
  }

  /// 格式化下载速度
  String get speedText {
    if (speedBytesPerSecond <= 0) return '';
    if (speedBytesPerSecond < 1024) return '$speedBytesPerSecond B/s';
    if (speedBytesPerSecond < 1024 * 1024) {
      return '${(speedBytesPerSecond / 1024).toStringAsFixed(1)} KB/s';
    }
    return '${(speedBytesPerSecond / (1024 * 1024)).toStringAsFixed(1)} MB/s';
  }

  /// 音频格式显示名称
  String get audioFormatLabel {
    switch (audioFormat) {
      case 'aac':
        return 'AAC';
      case 'm4a':
        return 'M4A';
      case 'mp3':
      default:
        return 'MP3';
    }
  }

  /// 格式化剩余时间
  String get remainingTimeText {
    if (remainingSeconds < 0) return '';
    if (remainingSeconds < 60) return '剩余 ${remainingSeconds}秒';
    if (remainingSeconds < 3600) {
      final min = remainingSeconds ~/ 60;
      final sec = remainingSeconds % 60;
      return '剩余 ${min}分${sec}秒';
    }
    final hour = remainingSeconds ~/ 3600;
    final min = (remainingSeconds % 3600) ~/ 60;
    return '剩余 ${hour}小时${min}分';
  }
}
