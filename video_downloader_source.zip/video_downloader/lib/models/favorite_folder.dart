import 'package:hive/hive.dart';

part 'favorite_folder.g.dart';

/// 收藏夹分组模型（Hive 持久化）
@HiveType(typeId: 14)
class FavoriteFolder extends HiveObject {
  /// 唯一 ID
  @HiveField(0)
  final String id;

  /// 分组名称
  @HiveField(1)
  final String name;

  /// 创建时间
  @HiveField(2)
  final DateTime createdAt;

  /// 封面图 URL（可选，取组内第一条收藏的封面）
  @HiveField(3)
  final String? coverUrl;

  /// 是否为默认分组（不可删除、不可重命名）
  @HiveField(4)
  final bool isDefault;

  FavoriteFolder({
    required this.id,
    required this.name,
    required this.createdAt,
    this.coverUrl,
    this.isDefault = false,
  });

  /// 创建副本并修改指定字段
  FavoriteFolder copyWith({
    String? id,
    String? name,
    DateTime? createdAt,
    String? coverUrl,
    bool? isDefault,
    bool clearCoverUrl = false,
  }) {
    return FavoriteFolder(
      id: id ?? this.id,
      name: name ?? this.name,
      createdAt: createdAt ?? this.createdAt,
      coverUrl: clearCoverUrl ? null : (coverUrl ?? this.coverUrl),
      isDefault: isDefault ?? this.isDefault,
    );
  }
}
