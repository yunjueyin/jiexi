/// 解析 API 源
class ApiSource {
  /// 唯一标识
  final String id;

  /// 名称
  final String name;

  /// API 地址（内置解析器为 null）
  final String? apiUrl;

  /// 官网地址
  final String? website;

  /// 描述
  final String description;

  /// 是否为内置解析器（不使用自定义 API 接口）
  final bool isBuiltIn;

  /// 支持的平台
  final List<String> supportedPlatforms;

  /// API Key 的参数名（作为 query 参数附加到请求上）
  /// 为 null 表示该源不需要 API Key
  final String? apiKeyParam;

  /// API Key 是否必填
  final bool apiKeyRequired;

  /// 获取 Key 的指引文字（显示在配置弹窗中）
  final String? apiKeyHint;

  const ApiSource({
    required this.id,
    required this.name,
    this.apiUrl,
    this.website,
    required this.description,
    this.isBuiltIn = false,
    this.supportedPlatforms = const ['douyin', 'kuaishou'],
    this.apiKeyParam,
    this.apiKeyRequired = false,
    this.apiKeyHint,
  });

  /// 是否需要用户配置（有 apiUrl 但地址或 key 需要填）
  bool get needsConfiguration =>
      !isBuiltIn && (apiUrl == null || apiKeyRequired);

  /// 内置解析器（官方直连）
  static const ApiSource builtIn = ApiSource(
    id: 'builtIn',
    name: '内置解析器',
    description: '本地直连官方接口解析，速度快但可能因官方更新而失效',
    isBuiltIn: true,
    supportedPlatforms: ['douyin', 'kuaishou', 'xiaohongshu'],
  );

  /// 预设的第三方 API 源列表
  static const List<ApiSource> presets = [
    builtIn,
    ApiSource(
      id: 'parse_video',
      name: 'ParseVideo API',
      apiUrl: 'https://api.parsevideo.cn/api/parse',
      website: 'https://www.parsevideo.cn',
      description: '稳定的视频解析服务，支持抖音、快手等多个平台',
      supportedPlatforms: ['douyin', 'kuaishou'],
      apiKeyParam: 'token',
      apiKeyRequired: false,
      apiKeyHint: '注册后在个人中心获取 Token，可选填入以获得更高调用额度',
    ),
    ApiSource(
      id: 'dy_api',
      name: '抖音解析 API',
      apiUrl: 'https://api.douyin.wtf/api',
      website: 'https://www.douyin.wtf',
      description: '专注抖音无水印解析，支持批量解析',
      supportedPlatforms: ['douyin'],
      apiKeyParam: 'key',
      apiKeyRequired: false,
      apiKeyHint: '部分高级接口需要 API Key，普通解析可留空',
    ),
    ApiSource(
      id: 'video_parse',
      name: '视频解析 API',
      apiUrl: 'https://api.videoparse.cn/api/analyze',
      website: 'https://www.videoparse.cn',
      description: '多平台短视频解析，支持抖音、快手、小红书等',
      supportedPlatforms: ['douyin', 'kuaishou', 'xiaohongshu'],
      apiKeyParam: 'apikey',
      apiKeyRequired: false,
      apiKeyHint: '注册账号后在控制台查看 API Key',
    ),
    ApiSource(
      id: 'jx_api',
      name: '极速解析 API',
      apiUrl: 'https://api.jiexi.video/api/parse',
      website: 'https://www.jiexi.video',
      description: '高速解析接口，响应快，支持多平台',
      supportedPlatforms: ['douyin', 'kuaishou'],
      apiKeyParam: 'key',
      apiKeyRequired: false,
      apiKeyHint: '可选填入 API Key 以解除频率限制',
    ),
    ApiSource(
      id: 'custom',
      name: '自定义API',
      description: '使用你自己的解析 API 地址，完全自定义',
      supportedPlatforms: ['douyin', 'kuaishou', 'xiaohongshu'],
      apiKeyParam: 'key',
      apiKeyRequired: false,
      apiKeyHint: '如果你的 API 需要密钥，可填入参数名和值',
    ),
  ];

  /// 根据 ID 获取 API 源
  static ApiSource? fromId(String id) {
    for (var source in presets) {
      if (source.id == id) return source;
    }
    return null;
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ApiSource && runtimeType == other.runtimeType && id == other.id;

  @override
  int get hashCode => id.hashCode;
}
