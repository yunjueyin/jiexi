import 'package:hive/hive.dart';

part 'crawl_checkpoint.g.dart';

/// 作者增量抓取检查点
///
/// 记录每个作者上次抓取的状态，用于增量抓取时只抓取新内容。
@HiveType(typeId: 6)
class CrawlCheckpoint extends HiveObject {
  /// 作者唯一标识（平台 + 作者ID，如 'douyin_ms89234'）
  @HiveField(0)
  final String authorKey;

  /// 平台
  @HiveField(1)
  final String platform;

  /// 作者 ID（sec_uid 或 uid）
  @HiveField(2)
  final String authorId;

  /// 作者昵称（便于展示）
  @HiveField(3)
  final String? nickname;

  /// 上次抓取时间
  @HiveField(4)
  final DateTime lastCrawlAt;

  /// 上次抓取到的最新视频发布时间（用于判断新视频）
  @HiveField(5)
  final DateTime? lastVideoPublishTime;

  /// 上次抓取到的最新视频 ID（用于精确去重）
  @HiveField(6)
  final String? lastVideoId;

  /// 累计抓取的视频数量
  @HiveField(7)
  final int totalVideoCount;

  /// 分页游标（用于支持分页抓取的平台）
  @HiveField(8)
  final String? cursor;

  CrawlCheckpoint({
    required this.authorKey,
    required this.platform,
    required this.authorId,
    this.nickname,
    required this.lastCrawlAt,
    this.lastVideoPublishTime,
    this.lastVideoId,
    this.totalVideoCount = 0,
    this.cursor,
  });

  /// 生成作者唯一 key
  static String makeKey(String platform, String authorId) {
    return '${platform}_$authorId';
  }

  /// 创建副本并更新字段
  CrawlCheckpoint copyWith({
    String? authorKey,
    String? platform,
    String? authorId,
    String? nickname,
    DateTime? lastCrawlAt,
    DateTime? lastVideoPublishTime,
    String? lastVideoId,
    int? totalVideoCount,
    String? cursor,
  }) {
    return CrawlCheckpoint(
      authorKey: authorKey ?? this.authorKey,
      platform: platform ?? this.platform,
      authorId: authorId ?? this.authorId,
      nickname: nickname ?? this.nickname,
      lastCrawlAt: lastCrawlAt ?? this.lastCrawlAt,
      lastVideoPublishTime: lastVideoPublishTime ?? this.lastVideoPublishTime,
      lastVideoId: lastVideoId ?? this.lastVideoId,
      totalVideoCount: totalVideoCount ?? this.totalVideoCount,
      cursor: cursor ?? this.cursor,
    );
  }
}
