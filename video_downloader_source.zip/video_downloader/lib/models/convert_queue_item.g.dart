// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'convert_queue_item.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class ConvertQueueStatusAdapter extends TypeAdapter<ConvertQueueStatus> {
  @override
  final int typeId = 14;

  @override
  ConvertQueueStatus read(BinaryReader reader) {
    switch (reader.readByte()) {
      case 0:
        return ConvertQueueStatus.pending;
      case 1:
        return ConvertQueueStatus.processing;
      case 2:
        return ConvertQueueStatus.completed;
      case 3:
        return ConvertQueueStatus.failed;
      default:
        return ConvertQueueStatus.pending;
    }
  }

  @override
  void write(BinaryWriter writer, ConvertQueueStatus obj) {
    switch (obj) {
      case ConvertQueueStatus.pending:
        writer.writeByte(0);
        break;
      case ConvertQueueStatus.processing:
        writer.writeByte(1);
        break;
      case ConvertQueueStatus.completed:
        writer.writeByte(2);
        break;
      case ConvertQueueStatus.failed:
        writer.writeByte(3);
        break;
    }
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ConvertQueueStatusAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class ConvertQueueTypeAdapter extends TypeAdapter<ConvertQueueType> {
  @override
  final int typeId = 15;

  @override
  ConvertQueueType read(BinaryReader reader) {
    switch (reader.readByte()) {
      case 0:
        return ConvertQueueType.toShort;
      case 1:
        return ConvertQueueType.toLong;
      default:
        return ConvertQueueType.toShort;
    }
  }

  @override
  void write(BinaryWriter writer, ConvertQueueType obj) {
    switch (obj) {
      case ConvertQueueType.toShort:
        writer.writeByte(0);
        break;
      case ConvertQueueType.toLong:
        writer.writeByte(1);
        break;
    }
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ConvertQueueTypeAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class ConvertQueueItemAdapter extends TypeAdapter<ConvertQueueItem> {
  @override
  final int typeId = 16;

  @override
  ConvertQueueItem read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return ConvertQueueItem(
      id: fields[0] as String,
      originalUrl: fields[1] as String,
      resultUrl: fields[2] as String?,
      platform: fields[3] as String?,
      convertType: fields[4] as ConvertQueueType,
      status: fields[5] as ConvertQueueStatus,
      errorMessage: fields[6] as String?,
      createdAt: fields[7] as DateTime,
      startedAt: fields[8] as DateTime?,
      completedAt: fields[9] as DateTime?,
      videoTitle: fields[10] as String?,
      source: fields[11] as String?,
    );
  }

  @override
  void write(BinaryWriter writer, ConvertQueueItem obj) {
    writer
      ..writeByte(12)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.originalUrl)
      ..writeByte(2)
      ..write(obj.resultUrl)
      ..writeByte(3)
      ..write(obj.platform)
      ..writeByte(4)
      ..write(obj.convertType)
      ..writeByte(5)
      ..write(obj.status)
      ..writeByte(6)
      ..write(obj.errorMessage)
      ..writeByte(7)
      ..write(obj.createdAt)
      ..writeByte(8)
      ..write(obj.startedAt)
      ..writeByte(9)
      ..write(obj.completedAt)
      ..writeByte(10)
      ..write(obj.videoTitle)
      ..writeByte(11)
      ..write(obj.source);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ConvertQueueItemAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
