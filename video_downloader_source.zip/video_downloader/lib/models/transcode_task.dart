import 'package:hive/hive.dart';

part 'transcode_task.g.dart';

/// 转码状态
@HiveType(typeId: 10)
enum TranscodeStatus {
  @HiveField(0)
  queued,
  @HiveField(1)
  processing,
  @HiveField(2)
  completed,
  @HiveField(3)
  failed,
  @HiveField(4)
  canceled,
}

/// 转码类型
@HiveType(typeId: 11)
enum TranscodeType {
  @HiveField(0)
  video, // 视频格式转换
  @HiveField(1)
  audio, // 音频格式转换
  @HiveField(2)
  videoCompress, // 视频压缩
}

/// 转码任务（Hive 持久化）
@HiveType(typeId: 5)
class TranscodeTask extends HiveObject {
  @HiveField(0)
  final String id;

  /// 源文件路径
  @HiveField(1)
  final String sourcePath;

  /// 输出文件路径
  @HiveField(2)
  String outputPath;

  /// 源文件名
  @HiveField(3)
  final String sourceFileName;

  /// 输出文件名
  @HiveField(4)
  String outputFileName;

  /// 转码类型
  @HiveField(5)
  final String transcodeType;

  /// 目标格式（mp4 / mov / mkv / avi / mp3 / aac / m4a / wav）
  @HiveField(6)
  final String targetFormat;

  /// 目标分辨率（视频压缩时使用：720p / 480p / 360p / original）
  @HiveField(7)
  final String? targetResolution;

  /// 目标码率（视频压缩时使用，kbps，null 表示自动）
  @HiveField(8)
  final int? targetBitrate;

  /// 转码状态
  @HiveField(9)
  TranscodeStatus status;

  /// 进度 0.0 - 1.0
  @HiveField(10)
  double progress;

  /// 创建时间
  @HiveField(11)
  final DateTime createdAt;

  /// 完成时间
  @HiveField(12)
  DateTime? completedAt;

  /// 错误信息
  @HiveField(13)
  String? errorMessage;

  /// 源文件大小（字节）
  @HiveField(14)
  final int sourceSizeBytes;

  /// 输出文件大小（字节）
  @HiveField(15)
  int? outputSizeBytes;

  /// 视频封面（用于 UI 显示）
  @HiveField(16)
  final String? videoCover;

  /// 视频标题（用于 UI 显示）
  @HiveField(17)
  final String? videoTitle;

  TranscodeTask({
    required this.id,
    required this.sourcePath,
    required this.outputPath,
    required this.sourceFileName,
    required this.outputFileName,
    required this.transcodeType,
    required this.targetFormat,
    this.targetResolution,
    this.targetBitrate,
    this.status = TranscodeStatus.queued,
    this.progress = 0.0,
    required this.createdAt,
    this.completedAt,
    this.errorMessage,
    this.sourceSizeBytes = 0,
    this.outputSizeBytes,
    this.videoCover,
    this.videoTitle,
  });

  /// 状态文字
  String get statusText {
    switch (status) {
      case TranscodeStatus.queued:
        return '等待中';
      case TranscodeStatus.processing:
        return '转码中';
      case TranscodeStatus.completed:
        return '已完成';
      case TranscodeStatus.failed:
        return '失败';
      case TranscodeStatus.canceled:
        return '已取消';
    }
  }

  /// 转码类型文字
  String get typeLabel {
    switch (transcodeType) {
      case 'video':
        return '视频转换';
      case 'audio':
        return '音频转换';
      case 'videoCompress':
        return '视频压缩';
      default:
        return '转码';
    }
  }

  /// 目标格式显示名称
  String get targetFormatLabel {
    return targetFormat.toUpperCase();
  }

  /// 格式化文件大小
  static String formatSize(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    if (bytes < 1024 * 1024 * 1024) {
      return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    }
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
  }
}
