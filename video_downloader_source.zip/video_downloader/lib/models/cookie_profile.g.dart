// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cookie_profile.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class CookieProfileAdapter extends TypeAdapter<CookieProfile> {
  @override
  final int typeId = 7;

  @override
  CookieProfile read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return CookieProfile(
      id: fields[0] as String,
      platform: fields[1] as String,
      name: fields[2] as String,
      cookieString: fields[3] as String,
      createdAt: fields[4] as DateTime,
      expiresAt: fields[5] as DateTime?,
      lastUsedAt: fields[6] as DateTime?,
      status: fields[7] as CookieStatus,
      remark: fields[8] as String?,
    );
  }

  @override
  void write(BinaryWriter writer, CookieProfile obj) {
    writer
      ..writeByte(9)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.platform)
      ..writeByte(2)
      ..write(obj.name)
      ..writeByte(3)
      ..write(obj.cookieString)
      ..writeByte(4)
      ..write(obj.createdAt)
      ..writeByte(5)
      ..write(obj.expiresAt)
      ..writeByte(6)
      ..write(obj.lastUsedAt)
      ..writeByte(7)
      ..write(obj.status)
      ..writeByte(8)
      ..write(obj.remark);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is CookieProfileAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class CookieStatusAdapter extends TypeAdapter<CookieStatus> {
  @override
  final int typeId = 10;

  @override
  CookieStatus read(BinaryReader reader) {
    switch (reader.readByte()) {
      case 0:
        return CookieStatus.active;
      case 1:
        return CookieStatus.expiringSoon;
      case 2:
        return CookieStatus.expired;
      default:
        return CookieStatus.active;
    }
  }

  @override
  void write(BinaryWriter writer, CookieStatus obj) {
    switch (obj) {
      case CookieStatus.active:
        writer.writeByte(0);
        break;
      case CookieStatus.expiringSoon:
        writer.writeByte(1);
        break;
      case CookieStatus.expired:
        writer.writeByte(2);
        break;
    }
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is CookieStatusAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
