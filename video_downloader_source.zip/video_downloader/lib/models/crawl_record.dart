import 'package:hive/hive.dart';

part 'crawl_record.g.dart';

/// 抓取类型
enum CrawlType {
  /// 作者主页信息
  author,
  /// 视频信息
  video,
}

/// 抓取记录基类（Hive 持久化）
@HiveType(typeId: 3)
class CrawlRecord extends HiveObject {
  /// 唯一 ID
  @HiveField(0)
  final String id;

  /// 原始链接
  @HiveField(1)
  final String url;

  /// 平台（douyin / kuaishou）
  @HiveField(2)
  final String platform;

  /// 抓取类型
  @HiveField(3)
  final String crawlType;

  /// 抓取时间
  @HiveField(4)
  final DateTime crawledAt;

  /// 抓取结果数据（用户选择字段过滤后的结果）
  @HiveField(5)
  final Map<String, dynamic> data;

  /// 抓取到的完整原始数据（未经过字段过滤）
  /// 用于保留封面/头像等预览图信息，不受用户字段选择影响
  @HiveField(6)
  final Map<String, dynamic>? rawData;

  /// 批次 ID（批量抓取时同一批次的记录共享相同 batchId）
  @HiveField(7)
  final String? batchId;

  // ==================== 断点续传相关字段（批量抓取进度） ====================
  // 这些字段用于批量抓取的断点续传功能。
  // 当 crawlType 为 'batch_progress' 时，本条记录是一个批次进度标记，
  // 用于保存/恢复批量抓取的进度状态。

  /// 批次总数（批量抓取时的 URL 总数）
  @HiveField(8)
  final int batchTotal;

  /// 已完成数（已成功抓取的数量）
  @HiveField(9)
  final int batchCompleted;

  /// 分页游标（用于分页抓取场景，如按页获取作者所有视频）
  @HiveField(10)
  final String? batchCursor;

  /// 批次 URL 列表（批量抓取时的所有 URL，用于断点续传时恢复任务列表）
  @HiveField(11)
  final List<String>? batchUrls;

  /// 当前处理索引（断点续传时从该索引继续）
  @HiveField(12)
  final int batchCurrentIndex;

  /// 批次选中的字段（断点续传时保持字段选择一致）
  @HiveField(13)
  final List<String>? batchFields;

  /// 是否为作者批量抓取（断点续传时判断抓取类型）
  @HiveField(14)
  final bool? batchIsAuthor;

  /// 批次状态：'in_progress'（进行中）、'interrupted'（已中断）、'completed'（已完成）
  @HiveField(15)
  final String? batchStatus;

  /// 是否已收藏
  @HiveField(16)
  final bool isFavorite;

  /// 收藏时间
  @HiveField(17)
  final DateTime? favoritedAt;

  /// 收藏夹分组 ID（null 表示默认分组）
  @HiveField(18)
  final String? favoriteFolderId;

  CrawlRecord({
    required this.id,
    required this.url,
    required this.platform,
    required this.crawlType,
    required this.crawledAt,
    required this.data,
    this.rawData,
    this.batchId,
    this.batchTotal = 0,
    this.batchCompleted = 0,
    this.batchCursor,
    this.batchUrls,
    this.batchCurrentIndex = 0,
    this.batchFields,
    this.batchIsAuthor,
    this.batchStatus,
    this.isFavorite = false,
    this.favoritedAt,
    this.favoriteFolderId,
  });

  /// 是否为作者抓取
  bool get isAuthor => crawlType == 'author';

  /// 是否为视频抓取
  bool get isVideo => crawlType == 'video';

  /// 是否为前10作品抓取
  bool get isTop10 => crawlType == 'top10';

  /// 是否为批次进度记录（用于断点续传）
  bool get isBatchProgress => crawlType == 'batch_progress';

  /// 批次是否处于进行中状态
  bool get isBatchInProgress =>
      batchStatus == 'in_progress' || batchStatus == 'interrupted';

  /// 批次是否已完成
  bool get isBatchCompleted => batchStatus == 'completed';

  /// 批次是否已中断
  bool get isBatchInterrupted => batchStatus == 'interrupted';

  /// 批次进度百分比（0-100）
  double get batchProgressPercent {
    if (batchTotal <= 0) return 0;
    return (batchCompleted / batchTotal * 100).clamp(0, 100).toDouble();
  }

  /// 批次进度百分比字符串（如 "45%"）
  String get batchProgressText {
    return '${batchProgressPercent.toStringAsFixed(0)}%';
  }

  /// 批次进度描述（如 "12/30"）
  String get batchProgressCountText {
    return '$batchCompleted/$batchTotal';
  }

  /// 批次状态文字
  String get batchStatusText {
    switch (batchStatus) {
      case 'in_progress':
        return '进行中';
      case 'interrupted':
        return '已中断';
      case 'completed':
        return '已完成';
      default:
        return '';
    }
  }

  /// 创建副本并更新指定字段（用于更新批次进度等场景）
  CrawlRecord copyWith({
    String? id,
    String? url,
    String? platform,
    String? crawlType,
    DateTime? crawledAt,
    Map<String, dynamic>? data,
    Map<String, dynamic>? rawData,
    String? batchId,
    int? batchTotal,
    int? batchCompleted,
    String? batchCursor,
    List<String>? batchUrls,
    int? batchCurrentIndex,
    List<String>? batchFields,
    bool? batchIsAuthor,
    String? batchStatus,
    bool? isFavorite,
    DateTime? favoritedAt,
    String? favoriteFolderId,
    bool clearFavoritedAt = false,
    bool clearFavoriteFolderId = false,
  }) {
    return CrawlRecord(
      id: id ?? this.id,
      url: url ?? this.url,
      platform: platform ?? this.platform,
      crawlType: crawlType ?? this.crawlType,
      crawledAt: crawledAt ?? this.crawledAt,
      data: data ?? this.data,
      rawData: rawData ?? this.rawData,
      batchId: batchId ?? this.batchId,
      batchTotal: batchTotal ?? this.batchTotal,
      batchCompleted: batchCompleted ?? this.batchCompleted,
      batchCursor: batchCursor ?? this.batchCursor,
      batchUrls: batchUrls ?? this.batchUrls,
      batchCurrentIndex: batchCurrentIndex ?? this.batchCurrentIndex,
      batchFields: batchFields ?? this.batchFields,
      batchIsAuthor: batchIsAuthor ?? this.batchIsAuthor,
      batchStatus: batchStatus ?? this.batchStatus,
      isFavorite: isFavorite ?? this.isFavorite,
      favoritedAt: clearFavoritedAt ? null : (favoritedAt ?? this.favoritedAt),
      favoriteFolderId: clearFavoriteFolderId
          ? null
          : (favoriteFolderId ?? this.favoriteFolderId),
    );
  }

  String get platformName {
    switch (platform) {
      case 'douyin':
        return '抖音';
      case 'kuaishou':
        return '快手';
      case 'xiaohongshu':
      case 'xhs':
        return '小红书';
      default:
        return '未知';
    }
  }

  String get typeLabel {
    switch (crawlType) {
      case 'author':
        return '作者信息';
      case 'video':
        return '视频信息';
      case 'top10':
        return '前10作品';
      default:
        return '未知';
    }
  }

  /// 获取标题（用于列表展示）
  String get displayTitle {
    if (isAuthor) {
      return data['nickname'] ?? data['authorName'] ?? data['uid'] ?? '未知作者';
    } else if (isTop10) {
      return data['authorName'] ?? data['nickname'] ?? '前10作品';
    } else {
      return data['title'] ?? data['desc'] ?? data['videoId'] ?? '未知视频';
    }
  }

  /// 获取副标题（用于列表展示）
  String get displaySubtitle {
    if (isAuthor) {
      final followers = data['followerCount'] ?? data['fansCount'];
      if (followers != null) {
        return '粉丝：${_formatCount(followers)}';
      }
      // 优先显示数字 uid，其次显示抖音号（uniqueId），
      // 不显示 secUid（base64 编码字符串，用户看不懂）
      final uid = data['uid']?.toString();
      if (uid != null && uid.isNotEmpty && uid != '0' && RegExp(r'^\d+$').hasMatch(uid)) {
        return 'ID：$uid';
      }
      final uniqueId = data['uniqueId']?.toString();
      if (uniqueId != null && uniqueId.isNotEmpty && uniqueId != '0') {
        return '抖音号：$uniqueId';
      }
      return '';
    } else if (isTop10) {
      final workCount = data['workCount'];
      if (workCount != null) {
        return '$workCount 条作品';
      }
      return '前10作品分析';
    } else {
      final likes = data['likeCount'] ?? data['diggCount'];
      if (likes != null) {
        return '点赞：${_formatCount(likes)}';
      }
      return data['videoId'] ?? data['awemeId'] ?? '';
    }
  }

  /// 数字格式化（万/亿）
  String _formatCount(dynamic count) {
    if (count == null) return '0';
    final num = count is int ? count : int.tryParse(count.toString()) ?? 0;
    if (num >= 100000000) {
      return '${(num / 100000000).toStringAsFixed(1)}亿';
    } else if (num >= 10000) {
      return '${(num / 10000).toStringAsFixed(1)}万';
    }
    return num.toString();
  }

  /// 获取所有字段（用于导出/复制）
  List<MapEntry<String, String>> get fields {
    final result = <MapEntry<String, String>>[];
    data.forEach((key, value) {
      result.add(MapEntry(_fieldLabel(key), value?.toString() ?? ''));
    });
    return result;
  }

  /// 字段名映射为中文标签（静态公共方法，供外部使用）
  static String getFieldLabel(String key) {
    return _fieldLabelMap[key] ?? key;
  }

  /// 字段名映射为中文标签
  String _fieldLabel(String key) {
    return _fieldLabelMap[key] ?? key;
  }

  /// 字段标签映射表
  static const Map<String, String> _fieldLabelMap = {
    // 作者相关
    'uid': '作者UID',
    'uniqueId': '抖音号',
    'nickname': '昵称',
    'authorName': '作者名称',
    'avatar': '头像',
    'signature': '简介',
    'description': '描述',
    'followerCount': '粉丝数',
    'fansCount': '粉丝数',
    'followingCount': '关注数',
    'followCount': '关注数',
    'totalFavorited': '获赞数',
    'likeCountTotal': '总获赞',
    'awemeCount': '作品数',
    'videoCount': '作品数',
    'favoriteCount': '收藏数',
    // 视频相关
    'videoId': '视频ID',
    'awemeId': '作品ID',
    'title': '标题',
    'desc': '描述',
    'cover': '封面',
    'shareUrl': '分享链接',
    'createTime': '发布时间',
    'publishTime': '发布时间',
    'duration': '时长(秒)',
    'durationSeconds': '时长(秒)',
    'diggCount': '点赞数',
    'likeCount': '点赞数',
    'commentCount': '评论数',
    'shareCount': '分享数',
    'collectCount': '收藏数',
    'playCount': '播放数',
    'downloadCount': '下载数',
    // 作者信息（视频里的）
    'authorUid': '作者UID',
    'authorUniqueId': '作者抖音号',
    'authorNickname': '作者昵称',
    'authorAvatar': '作者头像',
  };

  /// 导出为 JSON Map（用于批量导出）
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'url': url,
      'platform': platform,
      'crawlType': crawlType,
      'crawledAt': crawledAt.toIso8601String(),
      'data': data,
      if (rawData != null) 'rawData': rawData,
      if (batchId != null) 'batchId': batchId,
    };
  }
}
