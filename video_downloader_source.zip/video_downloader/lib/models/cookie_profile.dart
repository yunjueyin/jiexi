import 'package:hive/hive.dart';

part 'cookie_profile.g.dart';

/// Cookie 状态
@HiveType(typeId: 10)
enum CookieStatus {
  /// 有效
  @HiveField(0)
  active,

  /// 即将过期（7天内）
  @HiveField(1)
  expiringSoon,

  /// 已失效
  @HiveField(2)
  expired,
}

/// Cookie 配置档案
@HiveType(typeId: 7)
class CookieProfile extends HiveObject {
  /// 唯一标识
  @HiveField(0)
  final String id;

  /// 平台标识：douyin / kuaishou / xiaohongshu
  @HiveField(1)
  final String platform;

  /// 配置名称（用户自定义，方便识别）
  @HiveField(2)
  String name;

  /// Cookie 字符串（key=value; key2=value2 格式）
  @HiveField(3)
  String cookieString;

  /// 创建时间
  @HiveField(4)
  DateTime createdAt;

  /// 过期时间（null 表示永不过期）
  @HiveField(5)
  DateTime? expiresAt;

  /// 最后使用时间
  @HiveField(6)
  DateTime? lastUsedAt;

  /// 状态（运行时计算，也可持久化缓存）
  @HiveField(7)
  CookieStatus status;

  /// 备注
  @HiveField(8)
  String? remark;

  CookieProfile({
    required this.id,
    required this.platform,
    required this.name,
    required this.cookieString,
    required this.createdAt,
    this.expiresAt,
    this.lastUsedAt,
    this.status = CookieStatus.active,
    this.remark,
  });

  /// 解析 Cookie 字符串为 Map
  Map<String, String> get cookieMap {
    final map = <String, String>{};
    if (cookieString.isEmpty) return map;
    final pairs = cookieString.split(';');
    for (final pair in pairs) {
      final trimmed = pair.trim();
      final idx = trimmed.indexOf('=');
      if (idx > 0) {
        final key = trimmed.substring(0, idx).trim();
        final value = trimmed.substring(idx + 1).trim();
        if (key.isNotEmpty) {
          map[key] = value;
        }
      }
    }
    return map;
  }

  /// 获取 Cookie 数量
  int get cookieCount => cookieMap.length;

  /// 从 Map 构建 Cookie 字符串
  static String mapToString(Map<String, String> map) {
    return map.entries.map((e) => '${e.key}=${e.value}').join('; ');
  }

  /// 计算并更新状态
  CookieStatus computeStatus() {
    if (expiresAt == null) return CookieStatus.active;
    final now = DateTime.now();
    if (now.isAfter(expiresAt!)) {
      return CookieStatus.expired;
    }
    final sevenDays = const Duration(days: 7);
    if (expiresAt!.difference(now).compareTo(sevenDays) <= 0) {
      return CookieStatus.expiringSoon;
    }
    return CookieStatus.active;
  }

  /// 更新状态为计算值
  void refreshStatus() {
    status = computeStatus();
  }

  /// 距离过期的剩余时间描述
  String get remainingTimeText {
    if (expiresAt == null) return '永不过期';
    final diff = expiresAt!.difference(DateTime.now());
    if (diff.isNegative) return '已过期';
    final days = diff.inDays;
    if (days > 0) return '剩余 $days 天';
    final hours = diff.inHours;
    if (hours > 0) return '剩余 $hours 小时';
    final minutes = diff.inMinutes;
    return '剩余 $minutes 分钟';
  }

  /// 平台显示名称
  String get platformLabel {
    switch (platform) {
      case 'douyin':
        return '抖音';
      case 'kuaishou':
        return '快手';
      case 'xiaohongshu':
        return '小红书';
      default:
        return platform;
    }
  }

  /// 状态显示文本
  String get statusLabel {
    switch (status) {
      case CookieStatus.active:
        return '有效';
      case CookieStatus.expiringSoon:
        return '即将过期';
      case CookieStatus.expired:
        return '已失效';
    }
  }

  /// 复制
  CookieProfile copyWith({
    String? id,
    String? platform,
    String? name,
    String? cookieString,
    DateTime? createdAt,
    DateTime? expiresAt,
    DateTime? lastUsedAt,
    CookieStatus? status,
    String? remark,
  }) {
    return CookieProfile(
      id: id ?? this.id,
      platform: platform ?? this.platform,
      name: name ?? this.name,
      cookieString: cookieString ?? this.cookieString,
      createdAt: createdAt ?? this.createdAt,
      expiresAt: expiresAt ?? this.expiresAt,
      lastUsedAt: lastUsedAt ?? this.lastUsedAt,
      status: status ?? this.status,
      remark: remark ?? this.remark,
    );
  }
}
