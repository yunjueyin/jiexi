import 'package:hive/hive.dart';

part 'video_info.g.dart';

/// 内容类型
enum MediaType {
  /// 视频
  video,
  /// 图文/图片集
  image,
}

@HiveType(typeId: 0)
class VideoInfo extends HiveObject {
  @HiveField(0)
  final String id;

  @HiveField(1)
  final String url;

  @HiveField(2)
  final String platform;

  @HiveField(3)
  final String title;

  @HiveField(4)
  final String author;

  @HiveField(5)
  final String cover;

  @HiveField(6)
  final String? videoUrl;

  @HiveField(7)
  final String? videoUrlHd;

  @HiveField(8)
  final int? durationSeconds;

  @HiveField(9)
  final DateTime parsedAt;

  /// 内容类型（视频或图文）
  @HiveField(10)
  final String type;

  /// 图片列表（图文类型时使用）
  @HiveField(11)
  final List<String>? images;

  /// 是否已收藏
  @HiveField(20)
  final bool isFavorite;

  /// 收藏时间
  @HiveField(21)
  final DateTime? favoritedAt;

  /// 收藏夹分组 ID（null 表示默认分组）
  @HiveField(22)
  final String? favoriteFolderId;

  VideoInfo({
    required this.id,
    required this.url,
    required this.platform,
    required this.title,
    required this.author,
    required this.cover,
    this.videoUrl,
    this.videoUrlHd,
    this.durationSeconds,
    required this.parsedAt,
    this.type = 'video',
    this.images,
    this.isFavorite = false,
    this.favoritedAt,
    this.favoriteFolderId,
  });

  /// 是否为图文类型
  bool get isImage => type == 'image';

  /// 是否为视频类型
  bool get isVideo => type == 'video';

  /// 图片数量（图文时）
  int get imageCount => images?.length ?? 0;

  String get platformName {
    switch (platform) {
      case 'douyin':
        return '抖音';
      case 'kuaishou':
        return '快手';
      case 'xiaohongshu':
      case 'xhs':
        return '小红书';
      default:
        return '未知';
    }
  }

  String get typeName {
    switch (type) {
      case 'image':
        return '图文';
      case 'video':
      default:
        return '视频';
    }
  }

  String? getVideoUrl(String quality) {
    if (quality == 'hd' && videoUrlHd != null) {
      return videoUrlHd;
    }
    return videoUrl;
  }

  /// 创建副本并修改指定字段
  VideoInfo copyWith({
    String? id,
    String? url,
    String? platform,
    String? title,
    String? author,
    String? cover,
    String? videoUrl,
    String? videoUrlHd,
    int? durationSeconds,
    DateTime? parsedAt,
    String? type,
    List<String>? images,
    bool? isFavorite,
    DateTime? favoritedAt,
    String? favoriteFolderId,
    bool clearVideoUrl = false,
    bool clearVideoUrlHd = false,
    bool clearImages = false,
    bool clearFavoritedAt = false,
    bool clearFavoriteFolderId = false,
  }) {
    return VideoInfo(
      id: id ?? this.id,
      url: url ?? this.url,
      platform: platform ?? this.platform,
      title: title ?? this.title,
      author: author ?? this.author,
      cover: cover ?? this.cover,
      videoUrl: clearVideoUrl ? null : (videoUrl ?? this.videoUrl),
      videoUrlHd: clearVideoUrlHd ? null : (videoUrlHd ?? this.videoUrlHd),
      durationSeconds: durationSeconds ?? this.durationSeconds,
      parsedAt: parsedAt ?? this.parsedAt,
      type: type ?? this.type,
      images: clearImages ? null : (images ?? this.images),
      isFavorite: isFavorite ?? this.isFavorite,
      favoritedAt: clearFavoritedAt ? null : (favoritedAt ?? this.favoritedAt),
      favoriteFolderId: clearFavoriteFolderId
          ? null
          : (favoriteFolderId ?? this.favoriteFolderId),
    );
  }
}
