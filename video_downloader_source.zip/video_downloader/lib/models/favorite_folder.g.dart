// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'favorite_folder.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class FavoriteFolderAdapter extends TypeAdapter<FavoriteFolder> {
  @override
  final int typeId = 14;

  @override
  FavoriteFolder read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return FavoriteFolder(
      id: fields[0] as String,
      name: fields[1] as String,
      createdAt: fields[2] as DateTime,
      coverUrl: fields[3] as String?,
      isDefault: fields[4] as bool? ?? false,
    );
  }

  @override
  void write(BinaryWriter writer, FavoriteFolder obj) {
    writer
      ..writeByte(5)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.name)
      ..writeByte(2)
      ..write(obj.createdAt)
      ..writeByte(3)
      ..write(obj.coverUrl)
      ..writeByte(4)
      ..write(obj.isDefault);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is FavoriteFolderAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
