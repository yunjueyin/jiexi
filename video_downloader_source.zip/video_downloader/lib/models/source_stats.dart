import 'package:hive/hive.dart';

part 'source_stats.g.dart';

/// 解析源统计数据
@HiveType(typeId: 9)
class SourceStats extends HiveObject {
  /// 源 ID
  @HiveField(0)
  final String sourceId;

  /// 源名称
  @HiveField(1)
  String sourceName;

  /// 总请求数
  @HiveField(2)
  int totalRequests;

  /// 成功数
  @HiveField(3)
  int successCount;

  /// 失败数
  @HiveField(4)
  int failureCount;

  /// 累计耗时（毫秒）
  @HiveField(5)
  int totalDurationMs;

  /// 最后使用时间
  @HiveField(6)
  DateTime? lastUsedAt;

  /// 失败原因统计（key: 原因, value: 次数）
  @HiveField(7)
  Map<String, int> failureReasons;

  /// 最近 10 次请求耗时（用于计算波动）
  @HiveField(8)
  List<int> recentDurations;

  SourceStats({
    required this.sourceId,
    required this.sourceName,
    this.totalRequests = 0,
    this.successCount = 0,
    this.failureCount = 0,
    this.totalDurationMs = 0,
    this.lastUsedAt,
    Map<String, int>? failureReasons,
    List<int>? recentDurations,
  })  : failureReasons = failureReasons ?? {},
        recentDurations = recentDurations ?? [];

  /// 成功率
  double get successRate {
    if (totalRequests == 0) return 0;
    return successCount / totalRequests;
  }

  /// 平均耗时（毫秒）
  double get avgDurationMs {
    if (totalRequests == 0) return 0;
    return totalDurationMs / totalRequests;
  }

  /// 成功率显示文本
  String get successRateText {
    if (totalRequests == 0) return '--';
    return '${(successRate * 100).toStringAsFixed(1)}%';
  }

  /// 平均耗时显示文本
  String get avgDurationText {
    if (totalRequests == 0) return '--';
    final avg = avgDurationMs;
    if (avg < 1000) return '${avg.toStringAsFixed(0)}ms';
    return '${(avg / 1000).toStringAsFixed(2)}s';
  }

  /// 记录一次成功
  void recordSuccess(int durationMs) {
    totalRequests++;
    successCount++;
    totalDurationMs += durationMs;
    lastUsedAt = DateTime.now();
    _addRecentDuration(durationMs);
  }

  /// 记录一次失败
  void recordFailure(int durationMs, String? reason) {
    totalRequests++;
    failureCount++;
    totalDurationMs += durationMs;
    lastUsedAt = DateTime.now();
    _addRecentDuration(durationMs);
    if (reason != null && reason.isNotEmpty) {
      failureReasons[reason] = (failureReasons[reason] ?? 0) + 1;
    }
  }

  /// 添加最近耗时（保留最近 10 条）
  void _addRecentDuration(int durationMs) {
    recentDurations.add(durationMs);
    if (recentDurations.length > 10) {
      recentDurations.removeAt(0);
    }
  }

  /// 重置统计
  void reset() {
    totalRequests = 0;
    successCount = 0;
    failureCount = 0;
    totalDurationMs = 0;
    lastUsedAt = null;
    failureReasons.clear();
    recentDurations.clear();
  }

  /// 最近平均耗时
  double get recentAvgDurationMs {
    if (recentDurations.isEmpty) return 0;
    return recentDurations.reduce((a, b) => a + b) / recentDurations.length;
  }
}
