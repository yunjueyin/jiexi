import 'package:hive/hive.dart';

part 'top10_works_result.g.dart';

/// 单条作品数据（前10作品中的一条）
@HiveType(typeId: 13)
class Top10Work extends HiveObject {
  /// 视频/作品 ID
  @HiveField(0)
  final String videoId;

  /// 标题/描述
  @HiveField(1)
  final String title;

  /// 封面图 URL
  @HiveField(2)
  final String cover;

  /// 点赞数
  @HiveField(3)
  final int likeCount;

  /// 收藏数
  @HiveField(4)
  final int collectCount;

  /// 评论数
  @HiveField(5)
  final int commentCount;

  /// 发布时间
  @HiveField(6)
  final DateTime publishTime;

  /// 分享数（可选）
  @HiveField(7)
  final int? shareCount;

  /// 播放数（可选）
  @HiveField(8)
  final int? playCount;

  Top10Work({
    required this.videoId,
    required this.title,
    required this.cover,
    required this.likeCount,
    required this.collectCount,
    required this.commentCount,
    required this.publishTime,
    this.shareCount,
    this.playCount,
  });
}

/// 前10作品抓取结果
@HiveType(typeId: 12)
class Top10WorksResult extends HiveObject {
  /// 唯一 ID
  @HiveField(0)
  final String id;

  /// 原始链接
  @HiveField(1)
  final String url;

  /// 平台（douyin / kuaishou / xiaohongshu）
  @HiveField(2)
  final String platform;

  /// 作者 ID
  @HiveField(3)
  final String authorId;

  /// 作者昵称
  @HiveField(4)
  final String authorName;

  /// 作者头像 URL
  @HiveField(5)
  final String? authorAvatar;

  /// 作品列表（最多 10 条）
  @HiveField(6)
  final List<Top10Work> works;

  /// 点赞总数
  @HiveField(7)
  final int totalLikes;

  /// 收藏总数
  @HiveField(8)
  final int totalCollects;

  /// 评论总数
  @HiveField(9)
  final int totalComments;

  /// 点赞平均数
  @HiveField(10)
  final double avgLikes;

  /// 收藏平均数
  @HiveField(11)
  final double avgCollects;

  /// 评论平均数
  @HiveField(12)
  final double avgComments;

  /// 点赞中位数
  @HiveField(13)
  final double medianLikes;

  /// 收藏中位数
  @HiveField(14)
  final double medianCollects;

  /// 评论中位数
  @HiveField(15)
  final double medianComments;

  /// 抓取时间
  @HiveField(16)
  final DateTime crawledAt;

  Top10WorksResult({
    required this.id,
    required this.url,
    required this.platform,
    required this.authorId,
    required this.authorName,
    this.authorAvatar,
    required this.works,
    required this.totalLikes,
    required this.totalCollects,
    required this.totalComments,
    required this.avgLikes,
    required this.avgCollects,
    required this.avgComments,
    required this.medianLikes,
    required this.medianCollects,
    required this.medianComments,
    required this.crawledAt,
  });

  /// 作品发布时间跨度（天数）
  int get publishSpanDays {
    if (works.length < 2) return 0;
    final times = works.map((w) => w.publishTime).toList();
    times.sort();
    return times.last.difference(times.first).inDays;
  }

  /// 作品数量
  int get workCount => works.length;

  /// 平台中文名
  String get platformName {
    switch (platform) {
      case 'douyin':
        return '抖音';
      case 'kuaishou':
        return '快手';
      case 'xiaohongshu':
      case 'xhs':
        return '小红书';
      default:
        return '未知';
    }
  }

  /// 格式化数字（万/亿）
  static String formatCount(int count) {
    if (count >= 100000000) {
      return '${(count / 100000000).toStringAsFixed(1)}亿';
    } else if (count >= 10000) {
      return '${(count / 10000).toStringAsFixed(1)}万';
    }
    return count.toString();
  }

  /// 格式化双精度数字（万/亿）
  static String formatDouble(double value) {
    if (value >= 100000000) {
      return '${(value / 100000000).toStringAsFixed(1)}亿';
    } else if (value >= 10000) {
      return '${(value / 10000).toStringAsFixed(1)}万';
    }
    return value.toStringAsFixed(value.truncateToDouble() == value ? 0 : 1);
  }
}
