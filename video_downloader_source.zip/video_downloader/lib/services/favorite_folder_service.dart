import 'package:hive/hive.dart';
import '../models/favorite_folder.dart';

/// 收藏夹分组服务（Hive 持久化）
class FavoriteFolderService {
  static const String _boxName = 'favorite_folders';
  static const String defaultFolderId = 'default';

  Box<FavoriteFolder>? _box;

  bool get isInitialized => _box != null;

  Future<void> init() async {
    if (_box != null) return;
    try {
      _box = await Hive.openBox<FavoriteFolder>(_boxName);
    } catch (e) {
      try {
        await Hive.deleteBoxFromDisk(_boxName);
        _box = await Hive.openBox<FavoriteFolder>(_boxName);
      } catch (_) {
        rethrow;
      }
    }
    // 确保默认分组存在
    await _ensureDefaultFolder();
  }

  /// 确保默认分组存在
  Future<void> _ensureDefaultFolder() async {
    if (_box == null) return;
    if (!_box!.containsKey(defaultFolderId)) {
      final defaultFolder = FavoriteFolder(
        id: defaultFolderId,
        name: '默认分组',
        createdAt: DateTime.now(),
        isDefault: true,
      );
      await _box!.put(defaultFolderId, defaultFolder);
    }
  }

  /// 获取所有分组（按创建时间正序）
  List<FavoriteFolder> getAll() {
    if (_box == null) return [];
    final list = _box!.values.toList();
    list.sort((a, b) {
      // 默认分组始终排在最前
      if (a.isDefault) return -1;
      if (b.isDefault) return 1;
      return a.createdAt.compareTo(b.createdAt);
    });
    return list;
  }

  /// 根据 ID 获取分组
  FavoriteFolder? getById(String id) {
    if (_box == null) return null;
    return _box!.get(id);
  }

  /// 获取默认分组
  FavoriteFolder get defaultFolder {
    final folder = getById(defaultFolderId);
    if (folder != null) return folder;
    return FavoriteFolder(
      id: defaultFolderId,
      name: '默认分组',
      createdAt: DateTime.now(),
      isDefault: true,
    );
  }

  /// 创建新分组
  Future<FavoriteFolder> createFolder(String name) async {
    if (_box == null) {
      throw StateError('FavoriteFolderService not initialized');
    }
    final id = 'folder_${DateTime.now().millisecondsSinceEpoch}';
    final folder = FavoriteFolder(
      id: id,
      name: name.trim(),
      createdAt: DateTime.now(),
    );
    await _box!.put(id, folder);
    return folder;
  }

  /// 重命名分组
  Future<void> renameFolder(String id, String newName) async {
    if (_box == null) return;
    final folder = _box!.get(id);
    if (folder == null || folder.isDefault) return;
    final updated = folder.copyWith(name: newName.trim());
    await _box!.put(id, updated);
  }

  /// 删除分组
  ///
  /// [deleteContents] 是否同时删除组内的收藏记录
  /// 注意：组内收藏记录的清理由调用方负责，此方法仅删除分组本身
  Future<void> deleteFolder(String id) async {
    if (_box == null) return;
    final folder = _box!.get(id);
    if (folder == null || folder.isDefault) return;
    await _box!.delete(id);
  }

  /// 更新分组封面图
  Future<void> updateCover(String id, String? coverUrl) async {
    if (_box == null) return;
    final folder = _box!.get(id);
    if (folder == null) return;
    final updated = folder.copyWith(
      coverUrl: coverUrl,
      clearCoverUrl: coverUrl == null,
    );
    await _box!.put(id, updated);
  }

  /// 检查分组名称是否已存在
  bool nameExists(String name, {String? excludeId}) {
    if (_box == null) return false;
    final trimmedName = name.trim();
    return _box!.values.any((f) =>
        f.name.toLowerCase() == trimmedName.toLowerCase() &&
        f.id != excludeId);
  }

  /// 获取分组数量
  int get count => _box?.length ?? 0;
}
