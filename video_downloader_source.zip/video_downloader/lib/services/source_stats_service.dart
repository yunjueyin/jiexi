import 'package:hive_flutter/hive_flutter.dart';
import '../models/source_stats.dart';

/// 解析源统计服务
///
/// 记录每次解析的源、结果、耗时，用于质量看板
class SourceStatsService {
  static const String _boxName = 'source_stats';
  Box<SourceStats>? _box;

  bool get isInitialized => _box != null;

  Future<void> init() async {
    if (_box != null) return;
    try {
      _box = await Hive.openBox<SourceStats>(_boxName);
    } catch (e) {
      try {
        await Hive.deleteBoxFromDisk(_boxName);
        _box = await Hive.openBox<SourceStats>(_boxName);
      } catch (_) {
        rethrow;
      }
    }
  }

  /// 获取所有统计数据（按成功率降序排列）
  List<SourceStats> getAll() {
    if (_box == null) return [];
    final list = _box!.values.toList();
    list.sort((a, b) {
      // 先按总请求数排序，有数据的排前面
      if (b.totalRequests != a.totalRequests) {
        return b.totalRequests.compareTo(a.totalRequests);
      }
      // 再按成功率排序
      return b.successRate.compareTo(a.successRate);
    });
    return list;
  }

  /// 获取指定源的统计
  SourceStats? getStats(String sourceId, {String? sourceName}) {
    if (_box == null) return null;
    var stats = _box!.get(sourceId);
    if (stats == null && sourceName != null) {
      stats = SourceStats(sourceId: sourceId, sourceName: sourceName);
      _box!.put(sourceId, stats);
    }
    return stats;
  }

  /// 记录一次解析结果
  Future<void> recordResult({
    required String sourceId,
    required String sourceName,
    required bool success,
    required int durationMs,
    String? failureReason,
  }) async {
    if (_box == null) return;

    var stats = _box!.get(sourceId);
    stats ??= SourceStats(sourceId: sourceId, sourceName: sourceName);

    // 更新名称（如果变化）
    if (stats.sourceName != sourceName) {
      stats.sourceName = sourceName;
    }

    if (success) {
      stats.recordSuccess(durationMs);
    } else {
      stats.recordFailure(durationMs, failureReason);
    }

    await stats.save();
  }

  /// 记录成功
  Future<void> recordSuccess({
    required String sourceId,
    required String sourceName,
    required int durationMs,
  }) async {
    await recordResult(
      sourceId: sourceId,
      sourceName: sourceName,
      success: true,
      durationMs: durationMs,
    );
  }

  /// 记录失败
  Future<void> recordFailure({
    required String sourceId,
    required String sourceName,
    required int durationMs,
    String? reason,
  }) async {
    await recordResult(
      sourceId: sourceId,
      sourceName: sourceName,
      success: false,
      durationMs: durationMs,
      failureReason: reason,
    );
  }

  /// 重置单个源的统计
  Future<void> reset(String sourceId) async {
    if (_box == null) return;
    final stats = _box!.get(sourceId);
    if (stats != null) {
      stats.reset();
      await stats.save();
    }
  }

  /// 重置所有统计
  Future<void> resetAll() async {
    if (_box == null) return;
    for (final stats in _box!.values) {
      stats.reset();
      await stats.save();
    }
  }

  /// 删除指定源的统计
  Future<void> remove(String sourceId) async {
    if (_box == null) return;
    await _box!.delete(sourceId);
  }

  /// 清除所有统计数据
  Future<void> clear() async {
    if (_box == null) return;
    await _box!.clear();
  }

  /// 总请求数
  int get totalRequests {
    if (_box == null) return 0;
    return _box!.values.fold(0, (sum, s) => sum + s.totalRequests);
  }

  /// 总成功数
  int get totalSuccess {
    if (_box == null) return 0;
    return _box!.values.fold(0, (sum, s) => sum + s.successCount);
  }

  /// 总体成功率
  double get overallSuccessRate {
    final total = totalRequests;
    if (total == 0) return 0;
    return totalSuccess / total;
  }

  /// 获取所有失败原因的汇总统计
  Map<String, int> getAllFailureReasons() {
    if (_box == null) return {};
    final result = <String, int>{};
    for (final stats in _box!.values) {
      stats.failureReasons.forEach((reason, count) {
        result[reason] = (result[reason] ?? 0) + count;
      });
    }
    // 按次数降序
    final sorted = result.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    return Map.fromEntries(sorted);
  }

  /// 获取成功率排行榜（按成功率降序，至少 1 次请求）
  List<SourceStats> getSuccessRanking() {
    final list = getAll().where((s) => s.totalRequests > 0).toList();
    list.sort((a, b) => b.successRate.compareTo(a.successRate));
    return list;
  }

  /// 获取平均耗时排行榜（从快到慢，至少 1 次请求）
  List<SourceStats> getSpeedRanking() {
    final list = getAll().where((s) => s.totalRequests > 0).toList();
    list.sort((a, b) => a.avgDurationMs.compareTo(b.avgDurationMs));
    return list;
  }
}
