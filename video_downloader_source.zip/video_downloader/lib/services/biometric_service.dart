import 'package:local_auth/local_auth.dart';

/// 生物识别服务
///
/// 提供指纹/面容识别功能，用于隐私锁等场景。
class BiometricService {
  static final LocalAuthentication _auth = LocalAuthentication();

  /// 检查设备是否支持生物识别
  static Future<bool> canCheckBiometrics() async {
    try {
      return await _auth.canCheckBiometrics;
    } catch (_) {
      return false;
    }
  }

  /// 获取可用的生物识别类型列表
  static Future<List<BiometricType>> getAvailableBiometrics() async {
    try {
      return await _auth.getAvailableBiometrics();
    } catch (_) {
      return [];
    }
  }

  /// 检查设备是否有任何生物识别已注册
  static Future<bool> hasBiometrics() async {
    try {
      final available = await _auth.getAvailableBiometrics();
      return available.isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  /// 进行生物识别验证
  ///
  /// [reason] 是显示给用户的提示文字，如 "请验证身份以解锁"
  /// 返回 true 表示验证成功，false 表示失败或取消
  static Future<bool> authenticate({String reason = '请验证身份'}) async {
    try {
      return await _auth.authenticate(
        localizedReason: reason,
        options: const AuthenticationOptions(
          biometricOnly: false,
          stickyAuth: true,
          useErrorDialogs: true,
        ),
      );
    } catch (_) {
      return false;
    }
  }

  /// 停止生物识别（如果正在进行中）
  static Future<void> stopAuthentication() async {
    try {
      await _auth.stopAuthentication();
    } catch (_) {
      // 忽略错误
    }
  }
}
