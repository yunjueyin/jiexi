import 'dart:async';

/// WebView 抓取服务抽象接口
///
/// 用于隔离移动端特有的 flutter_inappwebview 依赖，
/// 桌面端不注册实现，调用时返回不支持的异常。
abstract class WebviewCrawlerService {
  static WebviewCrawlerService? _instance;

  /// 注册实现（仅在移动端调用）
  static void register(WebviewCrawlerService impl) {
    _instance = impl;
  }

  /// 获取实例
  static WebviewCrawlerService? get instance => _instance;

  /// 是否可用
  static bool get isAvailable => _instance != null;

  /// 抓取抖音作者作品列表
  Future<List<Map<String, dynamic>>> crawlAuthorPosts(
    String secUid, {
    int count = 30,
    String? cookies,
    void Function(String status)? onStatus,
    String? cursor,
  });
}

/// WebView 抓取不支持异常
class WebviewCrawlerNotSupportedException implements Exception {
  @override
  String toString() => '当前平台不支持 WebView 抓取';
}
