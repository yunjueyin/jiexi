import 'dart:convert';

/// 抖音/快手分享页数据提取器（纯函数，无网络依赖）
///
/// 从分享页 HTML 中提取内嵌 JSON（_ROUTER_DATA / RENDER_DATA /
/// __INITIAL_STATE__ 等），并映射为抓取字段。
///
/// 关键实现：使用括号配对法提取完整 JSON，避免正则在嵌套对象
/// 或字符串内部的 "};" 处提前截断（旧实现的致命 bug）。
class SharePageExtractor {
  SharePageExtractor._();

  // ==================== JSON 提取 ====================

  /// 提取 window._ROUTER_DATA（兼容带/不带 window. 前缀、赋值两侧空格）
  static Map<String, dynamic>? extractRouterData(String html) {
    if (html.isEmpty) return null;
    return _extractByMarkers(html, const [
      'window._ROUTER_DATA',
      '_ROUTER_DATA',
    ]);
  }

  /// 提取 RENDER_DATA script（内容为 URL 编码或原始 JSON）
  static Map<String, dynamic>? extractRenderData(String html) {
    if (html.isEmpty) return null;
    final m = RegExp(
      r'<script[^>]*id="RENDER_DATA"[^>]*>([^<]+)</script>',
      caseSensitive: false,
    ).firstMatch(html);
    if (m == null) return null;
    var content = m.group(1)!.trim();
    if (content.isEmpty) return null;
    // 内容通常是 URL 编码的 JSON
    if (content.startsWith('%')) {
      try {
        content = Uri.decodeComponent(content);
      } catch (_) {
        return null;
      }
    }
    return _tryDecodeObject(content);
  }

  /// 提取 window.__INITIAL_STATE__（兼容 INIT_STATE / _INITIAL_STATE_ /
  /// __NEXT_DATA__ / pageData）
  static Map<String, dynamic>? extractInitialState(String html) {
    if (html.isEmpty) return null;
    return _extractByMarkers(html, const [
      'window.__INITIAL_STATE__',
      'window.INIT_STATE',
      'window._INITIAL_STATE_',
      '__INITIAL_STATE__',
      '__NEXT_DATA__',
      'window.pageData',
    ]);
  }

  /// 依次尝试所有标记，返回第一个成功解析的 JSON
  static Map<String, dynamic>? extractAnyJson(String html) {
    return extractRouterData(html) ??
        extractInitialState(html) ??
        extractRenderData(html);
  }

  /// 抖音视频分享页 HTML → 抓取字段（ROUTER_DATA.item_list[0]）
  static Map<String, dynamic> douyinVideoFromHtml(String html) {
    // 1. 优先从 _ROUTER_DATA 提取（Next.js SSR 标准位置）
    final router = extractRouterData(html) ?? extractInitialState(html);
    if (router != null) {
      // 查找 item_list（多种可能路径）
      const listKeys = ['item_list', 'aweme_list', 'awemeList', 'list'];
      for (final listKey in listKeys) {
        final itemList = _deepFindKey(router, listKey);
        if (itemList is List && itemList.isNotEmpty) {
          final first = itemList.first;
          if (first is Map && _looksLikeAweme(first)) {
            return douyinVideoFromItem(first);
          }
        }
      }
      // 兜底：找 awemeDetail / videoInfoRes 中的数据
      for (final nodeKey in ['awemeDetail', 'videoInfoRes', 'aweme_detail']) {
        final node = _deepFindKey(router, nodeKey);
        if (node is Map && _looksLikeAweme(node)) {
          return douyinVideoFromItem(node);
        }
        if (node is Map) {
          final inner = node['aweme'] ?? node['item_info'];
          if (inner is Map && _looksLikeAweme(inner)) {
            return douyinVideoFromItem(inner);
          }
        }
      }
    }

    // 2. 兜底：从任意内嵌 JSON 中找（extractAnyJson 搜索更多格式）
    final anyJson = extractAnyJson(html);
    if (anyJson != null) {
      const listKeys = ['item_list', 'aweme_list', 'awemeList', 'list'];
      for (final listKey in listKeys) {
        final itemList = _deepFindKey(anyJson, listKey);
        if (itemList is List && itemList.isNotEmpty) {
          final first = itemList.first;
          if (first is Map && _looksLikeAweme(first)) {
            return douyinVideoFromItem(first);
          }
        }
      }
    }

    return {};
  }

  /// 判断一个 Map 是否看起来像抖音 aweme（视频/图文作品）对象
  ///
  /// 有 video 节点 或 images 列表都算有效作品。
  static bool _looksLikeAweme(dynamic data) {
    if (data is! Map) return false;
    if (data['video'] is Map) return true;
    final images = data['images'];
    if (images is List && images.isNotEmpty) return true;
    // 有 aweme_id 或 desc 也可能是（兜底判断）
    if (data['aweme_id'] != null || data['awemeId'] != null) return true;
    return false;
  }

  /// 快手视频分享页 HTML → 抓取字段
  /// 深度搜索内嵌 JSON 中真正的 photo 对象（photoUrl / mainMvUrls / images）
  static Map<String, dynamic> kuaishouVideoFromHtml(String html) {
    final json = extractInitialState(html);
    if (json == null) return {};
    final photo = _deepFindWhere(json, _looksLikeKuaishouPhoto);
    if (photo == null) return {};
    return kuaishouVideoFromPhoto(photo);
  }

  /// 判断节点是否为快手 photo 对象（含播放地址或图集）
  static bool _looksLikeKuaishouPhoto(Map m) {
    final photoUrl = m['photoUrl'];
    if (photoUrl is String && photoUrl.isNotEmpty) return true;
    if (m['mainMvUrls'] is List && (m['mainMvUrls'] as List).isNotEmpty) {
      return true;
    }
    return m['images'] is List && (m['images'] as List).isNotEmpty;
  }

  /// 抖音作者分享页 HTML → 抓取字段（多种内嵌 JSON 深度搜索）
  ///
  /// 深度搜索可能匹配到视频的 author 节点或其他用户节点，
  /// 但只要 uid 通过严格的纯数字校验（5-25位数字），就是有效的作者 UID
  /// （视频 author.uid 和作者主页 uid 是同一个值）。
  /// 如果深度搜索得到的 uid 无效，再尝试从作品列表、用户节点等多渠道提取。
  static Map<String, dynamic> douyinAuthorFromHtml(String html) {
    final json = extractAnyJson(html);
    if (json == null) return {};
    final result = douyinAuthorFromJson(json);
    // 数字 uid 优先：当前 uid 非纯数字（short_id/sec_uid 回退值）时，
    // 尝试从作品列表的 author.uid 补充数字 uid；
    // 补充失败则保留回退值（2026-08 起抖音已不返回数字 uid，
    // sec_uid 是当前唯一可用的规范用户标识，不能丢弃）
    final existingUid = result['uid']?.toString();
    if (!_isValidUid(existingUid)) {
      final uidFromSearch = _extractUidFromItemList(json);
      if (uidFromSearch != null && uidFromSearch.isNotEmpty) {
        result['uid'] = uidFromSearch;
        result.remove('uidIsSecUid');
      }
    }
    return result;
  }

  /// 从作者分享页 HTML 中提取作品列表（item_list / aweme_list）
  ///
  /// 返回原始 aweme 对象列表，外层调用方负责标准化字段。
  /// 作者分享页的 SSR 数据通常包含前若干条作品（一般是前10-20条）。
  static List<Map<String, dynamic>> douyinVideoListFromHtml(String html) {
    final result = <Map<String, dynamic>>[];
    final json = extractAnyJson(html);
    if (json == null) return result;

    const listKeys = ['item_list', 'aweme_list', 'awemeList', 'list'];
    for (final listKey in listKeys) {
      final itemList = _deepFindKey(json, listKey);
      if (itemList is List && itemList.isNotEmpty) {
        for (final item in itemList) {
          if (item is Map<String, dynamic> && _looksLikeAweme(item)) {
            result.add(item);
          }
        }
        if (result.isNotEmpty) break;
      }
    }
    return result;
  }

  /// 从作者分享页 HTML 中提取数字 uid（从作品列表的 author.uid 获取）
  ///
  /// 作者分享页的 SSR 数据包含作品列表（item_list），每条视频的
  /// author 节点都带可靠的数字 uid。本方法只提取 uid，
  /// 用于在 user/info API 数据基础上补充 uid 字段。
  /// 返回 null 表示提取失败。
  static String? extractUidFromAuthorPage(String html) {
    // 策略1：从内嵌 JSON 中提取
    final json = extractAnyJson(html);
    if (json != null) {
      final uid = _extractUidFromItemList(json);
      if (uid != null && uid.isNotEmpty) return uid;
    }
    // 策略2：从 HTML 中正则匹配 "uid": "数字" 格式（更激进的兜底）
    final uidFromRegex = _extractUidByRegex(html);
    if (uidFromRegex != null && uidFromRegex.isNotEmpty) return uidFromRegex;
    return null;
  }

  /// 从 HTML 中正则提取 uid（兜底策略）
  ///
  /// 匹配模式：
  /// - "uid":"1234567890"
  /// - "user_id":"1234567890"
  /// - 'uid': '1234567890'
  /// - uid=1234567890
  ///
  /// 严格校验：必须是 5-25 位纯数字，且不能全为 0
  static String? _extractUidByRegex(String html) {
    if (html.isEmpty) return null;

    // 模式1：JSON 格式 "uid": "123456" 或 "user_id": "123456"
    final patterns = [
      RegExp(r'"uid"\s*:\s*"(\d{5,25})"'),
      RegExp(r'"user_id"\s*:\s*"(\d{5,25})"'),
      RegExp(r"'uid'\s*:\s*'(\d{5,25})'"),
      RegExp(r'"uid"\s*:\s*(\d{5,25})[,}\s]'),
      RegExp(r'"user_id"\s*:\s*(\d{5,25})[,}\s]'),
    ];

    for (final pattern in patterns) {
      final matches = pattern.allMatches(html);
      for (final m in matches) {
        final uid = m.group(1);
        if (_isValidUid(uid)) return uid;
      }
    }
    return null;
  }

  /// 从内嵌 JSON 中提取作者数字 uid（多渠道尝试）
  ///
  /// 优先级：
  /// 1. 从作品列表第一条视频的 author.uid 提取（最可靠）
  /// 2. 从主用户信息节点的 uid 提取（需通过纯数字校验）
  ///
  /// 作品列表可能的 key：item_list / aweme_list / awemeList / list
  static String? _extractUidFromItemList(dynamic json) {
    // 1. 从作品列表的 author.uid 提取（最可靠）
    const listKeys = ['item_list', 'aweme_list', 'awemeList', 'list'];
    for (final listKey in listKeys) {
      final itemList = _deepFindKey(json, listKey);
      if (itemList is List && itemList.isNotEmpty) {
        final firstItem = itemList.first;
        if (firstItem is Map) {
          final author = firstItem['author'];
          if (author is Map) {
            final uid = author['uid']?.toString();
            if (_isValidUid(uid)) {
              return uid;
            }
          }
        }
      }
    }
    // 2. 从主用户信息节点提取（需严格验证）
    // 先找 userInfo / user_info / user 节点
    const userNodeKeys = ['userInfo', 'user_info', 'user', 'userInfos'];
    for (final nodeKey in userNodeKeys) {
      final userNode = _deepFindKey(json, nodeKey);
      if (userNode is Map) {
        final uid = userNode['uid']?.toString();
        if (_isValidUid(uid)) {
          return uid;
        }
        // 嵌套的 user 节点
        final inner = userNode['user'];
        if (inner is Map) {
          final innerUid = inner['uid']?.toString();
          if (_isValidUid(innerUid)) {
            return innerUid;
          }
        }
      }
    }
    return null;
  }

  /// 验证 uid 是否为有效的纯数字抖音 UID
  ///
  /// 抖音 UID 通常是 8-20 位纯数字，不能为 0 或空。
  static bool _isValidUid(String? uid) {
    if (uid == null || uid.isEmpty) return false;
    if (uid == '0') return false;
    if (!RegExp(r'^\d+$').hasMatch(uid)) return false;
    if (uid.length < 5 || uid.length > 25) return false;
    return true;
  }

  /// 快手 photo 原始对象（GraphQL VisionVideoDetail / 移动端页面）→ 抓取字段
  static Map<String, dynamic> kuaishouVideoFromPhoto(dynamic photo) {
    final result = <String, dynamic>{};
    if (photo is! Map) return result;

    _putStr(result, 'videoId', photo,
        ['photoId', 'id', 'objectId']);
    _putStr(result, 'title', photo,
        ['caption', 'originCaption', 'title', 'desc']);

    // 封面：coverUrl 字符串 或 coverUrls/webpCoverUrls 列表（移动端页面）
    String? cover = _urlFromResource(photo['coverUrl']);
    if (cover == null || cover.isEmpty) {
      cover = _urlFromResource(photo['poster']);
    }
    if (cover == null || cover.isEmpty) {
      for (final key in ['coverUrls', 'covers', 'webpCoverUrls']) {
        final list = photo[key];
        if (list is List && list.isNotEmpty) {
          for (final item in list) {
            final url = _urlFromResource(item is Map ? item : null) ??
                (item is String ? item : null);
            if (url != null && url.isNotEmpty) {
              cover = url;
              break;
            }
          }
          if (cover != null) break;
        }
      }
    }
    if (cover != null && cover.isNotEmpty) result['cover'] = cover;

    _putInt(result, 'diggCount', photo,
        ['likeCount', 'like_count', 'diggCount', 'realLikeCount']);
    // 播放数：仅写入 > 0 的真实值（平台不公开时显示占位符而非假 0）
    _putIntPositive(result, 'playCount', photo,
        ['viewCount', 'view_count', 'playCount']);
    _putInt(result, 'commentCount', photo,
        ['commentCount', 'comment_count']);
    _putInt(result, 'shareCount', photo,
        ['shareCount', 'share_count']);
    _putInt(result, 'collectCount', photo,
        ['collectCount', 'collect_count']);

    final d = toInt(photo['duration']);
    if (d != null && d > 0) {
      result['duration'] = d > 1000 ? d ~/ 1000 : d;
    }

    // 时间戳：秒或毫秒（移动端页面为毫秒）统一转秒
    var ts = toInt(photo['timestamp'] ??
        photo['createTime'] ??
        photo['create_time']);
    if (ts != null && ts > 0) {
      if (ts > 9999999999) ts = ts ~/ 1000;
      result['createTime'] = formatEpoch(ts);
    }

    _putStr(result, 'videoUrl', photo, ['photoUrl', 'photo_url']);

    // mainMvUrls 清晰度列表
    final mainMvUrls = photo['mainMvUrls'];
    if (mainMvUrls is List && mainMvUrls.isNotEmpty) {
      String? best;
      for (final mv in mainMvUrls) {
        if (mv is Map) {
          final u = mv['url']?.toString();
          if (u != null && u.isNotEmpty) {
            if (result['videoUrl'] == null) result['videoUrl'] = u;
            if (best == null || u.length > best.length) best = u;
          }
        }
      }
      if (best != null && best != result['videoUrl']) {
        result['videoUrlHd'] = best;
      }
    }

    final author = photo['author'] ?? photo['user'];
    if (author is Map) {
      _putStr(result, 'authorNickname', author,
          ['name', 'nickname', 'user_name', 'userName']);
      _putStr(result, 'authorUid', author, ['id', 'userId', 'user_id']);
      _putStr(result, 'authorAvatar', author,
          ['avatar', 'headUrl', 'head_url', 'headerUrl']);
    } else {
      // 移动端页面：作者字段平铺在 photo 上（userName/userId/headUrl）
      _putStr(result, 'authorNickname', photo, ['userName', 'user_name']);
      _putStr(result, 'authorUid', photo, ['userId', 'user_id', 'userEid']);
      _putStr(result, 'authorAvatar', photo,
          ['headUrl', 'head_url', 'headerUrl']);
    }

    result.removeWhere((k, v) => v == null || v.toString().isEmpty);
    return result;
  }

  /// 按标记逐个位置查找并提取平衡 JSON
  static Map<String, dynamic>? _extractByMarkers(
      String html, List<String> markers) {
    for (final marker in markers) {
      var searchFrom = 0;
      while (searchFrom < html.length) {
        final idx = html.indexOf(marker, searchFrom);
        if (idx < 0) break;

        final brace = html.indexOf('{', idx + marker.length);
        if (brace < 0) break;

        // 标记与 "{" 之间只允许 = 空白 等字符（防止误匹配注释里的文字）
        final between = html.substring(idx + marker.length, brace);
        if (between.length > 8 || !RegExp(r'^[=\s;:]*$').hasMatch(between)) {
          searchFrom = idx + marker.length;
          continue;
        }

        final jsonStr = extractBalancedJson(html, brace);
        if (jsonStr != null) {
          final decoded = _tryDecodeObject(jsonStr);
          if (decoded != null) return decoded;
        }
        searchFrom = brace;
      }
    }
    return null;
  }

  /// 括号配对提取完整 JSON 字符串（正确处理字符串内的花括号与转义）
  static String? extractBalancedJson(String text, int start) {
    if (start < 0 || start >= text.length) return null;
    var depth = 0;
    var inString = false;
    var escape = false;
    for (var i = start; i < text.length; i++) {
      final c = text[i];
      if (escape) {
        escape = false;
        continue;
      }
      if (inString) {
        if (c == '\\') {
          escape = true;
        } else if (c == '"') {
          inString = false;
        }
        continue;
      }
      if (c == '"') {
        inString = true;
      } else if (c == '{') {
        depth++;
      } else if (c == '}') {
        depth--;
        if (depth == 0) return text.substring(start, i + 1);
      }
    }
    return null;
  }

  static Map<String, dynamic>? _tryDecodeObject(String s) {
    try {
      final data = jsonDecode(s);
      return data is Map<String, dynamic> ? data : null;
    } catch (_) {
      return null;
    }
  }

  // ==================== 抖音视频字段映射 ====================

  /// item_list[0] 原始 aweme 对象 → 抓取字段
  /// 包含 statistics（点赞/评论/分享/收藏）、create_time、作者信息
  static Map<String, dynamic> douyinVideoFromItem(dynamic item) {
    final result = <String, dynamic>{};
    if (item is! Map) return result;

    _putStr(result, 'videoId', item, ['aweme_id', 'awemeId', 'item_id']);
    _putStr(result, 'title', item, ['desc', 'item_title']);
    if (result['title'] == null) {
      final shareInfo = item['share_info'];
      if (shareInfo is Map) {
        _putStr(result, 'title', shareInfo, ['share_title', 'title']);
      }
    }

    final video = item['video'];
    if (video is Map) {
      // 封面
      for (final key in ['cover', 'origin_cover', 'dynamic_cover']) {
        final cover = _urlFromResource(video[key]);
        if (cover != null && cover.isNotEmpty) {
          result['cover'] = cover;
          break;
        }
      }

      // 时长（毫秒 → 秒）
      final d = toInt(video['duration']);
      if (d != null && d > 0) {
        result['duration'] = d > 1000 ? d ~/ 1000 : d;
      }

      // 播放地址（playwm → play 去水印）
      final playAddr = video['play_addr'];
      if (playAddr is Map) {
        final urls = playAddr['url_list'];
        if (urls is List && urls.isNotEmpty) {
          final url = urls.first.toString().replaceAll('/playwm/', '/play/');
          if (url.isNotEmpty) result['videoUrl'] = url;
        }
      }

      // 高清地址（bit_rate 按码率降序取最高）
      final bitRate = video['bit_rate'];
      if (bitRate is List && bitRate.isNotEmpty) {
        final sorted = bitRate.whereType<Map>().toList()
          ..sort((a, b) =>
              (toInt(b['bit_rate']) ?? 0).compareTo(toInt(a['bit_rate']) ?? 0));
        for (final rate in sorted) {
          final addr = rate['play_addr'] ?? rate['download_addr'];
          if (addr is Map) {
            final urls = addr['url_list'];
            if (urls is List && urls.isNotEmpty) {
              final url = urls.first.toString().replaceAll('/playwm/', '/play/');
              if (url.isNotEmpty) {
                result['videoUrlHd'] = url;
                break;
              }
            }
          }
        }
      }
    }

    // 统计数据
    // 抖音分享页数据结构变化频繁，统计数据可能在多个位置：
    // 1. item.statistics / item.stats（标准位置）
    // 2. 直接在 item 上（部分版本）
    // 3. 在 video 节点内（少数版本）
    // 字段名也有多种变体：play_count / playCount / view_count / viewCount / play_num
    final stats = item['statistics'] ?? item['stats'] ?? item['statistic'] ?? item;
    if (stats is Map) {
      _putInt(result, 'diggCount', stats,
          ['digg_count', 'diggCount', 'like_count', 'likeCount', 'digg_count_v2', 'like_num']);
      _putInt(result, 'commentCount', stats,
          ['comment_count', 'commentCount', 'comment_num']);
      _putInt(result, 'shareCount', stats, ['share_count', 'shareCount', 'share_num']);
      _putInt(
          result, 'collectCount', stats, ['collect_count', 'collectCount', 'favorite_count', 'collect_num']);
      // 播放数：2026-08 实测抖音对匿名请求恒返回 0（官方政策：播放量仅作者本人可见）。
      // 为避免展示误导性的假 0，只在拿到大于 0 的真实值时才写入。
      _putIntPositive(result, 'playCount', stats,
          ['play_count', 'playCount', 'view_count', 'viewCount', 'play_num', 'view_num', 'watch_count']);
    }
    // 兜底：从 video 节点内找播放量（同样要求 > 0）
    if (!_hasValue(result, 'playCount')) {
      final video = item['video'];
      if (video is Map) {
        final vc = toInt(video['play_count'] ??
            video['playCount'] ??
            video['view_count'] ??
            video['viewCount']);
        if (vc != null && vc > 0) {
          result['playCount'] = vc;
        }
      }
    }
    // 兜底：直接从 item 根级别找（同样要求 > 0）
    if (!_hasValue(result, 'playCount')) {
      final vc = toInt(item['play_count'] ??
          item['playCount'] ??
          item['view_count'] ??
          item['viewCount'] ??
          item['play_count_v2']);
      if (vc != null && vc > 0) {
        result['playCount'] = vc;
      }
    }

    // 发布时间（epoch 秒 → yyyy-MM-dd HH:mm:ss）
    final createTime = toInt(item['create_time'] ?? item['createTime']);
    if (createTime != null && createTime > 0) {
      result['createTime'] = formatEpoch(createTime);
    }

    // 作者信息
    final author = item['author'];
    if (author is Map) {
      // 先保存 sec_uid（用于后续通过 DouyinUidService 补全数字 uid）
      _putStr(result, 'authorSecUid', author, ['sec_uid', 'secUid']);
      // 2026-08 实测：分享页 author 节点已无数字 uid，
      // 回退链：uid → short_id(≠"0") → sec_uid
      _putStr(result, 'authorUid', author, ['uid', 'user_id', 'author_user_id']);
      if (!_hasValue(result, 'authorUid')) {
        final shortId = author['short_id']?.toString();
        if (shortId != null && shortId.isNotEmpty && shortId != '0') {
          result['authorUid'] = shortId;
        }
      }
      if (!_hasValue(result, 'authorUid')) {
        _putStr(result, 'authorUid', author, ['sec_uid', 'secUid']);
      }
      // 作者抖音号（抖音网页端不返回数字 uid 时的替代标识）
      final aUniqueId = author['unique_id']?.toString() ??
          author['uniqueId']?.toString();
      if (aUniqueId != null && aUniqueId.isNotEmpty && aUniqueId != '0') {
        result['authorUniqueId'] = aUniqueId;
      }
      _putStr(result, 'authorNickname', author, ['nickname', 'name']);
      for (final key in ['avatar_medium', 'avatar_larger', 'avatar_thumb']) {
        final url = _urlFromResource(author[key]);
        if (url != null && url.isNotEmpty) {
          result['authorAvatar'] = url;
          break;
        }
      }
    }

    result.removeWhere((k, v) => v == null || v.toString().isEmpty);
    return result;
  }

  // ==================== 作者字段映射（抖音/快手通用） ====================

  static const List<String> _authorNameKeys = [
    'nickname', 'user_name', 'userName', 'name',
  ];
  static const List<String> _authorIdKeys = [
    'sec_uid', 'secUid', 'uid', 'user_id', 'userId',
    'follower_count', 'followerCount', 'fans', 'fansCount',
    'following_count', 'followingCount', 'follows',
    'aweme_count', 'awemeCount', 'photos',
  ];

  /// 抖音作者（保留命名兼容）
  static Map<String, dynamic> douyinAuthorFromJson(dynamic json) =>
      authorFromJson(json);

  /// 抖音 user/info API 响应 → 抓取字段
  /// （2026-08 实测 www.iesdouyin.com/web/api/v2/user_info 仍公开可用，
  /// 粉丝数字段为 mplatform_followers_count）
  static Map<String, dynamic> douyinAuthorFromUserInfoApi(Map data) {
    final userInfo = data['user_info'] ?? data['userInfo'];
    if (userInfo is! Map) return {};
    return mapAuthorNode(userInfo);
  }

  /// 快手 GraphQL visionProfile 响应 → 抓取字段
  /// 结构：data.visionProfile.userProfile.{ profile, ownerCount }
  static Map<String, dynamic> kuaishouAuthorFromGraphql(Map data) {
    final userProfile = _deepFindKey(data, 'userProfile');
    if (userProfile is! Map) return {};

    final result = <String, dynamic>{};
    final profile = userProfile['profile'];
    if (profile is Map) {
      _putStr(result, 'uid', profile, ['user_id', 'userId', 'id']);
      _putStr(result, 'nickname', profile, ['user_name', 'name', 'nickname']);
      final avatar =
          _urlFromResource(profile['headurl'] ?? profile['headUrl']);
      if (avatar != null && avatar.isNotEmpty) result['avatar'] = avatar;
    }
    final ownerCount = userProfile['ownerCount'];
    if (ownerCount is Map) {
      _putInt(result, 'followerCount',
          ownerCount, ['fan', 'fans', 'follower_count']);
      _putInt(result, 'followingCount',
          ownerCount, ['follow', 'follows', 'follow_count']);
      _putInt(result, 'awemeCount',
          ownerCount, ['photo', 'photos', 'photo_count']);
    }

    result.removeWhere((k, v) => v == null || v.toString().isEmpty);
    return result;
  }

  /// 通用作者信息提取：深度搜索自动定位用户信息节点，
  /// 兼容抖音（userInfo/userInfos/user）与快手（profile/user_name/fans）结构
  /// 
  /// 注意：深度搜索路径下不返回 uid 字段，因为可能误匹配到其他数据结构
  /// （如 loaderData 里的其他对象）导致抓到错误的 uid 值。
  /// 抖音网页端不返回数字 uid，uniqueId（抖音号）是正确的用户标识。
  static Map<String, dynamic> authorFromJson(dynamic json) {
    final user = _locateAuthorNode(json);
    if (user == null) return {};
    return mapAuthorNode(user);
  }

  /// 快手 live_api userinfo/byid 响应 → 抓取字段
  /// 结构：data.result=1, data.userInfo.{ name, avatar, id, cityName, ... }
  /// （粉丝/作品数需登录，匿名访问 counts 多为空）
  static Map<String, dynamic> kuaishouAuthorFromLiveApi(Map payload) {
    final userInfo = payload['userInfo'];
    if (userInfo is! Map) return {};

    final result = <String, dynamic>{};
    _putStr(result, 'uid', userInfo, ['id', 'user_id', 'userId', 'originUserId']);
    _putStr(result, 'nickname', userInfo, ['name', 'user_name', 'nickname']);
    _putStr(result, 'signature', userInfo, ['bio', 'signature', 'description']);

    final avatar = _urlFromResource(
        userInfo['avatar'] ?? userInfo['headUrl'] ?? userInfo['headurl']);
    if (avatar != null && avatar.isNotEmpty) result['avatar'] = avatar;

    final counts = userInfo['counts'];
    if (counts is Map) {
      _putInt(result, 'followerCount', counts,
          ['fan', 'fans', 'follower', 'followerCount']);
      _putInt(result, 'followingCount', counts,
          ['follow', 'following', 'followingCount']);
      _putInt(result, 'awemeCount', counts,
          ['photo', 'photos', 'photoCount', 'videoCount']);
    }

    result.removeWhere((k, v) => v == null || v.toString().isEmpty);
    return result;
  }

  /// 作者节点 → 标准抓取字段（供 API / GraphQL / 页面映射复用）
  ///
  /// 2026-08 实测：抖音已从所有匿名可访问的数据源（user/info API、
  /// 分享页 SSR）中移除数字 uid，仅返回 sec_uid / short_id / unique_id。
  /// 因此 uid 字段按以下回退链取值：
  ///   1. uid / user_id / userId（数字 uid，若平台返回则最优）
  ///   2. short_id（数字短 ID，非 "0" 时可用）
  ///   3. sec_uid（抖音当前对外唯一的规范用户标识）
  static Map<String, dynamic> mapAuthorNode(Map user) {
    final result = <String, dynamic>{};

    _putStr(result, 'uid', user, ['uid', 'user_id', 'userId']);
    if (!_hasValue(result, 'uid')) {
      final shortId = user['short_id']?.toString();
      if (shortId != null && shortId.isNotEmpty && shortId != '0') {
        result['uid'] = shortId;
      }
    }
    if (!_hasValue(result, 'uid')) {
      _putStr(result, 'uid', user, ['sec_uid', 'secUid']);
    }
    _putStr(result, 'secUid', user, ['sec_uid', 'secUid']);
    // uid 是否为回退到 sec_uid（用于 UI 标注）
    if (result['uid'] == result['secUid'] && result['uid'] != null) {
      result['uidIsSecUid'] = true;
    }
    // 抖音号（unique_id）：抖音网页端已不返回数字 uid，
    // unique_id 是用户可搜索的唯一标识，作为 uid 的实用替代
    final uniqueId = user['unique_id']?.toString() ??
        user['uniqueId']?.toString();
    if (uniqueId != null && uniqueId.isNotEmpty && uniqueId != '0') {
      result['uniqueId'] = uniqueId;
    }
    _putStr(result, 'nickname', user, _authorNameKeys);
    _putStr(result, 'signature', user, ['signature', 'bio', 'desc']);

    // 头像：可能是 {url_list:[...]} 或字符串
    for (final key in [
      'avatar_larger',
      'avatarLarger',
      'avatar_medium',
      'avatarMedium',
      'avatar_thumb',
      'avatarThumb',
      'avatar',
      'headUrl',
      'headurl',
      'head_url',
      'headerUrl',
      'avatarUrl',
    ]) {
      final url = _urlFromResource(user[key]);
      if (url != null && url.isNotEmpty) {
        result['avatar'] = url;
        break;
      }
    }

    _putInt(result, 'followerCount', user, [
      'follower_count',
      'followerCount',
      'mplatform_followers_count',
      'fans_count',
      'fansCount',
      'fans',
    ]);
    _putInt(result, 'followingCount', user,
        ['following_count', 'followingCount', 'follow_count', 'followCount', 'follows']);
    _putInt(result, 'totalFavorited', user,
        ['total_favorited', 'totalFavorited', 'total_likes']);
    _putInt(result, 'awemeCount', user,
        ['aweme_count', 'awemeCount', 'aweme_cnt', 'video_count', 'photos']);
    _putInt(
        result, 'favoriteCount', user, ['favorite_count', 'favoriteCount', 'favoriting_count']);

    result.removeWhere((k, v) => v == null || v.toString().isEmpty);
    return result;
  }

  /// 定位作者信息节点：优先 userInfo/userInfos/profile 等命名键，
  /// 其次含昵称键的 user 节点，最后兜底任意同时含昵称键与身份/计数键的节点
  static Map? _locateAuthorNode(dynamic json) {
    for (final key in ['userInfo', 'user_info', 'userInfos']) {
      final found = _deepFindKey(json, key);
      if (found is Map) return found;
    }
    for (final key in ['user', 'profile']) {
      final found = _deepFindKey(json, key);
      if (found is Map && _hasAnyKey(found, _authorNameKeys)) return found;
    }
    return _deepFindWhere(json,
        (m) => _hasAnyKey(m, _authorNameKeys) && _hasAnyKey(m, _authorIdKeys));
  }

  static bool _hasAnyKey(Map m, List<String> keys) {
    for (final k in keys) {
      if (m[k] != null) return true;
    }
    return false;
  }

  // ==================== 字段过滤 ====================

  /// 按用户选择的字段过滤数据（selected 为 null/空表示不过滤）
  /// 按用户勾选的字段过滤数据
  ///
  /// 规则：
  /// - 用户勾选的字段**一定保留**，即使抓取失败也会显示占位符 "—"
  /// - 未勾选的字段一律移除
  /// - 字段值为空字符串/null 时也显示占位符
  /// - 如果 selected 为 null/空，返回原始数据（不做过滤）
  static Map<String, dynamic> filterFields(
    Map<String, dynamic> data,
    List<String>? selected,
  ) {
    if (selected == null || selected.isEmpty) return data;
    final filtered = <String, dynamic>{};
    for (final key in selected) {
      if (data.containsKey(key)) {
        final value = data[key];
        // 值为空时用占位符
        if (value == null || value.toString().trim().isEmpty) {
          filtered[key] = '—';
        } else {
          filtered[key] = value;
        }
      } else {
        // 勾选了但没抓到，用占位符
        filtered[key] = '—';
      }
    }
    return filtered;
  }

  // ==================== 通用工具 ====================

  /// 安全转 int（兼容 int / double / 数字字符串）
  static int? toInt(dynamic v) {
    if (v is int) return v;
    if (v is double) return v.toInt();
    if (v is String) {
      final s = v.trim().replaceAll(',', '');
      if (s.isEmpty) return null;
      return int.tryParse(s);
    }
    return null;
  }

  /// epoch 秒 → "yyyy-MM-dd HH:mm:ss"（本地时区）
  static String formatEpoch(int seconds) {
    final dt = DateTime.fromMillisecondsSinceEpoch(seconds * 1000);
    String two(int n) => n.toString().padLeft(2, '0');
    return '${dt.year}-${two(dt.month)}-${two(dt.day)} '
        '${two(dt.hour)}:${two(dt.minute)}:${two(dt.second)}';
  }

  /// 从 {url_list:[...]} 或字符串中取第一个 URL
  static String? _urlFromResource(dynamic resource) {
    if (resource is String) return resource.isEmpty ? null : resource;
    if (resource is Map) {
      final urls = resource['url_list'];
      if (urls is List && urls.isNotEmpty) {
        return urls.first.toString();
      }
      final url = resource['url'];
      if (url is String && url.isNotEmpty) return url;
    }
    return null;
  }

  static void _putStr(Map<String, dynamic> result, String dstKey, Map src,
      List<String> keys) {
    for (final key in keys) {
      final v = src[key];
      if (v != null && v.toString().isNotEmpty) {
        result[dstKey] = v.toString();
        return;
      }
    }
  }

  static void _putInt(Map<String, dynamic> result, String dstKey, Map src,
      List<String> keys) {
    for (final key in keys) {
      final v = toInt(src[key]);
      if (v != null) {
        result[dstKey] = v;
        return;
      }
    }
  }

  /// 同 [_putInt]，但只接受大于 0 的值（用于播放数等平台可能返回假 0 的字段）
  static void _putIntPositive(Map<String, dynamic> result, String dstKey,
      Map src, List<String> keys) {
    for (final key in keys) {
      final v = toInt(src[key]);
      if (v != null && v > 0) {
        result[dstKey] = v;
        return;
      }
    }
  }

  /// result 中指定 key 是否已有非空值
  static bool _hasValue(Map<String, dynamic> result, String key) {
    final v = result[key];
    return v != null && v.toString().isNotEmpty;
  }

  /// 深度查找指定 key（限制深度防止爆栈）
  /// 深度查找指定 key 的值（限制深度避免爆炸）
  /// 公开方法，供外部调用
  static dynamic deepFindKey(dynamic data, String key, {int maxDepth = 8}) {
    return _deepFindKey(data, key, depth: 0, maxDepth: maxDepth);
  }

  /// 深度查找指定 key（限制深度防止爆栈）
  static dynamic _deepFindKey(dynamic data, String key, {int depth = 0, int maxDepth = 10}) {
    if (depth > maxDepth) return null;
    if (data is Map) {
      if (data.containsKey(key)) return data[key];
      for (final value in data.values) {
        final r = _deepFindKey(value, key, depth: depth + 1, maxDepth: maxDepth);
        if (r != null) return r;
      }
    } else if (data is List) {
      for (final item in data) {
        final r = _deepFindKey(item, key, depth: depth + 1, maxDepth: maxDepth);
        if (r != null) return r;
      }
    }
    return null;
  }

  /// 深度查找满足条件的 Map
  static Map? _deepFindWhere(dynamic data, bool Function(Map) test,
      [int depth = 0]) {
    if (depth > 10) return null;
    if (data is Map) {
      if (test(data)) return data;
      for (final value in data.values) {
        final r = _deepFindWhere(value, test, depth + 1);
        if (r != null) return r;
      }
    } else if (data is List) {
      for (final item in data) {
        final r = _deepFindWhere(item, test, depth + 1);
        if (r != null) return r;
      }
    }
    return null;
  }
}
