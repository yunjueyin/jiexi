import 'dart:async';
import 'dart:collection';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

import '../../app.dart';
import 'webview_crawler_service.dart';

/// WebView 抓取失败异常
class DouyinWebviewCrawlException implements Exception {
  final String message;
  DouyinWebviewCrawlException(this.message);

  @override
  String toString() => message;
}

/// WebView 抓取服务的抖音实现
class _DouyinWebviewCrawlerImpl implements WebviewCrawlerService {
  @override
  Future<List<Map<String, dynamic>>> crawlAuthorPosts(
    String secUid, {
    int count = 30,
    String? cookies,
    void Function(String status)? onStatus,
    String? cursor,
  }) async {
    return DouyinWebviewCrawler.crawlAuthorPosts(
      secUid,
      count: count,
      cookies: cookies != null
          ? _parseCookieString(cookies)
          : null,
      onStatus: onStatus,
    );
  }

  Map<String, String> _parseCookieString(String cookieStr) {
    final map = <String, String>{};
    for (final pair in cookieStr.split(';')) {
      final trimmed = pair.trim();
      if (trimmed.isEmpty) continue;
      final idx = trimmed.indexOf('=');
      if (idx > 0) {
        map[trimmed.substring(0, idx)] = trimmed.substring(idx + 1);
      }
    }
    return map;
  }
}

/// 注册抖音 WebView 抓取服务实现（仅移动端调用）
void registerDouyinWebviewCrawler() {
  WebviewCrawlerService.register(_DouyinWebviewCrawlerImpl());
}

/// 抖音作者主页 WebView 抓取器（API 拦截版）
///
/// 2026-09 沙箱真实浏览器实测结论（chromium + 桌面 UA 访问 douyin.com/user/{secUid}）：
///   1. SSR 数据（RENDER_DATA/_ROUTER_DATA/__INITIAL_STATE__）已不再包含作品列表，
///      RENDER_DATA 里只有站点配置（app 节点），深度搜索找不到任何 aweme；
///   2. 作品列表由页面 JS 通过 `/aweme/v1/web/aweme/post/` 接口获取（带 X-Bogus 签名），
///      匿名/风控环境下该接口返回 200 空 body，页面作品网格完全不渲染，
///      页面只剩页脚「热门」区块的 SEO 假链接（href 带 source=Baiduspider）；
///   3. 作者信息接口 `/aweme/v1/web/user/profile/other/` 匿名可访问，返回完整资料。
///
/// 本抓取器方案（可靠性设计）：
///   - 「文档开始注入 + API 拦截」：在任何页面脚本执行前包装 XHR/fetch
///     （flutter_inappwebview 的 AT_DOCUMENT_START 用户脚本，主 world 注入，
///     Android 经 WebViewCompat.addDocumentStartJavaScript 真正于文档开始执行，
///     页面跳转/风控挑战后自动重新注入），捕获页面自身发起的作品列表/
///     作者信息接口响应（页面自算的 X-Bogus 签名天然有效，运行在用户真实
///     设备与网络环境下风控压力最小）；
///   - 分页合并：页面滚动触发的多次接口响应按 aweme_id 去重合并，
///     按 has_more 判断是否已取全；数据不足时自动滚动页面触发加载更多；
///   - 安全验证自动可见化：检测到滑块验证码（secsdk-captcha）时，
///     WebView 自动放大到全屏并允许交互，用户完成验证后自动隐藏继续抓取，
///     验证期间暂停超时计时；
///   - 兜底1：SSR 内嵌数据深搜（RENDER_DATA/_ROUTER_DATA/__INITIAL_STATE__，
///     在页面内完成搜索并裁剪字段，避免传输超大 JSON）；
///   - 兜底2：DOM 提取（过滤页脚 SEO 假链接与 source= 追踪参数，尝试解析点赞数）；
///   - 作品接口返回空 body 时（未登录/风控），8 秒内无其它数据则提前失败，
///     并提示到「设置-抖音Cookie」登录（登录态注入后接口通常恢复返回数据）；
///   - 若用户已在设置中保存抖音 Cookie，抓取前注入 WebView（登录态访问）。
///
/// WebView 平时以 1280x800（桌面页面正常布局尺寸，避免虚拟列表因视口过小不渲染）、
/// 透明度 0.01、忽略点击的悬浮层挂在全局 Overlay 上，对用户不可见且不影响操作；
/// 出现安全验证时自动切换为全屏可见可交互。
class DouyinWebviewCrawler {
  DouyinWebviewCrawler._();

  /// 桌面端 UA：确保抖音返回网页版页面（数据接口与 DOM 结构与实测一致）
  static const String _desktopUa =
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

  /// 并发保护：同一时刻只允许一个 WebView 抓取任务
  static bool _running = false;

  /// 文档开始注入的拦截脚本（拦截核心已通过 23 项端到端测试验证）
  ///
  /// 功能：
  /// - 包装 XMLHttpRequest / fetch，匹配 `/aweme/v1/web/aweme/post/`
  ///   与 `/aweme/v1/web/user/profile/other/` 两个接口；
  /// - 捕获作品列表响应：裁剪每条 aweme 至必要字段，多次分页响应按
  ///   aweme_id 去重合并、按发布时间倒序，存入 window.__dyCap.posts；
  /// - 记录最后一次响应的 has_more 到 cap.hasMore（判断是否已取全）；
  /// - 接口返回空 body / 非 JSON（风控）时标记 postApiEmpty；
  /// - 合法空列表（作者无作品）时 posts 置为空数组（Dart 侧据此给出精确提示），
  ///   已有数据时不会被后续空响应清空；
  /// - 捕获作者信息存入 window.__dyCap.profile。
  static const String _hookJs = r'''
(function() {
  if (window.__dyCap) return;
  var cap = {
    posts: null,
    profile: null,
    postApiEmpty: false,
    postApiStatus: 0,
    hasMore: null
  };
  window.__dyCap = cap;

  function trimAweme(a) {
    if (!a || typeof a !== 'object') return null;
    try {
      var st = a.statistics || {};
      var au = a.author || {};
      var v = a.video || {};
      return {
        aweme_id: a.aweme_id != null ? a.aweme_id : (a.awemeId != null ? a.awemeId : a.id),
        desc: a.desc != null ? a.desc : a.title,
        create_time: a.create_time != null ? a.create_time : a.createTime,
        duration: a.duration,
        share_url: a.share_url,
        statistics: {
          digg_count: st.digg_count,
          comment_count: st.comment_count,
          share_count: st.share_count,
          collect_count: st.collect_count,
          play_count: st.play_count
        },
        author: {
          uid: au.uid,
          sec_uid: au.sec_uid,
          unique_id: au.unique_id,
          nickname: au.nickname,
          avatar_thumb: au.avatar_thumb,
          avatar_medium: au.avatar_medium
        },
        video: {
          play_addr: v.play_addr,
          download_addr: v.download_addr,
          cover: v.cover
        }
      };
    } catch (e) {
      return null;
    }
  }

  function handlePostResponse(text) {
    try {
      if (!text || !text.length) {
        cap.postApiEmpty = true;
        return;
      }
      var d = JSON.parse(text);
      cap.hasMore = !!(d.has_more === true || d.hasMore === true);
      var list = d.aweme_list || d.awemeList;
      if (list && list.length) {
        var trimmed = [];
        for (var i = 0; i < list.length; i++) {
          var t = trimAweme(list[i]);
          if (t) trimmed.push(t);
        }
        if (trimmed.length) {
          // 多次分页响应合并去重（滚动加载更多时不清空已有数据）
          var seen = {};
          var merged = cap.posts ? cap.posts.slice() : [];
          for (var i = 0; i < merged.length; i++) {
            if (merged[i].aweme_id != null) seen[merged[i].aweme_id] = 1;
          }
          for (var j = 0; j < trimmed.length; j++) {
            var id = trimmed[j].aweme_id;
            if (id == null || !seen[id]) {
              if (id != null) seen[id] = 1;
              merged.push(trimmed[j]);
            }
          }
          merged.sort(function(a, b) {
            return ((b.create_time || 0) | 0) - ((a.create_time || 0) | 0);
          });
          cap.posts = merged;
          cap.postApiEmpty = false;
          return;
        }
      }
      if (d.aweme_list != null || d.awemeList != null) {
        // 合法空列表：仅首次（无已有数据）时置空数组
        if (cap.posts == null) cap.posts = [];
        cap.postApiEmpty = false;
        return;
      }
      cap.postApiEmpty = true;
    } catch (e) {
      cap.postApiEmpty = true;
    }
  }

  function handleProfileResponse(text) {
    try {
      if (!text || !text.length) return;
      var d = JSON.parse(text);
      var u = d.user;
      if (u && u.sec_uid) {
        cap.profile = {
          sec_uid: u.sec_uid,
          uid: u.uid,
          short_id: u.short_id,
          nickname: u.nickname,
          unique_id: u.unique_id,
          signature: u.signature,
          avatar_url: (u.avatar_168x168 && u.avatar_168x168.url_list && u.avatar_168x168.url_list[0]) ||
            (u.avatar_300x300 && u.avatar_300x300.url_list && u.avatar_300x300.url_list[0]) || '',
          follower_count: u.follower_count,
          total_favorited: u.total_favorited,
          aweme_count: u.aweme_count
        };
      }
    } catch (e) {}
  }

  function matchPost(url) {
    return /\/aweme\/v1\/web\/aweme\/post\//.test(url);
  }

  function matchProfile(url) {
    return /\/aweme\/v1\/web\/user\/profile\/other\//.test(url);
  }

  var oo = XMLHttpRequest.prototype.open;
  var os = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function(m, u) {
    this.__dyUrl = (u == null ? '' : u) + '';
    return oo.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function() {
    var xhr = this;
    var url = xhr.__dyUrl || '';
    if (matchPost(url) || matchProfile(url)) {
      xhr.addEventListener('load', function() {
        var t = '';
        try { t = xhr.responseText; } catch (e) {}
        if (matchPost(url)) {
          cap.postApiStatus = xhr.status;
          handlePostResponse(t);
        } else {
          handleProfileResponse(t);
        }
      });
    }
    return os.apply(this, arguments);
  };

  if (window.fetch) {
    var of = window.fetch;
    window.fetch = function(input, init) {
      var url = '';
      try {
        url = typeof input === 'string' ? input : (input && input.url) || '';
      } catch (e) {}
      var p = of.apply(this, arguments);
      if (matchPost(url) || matchProfile(url)) {
        p.then(function(resp) {
          if (matchPost(url)) cap.postApiStatus = resp.status;
          try {
            resp.clone().text().then(function(t) {
              if (matchPost(url)) handlePostResponse(t);
              else handleProfileResponse(t);
            });
          } catch (e) {}
        }).catch(function() {});
      }
      return p;
    };
  }
})();
''';

  /// 轮询提取脚本
  ///
  /// 返回：
  /// - captured: 拦截到的作品列表（完整数据，已合并去重、按时间倒序、字段已裁剪）
  /// - postsComplete: 最后一次作品接口响应 has_more=false（数据已取全）
  /// - profile: 拦截到的作者信息
  /// - postApiEmpty: 作品接口响应为空（未登录/风控）
  /// - postApiEmptyList: 作品接口返回合法空列表（作者无公开作品）
  /// - verify: 页面出现滑块安全验证（需用户交互）
  /// - ssr: 页面内嵌数据深搜出的作品列表（在页面内完成搜索与裁剪）
  /// - dom: DOM 提取的作品（过滤页脚 SEO 假链接/source= 参数，含点赞数解析）
  /// - domFake: 被过滤的假/非正文链接数量
  static const String _pollJs = r'''
(function() {
  var out = {
    readyState: document.readyState,
    href: location.href
  };
  var cap = window.__dyCap;
  if (cap) {
    if (cap.posts && cap.posts.length) out.captured = cap.posts;
    if (cap.profile) out.profile = cap.profile;
    if (cap.postApiEmpty) out.postApiEmpty = true;
    if (cap.postApiStatus) out.postApiStatus = cap.postApiStatus;
    if (cap.posts && cap.posts.length === 0) out.postApiEmptyList = true;
    if (cap.posts && cap.posts.length && cap.hasMore === false) out.postsComplete = true;
  }

  // 安全验证检测（抖音 secsdk 滑块验证码）
  out.verify = (function() {
    try {
      if (document.querySelector('#captcha-verify-image, .captcha_verify_container, .captcha_verify_slide, .secsdk-captcha-drag-icon, iframe[src*="captcha"], iframe[src*="verify"]')) return true;
      if (document.body) {
        var t = document.body.innerText || '';
        if (t.indexOf('安全验证') >= 0 || t.indexOf('拖动滑块') >= 0) return true;
      }
      if (/captcha|verify/i.test(location.href)) return true;
    } catch (e) {}
    return false;
  })();

  out.ssr = (function() {
    function trimAweme(a) {
      if (!a || typeof a !== 'object') return null;
      try {
        var st = a.statistics || {};
        var au = a.author || {};
        var v = a.video || {};
        return {
          aweme_id: a.aweme_id != null ? a.aweme_id : (a.awemeId != null ? a.awemeId : a.id),
          desc: a.desc != null ? a.desc : a.title,
          create_time: a.create_time != null ? a.create_time : a.createTime,
          duration: a.duration,
          share_url: a.share_url,
          statistics: {
            digg_count: st.digg_count,
            comment_count: st.comment_count,
            share_count: st.share_count,
            collect_count: st.collect_count,
            play_count: st.play_count
          },
          author: {
            uid: au.uid,
            sec_uid: au.sec_uid,
            unique_id: au.unique_id,
            nickname: au.nickname,
            avatar_thumb: au.avatar_thumb,
            avatar_medium: au.avatar_medium
          },
          video: {
            play_addr: v.play_addr,
            download_addr: v.download_addr,
            cover: v.cover
          }
        };
      } catch (e) {
        return null;
      }
    }
    function looksLikeAweme(m) {
      var hasId = m.aweme_id != null || m.awemeId != null || m.id != null;
      var hasDesc = m.desc != null || m.title != null;
      if (m.video && typeof m.video === 'object' && hasId) return true;
      if (m.statistics && typeof m.statistics === 'object' && hasId) return true;
      if (hasId && hasDesc && (m.statistics || m.create_time != null)) return true;
      return false;
    }
    var found = [];
    var seen = {};
    function collect(n, depth) {
      if (found.length >= 40 || depth > 12 || n == null) return;
      if (n instanceof Array) {
        var matched = [];
        for (var i = 0; i < n.length; i++) {
          if (n[i] && typeof n[i] === 'object' && looksLikeAweme(n[i])) matched.push(n[i]);
        }
        if (matched.length && n.length <= matched.length * 2) {
          for (var j = 0; j < matched.length && found.length < 40; j++) found.push(matched[j]);
        } else {
          for (var k = 0; k < n.length; k++) collect(n[k], depth + 1);
        }
      } else if (typeof n === 'object') {
        for (var key in n) {
          try { collect(n[key], depth + 1); } catch (e) {}
        }
      }
    }
    var sources = [];
    try {
      var rd = document.getElementById('RENDER_DATA');
      if (rd && rd.textContent) {
        var t = rd.textContent.trim();
        if (t.charAt(0) === '%') {
          try { t = decodeURIComponent(t); } catch (e) {}
        }
        if (t.charAt(0) === '{') sources.push(JSON.parse(t));
      }
    } catch (e) {}
    try { if (window._ROUTER_DATA) sources.push(window._ROUTER_DATA); } catch (e) {}
    try { if (window.__INITIAL_STATE__) sources.push(window.__INITIAL_STATE__); } catch (e) {}
    for (var s = 0; s < sources.length; s++) collect(sources[s], 0);
    var uniq = [];
    for (var i = 0; i < found.length; i++) {
      var p = found[i];
      var id = (p.aweme_id || p.awemeId || p.id || '') + '';
      if (!id || seen[id]) continue;
      seen[id] = 1;
      uniq.push(p);
    }
    uniq.sort(function(a, b) {
      return ((b.create_time || b.createTime || 0) | 0) - ((a.create_time || a.createTime || 0) | 0);
    });
    var trimmed = [];
    for (var i = 0; i < uniq.length && trimmed.length < 40; i++) {
      var t = trimAweme(uniq[i]);
      if (t) trimmed.push(t);
    }
    return trimmed.length ? trimmed : null;
  })();

  var domFake = 0;
  out.dom = (function() {
    function parseCount(s) {
      var m = (s || '').trim().match(/^(\d+(?:\.\d+)?)(万|w|W)?$/);
      if (!m) return null;
      var v = parseFloat(m[1]);
      if (m[2]) v *= 10000;
      return Math.round(v);
    }
    var mainRoot = document.getElementById('douyin-right-container') ||
      document.querySelector('[data-e2e="user-post-list"]');
    var anchors = document.querySelectorAll('a[href*="/video/"], a[href*="/note/"]');
    var seen = {};
    var items = [];
    for (var i = 0; i < anchors.length; i++) {
      var a = anchors[i];
      var href = a.getAttribute('href') || '';
      var mm = href.match(/\/(?:video|note)\/(\d+)/);
      if (!mm) continue;
      if (href.indexOf('source=') >= 0) { domFake++; continue; }
      if (a.closest && a.closest('footer')) { domFake++; continue; }
      if (mainRoot && !mainRoot.contains(a)) { domFake++; continue; }
      var id = mm[1];
      if (seen[id]) continue;
      seen[id] = 1;
      var img = a.querySelector('img');
      var title = (img && img.alt) || a.getAttribute('aria-label') ||
        (a.textContent || '').trim().slice(0, 120);
      var likes = null;
      var card = a.closest('li') || a.parentElement;
      if (card) {
        var leafs = card.querySelectorAll('span, div, p');
        var counts = [];
        for (var k = 0; k < leafs.length; k++) {
          var el = leafs[k];
          if (el.children.length !== 0) continue;
          var t = (el.textContent || '').trim();
          if (!t) continue;
          var c = parseCount(t);
          if (c != null) counts.push(c);
        }
        if (counts.length === 1) likes = counts[0];
      }
      items.push({ id: id, title: title, likes: likes });
    }
    return items.length ? items : null;
  })();
  out.domFake = domFake;

  return out;
})();
''';

  /// 抓取作者作品列表
  ///
  /// 返回原始 aweme 形状的对象列表（字段名与抖音 API 一致：
  /// aweme_id/desc/statistics/author/video/create_time 等），
  /// 由调用方（CrawlService）负责标准化。
  ///
  /// [secUid] 作者 sec_uid（MS4wLjABAAAA... 格式）
  /// [count] 需要的作品数量
  /// [timeout] 总超时时间（包含风控挑战 + 页面加载 + 提取；不含用户完成安全验证的等待）
  /// [cookies] 用户在设置中保存的抖音 Cookie（登录态，注入后成功率更高）
  /// [onStatus] 状态回调（供 UI 展示进度提示）
  static Future<List<Map<String, dynamic>>> crawlAuthorPosts(
    String secUid, {
    int count = 20,
    Duration timeout = const Duration(seconds: 60),
    Map<String, String>? cookies,
    void Function(String message)? onStatus,
  }) async {
    if (kIsWeb || !(Platform.isAndroid || Platform.isIOS)) {
      throw DouyinWebviewCrawlException('当前平台不支持浏览器抓取');
    }
    if (_running) {
      throw DouyinWebviewCrawlException('已有抓取任务进行中，请稍候再试');
    }
    if (secUid.isEmpty) {
      throw DouyinWebviewCrawlException('作者 ID 为空');
    }

    _running = true;
    try {
      return await _doCrawl(
        secUid,
        count: count,
        timeout: timeout,
        cookies: cookies,
        onStatus: onStatus,
      );
    } finally {
      _running = false;
    }
  }

  static Future<List<Map<String, dynamic>>> _doCrawl(
    String secUid, {
    required int count,
    required Duration timeout,
    Map<String, String>? cookies,
    void Function(String message)? onStatus,
  }) async {
    void report(String msg) => onStatus?.call(msg);

    final overlay = appNavigatorKey.currentState?.overlay;
    if (overlay == null) {
      throw DouyinWebviewCrawlException('界面未就绪，无法启动内置浏览器');
    }

    // 注入用户保存的抖音 Cookie（登录态访问：作品接口在未登录/风控环境下
    // 会返回空数据，登录后即可正常返回）
    if (cookies != null && cookies.isNotEmpty) {
      try {
        final cm = CookieManager.instance();
        for (final e in cookies.entries) {
          await cm.setCookie(
            url: WebUri('https://www.douyin.com/'),
            name: e.key,
            value: e.value,
            domain: '.douyin.com',
            isSecure: true,
          );
        }
        report('已应用已保存的抖音登录状态…');
      } catch (_) {
        // Cookie 注入失败不阻断流程，继续匿名访问
      }
    }

    final url = 'https://www.douyin.com/user/$secUid';
    final completer = Completer<List<Map<String, dynamic>>>();

    InAppWebViewController? webController;
    Timer? pollTimer;
    Timer? timeoutTimer;
    OverlayEntry? entry;
    var extracting = false;
    var lastDomCount = -1;
    var apiEmptyAt = 0; // 作品接口返回空数据的时刻（毫秒时间戳）
    var pollCount = 0;
    var lastCapturedCount = 0;
    var capturedStaleAt = 0; // 拦截数据数量停止增长的时刻
    Map<String, dynamic>? profile;

    // 安全验证可见化状态
    var verifyVisible = false;
    var verifyMissCount = 0;

    void cleanup() {
      pollTimer?.cancel();
      pollTimer = null;
      timeoutTimer?.cancel();
      timeoutTimer = null;
      entry?.remove();
      entry = null;
    }

    void finish(List<Map<String, dynamic>> posts) {
      if (!completer.isCompleted) {
        cleanup();
        completer.complete(posts);
      }
    }

    void fail(String message) {
      if (!completer.isCompleted) {
        cleanup();
        completer.completeError(DouyinWebviewCrawlException(message));
      }
    }

    /// 重置总超时（安全验证出现/消失时切换等待时长）
    void resetTimeout(Duration d, String message) {
      timeoutTimer?.cancel();
      timeoutTimer = Timer(d, () => fail(message));
    }

    /// 切换安全验证视图可见性
    ///
    /// 通过 markNeedsBuild 重建 OverlayEntry；控件树结构保持不变
    /// （Positioned>IgnorePointer>Opacity>Material>Column>WebView），
    /// 仅参数变化，WebView 实例与页面状态得以保留，不会重新加载。
    void setVerifyVisible(bool v) {
      if (verifyVisible == v) return;
      verifyVisible = v;
      entry?.markNeedsBuild();
    }

    report('正在启动内置浏览器…');

    // 轮询提取：页面加载 / 风控挑战自动跳转 / 异步渲染期间持续尝试
    Future<void> poll() async {
      final c = webController;
      if (c == null || extracting || completer.isCompleted) return;
      extracting = true;
      try {
        final res = await c.evaluateJavascript(source: _pollJs);
        final map = _asMap(res);
        if (map == null) return;
        pollCount++;

        // 作者信息（页面已正常加载的信号，也用于 DOM 兜底时补充作者字段）
        final p = _asMap(map['profile']);
        if (p != null && profile == null) {
          profile = p;
          final nick = p['nickname']?.toString() ?? '';
          if (nick.isNotEmpty) {
            report('已识别作者「$nick」，正在获取作品列表…');
          }
        }

        // 1. 拦截到的作品接口数据（含完整统计，最可靠）
        final captured = _asPostList(map['captured']);
        if (captured != null && captured.isNotEmpty) {
          final complete = map['postsComplete'] == true;
          if (captured.length > lastCapturedCount) {
            lastCapturedCount = captured.length;
            capturedStaleAt = DateTime.now().millisecondsSinceEpoch;
          }
          final now = DateTime.now().millisecondsSinceEpoch;
          final stalled = capturedStaleAt != 0 && now - capturedStaleAt > 8000;
          // 已取全 / 数量达标 / 8 秒无新增（作者作品不足）→ 完成
          if (captured.length >= count || complete || stalled) {
            report('成功获取 ${captured.length} 条作品（完整数据）');
            finish(captured.take(count).toList());
            return;
          }
          // 数量不足：滚动页面到底部触发虚拟列表加载更多
          if (pollCount % 5 == 0) {
            try {
              await c.evaluateJavascript(
                source: 'window.scrollTo(0, document.body.scrollHeight)',
              );
            } catch (_) {}
            report('已获取 ${captured.length} 条，正在加载更多…');
          }
        }

        // 2. 作品接口返回了合法空列表：作者无公开作品，无需继续等待
        if (map['postApiEmptyList'] == true && captured == null) {
          fail('该作者暂无公开作品（作品列表为空，可能已设为仅自己可见）');
          return;
        }

        // 3. SSR 内嵌数据深搜（完整数据）
        final ssr = _asPostList(map['ssr']);
        if (ssr != null && ssr.isNotEmpty) {
          report('从页面数据中提取到 ${ssr.length} 条作品');
          finish(ssr.take(count).toList());
          return;
        }

        // 4. DOM 兜底（仅 id/标题/可能的点赞数）
        final dom = _asPostList(map['dom']);
        if (dom != null && dom.isNotEmpty) {
          if (lastDomCount == dom.length) {
            // 连续两次数量一致才认为稳定，避免拿到半截数据
            report('从页面提取到 ${dom.length} 条作品');
            final posts = <Map<String, dynamic>>[];
            for (final item in dom) {
              final id = item['id']?.toString() ?? '';
              if (id.isEmpty) continue;
              final likes = item['likes'];
              posts.add({
                'aweme_id': id,
                'awemeId': id,
                'desc': item['title']?.toString() ?? '',
                'title': item['title']?.toString() ?? '',
                'statistics':
                    likes != null ? {'digg_count': likes} : null,
              });
            }
            // DOM 数据无作者信息，用拦截到的作者资料补充
            if (profile != null) {
              final avatarUrl = profile!['avatar_url']?.toString() ?? '';
              for (final post in posts) {
                post['author'] = {
                  'nickname': profile!['nickname'],
                  'sec_uid': profile!['sec_uid'],
                  'uid': profile!['uid'],
                  'unique_id': profile!['unique_id'],
                  'avatar_thumb': {'url_list': [avatarUrl]},
                };
              }
            }
            finish(posts.take(count).toList());
            return;
          }
          lastDomCount = dom.length;
          report('页面已渲染 ${dom.length} 条作品，正在确认列表稳定…');
        }

        // 5. 安全验证检测：出现滑块验证时切换为可见可交互，
        //    用户完成后自动隐藏继续抓取
        final verify = map['verify'] == true;
        if (verify) {
          verifyMissCount = 0;
          if (!verifyVisible) {
            setVerifyVisible(true);
            apiEmptyAt = 0;
            // 验证期间暂停原有计时，给用户 150 秒完成滑块
            resetTimeout(
              const Duration(seconds: 150),
              '安全验证超时未完成，已停止本次抓取，请重试',
            );
            report('检测到抖音安全验证，请在屏幕上完成滑块验证');
          }
        } else if (verifyVisible) {
          // 连续 2 次未检测到验证元素才认为已通过（避免误判闪断）
          verifyMissCount++;
          if (verifyMissCount >= 2) {
            setVerifyVisible(false);
            resetTimeout(
              const Duration(seconds: 45),
              '抓取超时：完成验证后作品数据未返回，请重试',
            );
            report('验证已通过，正在继续获取作品数据…');
          }
        }

        // 6. 作品接口受限（返回空 body）：等待 8 秒仍无任何数据则提前失败
        //    （页面网格此时不会渲染，DOM 也不会有真实作品；验证期间不早退）
        if (!verifyVisible && map['postApiEmpty'] == true && apiEmptyAt == 0) {
          apiEmptyAt = DateTime.now().millisecondsSinceEpoch;
          report('作品接口暂未返回数据，正在等待…');
        }
        if (!verifyVisible &&
            apiEmptyAt != 0 &&
            DateTime.now().millisecondsSinceEpoch - apiEmptyAt > 8000) {
          final hasCookie = cookies != null && cookies.isNotEmpty;
          fail(
            '抖音未返回作品列表数据'
            '${hasCookie ? '（登录状态可能已过期）' : '（当前网络环境受限）'}。\n'
            '建议：在「设置-抖音Cookie」中${hasCookie ? '重新' : ''}登录抖音账号后重试。',
          );
        }
      } catch (_) {
        // 页面尚未就绪（JS 不可用 / 正在跳转），下一轮继续
      } finally {
        extracting = false;
      }
    }

    pollTimer = Timer.periodic(const Duration(milliseconds: 1200), (_) {
      poll();
    });

    // 总超时：覆盖风控挑战 + 页面加载 + 提取全过程
    resetTimeout(
      timeout,
      '内置浏览器抓取超时：页面加载或风控验证未完成。\n'
      '请检查网络连接后重试。',
    );

    // 挂载 WebView 悬浮层：
    // - 平时：1280x800（桌面页面正常布局尺寸）、透明度 0.01、忽略点击，
    //   对用户不可见且不遮挡操作；
    // - 安全验证时：全屏可见可交互，顶部提示栏可取消。
    // 控件树结构在两种状态下保持一致（仅参数不同），
    // 确保切换时 WebView 实例与页面状态不丢失。
    final overlayEntry = OverlayEntry(
      builder: (context) {
        final size = MediaQuery.of(context).size;
        final visible = verifyVisible;
        return Positioned(
          left: 0,
          top: 0,
          width: visible ? size.width : 1280.0,
          height: visible ? size.height : 800.0,
          child: IgnorePointer(
            ignoring: !visible,
            child: Opacity(
              opacity: visible ? 1.0 : 0.01,
              child: Material(
                color: visible ? Colors.white : Colors.transparent,
                child: Column(
                  children: [
                    // 验证提示栏（不可见时高度为 0，保持树结构稳定）
                    SizedBox(
                      height: visible ? 52.0 : 0.0,
                      child: Material(
                        color: const Color(0xFF1F2024),
                        child: Row(
                          children: [
                            const SizedBox(width: 14),
                            const Icon(
                              Icons.verified_user,
                              color: Colors.white,
                              size: 20,
                            ),
                            const SizedBox(width: 8),
                            const Expanded(
                              child: Text(
                                '请完成抖音安全验证后继续抓取',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w500,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            TextButton(
                              onPressed: () =>
                                  fail('已取消安全验证，本次抓取已停止'),
                              style: TextButton.styleFrom(
                                foregroundColor: Colors.white,
                                minimumSize: const Size(64, 40),
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 12),
                              ),
                              child: const Text('取消'),
                            ),
                            const SizedBox(width: 6),
                          ],
                        ),
                      ),
                    ),
                    Expanded(
                      child: InAppWebView(
                        initialUrlRequest: URLRequest(url: WebUri(url)),
                        initialSettings: InAppWebViewSettings(
                          userAgent: _desktopUa,
                          javaScriptEnabled: true,
                          supportZoom: false,
                          useHybridComposition: true,
                        ),
                        // 文档开始时注入拦截脚本（主 world）：
                        // 必须在页面任何脚本执行前包装 XHR/fetch，
                        // 才能捕获页面首次发起的作品列表请求；
                        // 风控挑战页跳转后脚本会自动重新注入。
                        initialUserScripts:
                            UnmodifiableListView<UserScript>([
                          UserScript(
                            source: _hookJs,
                            injectionTime:
                                UserScriptInjectionTime.AT_DOCUMENT_START,
                          ),
                        ]),
                        onWebViewCreated: (controller) {
                          webController = controller;
                        },
                        onLoadStop: (controller, uri) {
                          if (!completer.isCompleted && !verifyVisible) {
                            report('页面已加载，正在提取作品数据…');
                          }
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
    entry = overlayEntry;
    overlay.insert(overlayEntry);

    return completer.future;
  }

  // ==================== 工具 ====================

  /// 将 evaluateJavascript 的返回值规范化为 Map
  /// （Android 可能返回 JSON 字符串，iOS 直接返回对象）
  static Map<String, dynamic>? _asMap(dynamic v) {
    if (v is Map<String, dynamic>) return v;
    if (v is Map) return Map<String, dynamic>.from(v);
    if (v is String && v.isNotEmpty) {
      try {
        final decoded = jsonDecode(v);
        if (decoded is Map) return Map<String, dynamic>.from(decoded);
      } catch (_) {}
    }
    return null;
  }

  /// 将列表规范化为 Map 列表（空列表返回 null）
  static List<Map<String, dynamic>>? _asPostList(dynamic v) {
    if (v is! List || v.isEmpty) return null;
    final out = <Map<String, dynamic>>[];
    for (final e in v) {
      if (e is Map) {
        out.add(Map<String, dynamic>.from(e));
      }
    }
    return out.isEmpty ? null : out;
  }
}
