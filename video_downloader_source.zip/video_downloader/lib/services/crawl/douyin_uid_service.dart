import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:dio/io.dart';
import '../proxy_service.dart';

/// 抖音作者数字 UID 抓取服务
///
/// 2026-08 起抖音网页端所有匿名接口均不再返回数字 uid，
/// 本服务通过多级 App / Web API 级联尝试，尽可能获取到真实数字 uid。
///
/// 级联顺序（前者失败自动走下一个）：
///   U1 — snssdk App API（aweme/v1/user/profile/other/）
///   U2 — snssdk 视频列表提取作者 uid（aweme/v1/aweme/post/）
///   U4 — iesdouyin 三端点轮试
///   U0 — 抖音 Web 官方 API 兜底（需 s_v_web_id + ttwid Cookie）
class DouyinUidService {
  final Dio _dio;

  /// 自定义 UID 补全服务 URL（如 Supabase Edge Function）
  /// 配置后作为最高优先级调用，服务端应返回数字 uid
  /// 协议：GET {customServiceUrl}?sec_uid=xxx
  ///       响应：{"uid": "123456"} 或纯文本 "123456"
  String? customServiceUrl;

  DouyinUidService({Dio? dio, this.customServiceUrl})
      : _dio = dio ?? Dio() {
    _dio.options = BaseOptions(
      followRedirects: true,
      maxRedirects: 10,
      connectTimeout: const Duration(seconds: 15),
      receiveTimeout: const Duration(seconds: 15),
      validateStatus: (status) => status! < 500,
    );
  }

  // ==================== 设备 / 签名常量 ====================

  /// Android 14 Pixel 8 App UA（snssdk 系列接口使用）
  static const String _appUserAgent =
      'com.ss.android.ugc.aweme/260103 (Linux; U; Android 14; Pixel 8 Build/UP1A.231005.007)';

  /// PC Chrome UA（Web 系列接口使用）
  static const String _pcUserAgent =
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

  /// snssdk App 通用查询参数
  static const Map<String, String> _appBaseParams = {
    'version_name': '26.1.3',
    'version_code': '260103',
    'app_name': 'aweme',
    'app_version': '26.1.3',
    'channel': 'google_play',
    'device_platform': 'android',
    'device_type': 'Pixel 8',
    'device_brand': 'google',
    'os_version': '14',
    'os_api': '34',
    'ssmix': 'a',
    'manifest_version_code': '260103',
    'update_version_code': '260103',
    'resolution': '1080*2400',
    'dpi': '420',
    'language': 'zh',
    'app_language': 'zh',
    'region': 'CN',
    'sys_region': 'CN',
    'carrier_region': 'CN',
    'ac': 'wifi',
    'aid': '1128',
  };

  /// X-Gorgon 哑值（ByteDance 国际节点 snssdk 不强制验签）
  static const String _xGorgonDummy = '00000000000000000000000000000000';

  /// X-Khronos 哑值（0 时间戳，配合 Gorgon 哑值使用）
  static const String _xKhronosDummy = '0';

  // ==================== 对外主入口 ====================

  /// 多级级联获取抖音作者数字 UID
  ///
  /// [secUid] 作者的 sec_uid（必填）
  /// 返回纯数字 uid 字符串；全部失败返回 null
  Future<String?> fetchUid(String secUid) async {
    if (secUid.isEmpty) return null;

    // U0*: 自定义补全服务（最高优先级，如 Supabase Edge Function）
    if (customServiceUrl != null && customServiceUrl!.isNotEmpty) {
      try {
        final uid = await _fetchFromCustomService(secUid);
        if (_isValidNumericUid(uid)) return uid;
      } catch (_) {}
    }

    // U1: snssdk App API（最优）
    try {
      final uid = await _u1SnssdkAppApi(secUid);
      if (_isValidNumericUid(uid)) return uid;
    } catch (_) {}

    // U2: snssdk 视频列表提取作者 uid
    try {
      final uid = await _u2VideoListAuthor(secUid);
      if (_isValidNumericUid(uid)) return uid;
    } catch (_) {}

    // U4: iesdouyin 三端点轮试
    try {
      final uid = await _u4IesDouyinApi(secUid);
      if (_isValidNumericUid(uid)) return uid;
    } catch (_) {}

    // U0: 抖音 Web 官方 API（最后兜底）
    try {
      final uid = await _u0DouyinWebApi(secUid);
      if (_isValidNumericUid(uid)) return uid;
    } catch (_) {}

    return null;
  }

  // ==================== 🥇 U1：snssdk App API ====================

  /// GET aweme/v1/user/profile/other/
  /// 从 data.user.uid / data.user_info.uid 读取 UID
  Future<String?> _u1SnssdkAppApi(String secUid) async {
    const hosts = ['aweme.snssdk.com', 'api.amemv.com'];
    for (final host in hosts) {
      try {
        final response = await _dio.get(
          'https://$host/aweme/v1/user/profile/other/',
          queryParameters: {
            ..._appBaseParams,
            'sec_user_id': secUid,
          },
          options: Options(headers: _appHeaders()),
        );
        final uid = _extractUidFromUserResponse(response.data);
        if (_isValidNumericUid(uid)) return uid;
      } catch (_) {
        // 当前 host 失败，尝试下一个
      }
    }
    return null;
  }

  // ==================== 🥈 U2：视频列表提取作者 ====================

  /// GET aweme/v1/aweme/post/?count=1
  /// 从 aweme_list[0].author.uid 提取作者 UID
  Future<String?> _u2VideoListAuthor(String secUid) async {
    const hosts = ['aweme.snssdk.com', 'api.amemv.com'];
    for (final host in hosts) {
      try {
        final response = await _dio.get(
          'https://$host/aweme/v1/aweme/post/',
          queryParameters: {
            ..._appBaseParams,
            'sec_user_id': secUid,
            'count': '1',
            'max_cursor': '0',
          },
          options: Options(headers: _appHeaders()),
        );
        dynamic data = response.data;
        if (data is String) data = jsonDecode(data);
        if (data is! Map) continue;

        final awemeList = data['aweme_list'];
        if (awemeList is List && awemeList.isNotEmpty) {
          final first = awemeList.first;
          if (first is Map) {
            final author = first['author'];
            if (author is Map) {
              final uid = author['uid']?.toString();
              if (_isValidNumericUid(uid)) return uid;
            }
          }
        }
      } catch (_) {
        // 当前 host 失败，尝试下一个
      }
    }
    return null;
  }

  // ==================== 🥉 U4：iesdouyin 三端点轮试 ====================

  /// 依次尝试 iesdouyin 的 3 个用户信息端点
  Future<String?> _u4IesDouyinApi(String secUid) async {
    final endpoints = [
      'https://www.iesdouyin.com/web/api/v2/user/info/',
      'https://www.iesdouyin.com/api/user/profile/other/',
      'https://www.iesdouyin.com/aweme/v1/web/user/profile/other/',
    ];
    for (final endpoint in endpoints) {
      try {
        final params = <String, String>{'sec_uid': secUid};
        if (endpoint.contains('v1/web')) {
          params['aid'] = '1128';
        }
        final response = await _dio.get(
          endpoint,
          queryParameters: params,
          options: Options(headers: _webHeaders()),
        );
        final uid = _extractUidFromUserResponse(response.data);
        if (_isValidNumericUid(uid)) return uid;
      } catch (_) {
        // 当前端点失败，尝试下一个
      }
    }
    return null;
  }

  // ==================== 🔚 U0：抖音 Web 官方 API 兜底 ====================

  /// 1. 请求 douyin.com 首页获取 s_v_web_id
  /// 2. 请求 ttwid.bytedance.com 获取 ttwid
  /// 3. 携带 Cookie 调用 web/user/profile/other/
  Future<String?> _u0DouyinWebApi(String secUid) async {
    final cookieJar = <String, String>{};

    // 第一步：访问抖音首页，获取 s_v_web_id
    try {
      final home = await _dio.get(
        'https://www.douyin.com/',
        options: Options(headers: _pcHeaders()),
      );
      _collectCookies(home.headers.map, cookieJar);
    } catch (_) {}

    // 第二步：获取 ttwid
    try {
      final ttwidResp = await _dio.get(
        'https://ttwid.bytedance.com/ttwid/union/register/',
        queryParameters: {
          'region': 'cn',
          'aid': '1128',
          'needFid': 'false',
          'service': 'www.iesdouyin.com',
        },
        options: Options(headers: _pcHeaders()),
      );
      _collectCookies(ttwidResp.headers.map, cookieJar);
    } catch (_) {}

    if (cookieJar.isEmpty) return null;

    // 第三步：携带 Cookie 调用用户信息接口
    try {
      final cookieStr = cookieJar.entries
          .map((e) => '${e.key}=${e.value}')
          .join('; ');
      final response = await _dio.get(
        'https://www.douyin.com/aweme/v1/web/user/profile/other/',
        queryParameters: {
          'sec_user_id': secUid,
          'aid': '1128',
        },
        options: Options(headers: {
          ..._pcHeaders(),
          'Cookie': cookieStr,
          'Referer': 'https://www.douyin.com/user/$secUid',
        }),
      );
      return _extractUidFromUserResponse(response.data);
    } catch (_) {
      return null;
    }
  }

  // ==================== 自定义补全服务 ====================

  /// 调用用户配置的服务端 URL 获取 uid
  /// 支持两种响应格式：
  ///   1. JSON: {"uid": "123456"} 或 {"data": {"uid": "123456"}}
  ///   2. 纯文本: "123456"
  Future<String?> _fetchFromCustomService(String secUid) async {
    final url = customServiceUrl;
    if (url == null || url.isEmpty) return null;

    final response = await _dio.get(
      url,
      queryParameters: {'sec_uid': secUid},
      options: Options(
        headers: {'Accept': 'application/json, text/plain'},
        responseType: ResponseType.plain,
      ),
    );

    final body = response.data?.toString() ?? '';
    if (body.isEmpty) return null;

    // 先尝试 JSON
    try {
      final decoded = jsonDecode(body);
      if (decoded is Map) {
        final uid = decoded['uid']?.toString() ??
            decoded['data']?['uid']?.toString() ??
            decoded['result']?['uid']?.toString();
        if (_isValidNumericUid(uid)) return uid;
      }
    } catch (_) {}

    // 再尝试纯文本
    final trimmed = body.trim();
    if (_isValidNumericUid(trimmed)) return trimmed;

    return null;
  }

  // ==================== 工具方法 ====================

  /// 从用户信息 API 响应中提取 uid
  /// 可能的路径：user.uid / user_info.uid / data.user.uid 等
  String? _extractUidFromUserResponse(dynamic responseData) {
    dynamic data = responseData;
    if (data is String) {
      try {
        data = jsonDecode(data);
      } catch (_) {
        return null;
      }
    }
    // 兼容 List 响应：取第一个元素（非空且为 Map 时）继续解析
    if (data is List) {
      if (data.isNotEmpty && data.first is Map) {
        data = data.first;
      } else {
        return null;
      }
    }
    if (data is! Map) return null;

    // 直接在根级找 user / user_info
    final candidates = <Map>[];
    for (final key in const ['user', 'user_info', 'userInfo', 'data']) {
      final v = data[key];
      if (v is Map) candidates.add(v);
    }
    // data 本身可能就是用户对象
    if (data['uid'] != null || data['user_id'] != null) {
      candidates.add(data);
    }

    for (final user in candidates) {
      // 嵌套 data.user 的情况
      final innerData = user['data'];
      if (innerData is Map) {
        for (final key in const ['user', 'user_info', 'userInfo']) {
          final u = innerData[key];
          if (u is Map) candidates.add(u);
        }
      }
      final uid = user['uid']?.toString() ?? user['user_id']?.toString();
      if (_isValidNumericUid(uid)) return uid;
    }
    return null;
  }

  /// 校验是否为有效数字 uid（纯数字且非 "0"）
  bool _isValidNumericUid(String? uid) {
    if (uid == null) return false;
    final trimmed = uid.trim();
    if (trimmed.isEmpty || trimmed == '0') return false;
    return RegExp(r'^\d+$').hasMatch(trimmed);
  }

  /// snssdk App 接口请求头
  Map<String, String> _appHeaders() => {
        'User-Agent': _appUserAgent,
        'X-Gorgon': _xGorgonDummy,
        'X-Khronos': _xKhronosDummy,
        'Accept-Encoding': 'gzip',
        'Connection': 'Keep-Alive',
      };

  /// iesdouyin Web 接口请求头
  Map<String, String> _webHeaders() => {
        'User-Agent': _pcUserAgent,
        'Accept': 'application/json, text/plain, */*',
        'Referer': 'https://www.iesdouyin.com/',
        'Origin': 'https://www.iesdouyin.com',
      };

  /// PC 浏览器请求头
  Map<String, String> _pcHeaders() => {
        'User-Agent': _pcUserAgent,
        'Accept':
            'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'Accept-Language': 'zh-CN,zh;q=0.9',
        'Cache-Control': 'no-cache',
      };

  /// 从响应头收集 Set-Cookie
  void _collectCookies(Map<String, List<String>> headers, Map<String, String> jar) {
    final setCookies = headers['set-cookie'] ?? const <String>[];
    for (final sc in setCookies) {
      final firstPart = sc.split(';').first.trim();
      final eqIdx = firstPart.indexOf('=');
      if (eqIdx > 0 && eqIdx < firstPart.length - 1) {
        final name = firstPart.substring(0, eqIdx);
        final value = firstPart.substring(eqIdx + 1);
        jar[name] = value;
      }
    }
  }

  /// 应用代理配置
  void applyProxy(ProxyService? proxyService) {
    if (proxyService != null) {
      proxyService.applyToDio(_dio);
    } else {
      _dio.httpClientAdapter = IOHttpClientAdapter();
    }
  }
}
