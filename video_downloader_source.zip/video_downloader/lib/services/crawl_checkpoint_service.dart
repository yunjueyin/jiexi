import 'package:hive/hive.dart';
import '../models/crawl_checkpoint.dart';

/// 增量抓取检查点服务
///
/// 管理每个作者的上次抓取状态，用于增量抓取时只抓取新内容。
class CrawlCheckpointService {
  static const String _boxName = 'crawl_checkpoints';
  Box<CrawlCheckpoint>? _box;

  Future<void> init() async {
    _box ??= await Hive.openBox<CrawlCheckpoint>(_boxName);
  }

  Box<CrawlCheckpoint> get box {
    if (_box == null) {
      throw StateError('CrawlCheckpointService not initialized');
    }
    return _box!;
  }

  /// 获取指定作者的检查点
  CrawlCheckpoint? getCheckpoint(String platform, String authorId) {
    final key = CrawlCheckpoint.makeKey(platform, authorId);
    return box.get(key);
  }

  /// 保存检查点
  Future<void> saveCheckpoint(CrawlCheckpoint checkpoint) async {
    await box.put(checkpoint.authorKey, checkpoint);
  }

  /// 更新检查点（部分字段）
  Future<void> updateCheckpoint(
    String platform,
    String authorId, {
    DateTime? lastCrawlAt,
    DateTime? lastVideoPublishTime,
    String? lastVideoId,
    int? totalVideoCount,
    String? cursor,
    String? nickname,
  }) async {
    final key = CrawlCheckpoint.makeKey(platform, authorId);
    final existing = box.get(key);

    final updated = CrawlCheckpoint(
      authorKey: key,
      platform: platform,
      authorId: authorId,
      nickname: nickname ?? existing?.nickname,
      lastCrawlAt: lastCrawlAt ?? existing?.lastCrawlAt ?? DateTime.now(),
      lastVideoPublishTime: lastVideoPublishTime ?? existing?.lastVideoPublishTime,
      lastVideoId: lastVideoId ?? existing?.lastVideoId,
      totalVideoCount: totalVideoCount ?? existing?.totalVideoCount ?? 0,
      cursor: cursor ?? existing?.cursor,
    );

    await box.put(key, updated);
  }

  /// 删除检查点
  Future<void> removeCheckpoint(String platform, String authorId) async {
    final key = CrawlCheckpoint.makeKey(platform, authorId);
    await box.delete(key);
  }

  /// 获取所有检查点（按时间倒序）
  List<CrawlCheckpoint> getAllCheckpoints() {
    final list = box.values.toList();
    list.sort((a, b) => b.lastCrawlAt.compareTo(a.lastCrawlAt));
    return list;
  }

  /// 清空所有检查点
  Future<void> clearAll() async {
    await box.clear();
  }

  /// 检查作者是否有检查点（即是否曾经抓取过）
  bool hasCheckpoint(String platform, String authorId) {
    final key = CrawlCheckpoint.makeKey(platform, authorId);
    return box.containsKey(key);
  }
}
