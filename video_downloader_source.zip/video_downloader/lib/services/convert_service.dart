import 'package:dio/dio.dart';
import 'package:uuid/uuid.dart';
import '../models/convert_record.dart';
import '../utils/platform_detector.dart';

/// 链接类型
enum ConvertLinkType {
  /// 短链接
  shortLink,

  /// 长链接
  longLink,

  /// 未知
  unknown,
}

/// 转换结果项
class ConvertResultItem {
  final String originalUrl;
  final String? resultUrl;
  final String? platform;
  final bool success;
  final String? errorMessage;

  /// 原始链接类型
  final ConvertLinkType originalLinkType;

  /// 结果链接类型
  final ConvertLinkType resultLinkType;

  /// 链接是否有效（通过 HEAD 请求校验）
  final bool? isValid;

  /// 有效性校验的状态码
  final int? statusCode;

  ConvertResultItem({
    required this.originalUrl,
    this.resultUrl,
    this.platform,
    this.success = false,
    this.errorMessage,
    this.originalLinkType = ConvertLinkType.unknown,
    this.resultLinkType = ConvertLinkType.unknown,
    this.isValid,
    this.statusCode,
  });

  /// 创建副本并更新字段
  ConvertResultItem copyWith({
    String? originalUrl,
    String? resultUrl,
    String? platform,
    bool? success,
    String? errorMessage,
    ConvertLinkType? originalLinkType,
    ConvertLinkType? resultLinkType,
    bool? isValid,
    int? statusCode,
  }) {
    return ConvertResultItem(
      originalUrl: originalUrl ?? this.originalUrl,
      resultUrl: resultUrl ?? this.resultUrl,
      platform: platform ?? this.platform,
      success: success ?? this.success,
      errorMessage: errorMessage ?? this.errorMessage,
      originalLinkType: originalLinkType ?? this.originalLinkType,
      resultLinkType: resultLinkType ?? this.resultLinkType,
      isValid: isValid ?? this.isValid,
      statusCode: statusCode ?? this.statusCode,
    );
  }
}

/// 链接转换服务
///
/// 支持抖音、快手、小红书三个平台的链接转换：
/// - 转短链：将长链接转换为标准短链格式
/// - 转长链：展开短链接为完整长链
///
/// 自动识别平台，无需手动选择。
class ConvertService {
  final Dio _dio;
  final _uuid = const Uuid();

  /// 支持转换的平台
  static const List<String> supportedPlatforms = [
    'douyin',
    'kuaishou',
    'xiaohongshu',
  ];

  /// 检查平台是否支持转换
  static bool isPlatformSupported(String platform) {
    return supportedPlatforms.contains(platform);
  }

  ConvertService({Dio? dio}) : _dio = dio ?? Dio(_baseOptions) {
    _dio.options = _baseOptions;
  }

  static final BaseOptions _baseOptions = BaseOptions(
    followRedirects: true,
    maxRedirects: 10,
    connectTimeout: const Duration(seconds: 15),
    receiveTimeout: const Duration(seconds: 15),
    validateStatus: (status) => status! < 500,
    headers: {
      'User-Agent':
          'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1',
    },
  );

  // ======================================================
  // 公开 API
  // ======================================================

  /// 转换单条链接为短链
  Future<ConvertResultItem> toShort(String url) async {
    // 从文本中提取纯 URL（支持带文字的分享链接）
    final cleanUrl = PlatformDetector.normalizeUrl(url) ?? url.trim();
    final platform = PlatformDetector.detectPlatform(cleanUrl);
    if (platform == VideoPlatform.unknown) {
      return ConvertResultItem(
        originalUrl: url,
        success: false,
        errorMessage: '无法识别平台',
      );
    }
    final platformId = platform.id;

    try {
      String workingUrl = cleanUrl;

      // 如果是短链，先解析成长链
      if (PlatformDetector.isShortLinkForPlatform(cleanUrl, platform)) {
        workingUrl = await _resolveShortLink(cleanUrl);
      }

      // 判断链接类型
      final linkType = PlatformDetector.detectLinkTypeForPlatform(workingUrl, platform);

      if (linkType == LinkType.author) {
        // 明确是作者主页链接
        final userId = _extractUserId(workingUrl, platform);
        if (userId == null || userId.isEmpty) {
          return ConvertResultItem(
            originalUrl: url,
            platform: platformId,
            success: false,
            errorMessage: '未能提取作者ID',
          );
        }
        final resultUrl = _buildAuthorShortLink(userId, platform);
        return ConvertResultItem(
          originalUrl: url,
          resultUrl: resultUrl,
          platform: platformId,
          success: true,
        );
      } else if (linkType == LinkType.video) {
        // 明确是视频/笔记链接
        final itemId = _extractVideoId(workingUrl, platform);
        if (itemId == null || itemId.isEmpty) {
          return ConvertResultItem(
            originalUrl: url,
            platform: platformId,
            success: false,
            errorMessage: '未能提取视频/笔记ID',
          );
        }
        final resultUrl = _buildVideoShortLink(itemId, platform);
        return ConvertResultItem(
          originalUrl: url,
          resultUrl: resultUrl,
          platform: platformId,
          success: true,
        );
      } else {
        // 类型未知，先尝试视频/笔记，失败再尝试作者
        final itemId = _extractVideoId(workingUrl, platform);
        if (itemId != null && itemId.isNotEmpty) {
          final resultUrl = _buildVideoShortLink(itemId, platform);
          return ConvertResultItem(
            originalUrl: url,
            resultUrl: resultUrl,
            platform: platformId,
            success: true,
          );
        }
        final userId = _extractUserId(workingUrl, platform);
        if (userId != null && userId.isNotEmpty) {
          final resultUrl = _buildAuthorShortLink(userId, platform);
          return ConvertResultItem(
            originalUrl: url,
            resultUrl: resultUrl,
            platform: platformId,
            success: true,
          );
        }
        return ConvertResultItem(
          originalUrl: url,
          platform: platformId,
          success: false,
          errorMessage: '未能识别链接类型或提取ID',
        );
      }
    } catch (e) {
      return ConvertResultItem(
        originalUrl: url,
        platform: platformId,
        success: false,
        errorMessage: e.toString().replaceAll('Exception: ', ''),
      );
    }
  }

  /// 转换单条链接为长链
  Future<ConvertResultItem> toLong(String url) async {
    // 从文本中提取纯 URL（支持带文字的分享链接）
    final cleanUrl = PlatformDetector.normalizeUrl(url) ?? url.trim();
    final platform = PlatformDetector.detectPlatform(cleanUrl);
    if (platform == VideoPlatform.unknown) {
      return ConvertResultItem(
        originalUrl: url,
        success: false,
        errorMessage: '无法识别平台',
      );
    }

    try {
      String resultUrl;

      if (PlatformDetector.isShortLinkForPlatform(cleanUrl, platform)) {
        resultUrl = await _resolveShortLink(cleanUrl);
      } else {
        resultUrl = cleanUrl;
      }

      return ConvertResultItem(
        originalUrl: url,
        resultUrl: resultUrl,
        platform: platform.id,
        success: true,
      );
    } catch (e) {
      return ConvertResultItem(
        originalUrl: url,
        platform: platform.id,
        success: false,
        errorMessage: e.toString().replaceAll('Exception: ', ''),
      );
    }
  }

  /// 批量转换为短链（带进度回调）
  Future<List<ConvertRecord>> batchToShort(
    List<String> urls, {
    int concurrency = 3,
    void Function(int success, int fail, List<ConvertResultItem> results)? onProgress,
  }) async {
    final batchId = _uuid.v4();

    // 预分配固定长度的结果列表，按索引写入，保证顺序与输入一致
    final resultList = List<ConvertResultItem?>.filled(urls.length, null);
    final recordList = List<ConvertRecord?>.filled(urls.length, null);
    int nextTaskIndex = 0;

    // 统计当前已完成任务的成功/失败数量，并构建进度结果列表
    void _reportProgress() {
      int success = 0;
      int fail = 0;
      final currentResults = <ConvertResultItem>[];
      for (int j = 0; j < urls.length; j++) {
        final r = resultList[j];
        if (r != null) {
          currentResults.add(r);
          if (r.success) {
            success++;
          } else {
            fail++;
          }
        }
      }
      onProgress?.call(success, fail, currentResults);
    }

    Future<void> worker() async {
      while (true) {
        // 在同步代码块中获取并递增任务索引（Dart 单线程下安全）
        final i = nextTaskIndex;
        if (i >= urls.length) break;
        nextTaskIndex++;

        final url = urls[i];
        final result = await toShort(url);

        // 按索引写入，保证结果顺序与输入一致
        resultList[i] = result;

        if (result.success) {
          recordList[i] = ConvertRecord(
            id: 'conv_${_uuid.v4()}',
            originalUrl: result.originalUrl,
            resultUrl: result.resultUrl!,
            platform: result.platform!,
            convertType: 'toShort',
            convertedAt: DateTime.now(),
            batchId: urls.length > 1 ? 'conv_batch_$batchId' : null,
            success: true,
          );
        }

        _reportProgress();
      }
    }

    final workers = <Future<void>>[];
    final actualConcurrency = concurrency.clamp(1, urls.length);
    for (int i = 0; i < actualConcurrency; i++) {
      workers.add(worker());
    }
    await Future.wait(workers);

    // 按原始顺序返回成功的记录
    return recordList.whereType<ConvertRecord>().toList();
  }

  /// 批量转换为长链（带进度回调）
  Future<List<ConvertRecord>> batchToLong(
    List<String> urls, {
    int concurrency = 3,
    void Function(int success, int fail, List<ConvertResultItem> results)? onProgress,
  }) async {
    final batchId = _uuid.v4();

    // 预分配固定长度的结果列表，按索引写入，保证顺序与输入一致
    final resultList = List<ConvertResultItem?>.filled(urls.length, null);
    final recordList = List<ConvertRecord?>.filled(urls.length, null);
    int nextTaskIndex = 0;

    // 统计当前已完成任务的成功/失败数量，并构建进度结果列表
    void _reportProgress() {
      int success = 0;
      int fail = 0;
      final currentResults = <ConvertResultItem>[];
      for (int j = 0; j < urls.length; j++) {
        final r = resultList[j];
        if (r != null) {
          currentResults.add(r);
          if (r.success) {
            success++;
          } else {
            fail++;
          }
        }
      }
      onProgress?.call(success, fail, currentResults);
    }

    Future<void> worker() async {
      while (true) {
        // 在同步代码块中获取并递增任务索引（Dart 单线程下安全）
        final i = nextTaskIndex;
        if (i >= urls.length) break;
        nextTaskIndex++;

        final url = urls[i];
        final result = await toLong(url);

        // 按索引写入，保证结果顺序与输入一致
        resultList[i] = result;

        if (result.success) {
          recordList[i] = ConvertRecord(
            id: 'conv_${_uuid.v4()}',
            originalUrl: result.originalUrl,
            resultUrl: result.resultUrl!,
            platform: result.platform!,
            convertType: 'toLong',
            convertedAt: DateTime.now(),
            batchId: urls.length > 1 ? 'conv_batch_$batchId' : null,
            success: true,
          );
        }

        _reportProgress();
      }
    }

    final workers = <Future<void>>[];
    final actualConcurrency = concurrency.clamp(1, urls.length);
    for (int i = 0; i < actualConcurrency; i++) {
      workers.add(worker());
    }
    await Future.wait(workers);

    // 按原始顺序返回成功的记录
    return recordList.whereType<ConvertRecord>().toList();
  }

  /// 智能转换：自动识别链接类型，统一输出为标准长链格式
  ///
  /// 适用于混合输入场景：不管输入是短链还是长链，都输出标准长链
  Future<ConvertResultItem> smartToLong(String url) async {
    final cleanUrl = PlatformDetector.normalizeUrl(url) ?? url.trim();
    final platform = PlatformDetector.detectPlatform(cleanUrl);

    // 检测原始链接类型
    ConvertLinkType originalType = ConvertLinkType.unknown;
    if (platform != VideoPlatform.unknown) {
      originalType = PlatformDetector.isShortLinkForPlatform(cleanUrl, platform)
          ? ConvertLinkType.shortLink
          : ConvertLinkType.longLink;
    }

    // 使用现有的 toLong 方法
    final result = await toLong(url);

    return result.copyWith(
      originalLinkType: originalType,
      resultLinkType: ConvertLinkType.longLink,
    );
  }

  /// 智能转换：自动识别链接类型，统一输出为标准短链格式
  ///
  /// 适用于混合输入场景：不管输入是短链还是长链，都输出标准短链
  Future<ConvertResultItem> smartToShort(String url) async {
    final cleanUrl = PlatformDetector.normalizeUrl(url) ?? url.trim();
    final platform = PlatformDetector.detectPlatform(cleanUrl);

    // 检测原始链接类型
    ConvertLinkType originalType = ConvertLinkType.unknown;
    if (platform != VideoPlatform.unknown) {
      originalType = PlatformDetector.isShortLinkForPlatform(cleanUrl, platform)
          ? ConvertLinkType.shortLink
          : ConvertLinkType.longLink;
    }

    // 使用现有的 toShort 方法
    final result = await toShort(url);

    return result.copyWith(
      originalLinkType: originalType,
      resultLinkType: ConvertLinkType.shortLink,
    );
  }

  /// 批量智能转换为长链（混合输入，统一输出长链）
  Future<List<ConvertRecord>> batchSmartToLong(
    List<String> urls, {
    int concurrency = 3,
    void Function(int success, int fail, List<ConvertResultItem> results)? onProgress,
  }) async {
    final batchId = _uuid.v4();

    // 预分配固定长度的结果列表，按索引写入，保证顺序与输入一致
    final resultList = List<ConvertResultItem?>.filled(urls.length, null);
    final recordList = List<ConvertRecord?>.filled(urls.length, null);
    int nextTaskIndex = 0;

    // 统计当前已完成任务的成功/失败数量，并构建进度结果列表
    void _reportProgress() {
      int success = 0;
      int fail = 0;
      final currentResults = <ConvertResultItem>[];
      for (int j = 0; j < urls.length; j++) {
        final r = resultList[j];
        if (r != null) {
          currentResults.add(r);
          if (r.success) {
            success++;
          } else {
            fail++;
          }
        }
      }
      onProgress?.call(success, fail, currentResults);
    }

    Future<void> worker() async {
      while (true) {
        // 在同步代码块中获取并递增任务索引（Dart 单线程下安全）
        final i = nextTaskIndex;
        if (i >= urls.length) break;
        nextTaskIndex++;

        final url = urls[i];
        final result = await smartToLong(url);

        // 按索引写入，保证结果顺序与输入一致
        resultList[i] = result;

        if (result.success) {
          recordList[i] = ConvertRecord(
            id: 'conv_${_uuid.v4()}',
            originalUrl: result.originalUrl,
            resultUrl: result.resultUrl!,
            platform: result.platform!,
            convertType: 'toLong',
            convertedAt: DateTime.now(),
            batchId: urls.length > 1 ? 'conv_batch_$batchId' : null,
            success: true,
          );
        }

        _reportProgress();
      }
    }

    final workers = <Future<void>>[];
    final actualConcurrency = concurrency.clamp(1, urls.length);
    for (int i = 0; i < actualConcurrency; i++) {
      workers.add(worker());
    }
    await Future.wait(workers);

    // 按原始顺序返回成功的记录
    return recordList.whereType<ConvertRecord>().toList();
  }

  /// 批量智能转换为短链（混合输入，统一输出短链）
  Future<List<ConvertRecord>> batchSmartToShort(
    List<String> urls, {
    int concurrency = 3,
    void Function(int success, int fail, List<ConvertResultItem> results)? onProgress,
  }) async {
    final batchId = _uuid.v4();

    // 预分配固定长度的结果列表，按索引写入，保证顺序与输入一致
    final resultList = List<ConvertResultItem?>.filled(urls.length, null);
    final recordList = List<ConvertRecord?>.filled(urls.length, null);
    int nextTaskIndex = 0;

    // 统计当前已完成任务的成功/失败数量，并构建进度结果列表
    void _reportProgress() {
      int success = 0;
      int fail = 0;
      final currentResults = <ConvertResultItem>[];
      for (int j = 0; j < urls.length; j++) {
        final r = resultList[j];
        if (r != null) {
          currentResults.add(r);
          if (r.success) {
            success++;
          } else {
            fail++;
          }
        }
      }
      onProgress?.call(success, fail, currentResults);
    }

    Future<void> worker() async {
      while (true) {
        // 在同步代码块中获取并递增任务索引（Dart 单线程下安全）
        final i = nextTaskIndex;
        if (i >= urls.length) break;
        nextTaskIndex++;

        final url = urls[i];
        final result = await smartToShort(url);

        // 按索引写入，保证结果顺序与输入一致
        resultList[i] = result;

        if (result.success) {
          recordList[i] = ConvertRecord(
            id: 'conv_${_uuid.v4()}',
            originalUrl: result.originalUrl,
            resultUrl: result.resultUrl!,
            platform: result.platform!,
            convertType: 'toShort',
            convertedAt: DateTime.now(),
            batchId: urls.length > 1 ? 'conv_batch_$batchId' : null,
            success: true,
          );
        }

        _reportProgress();
      }
    }

    final workers = <Future<void>>[];
    final actualConcurrency = concurrency.clamp(1, urls.length);
    for (int i = 0; i < actualConcurrency; i++) {
      workers.add(worker());
    }
    await Future.wait(workers);

    // 按原始顺序返回成功的记录
    return recordList.whereType<ConvertRecord>().toList();
  }

  /// 校验链接是否有效（发送 HEAD 请求）
  ///
  /// 返回 (isValid, statusCode)
  Future<(bool, int)> validateLink(String url) async {
    try {
      final response = await _dio.head(
        url,
        options: Options(
          followRedirects: true,
          validateStatus: (status) => status! < 500,
          receiveTimeout: const Duration(seconds: 10),
          sendTimeout: const Duration(seconds: 10),
        ),
      );
      final statusCode = response.statusCode ?? 0;
      final isValid = statusCode >= 200 && statusCode < 400;
      return (isValid, statusCode);
    } catch (e) {
      return (false, 0);
    }
  }

  /// 从文本中提取所有 URL
  List<String> extractAllUrls(String text) {
    return PlatformDetector.extractAllUrls(text);
  }

  // ======================================================
  // 内部方法：短链解析
  // ======================================================

  Future<String> _resolveShortLink(String url) async {
    try {
      final response = await _dio.head(url);
      final realUrl = response.realUri.toString();
      if (realUrl.isNotEmpty && realUrl != url) {
        return realUrl;
      }
      final getResponse = await _dio.get(url);
      return getResponse.realUri.toString();
    } catch (e) {
      try {
        final response = await _dio.head(
          url,
          options: Options(
            followRedirects: false,
            validateStatus: (status) => status! < 400,
          ),
        );
        final location = response.headers.value('location');
        if (location != null && location.isNotEmpty) {
          if (location.startsWith('http')) {
            return location;
          }
          final uri = Uri.parse(url);
          return '${uri.scheme}://${uri.host}$location';
        }
      } catch (_) {}
      rethrow;
    }
  }

  // ======================================================
  // 内部方法：ID 提取
  // ======================================================

  String? _extractVideoId(String url, VideoPlatform platform) {
    switch (platform) {
      case VideoPlatform.douyin:
        return _extractDouyinVideoId(url);
      case VideoPlatform.kuaishou:
        return _extractKuaishouVideoId(url);
      case VideoPlatform.xiaohongshu:
        return _extractXiaohongshuNoteId(url);
      case VideoPlatform.unknown:
        return null;
    }
  }

  String? _extractUserId(String url, VideoPlatform platform) {
    switch (platform) {
      case VideoPlatform.douyin:
        return _extractDouyinUserId(url);
      case VideoPlatform.kuaishou:
        return _extractKuaishouUserId(url);
      case VideoPlatform.xiaohongshu:
        return _extractXiaohongshuUserId(url);
      case VideoPlatform.unknown:
        return null;
    }
  }

  String? _extractDouyinVideoId(String url) {
    // 标准视频路径：/video/{id}
    final regex1 = RegExp(r'video\/(\d+)');
    final match1 = regex1.firstMatch(url);
    if (match1 != null) return match1.group(1);
    // 分享视频路径：/share/video/{id}
    final regex2 = RegExp(r'share\/video\/(\d+)');
    final match2 = regex2.firstMatch(url);
    if (match2 != null) return match2.group(1);
    // 图文路径：/note/{id} 或 /slides/{id}
    final regex3 = RegExp(r'(?:note|slides)\/(\d+)');
    final match3 = regex3.firstMatch(url);
    if (match3 != null) return match3.group(1);
    // 分享图文路径：/share/note/{id}
    final regex4 = RegExp(r'share\/note\/(\d+)');
    final match4 = regex4.firstMatch(url);
    if (match4 != null) return match4.group(1);
    // 从查询参数提取
    final uri = Uri.tryParse(url);
    if (uri != null) {
      if (uri.queryParameters['item_id'] != null) {
        return uri.queryParameters['item_id'];
      }
      if (uri.queryParameters['aweme_id'] != null) {
        return uri.queryParameters['aweme_id'];
      }
      if (uri.queryParameters['modal_id'] != null) {
        return uri.queryParameters['modal_id'];
      }
    }
    return null;
  }

  String? _extractDouyinUserId(String url) {
    // douyin.com/user/{sec_uid} 或 iesdouyin.com/share/user/{id}
    // 排除包含 video/note/slides 的路径（避免视频链接中的 user 路径被误匹配）
    if (!url.contains('/video/') &&
        !url.contains('/share/video/') &&
        !url.contains('/note/') &&
        !url.contains('/slides/')) {
      final regex1 = RegExp(r'user\/([a-zA-Z0-9_-]+)');
      final match1 = regex1.firstMatch(url);
      if (match1 != null) return match1.group(1);
      // /m/user/ 移动端路径
      final regex2 = RegExp(r'm\/user\/([a-zA-Z0-9_-]+)');
      final match2 = regex2.firstMatch(url);
      if (match2 != null) return match2.group(1);
    }
    // 从参数 sec_uid 提取
    final uri = Uri.tryParse(url);
    if (uri != null && uri.queryParameters['sec_uid'] != null) {
      return uri.queryParameters['sec_uid'];
    }
    return null;
  }

  String? _extractKuaishouVideoId(String url) {
    // /short-video/{id}
    final regex1 = RegExp(r'short-video\/([a-zA-Z0-9_]+)');
    final match1 = regex1.firstMatch(url);
    if (match1 != null) return match1.group(1);
    // /fw/photo/{id} 或 /photo/{id}
    final regex2 = RegExp(r'(?:fw\/)?photo\/([a-zA-Z0-9_]+)');
    final match2 = regex2.firstMatch(url);
    if (match2 != null) return match2.group(1);
    // /long-video/{id}
    final regex3 = RegExp(r'long-video\/([a-zA-Z0-9_]+)');
    final match3 = regex3.firstMatch(url);
    if (match3 != null) return match3.group(1);
    // 从查询参数提取
    final uri = Uri.tryParse(url);
    if (uri != null) {
      if (uri.queryParameters['photoId'] != null) {
        return uri.queryParameters['photoId'];
      }
      if (uri.queryParameters['objectId'] != null) {
        return uri.queryParameters['objectId'];
      }
    }
    return null;
  }

  String? _extractKuaishouUserId(String url) {
    // /profile/{userId} 或 /u/{userId} 或 /user/{userId}
    final regex1 = RegExp(r'(?:profile|user|u)\/([a-zA-Z0-9_]+)');
    final match1 = regex1.firstMatch(url);
    if (match1 != null) {
      // 排除视频相关路径
      if (!url.contains('/short-video/') &&
          !url.contains('/photo/') &&
          !url.contains('/fw/photo/') &&
          !url.contains('/long-video/')) {
        return match1.group(1);
      }
    }
    // /fw/user/{id} 或 /share/user/{id}
    final regex2 = RegExp(r'(?:fw\/user|share\/user)\/([a-zA-Z0-9_]+)');
    final match2 = regex2.firstMatch(url);
    if (match2 != null) return match2.group(1);
    // 从查询参数提取
    final uri = Uri.tryParse(url);
    if (uri != null) {
      if (uri.queryParameters['userId'] != null) {
        return uri.queryParameters['userId'];
      }
      if (uri.queryParameters['principalId'] != null) {
        return uri.queryParameters['principalId'];
      }
    }
    return null;
  }

  String? _extractXiaohongshuNoteId(String url) {
    // /explore/{noteId} 或 /discovery/item/{noteId} 或 /discovery/explore/{noteId}
    final regex1 = RegExp(r'(?:explore|discovery\/item|discovery\/explore)\/([a-zA-Z0-9]+)');
    final match1 = regex1.firstMatch(url);
    if (match1 != null) return match1.group(1);
    // /note/{noteId}
    final regex2 = RegExp(r'note\/([a-zA-Z0-9]+)');
    final match2 = regex2.firstMatch(url);
    if (match2 != null) return match2.group(1);
    // 从查询参数提取
    final uri = Uri.tryParse(url);
    if (uri != null) {
      if (uri.queryParameters['note_id'] != null) {
        return uri.queryParameters['note_id'];
      }
      if (uri.queryParameters['id'] != null) {
        final id = uri.queryParameters['id']!;
        // 小红书 noteId 是 24 位
        if (id.length == 24) return id;
      }
    }
    return null;
  }

  String? _extractXiaohongshuUserId(String url) {
    // /user/profile/{userId} 或 /profile/{userId}
    final regex1 = RegExp(r'(?:user\/profile|profile)\/([a-zA-Z0-9]+)');
    final match1 = regex1.firstMatch(url);
    if (match1 != null) return match1.group(1);
    // /user/{userId}（排除 /user/profile/ 已匹配的情况）
    if (!url.contains('/user/profile/')) {
      final regex2 = RegExp(r'user\/([a-zA-Z0-9]+)');
      final match2 = regex2.firstMatch(url);
      if (match2 != null) {
        // 排除笔记路径
        if (!url.contains('/explore/') &&
            !url.contains('/note/') &&
            !url.contains('/discovery/')) {
          return match2.group(1);
        }
      }
    }
    // 从查询参数提取
    final uri = Uri.tryParse(url);
    if (uri != null) {
      if (uri.queryParameters['user_id'] != null) {
        return uri.queryParameters['user_id'];
      }
      if (uri.queryParameters['uid'] != null) {
        return uri.queryParameters['uid'];
      }
    }
    return null;
  }

  // ======================================================
  // 内部方法：短链 / 长链构建
  // ======================================================

  String _buildVideoShortLink(String itemId, VideoPlatform platform) {
    // 生成标准格式的干净长链
    // 注意：平台短链（如 v.douyin.com/xxx）的短码由平台生成，无法自行构造
    // 因此输出各平台最标准、最精简的长链格式（去掉所有冗余参数）
    switch (platform) {
      case VideoPlatform.douyin:
        return 'https://www.douyin.com/video/$itemId';
      case VideoPlatform.kuaishou:
        return 'https://www.kuaishou.com/short-video/$itemId';
      case VideoPlatform.xiaohongshu:
        return 'https://www.xiaohongshu.com/explore/$itemId';
      case VideoPlatform.unknown:
        return '';
    }
  }

  String _buildAuthorShortLink(String userId, VideoPlatform platform) {
    // 生成标准格式的干净长链
    switch (platform) {
      case VideoPlatform.douyin:
        return 'https://www.douyin.com/user/$userId';
      case VideoPlatform.kuaishou:
        return 'https://www.kuaishou.com/profile/$userId';
      case VideoPlatform.xiaohongshu:
        return 'https://www.xiaohongshu.com/user/profile/$userId';
      case VideoPlatform.unknown:
        return '';
    }
  }
}
