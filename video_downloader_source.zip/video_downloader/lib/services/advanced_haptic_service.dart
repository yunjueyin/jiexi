import 'package:vibration/vibration.dart';
import 'package:flutter/services.dart';

/// 振动模式类型
enum VibrationPattern {
  /// 成功：短促的一下
  success,

  /// 失败：两下短促振动
  error,

  /// 警告：长震一下
  warning,

  /// 轻触
  light,

  /// 中等
  medium,

  /// 重度
  heavy,
}

/// 高级触觉反馈服务（扩展 HapticService）
///
/// 提供更丰富的振动模式，用于下载完成、失败等场景。
/// 使用 vibration 包实现自定义振动模式。
class AdvancedHapticService {
  static bool _enabled = true;

  /// 设置是否启用
  static void setEnabled(bool enabled) {
    _enabled = enabled;
  }

  /// 播放指定模式的振动
  static Future<void> vibratePattern(VibrationPattern pattern) async {
    if (!_enabled) return;

    try {
      final hasVibrator = await Vibration.hasVibrator();
      if (hasVibrator != true) {
        // 如果没有振动器，回退到 HapticFeedback
        _fallbackHaptic(pattern);
        return;
      }

      switch (pattern) {
        case VibrationPattern.success:
          // 成功：短促 50ms
          Vibration.vibrate(duration: 50, amplitude: 128);
          break;
        case VibrationPattern.error:
          // 失败：短-停-短 模式
          Vibration.vibrate(pattern: [0, 80, 100, 80], intensities: [0, 180, 0, 180]);
          break;
        case VibrationPattern.warning:
          // 警告：稍长的一次
          Vibration.vibrate(duration: 200, amplitude: 200);
          break;
        case VibrationPattern.light:
          Vibration.vibrate(duration: 30, amplitude: 64);
          break;
        case VibrationPattern.medium:
          Vibration.vibrate(duration: 50, amplitude: 128);
          break;
        case VibrationPattern.heavy:
          Vibration.vibrate(duration: 100, amplitude: 255);
          break;
      }
    } catch (_) {
      // 出错时回退到 HapticFeedback
      _fallbackHaptic(pattern);
    }
  }

  /// 回退到系统 HapticFeedback
  static void _fallbackHaptic(VibrationPattern pattern) {
    switch (pattern) {
      case VibrationPattern.success:
      case VibrationPattern.light:
        HapticFeedback.lightImpact();
        break;
      case VibrationPattern.medium:
      case VibrationPattern.warning:
        HapticFeedback.mediumImpact();
        break;
      case VibrationPattern.error:
      case VibrationPattern.heavy:
        HapticFeedback.heavyImpact();
        // 错误模式下连续两次
        Future.delayed(const Duration(milliseconds: 150), () {
          HapticFeedback.heavyImpact();
        });
        break;
    }
  }

  /// 取消正在进行的振动
  static Future<void> cancel() async {
    try {
      await Vibration.cancel();
    } catch (_) {
      // 忽略错误
    }
  }
}
