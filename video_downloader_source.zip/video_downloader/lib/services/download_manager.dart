import 'dart:io';
import 'package:dio/dio.dart';
import 'package:dio/io.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:file_picker/file_picker.dart';
import '../models/download_task.dart';
import '../models/video_info.dart';
import 'notification_service.dart';
import 'advanced_haptic_service.dart';
import 'proxy_service.dart';

class DownloadManager {
  static const String _boxName = 'download_tasks';
  Box<DownloadTask>? _box;

  final Dio _dio = Dio();
  final Map<String, CancelToken> _cancelTokens = {};
  List<DownloadTask> _tasks = [];
  final Set<String> _activeDownloads = {};
  final Map<String, int> _retryCounts = {}; // 任务重试次数
  // 标记是否为用户主动暂停（用于区分暂停和取消）
  final Set<String> _pausedTasks = {};
  // 最近删除的任务（用于撤销删除）
  final List<DownloadTask> _recentlyRemoved = [];
  static const int _maxRecentlyRemoved = 20;
  // 通知 ID 映射：taskId -> notificationId（用于进度通知更新）
  final Map<String, int> _notificationIds = {};
  // 上次通知更新时间：taskId -> DateTime（用于控制通知更新频率）
  final Map<String, DateTime> _lastNotificationTime = {};
  // 通知 ID 计数器
  int _notificationIdCounter = 1000;
  int _maxConcurrency = 2;
  static const int _maxRetries = 10; // 最大重试次数（网络差时多试几次）
  static const int _connectTimeout = 30000; // 连接超时 30s
  static const int _receiveTimeout = 60000; // 接收超时 60s（大文件需要更长时间）

  // 批量下载完成通知计数
  int _batchSuccessCount = 0;
  int _batchFailCount = 0;
  // 批量通知的通知 ID（用于复用同一个通知）
  static const int _batchNotificationId = 9999;

  /// 下载失败是否自动重试（用户可配置）
  bool autoRetryOnFailure = true;

  /// 用户配置的最大重试次数（1-5次）
  int userMaxRetryCount = 3;

  static const _mediaChannel = MethodChannel('com.example.video_downloader/media');

  /// 代理服务（可选，注入后自动应用代理配置）
  ProxyService? _proxyService;

  /// 设置代理服务并应用配置
  void setProxyService(ProxyService? proxyService) {
    // 移除旧的监听
    _proxyService?.removeListener(_onProxyChanged);
    _proxyService = proxyService;
    if (proxyService != null) {
      proxyService.applyToDio(_dio);
      proxyService.addListener(_onProxyChanged);
    } else {
      // 清除代理配置
      _dio.httpClientAdapter = IOHttpClientAdapter();
    }
  }

  void _onProxyChanged() {
    _proxyService?.applyToDio(_dio);
  }

  /// 初始化持久化存储
  Future<void> init() async {
    _box ??= await Hive.openBox<DownloadTask>(_boxName);
    // 从 Hive 加载所有任务
    _tasks = _box!.values.toList();
    // 按创建时间倒序排列（新的在前）
    _tasks.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    // 对于上次退出时正在下载的任务，标记为失败（因为实际已经中断了）
    // 但保留已下载的字节数，用户可以手动点击继续下载（断点续传）
    for (final task in _tasks) {
      if (task.status == DownloadStatus.downloading ||
          task.status == DownloadStatus.queued) {
        task.status = DownloadStatus.failed;
        task.errorMessage = '下载中断，点击继续下载';
      }
    }
    // 批量保存状态变更
    if (_box != null) {
      for (final task in _tasks) {
        await _box!.put(task.id, task);
      }
    }
  }

  /// 保存任务到持久化存储
  Future<void> _saveTask(DownloadTask task) async {
    try {
      await _box?.put(task.id, task);
    } catch (_) {
      // 保存失败不影响下载
    }
  }

  /// 从持久化存储删除任务
  Future<void> _deleteTask(String taskId) async {
    try {
      await _box?.delete(taskId);
    } catch (_) {}
  }

  /// 更新任务状态并持久化保存（仅在状态变更的关键节点调用）
  void _updateTaskStatus(DownloadTask task, DownloadStatus status, {String? errorMessage}) {
    final oldStatus = task.status;
    task.status = status;
    if (errorMessage != null) {
      task.errorMessage = errorMessage;
    }
    _saveTask(task);

    // 触感反馈
    if (status == DownloadStatus.completed && oldStatus != DownloadStatus.completed) {
      if (hapticOnComplete) {
        AdvancedHapticService.vibratePattern(VibrationPattern.success);
      }
    } else if (status == DownloadStatus.failed && oldStatus != DownloadStatus.failed) {
      if (hapticOnFailed) {
        AdvancedHapticService.vibratePattern(VibrationPattern.error);
      }
    }
  }

  /// 自定义下载路径（为空表示使用默认目录）
  String? _customDownloadPath;

  List<DownloadTask> get tasks => List.unmodifiable(_tasks);
  List<DownloadTask> get downloadingTasks =>
      _tasks.where((t) => t.status == DownloadStatus.downloading).toList();
  List<DownloadTask> get completedTasks =>
      _tasks.where((t) => t.status == DownloadStatus.completed).toList();

  /// 获取分组后的任务列表（同一图集的图片归为一组）
  /// 返回的列表中，每个组只显示第一条（代表任务），
  /// 具体组内任务通过 [getGroupTasks] 获取
  List<DownloadTask> get groupedTasks {
    final seenGroups = <String?>{};
    return _tasks.where((task) {
      if (task.groupId == null) return true; // 非组任务直接显示
      if (seenGroups.contains(task.groupId)) return false; // 已显示过的组跳过
      seenGroups.add(task.groupId);
      return true; // 组的第一条保留
    }).toList();
  }

  /// 获取某个组的所有任务
  List<DownloadTask> getGroupTasks(String groupId) {
    return _tasks
        .where((t) => t.groupId == groupId)
        .toList()
      ..sort((a, b) => (a.groupIndex ?? 0).compareTo(b.groupIndex ?? 0));
  }

  /// 获取某个组的完成进度（0.0 - 1.0）
  double getGroupProgress(String groupId) {
    final groupTasks = getGroupTasks(groupId);
    if (groupTasks.isEmpty) return 0.0;
    final totalProgress = groupTasks.fold<double>(0, (sum, t) => sum + t.progress);
    return totalProgress / groupTasks.length;
  }

  /// 获取某个组的状态文字
  String getGroupStatusText(String groupId) {
    final groupTasks = getGroupTasks(groupId);
    if (groupTasks.isEmpty) return '';
    final total = groupTasks.length;
    final completed = groupTasks.where((t) => t.status == DownloadStatus.completed).length;
    final downloading = groupTasks.where((t) => t.status == DownloadStatus.downloading).length;
    final failed = groupTasks.where((t) => t.status == DownloadStatus.failed).length;
    final paused = groupTasks.where((t) => t.status == DownloadStatus.paused).length;

    if (completed == total) return '已完成 ($completed/$total)';
    if (failed > 0) return '失败 $failed 张 ($completed/$total)';
    if (paused > 0) return '已暂停 ($completed/$total)';
    if (downloading > 0) return '下载中 ($completed/$total)';
    return '等待中 ($completed/$total)';
  }

  /// 判断组内是否有正在下载的任务
  bool isGroupDownloading(String groupId) {
    return getGroupTasks(groupId)
        .any((t) => t.status == DownloadStatus.downloading || t.status == DownloadStatus.queued);
  }

  /// 暂停整个图集组
  void pauseGroup(String groupId) {
    for (final task in getGroupTasks(groupId)) {
      pauseTask(task.id);
    }
  }

  /// 恢复整个图集组
  void resumeGroup(String groupId) {
    for (final task in getGroupTasks(groupId)) {
      resumeTask(task.id);
    }
  }

  /// 删除整个图集组
  void removeGroup(String groupId, {bool deleteFile = false}) {
    for (final task in getGroupTasks(groupId)) {
      removeTask(task.id, deleteFile: deleteFile);
    }
  }

  Function(DownloadTask)? onProgress;
  Function(DownloadTask)? onComplete;
  Function(DownloadTask, String)? onError;

  /// 设置自定义下载路径
  void setCustomDownloadPath(String? path) {
    _customDownloadPath = path;
  }

  /// 获取当前下载目录（用于显示）
  String get displayDownloadPath {
    if (_customDownloadPath != null && _customDownloadPath!.isNotEmpty) {
      return _customDownloadPath!;
    }
    if (Platform.isAndroid) {
      return 'DCIM/VideoDownloader（相册可见）';
    }
    return '默认下载目录';
  }

  /// 是否使用自定义路径
  bool get useCustomPath =>
      _customDownloadPath != null && _customDownloadPath!.isNotEmpty;

  /// 是否按平台分类保存
  bool organizeByPlatform = true;

  // ==================== 智能分类存储 ====================

  /// 存储组织模式：flat / platform / author / date / platform_author
  String storageOrganizeMode = 'flat';

  /// 日期格式：yyyyMMdd / yyyy-MM / yyyy-MM-dd
  String storageDateFormat = 'yyyyMMdd';

  /// 文件命名规则：title / platform_title / date_title / id_title
  String storageNamingRule = 'title';

  /// 下载完成时是否发送通知
  bool downloadNotificationEnabled = true;

  /// 下载完成时是否触发触感反馈
  bool hapticOnComplete = true;

  /// 下载失败时是否触发触感反馈
  bool hapticOnFailed = true;

  /// 下载完成后是否自动保存到系统相册（默认开启）
  /// 仅对视频和图片类型的下载生效，音频不添加
  bool autoSaveToGallery = true;

  // ==================== 自动清理下载记录 ====================

  /// 是否开启自动清理已完成下载记录
  bool autoCleanDownloadsEnabled = false;

  /// 清理策略：'days'（按保留天数）/ 'count'（按保留数量）
  String autoCleanMode = 'days';

  /// 按天数保留时的保留天数
  int autoCleanDays = 30;

  /// 按数量保留时的最大保留条数
  int autoCleanMaxCount = 200;

  /// 清理时是否同时删除文件
  bool autoCleanDeleteFiles = false;

  /// 最大并发下载数
  int get maxConcurrency => _maxConcurrency;

  /// 设置最大并发下载数（范围 1-5）
  void setMaxConcurrency(int value) {
    if (value < 1) value = 1;
    if (value > 5) value = 5;
    _maxConcurrency = value;
    // 如果增加了并发数，尝试启动更多等待中的任务
    _processQueue();
  }

  /// 设置下载失败是否自动重试
  void setAutoRetryOnFailure(bool value) {
    autoRetryOnFailure = value;
  }

  /// 设置最大重试次数（范围 1-5）
  void setMaxRetryCount(int value) {
    if (value < 1) value = 1;
    if (value > 5) value = 5;
    userMaxRetryCount = value;
  }

  /// 平台名称映射
  String _platformFolderName(String platform) {
    switch (platform) {
      case 'douyin':
        return '抖音';
      case 'kuaishou':
        return '快手';
      case 'xhs':
      case 'xiaohongshu':
        return '小红书';
      default:
        return platform;
    }
  }

  /// 作者名称清理（用于文件夹名）
  String _sanitizeFolderName(String name) {
    final cleaned = name.replaceAll(RegExp(r'[\\/:*?"<>|\n\r\t]'), '_');
    final trimmed = cleaned.trim();
    if (trimmed.isEmpty) return 'unknown';
    if (trimmed.length > 50) return trimmed.substring(0, 50);
    return trimmed;
  }

  /// 根据组织模式生成分类存储路径
  ///
  /// [baseDir] - 基础下载目录
  /// [platform] - 平台名称
  /// [author] - 作者名称（可选）
  /// [dateTime] - 日期时间（用于日期模式）
  ///
  /// 返回组织后的目录路径，自动创建不存在的目录
  Future<String> _getOrganizedSavePath({
    required String baseDir,
    String? platform,
    String? author,
    DateTime? dateTime,
  }) async {
    final mode = storageOrganizeMode;
    String subPath = baseDir;

    switch (mode) {
      case 'flat':
        // 平铺模式：不创建子目录
        subPath = baseDir;
        break;

      case 'platform':
        // 按平台分类
        if (platform != null && platform.isNotEmpty) {
          subPath = '$baseDir/${_platformFolderName(platform)}';
        }
        break;

      case 'author':
        // 按作者分类
        if (author != null && author.isNotEmpty) {
          subPath = '$baseDir/${_sanitizeFolderName(author)}';
        }
        break;

      case 'date':
        // 按日期分类
        final date = dateTime ?? DateTime.now();
        final dateStr = _formatDate(date, storageDateFormat);
        subPath = '$baseDir/$dateStr';
        break;

      case 'platform_author':
        // 平台+作者两级分类
        if (platform != null && platform.isNotEmpty) {
          subPath = '$baseDir/${_platformFolderName(platform)}';
          if (author != null && author.isNotEmpty) {
            subPath = '$subPath/${_sanitizeFolderName(author)}';
          }
        } else if (author != null && author.isNotEmpty) {
          subPath = '$baseDir/${_sanitizeFolderName(author)}';
        }
        break;

      default:
        subPath = baseDir;
    }

    // 创建目录
    if (subPath != baseDir) {
      final dir = Directory(subPath);
      if (!await dir.exists()) {
        try {
          await dir.create(recursive: true);
        } catch (_) {
          // 创建失败则使用基础目录
          return baseDir;
        }
      }
    }

    return subPath;
  }

  /// 格式化日期
  String _formatDate(DateTime date, String format) {
    final y = date.year.toString().padLeft(4, '0');
    final m = date.month.toString().padLeft(2, '0');
    final d = date.day.toString().padLeft(2, '0');
    switch (format) {
      case 'yyyy-MM':
        return '$y-$m';
      case 'yyyy-MM-dd':
        return '$y-$m-$d';
      case 'yyyyMMdd':
      default:
        return '$y$m$d';
    }
  }

  /// 根据命名规则生成文件名（不含扩展名）
  String _generateFileName({
    required String title,
    required String videoId,
    String? platform,
    DateTime? dateTime,
  }) {
    final rule = storageNamingRule;
    final shortId = videoId.length > 8 ? videoId.substring(0, 8) : videoId;
    final date = dateTime ?? DateTime.now();
    final dateStr = _formatDate(date, 'yyyyMMdd');
    final platformName = platform != null ? _platformFolderName(platform) : '';

    String name;
    switch (rule) {
      case 'platform_title':
        name = platformName.isNotEmpty ? '${platformName}_$title' : title;
        break;
      case 'date_title':
        name = '${dateStr}_$title';
        break;
      case 'id_title':
        name = '${shortId}_$title';
        break;
      case 'title':
      default:
        name = title;
    }

    return _sanitizeFileName(name);
  }

  /// 检查存储权限
  /// 只有使用自定义路径时才需要申请权限
  Future<bool> checkStoragePermission() async {
    // 如果使用默认下载目录，不需要权限
    if (!useCustomPath) {
      return true;
    }

    // 使用自定义路径，需要检查权限
    if (Platform.isAndroid) {
      final status = await Permission.storage.status;
      if (status.isGranted) return true;
      final result = await Permission.storage.request();
      return result.isGranted;
    }
    return true;
  }

  /// 请求存储权限（用于选择目录前主动申请）
  Future<bool> requestStoragePermission() async {
    if (Platform.isAndroid) {
      final status = await Permission.storage.status;
      if (status.isGranted) return true;
      if (status.isPermanentlyDenied) {
        // 永久拒绝，引导用户到设置
        await openAppSettings();
        return false;
      }
      final result = await Permission.storage.request();
      return result.isGranted;
    }
    return true;
  }

  /// 打开系统文件管理器选择目录
  ///
  /// Android 说明：
  /// - Android 11 (API 30) 及以上：FilePicker 使用 SAF（存储访问框架）
  ///   选择目录，不需要存储权限，直接调用即可
  /// - 绝大多数现代设备都 >= Android 11，因此直接调用，失败则返回 null
  Future<String?> pickDirectory() async {
    try {
      // 直接调用系统文件选择器（SAF 方式，Android 11+ 无需权限）
      final result = await FilePicker.platform.getDirectoryPath(
        dialogTitle: '选择下载目录',
        lockParentWindow: true,
      );
      return result;
    } catch (e) {
      return null;
    }
  }

  /// 获取下载目录（根据文件类型选择不同的默认目录）
  /// 
  /// [isImage] - 是否为图片，图片默认保存到 Pictures 目录，视频保存到 DCIM 目录
  /// [platform] - 平台名称
  /// [author] - 作者名称（用于 author / platform_author 模式）
  /// [dateTime] - 日期时间（用于 date 模式）
  Future<String> getDownloadDirectory({
    bool isImage = false,
    String? platform,
    String? author,
    DateTime? dateTime,
  }) async {
    Directory directory;

    if (useCustomPath) {
      // 使用自定义路径
      directory = Directory(_customDownloadPath!);
    } else if (Platform.isAndroid) {
      // 默认优先保存到 DCIM（视频）或 Pictures（图片）目录，相册可见
      directory = await _getGalleryDirectory(isImage: isImage);
    } else {
      // 其他平台使用应用文档目录
      directory = await getApplicationDocumentsDirectory();
      if (!await directory.exists()) {
        await directory.create(recursive: true);
      }
    }

    // 使用新的智能分类存储系统
    return await _getOrganizedSavePath(
      baseDir: directory.path,
      platform: platform,
      author: author,
      dateTime: dateTime,
    );
  }

  /// 获取相册可见的目录（DCIM 或 Pictures）
  /// 
  /// 优先尝试原生方式获取，失败则手动拼接路径并尝试创建
  Future<Directory> _getGalleryDirectory({required bool isImage}) async {
    try {
      final method = isImage ? 'getPicturesDirectory' : 'getDCIMDirectory';
      final path = await _mediaChannel.invokeMethod<String>(method);
      if (path != null && path.isNotEmpty) {
        final dir = Directory(path);
        if (await dir.exists() || _tryCreateDir(dir)) {
          if (await _testWritable(dir)) {
            return dir;
          }
        }
      }
    } catch (_) {
      // 原生调用失败，继续兜底
    }

    // 兜底：手动尝试 DCIM/Pictures 目录
    final baseDir = isImage
        ? Directory('/storage/emulated/0/Pictures/VideoDownloader')
        : Directory('/storage/emulated/0/DCIM/VideoDownloader');
    try {
      if (!await baseDir.exists()) {
        await baseDir.create(recursive: true);
      }
      if (await _testWritable(baseDir)) {
        return baseDir;
      }
    } catch (_) {}

    // 再兜底：尝试 Download 目录
    final downloadDir = Directory('/storage/emulated/0/Download/VideoDownloader');
    try {
      if (!await downloadDir.exists()) {
        await downloadDir.create(recursive: true);
      }
      if (await _testWritable(downloadDir)) {
        return downloadDir;
      }
    } catch (_) {}

    // 最终兜底：应用外部文件目录
    final extDir = await getExternalStorageDirectory();
    if (extDir != null) {
      final subDir = Directory('${extDir.path}/VideoDownloader');
      if (!await subDir.exists()) {
        await subDir.create(recursive: true);
      }
      return subDir;
    }

    // 最后兜底：临时目录
    return await getTemporaryDirectory();
  }

  bool _tryCreateDir(Directory dir) {
    try {
      dir.createSync(recursive: true);
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<bool> _testWritable(Directory dir) async {
    try {
      final testFile = File('${dir.path}/.write_test');
      await testFile.writeAsBytes([1]);
      await testFile.delete();
      return true;
    } catch (_) {
      return false;
    }
  }

  /// 通知媒体库扫描文件（让相册能看到）
  ///
  /// 优先使用 MediaStore API 插入（Android 10+ 最可靠），失败则回退到 MediaScannerConnection
  Future<void> _scanMediaFile(String path, {required bool isImage, String? title}) async {
    if (!Platform.isAndroid) return;
    try {
      final mimeType = isImage ? 'image/*' : 'video/*';
      // 优先尝试 MediaStore API 插入（确保相册可见）
      final success = await _mediaChannel.invokeMethod<bool>('insertMedia', {
        'path': path,
        'mimeType': mimeType,
        'title': title,
      });
      if (success == true) return;
      // 失败则回退到扫描
      await _mediaChannel.invokeMethod('scanFile', {
        'path': path,
        'mimeType': mimeType,
      });
    } catch (_) {
      // 扫描失败不影响下载结果
    }
  }

  /// 创建下载任务
  /// - 视频类型：创建单个下载任务
  /// - 图文类型：为每张图片创建一个下载任务，共享同一个 groupId
  /// 返回值：视频类型返回单个任务，图文类型返回第一张图片的任务（组代表）
  Future<DownloadTask> createTask(VideoInfo video, String quality) async {
    // 图文类型：批量创建任务
    if (video.isImage && video.images != null && video.images!.isNotEmpty) {
      return await _createImageGroupTasks(video, quality);
    }

    // 视频类型：单个任务
    final videoUrl = video.getVideoUrl(quality) ?? video.videoUrl;
    if (videoUrl == null) {
      throw Exception('没有可用的下载地址');
    }

    final downloadDir = await getDownloadDirectory(
      isImage: false,
      platform: video.platform,
      author: video.author,
      dateTime: DateTime.now(),
    );
    final baseName = _generateFileName(
      title: video.title,
      videoId: video.id,
      platform: video.platform,
      dateTime: DateTime.now(),
    );
    final fileName = _sanitizeFileName('$baseName.mp4');
    final savePath = '$downloadDir/$fileName';

    final task = DownloadTask(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      videoId: video.id,
      videoUrl: videoUrl,
      savePath: savePath,
      fileName: fileName,
      quality: quality,
      videoTitle: video.title,
      videoCover: video.cover,
      platform: video.platform,
      createdAt: DateTime.now(),
      isImage: false,
    );

    _tasks.insert(0, task);
    _saveTask(task);
    _processQueue();

    return task;
  }

  /// 创建纯音频下载任务
  ///
  /// 直接下载视频文件，后续可通过 extractAudio 提取音频
  /// （简化方案：下载完整视频，由用户手动提取音频）
  Future<DownloadTask> createAudioTask(
    VideoInfo video,
    String quality, {
    String audioFormat = 'mp3',
  }) async {
    if (video.isImage) {
      throw Exception('图文类型不支持音频下载');
    }

    final videoUrl = video.getVideoUrl(quality) ?? video.videoUrl;
    if (videoUrl == null) {
      throw Exception('没有可用的下载地址');
    }

    final downloadDir = await getDownloadDirectory(isImage: false, platform: video.platform);
    // 音频任务先下载视频文件，后续提取音频
    final fileName = _sanitizeFileName(
      '${video.title}_${video.id.substring(0, video.id.length > 8 ? 8 : video.id.length)}_audio.mp4',
    );
    final savePath = '$downloadDir/$fileName';

    final task = DownloadTask(
      id: 'audio_${DateTime.now().millisecondsSinceEpoch}',
      videoId: video.id,
      videoUrl: videoUrl,
      savePath: savePath,
      fileName: fileName,
      quality: quality,
      videoTitle: video.title,
      videoCover: video.cover,
      platform: video.platform,
      createdAt: DateTime.now(),
      isImage: false,
      isAudioOnly: true,
      audioFormat: audioFormat,
    );

    _tasks.insert(0, task);
    _saveTask(task);
    _processQueue();

    return task;
  }

  /// 从已下载的视频中提取音频
  ///
  /// 简化方案：复制视频文件并重命名为音频格式，
  /// 真实场景下应使用 ffmpeg 提取音频流。
  /// 返回输出文件路径。
  Future<String> extractAudio({
    required String videoPath,
    required String outputDir,
    String audioFormat = 'mp3',
  }) async {
    final videoFile = File(videoPath);
    if (!await videoFile.exists()) {
      throw Exception('视频文件不存在');
    }

    // 确保输出目录存在
    final dir = Directory(outputDir);
    if (!await dir.exists()) {
      await dir.create(recursive: true);
    }

    final videoFileName = videoFile.uri.pathSegments.last;
    final baseName = videoFileName.replaceAll(RegExp(r'\.[^.]+$'), '');
    final outputFileName = '$baseName.$audioFormat';
    final outputPath = '$outputDir/$outputFileName';

    // 简化实现：直接复制文件并重命名
    // 真实实现应该用 ffmpeg 提取音频：ffmpeg -i input.mp4 -vn -acodec copy output.mp3
    await videoFile.copy(outputPath);

    return outputPath;
  }

  /// 为图文作品创建一组下载任务（每张图片一个任务）
  Future<DownloadTask> _createImageGroupTasks(
      VideoInfo video, String quality) async {
    final images = video.images!;
    final groupId = 'img_${video.id}_${DateTime.now().millisecondsSinceEpoch}';
    final downloadDir = await getDownloadDirectory(
      isImage: true,
      platform: video.platform,
      author: video.author,
      dateTime: DateTime.now(),
    );
    final baseName = _generateFileName(
      title: video.title,
      videoId: video.id,
      platform: video.platform,
      dateTime: DateTime.now(),
    );

    DownloadTask? firstTask;
    final now = DateTime.now();

    for (int i = 0; i < images.length; i++) {
      final imgUrl = images[i];
      final ext = _getImageExtension(imgUrl);
      final indexStr = (i + 1).toString().padLeft(2, '0');
      final fileName = '${baseName}_$indexStr.$ext';
      final savePath = '$downloadDir/$fileName';

      final task = DownloadTask(
        id: '${now.millisecondsSinceEpoch}_$i',
        videoId: video.id,
        videoUrl: imgUrl,
        savePath: savePath,
        fileName: fileName,
        quality: quality,
        videoTitle: video.title,
        videoCover: video.cover,
        platform: video.platform,
        createdAt: now,
        isImage: true,
        groupId: groupId,
        groupTotal: images.length,
        groupIndex: i + 1,
      );

      _tasks.add(task); // 批量添加到末尾
      _saveTask(task);

      if (i == 0) firstTask = task;
    }

    // 按创建时间倒序排列
    _tasks.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    _processQueue();

    return firstTask!;
  }

  void _processQueue() {
    final queuedTasks = _tasks.where((t) => t.status == DownloadStatus.queued).toList();
    for (var task in queuedTasks) {
      if (_activeDownloads.length >= _maxConcurrency) break;
      _startDownload(task);
    }
  }

  /// 获取任务对应的通知 ID（不存在则创建）
  int _getNotificationId(String taskId) {
    if (!_notificationIds.containsKey(taskId)) {
      _notificationIdCounter++;
      _notificationIds[taskId] = _notificationIdCounter;
    }
    return _notificationIds[taskId]!;
  }

  /// 更新下载进度通知（节流控制，避免频繁更新）
  ///
  /// 每 1.5 秒最多更新一次通知，避免通知栏闪烁和性能损耗。
  void _updateProgressNotification(DownloadTask task) {
    if (!downloadNotificationEnabled) return;

    final now = DateTime.now();
    final lastTime = _lastNotificationTime[task.id];
    // 距离上次更新不足 1.5 秒则跳过
    if (lastTime != null && now.difference(lastTime).inMilliseconds < 1500) {
      return;
    }
    _lastNotificationTime[task.id] = now;

    final notificationId = _getNotificationId(task.id);
    final progressPercent = (task.progress * 100).round().clamp(0, 100);

    NotificationService.instance.updateDownloadProgress(
      notificationId,
      task.videoTitle,
      progressPercent,
      task.speedBytesPerSecond,
    );
  }

  /// 清理任务的通知相关状态
  void _cleanupNotificationState(String taskId) {
    _notificationIds.remove(taskId);
    _lastNotificationTime.remove(taskId);
  }

  Future<void> _startDownload(DownloadTask task) async {
    if (_activeDownloads.contains(task.id)) return;
    // 二次校验：任务状态可能在排队到启动的间隙被外部改变（如 cancel/pause）
    if (task.status != DownloadStatus.queued) return;
    _activeDownloads.add(task.id);

    _updateTaskStatus(task, DownloadStatus.downloading);
    _pausedTasks.remove(task.id);
    onProgress?.call(task);

    // 初始化重试计数
    _retryCounts[task.id] ??= 0;
    task.retryCount = 0;

    // 计算实际最大重试次数：如果开启了自动重试，使用用户配置的次数，否则为0
    final actualMaxRetries = autoRetryOnFailure ? userMaxRetryCount.clamp(1, 5) : 0;

    // 临时文件路径（下载过程中写入，完成后重命名为最终文件）
    // 这样即使下载中断，也不会损坏已完成的文件
    final tmpPath = '${task.savePath}.tmp';

    while (_retryCounts[task.id]! <= actualMaxRetries) {
      final cancelToken = CancelToken();
      _cancelTokens[task.id] = cancelToken;

      try {
        // 根据平台设置 Referer，避免抖音/快手 CDN 返回 403
        final referer = _getReferer(task.platform, task.videoUrl);
        final headers = <String, String>{
          'User-Agent': 'Mozilla/5.0 (Linux; Android 10; MI 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.99 Mobile Safari/537.36',
        };
        if (referer != null) {
          headers['Referer'] = referer;
        }

        // ===== 断点续传：检查临时文件大小 =====
        // 始终从 .tmp 临时文件续传，避免影响最终文件
        int startByte = 0;
        final tmpFile = File(tmpPath);
        bool supportsResume = false; // 服务器是否支持断点续传

        if (await tmpFile.exists()) {
          final fileLength = await tmpFile.length();
          if (fileLength > 0) {
            startByte = fileLength;
            if (task.receivedBytes < fileLength) {
              task.receivedBytes = fileLength;
            }
            headers['Range'] = 'bytes=$startByte-';
            supportsResume = true; // 先假设支持，根据响应判断
          }
        } else {
          // 临时文件不存在，确保进度从零开始
          task.receivedBytes = 0;
          task.progress = 0;
        }

        // 使用流下载，支持断点续传追加写入
        final response = await _dio.get<ResponseBody>(
          task.videoUrl,
          cancelToken: cancelToken,
          options: Options(
            headers: headers,
            responseType: ResponseType.stream,
            connectTimeout: const Duration(milliseconds: _connectTimeout),
            receiveTimeout: const Duration(milliseconds: _receiveTimeout),
          ),
        );

        // 检查服务器是否支持断点续传
        final statusCode = response.statusCode ?? 200;
        final isPartial = statusCode == 206; // 206 Partial Content

        // 如果我们请求了 Range 但服务器返回 200，说明不支持续传
        // 需要清空临时文件从头下载
        if (supportsResume && !isPartial) {
          startByte = 0;
          task.receivedBytes = 0;
          // 清空临时文件
          if (await tmpFile.exists()) {
            await tmpFile.delete();
          }
        }

        // 获取总大小
        final contentLength = int.tryParse(
              response.headers.value(HttpHeaders.contentLengthHeader) ?? '',
            ) ??
            0;
        final totalSize = isPartial
            ? (startByte + contentLength)
            : contentLength;
        task.totalBytes = totalSize;

        // 写入临时文件（追加模式或新建模式）
        final raf = await tmpFile.open(
          mode: isPartial ? FileMode.append : FileMode.write,
        );

        // ===== 下载速度计算 =====
        int downloaded = 0;
        int lastCalcBytes = 0;
        DateTime lastCalcTime = DateTime.now();

        try {
          await for (final chunk in response.data!.stream) {
            if (cancelToken.isCancelled) {
              break;
            }
            await raf.writeFrom(chunk);
            downloaded += chunk.length;
            final totalReceived = startByte + downloaded;
            task.receivedBytes = totalReceived;
            if (totalSize > 0) {
              task.progress = totalReceived / totalSize;
            }

            // 每秒更新一次速度和剩余时间（避免频繁计算）
            final now = DateTime.now();
            final elapsed = now.difference(lastCalcTime).inMilliseconds;
            if (elapsed >= 1000) {
              final bytesDelta = downloaded - lastCalcBytes;
              if (bytesDelta > 0 && elapsed > 0) {
                // 计算速度：字节/秒
                task.speedBytesPerSecond = (bytesDelta * 1000 / elapsed).round();
                // 计算剩余时间
                if (totalSize > 0 && task.speedBytesPerSecond > 0) {
                  final remainingBytes = totalSize - totalReceived;
                  task.remainingSeconds =
                      (remainingBytes / task.speedBytesPerSecond).round();
                } else {
                  task.remainingSeconds = -1;
                }
              }
              lastCalcBytes = downloaded;
              lastCalcTime = now;
            }

            // 更新进度通知（内部有节流控制，约每 1.5 秒更新一次）
            _updateProgressNotification(task);

            onProgress?.call(task);
          }
        } finally {
          await raf.close();
        }

        // 如果是被取消的，抛出 cancel 异常让上层处理
        if (cancelToken.isCancelled) {
          throw DioException(
            requestOptions: response.requestOptions,
            type: DioExceptionType.cancel,
          );
        }

        // ===== 下载完成：将临时文件重命名为最终文件 =====
        final finalFile = File(task.savePath);
        // 如果最终文件已存在（可能是之前下载的），先删除
        if (await finalFile.exists()) {
          await finalFile.delete();
        }
        await tmpFile.rename(task.savePath);

        // 重置速度和剩余时间
        task.speedBytesPerSecond = 0;
        task.remainingSeconds = -1;

        _updateTaskStatus(task, DownloadStatus.completed);
        task.completedAt = DateTime.now();
        task.progress = 1.0;
        if (totalSize > 0) {
          task.totalBytes = totalSize;
        }
        _saveTask(task); // 完成时保存最终状态

        // 下载完成后通知媒体库扫描，让相册可见（仅在开启自动保存到相册且非音频时生效）
        if (autoSaveToGallery && !task.isAudioOnly) {
          await _scanMediaFile(task.savePath, isImage: _isImageFile(task.savePath), title: task.videoTitle);
        }

        // 下载完成通知（复用进度通知的 ID，实现从进度到完成的平滑过渡）
        if (downloadNotificationEnabled) {
          final notificationId = _notificationIds[task.id];
          NotificationService.instance.showDownloadComplete(
            task.videoTitle,
            task.savePath,
            id: notificationId,
          );
        }
        _cleanupNotificationState(task.id);

        // 批量计数
        _batchSuccessCount++;

        onComplete?.call(task);
        _retryCounts.remove(task.id);

        // 下载完成后触发自动清理
        if (autoCleanDownloadsEnabled) {
          // 异步执行，不阻塞当前流程
          Future.delayed(const Duration(milliseconds: 500), () {
            performAutoClean();
          });
        }

        break; // 下载成功，退出重试循环
      } on DioException catch (e) {
        // ===== 处理用户主动暂停 =====
        if (e.type == DioExceptionType.cancel && _pausedTasks.contains(task.id)) {
          _updateTaskStatus(task, DownloadStatus.paused);
          _pausedTasks.remove(task.id);
          _retryCounts.remove(task.id);
          // 暂停时取消进度通知
          if (downloadNotificationEnabled) {
            final notificationId = _notificationIds[task.id];
            if (notificationId != null) {
              NotificationService.instance.cancelNotification(notificationId);
            }
          }
          _cleanupNotificationState(task.id);
          break;
        }

        // 处理用户取消（不是暂停）
        if (e.type == DioExceptionType.cancel) {
          _updateTaskStatus(task, DownloadStatus.canceled);
          _retryCounts.remove(task.id);
          // 取消时清理进度通知
          if (downloadNotificationEnabled) {
            final notificationId = _notificationIds[task.id];
            if (notificationId != null) {
              NotificationService.instance.cancelNotification(notificationId);
            }
          }
          _cleanupNotificationState(task.id);
          break;
        }

        // ===== 判断是否应该重试 =====
        final shouldRetry = _shouldRetry(e);
        if (shouldRetry && _retryCounts[task.id]! < actualMaxRetries) {
          _retryCounts[task.id] = _retryCounts[task.id]! + 1;
          final retryNum = _retryCounts[task.id]!;
          task.retryCount = retryNum; // 更新模型中的重试次数字段
          // 指数退避等待：2s, 4s, 8s, 16s... 最大 60s
          final waitSeconds = retryNum <= 5
              ? (1 << retryNum) // 2, 4, 8, 16, 32
              : 60; // 第 6 次及以后固定 60s
          task.errorMessage = '网络波动，第 $retryNum 次重试中（等待 ${waitSeconds}s）...';
          _saveTask(task); // 重试中也保存一下
          onProgress?.call(task);

          // 等待，期间如果被取消或暂停则退出
          try {
            await Future.delayed(Duration(seconds: waitSeconds));
          } catch (_) {}

          // 检查是否被取消或暂停了
          if (cancelToken.isCancelled) {
            if (_pausedTasks.contains(task.id)) {
              _updateTaskStatus(task, DownloadStatus.paused);
              _pausedTasks.remove(task.id);
            } else {
              _updateTaskStatus(task, DownloadStatus.canceled);
            }
            // 重试等待期间取消/暂停时清理通知
            if (downloadNotificationEnabled) {
              final notificationId = _notificationIds[task.id];
              if (notificationId != null) {
                NotificationService.instance.cancelNotification(notificationId);
              }
            }
            _cleanupNotificationState(task.id);
            _retryCounts.remove(task.id);
            break;
          }
          continue; // 重试
        } else {
          // 不重试或重试次数用完
          final errorMsg = e.message ?? '下载失败';
          final finalError = _retryCounts[task.id]! > 0
              ? '$errorMsg（已重试 ${_retryCounts[task.id]} 次）'
              : errorMsg;
          _updateTaskStatus(task, DownloadStatus.failed, errorMessage: finalError);

          // 下载失败通知（复用进度通知的 ID）
          if (downloadNotificationEnabled) {
            final notificationId = _notificationIds[task.id];
            NotificationService.instance.showDownloadFailed(
              task.videoTitle,
              finalError,
              id: notificationId,
            );
          }
          _cleanupNotificationState(task.id);

          onError?.call(task, finalError);
          _retryCounts.remove(task.id);
          break;
        }
      } catch (e) {
        final errorMsg = e.toString();
        final finalError = _retryCounts[task.id]! > 0
            ? '$errorMsg（已重试 ${_retryCounts[task.id]} 次）'
            : errorMsg;
        _updateTaskStatus(task, DownloadStatus.failed, errorMessage: finalError);

        // 下载失败通知（复用进度通知的 ID）
        if (downloadNotificationEnabled) {
          final notificationId = _notificationIds[task.id];
          NotificationService.instance.showDownloadFailed(
            task.videoTitle,
            finalError,
            id: notificationId,
          );
        }
        _cleanupNotificationState(task.id);

        // 批量计数
        _batchFailCount++;

        onError?.call(task, finalError);
        _retryCounts.remove(task.id);
        break;
      } finally {
        _cancelTokens.remove(task.id);
      }
    }

    _activeDownloads.remove(task.id);
    onProgress?.call(task);
    _processQueue();

    // 检查是否所有下载都已完成（无活跃、无排队）
    _checkBatchComplete();
  }

  /// 检查批量下载是否全部完成，完成则发送批量通知
  void _checkBatchComplete() {
    if (!downloadNotificationEnabled) return;

    final hasQueued = _tasks.any((t) => t.status == DownloadStatus.queued);
    final hasActive = _activeDownloads.isNotEmpty;
    final totalBatch = _batchSuccessCount + _batchFailCount;

    // 没有排队的，没有活跃的，且本批次有完成的任务
    if (!hasQueued && !hasActive && totalBatch > 0) {
      NotificationService.instance.showBatchDownloadComplete(
        _batchSuccessCount,
        _batchFailCount,
        id: _batchNotificationId,
      );
      // 重置计数
      _batchSuccessCount = 0;
      _batchFailCount = 0;
    }
  }

  /// 判断是否应该重试
  bool _shouldRetry(DioException e) {
    // 主动取消不重试
    if (e.type == DioExceptionType.cancel) return false;

    // 连接超时、接收超时、发送超时、网络错误 → 重试
    if (e.type == DioExceptionType.connectionTimeout ||
        e.type == DioExceptionType.receiveTimeout ||
        e.type == DioExceptionType.sendTimeout ||
        e.type == DioExceptionType.connectionError ||
        e.type == DioExceptionType.badCertificate) {
      return true;
    }

    // 服务端错误（5xx）→ 重试
    final statusCode = e.response?.statusCode;
    if (statusCode != null && statusCode >= 500 && statusCode < 600) {
      return true;
    }

    // 429 Too Many Requests → 重试
    if (statusCode == 429) return true;

    // 408 Request Timeout → 重试
    if (statusCode == 408) return true;

    // 其他情况不重试（如 403、404 等客户端错误）
    return false;
  }

  void pauseTask(String taskId) {
    final task = _tasks.firstWhere((t) => t.id == taskId, orElse: () => throw '任务不存在');
    if (task.status == DownloadStatus.downloading) {
      // 标记为用户主动暂停，区分于取消
      _pausedTasks.add(taskId);
      _cancelTokens[taskId]?.cancel();
    } else if (task.status == DownloadStatus.queued) {
      // 等待中的任务直接暂停
      _updateTaskStatus(task, DownloadStatus.paused);
      onProgress?.call(task);
    }
  }

  void resumeTask(String taskId) {
    final task = _tasks.firstWhere((t) => t.id == taskId, orElse: () => throw '任务不存在');
    if (task.status == DownloadStatus.paused) {
      // 暂停任务恢复：直接回到队列，临时文件和进度一定是正确的
      task.status = DownloadStatus.queued;
      task.errorMessage = null;
      _pausedTasks.remove(taskId);
      _saveTask(task);
      onProgress?.call(task);
      _processQueue();
    } else if (task.status == DownloadStatus.failed) {
      // 失败任务重试：重置重试计数，保留临时文件断点续传
      task.status = DownloadStatus.queued;
      task.errorMessage = null;
      _retryCounts[taskId] = 0;
      // 检查临时文件状态，决定是续传还是从零开始
      final tmpFile = File('${task.savePath}.tmp');
      if (!tmpFile.existsSync()) {
        // 临时文件不存在，检查最终文件是否存在（可能之前版本下载的）
        final finalFile = File(task.savePath);
        if (finalFile.existsSync()) {
          // 最终文件存在，说明之前已下载完成，直接标记完成
          task.status = DownloadStatus.completed;
          task.progress = 1.0;
          task.receivedBytes = finalFile.lengthSync();
          task.totalBytes = finalFile.lengthSync();
        } else {
          // 都不存在，从零开始
          task.progress = 0;
          task.receivedBytes = 0;
        }
      } else {
        final fileSize = tmpFile.lengthSync();
        if (task.receivedBytes < fileSize) {
          task.receivedBytes = fileSize;
        }
      }
      _saveTask(task);
      onProgress?.call(task);
      _processQueue();
    }
  }

  void cancelTask(String taskId) {
    final task = _tasks.firstWhere((t) => t.id == taskId, orElse: () => throw '任务不存在');
    if (task.status == DownloadStatus.downloading) {
      _cancelTokens[taskId]?.cancel();
    }
    _updateTaskStatus(task, DownloadStatus.canceled);

    // 取消时清理进度通知，避免通知残留
    if (downloadNotificationEnabled) {
      final notificationId = _notificationIds[task.id];
      if (notificationId != null) {
        NotificationService.instance.cancelNotification(notificationId);
      }
    }
    _cleanupNotificationState(task.id);

    onProgress?.call(task);
  }

  void removeTask(String taskId, {bool deleteFile = false}) {
    final task = _tasks.firstWhere((t) => t.id == taskId, orElse: () => throw '任务不存在');
    if (task.status == DownloadStatus.downloading) {
      _cancelTokens[taskId]?.cancel();
    }
    _tasks.remove(task);
    _deleteTask(taskId); // 从持久化删除

    // 保存到最近删除列表，用于撤销
    _recentlyRemoved.insert(0, task);
    if (_recentlyRemoved.length > _maxRecentlyRemoved) {
      _recentlyRemoved.removeLast();
    }

    if (deleteFile) {
      // 删除最终文件
      final file = File(task.savePath);
      if (file.existsSync()) {
        file.deleteSync();
      }
      // 同时删除临时文件（如果有）
      final tmpFile = File('${task.savePath}.tmp');
      if (tmpFile.existsSync()) {
        tmpFile.deleteSync();
      }
    }
  }

  /// 撤销最后一次删除（恢复任务）
  /// 返回恢复的任务，如果没有可撤销的则返回 null
  DownloadTask? undoLastRemove() {
    if (_recentlyRemoved.isEmpty) return null;
    final task = _recentlyRemoved.removeAt(0);
    // 重新添加到任务列表
    _tasks.insert(0, task);
    _saveTask(task); // 重新保存到持久化
    // 按创建时间倒序排列
    _tasks.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return task;
  }

  void clearCompleted() {
    final toRemove = _tasks
        .where((t) =>
            t.status == DownloadStatus.completed ||
            t.status == DownloadStatus.failed ||
            t.status == DownloadStatus.canceled)
        .toList();
    _tasks.removeWhere((t) =>
        t.status == DownloadStatus.completed ||
        t.status == DownloadStatus.failed ||
        t.status == DownloadStatus.canceled);
    // 批量从持久化删除
    for (final task in toRemove) {
      _deleteTask(task.id);
    }
  }

  /// 执行自动清理已完成下载记录
  ///
  /// 根据设置的清理策略（按天数/按数量）清理超出限制的已完成任务。
  /// 如果 [autoCleanDeleteFiles] 为 true，则同时删除本地文件。
  /// 每次下载完成后自动调用。
  Future<void> performAutoClean() async {
    if (!autoCleanDownloadsEnabled) return;

    // 只清理已完成的任务
    final completedTasks = _tasks
        .where((t) => t.status == DownloadStatus.completed)
        .toList();

    if (completedTasks.isEmpty) return;

    List<DownloadTask> toRemove = [];

    if (autoCleanMode == 'days') {
      // 按保留天数清理
      final now = DateTime.now();
      final cutoffDate = now.subtract(Duration(days: autoCleanDays));

      toRemove = completedTasks.where((task) {
        final date = task.completedAt ?? task.createdAt;
        return date.isBefore(cutoffDate);
      }).toList();
    } else if (autoCleanMode == 'count') {
      // 按保留数量清理（按完成时间倒序，保留最新的 N 条）
      final sorted = List<DownloadTask>.from(completedTasks)
        ..sort((a, b) =>
            (b.completedAt ?? b.createdAt).compareTo(a.completedAt ?? a.createdAt));

      if (sorted.length > autoCleanMaxCount) {
        toRemove = sorted.sublist(autoCleanMaxCount);
      }
    }

    if (toRemove.isEmpty) return;

    // 执行清理
    for (final task in toRemove) {
      // 跳过组内的子任务（组任务一起处理）
      if (task.groupId != null) continue;

      if (autoCleanDeleteFiles) {
        // 删除记录和文件
        if (task.groupId != null) {
          removeGroup(task.groupId!, deleteFile: true);
        } else {
          removeTask(task.id, deleteFile: true);
        }
      } else {
        // 仅删除记录
        if (task.groupId != null) {
          removeGroup(task.groupId!, deleteFile: false);
        } else {
          removeTask(task.id, deleteFile: false);
        }
      }
    }
  }

  /// 根据视频 ID 列表删除相关的下载文件
  /// 
  /// [videoIds] 要删除文件的视频 ID 列表
  /// [deleteFile] 是否同时删除本地文件
  /// 返回删除的任务数量
  int removeTasksByVideoIds(List<String> videoIds, {bool deleteFile = false}) {
    final toRemove = _tasks.where((t) => videoIds.contains(t.videoId)).toList();
    if (toRemove.isEmpty) return 0;

    for (final task in toRemove) {
      if (task.status == DownloadStatus.downloading) {
        _cancelTokens[task.id]?.cancel();
      }
      _deleteTask(task.id);

      if (deleteFile) {
        try {
          final file = File(task.savePath);
          if (file.existsSync()) {
            file.deleteSync();
          }
          final tmpFile = File('${task.savePath}.tmp');
          if (tmpFile.existsSync()) {
            tmpFile.deleteSync();
          }
        } catch (_) {}
      }
    }

    _tasks.removeWhere((t) => videoIds.contains(t.videoId));
    return toRemove.length;
  }

  String _sanitizeFileName(String name) {
    // 去除 emoji 和其他特殊 Unicode 字符，只保留中英文、数字、常用符号
    final buffer = StringBuffer();
    // 允许的字符范围（正则）：中文(\u4e00-\u9fa5)、英文、数字、空白、常见中英文标点
    final allowed = RegExp(
      r'[\u4e00-\u9fa5a-zA-Z0-9\s\-_.()\[\]《》!?，,。.、；;："~@#$%^&+=]',
    );
    for (final rune in name.runes) {
      final char = String.fromCharCode(rune);
      if (allowed.hasMatch(char)) {
        buffer.write(char);
      }
    }
    var cleaned = buffer.toString();
    // 替换文件系统非法字符（Windows + Android）
    cleaned = cleaned.replaceAll(RegExp(r'[\\/:*?"<>|]'), '_');
    // 连续下划线/空格合并
    cleaned = cleaned.replaceAll(RegExp(r'[_\s]+'), '_');
    // 去除首尾下划线和点
    cleaned = cleaned.trim().replaceAll(RegExp(r'^[_.]+|[_.]+$'), '');
    // 空文件名兜底
    if (cleaned.isEmpty) {
      cleaned = 'video_${DateTime.now().millisecondsSinceEpoch}';
    }
    // 限制长度（防止路径过长）
    if (cleaned.length > 80) {
      cleaned = cleaned.substring(0, 80);
    }
    return cleaned;
  }

  /// 根据平台获取下载 Referer，解决抖音/快手 CDN 403 问题
  String? _getReferer(String? platform, String videoUrl) {
    if (platform == 'douyin' || videoUrl.contains('douyin') || videoUrl.contains('iesdouyin')) {
      return 'https://www.douyin.com/';
    }
    if (platform == 'kuaishou' || videoUrl.contains('kuaishou') || videoUrl.contains('gifshow')) {
      return 'https://www.kuaishou.com/';
    }
    return null;
  }

  /// 从 URL 中推断图片扩展名
  String _getImageExtension(String url) {
    final uri = Uri.tryParse(url);
    if (uri != null) {
      final path = uri.path.toLowerCase();
      if (path.endsWith('.jpg') || path.endsWith('.jpeg')) return 'jpg';
      if (path.endsWith('.png')) return 'png';
      if (path.endsWith('.webp')) return 'webp';
      if (path.endsWith('.gif')) return 'gif';
      if (path.endsWith('.bmp')) return 'bmp';
    }
    // 默认使用 jpg
    return 'jpg';
  }

  /// 判断文件是否为图片
  bool _isImageFile(String path) {
    final lower = path.toLowerCase();
    return lower.endsWith('.jpg') ||
        lower.endsWith('.jpeg') ||
        lower.endsWith('.png') ||
        lower.endsWith('.webp') ||
        lower.endsWith('.gif') ||
        lower.endsWith('.bmp');
  }

  static String formatSize(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    if (bytes < 1024 * 1024 * 1024) {
      return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    }
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
  }
}
