import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:dio/dio.dart';
import 'package:dio/io.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../models/custom_api_source.dart';
import 'proxy_service.dart';

/// 自定义解析源管理服务
class CustomSourceService {
  static const String _boxName = 'custom_api_sources';
  Box<CustomApiSource>? _box;
  final Dio _dio = Dio();

  /// 代理服务
  ProxyService? _proxyService;

  /// 设置代理服务
  void setProxyService(ProxyService? proxyService) {
    _proxyService?.removeListener(_onProxyChanged);
    _proxyService = proxyService;
    if (proxyService != null) {
      proxyService.applyToDio(_dio);
      proxyService.addListener(_onProxyChanged);
    } else {
      _dio.httpClientAdapter = IOHttpClientAdapter();
    }
  }

  void _onProxyChanged() {
    _proxyService?.applyToDio(_dio);
  }

  bool get isInitialized => _box != null;

  Future<void> init() async {
    if (_box != null) return;
    try {
      _box = await Hive.openBox<CustomApiSource>(_boxName);
    } catch (e) {
      try {
        await Hive.deleteBoxFromDisk(_boxName);
        _box = await Hive.openBox<CustomApiSource>(_boxName);
      } catch (_) {
        rethrow;
      }
    }
  }

  /// 获取所有自定义源（按优先级排序）
  List<CustomApiSource> getAll() {
    if (_box == null) return [];
    final list = _box!.values.toList();
    list.sort((a, b) => a.priority.compareTo(b.priority));
    return list;
  }

  /// 获取启用的自定义源
  List<CustomApiSource> getEnabled() {
    return getAll().where((s) => s.enabled).toList();
  }

  /// 根据 ID 获取
  CustomApiSource? getById(String id) {
    if (_box == null) return null;
    return _box!.get(id);
  }

  /// 添加自定义源
  Future<void> add(CustomApiSource source) async {
    if (_box == null) return;
    await _box!.put(source.id, source);
  }

  /// 更新
  Future<void> update(CustomApiSource source) async {
    if (_box == null) return;
    await _box!.put(source.id, source);
  }

  /// 删除
  Future<void> remove(String id) async {
    if (_box == null) return;
    await _box!.delete(id);
  }

  /// 清除所有自定义源
  Future<void> clear() async {
    if (_box == null) return;
    await _box!.clear();
  }

  /// 切换启用状态
  Future<void> toggleEnabled(String id) async {
    if (_box == null) return;
    final source = _box!.get(id);
    if (source == null) return;
    source.enabled = !source.enabled;
    await source.save();
  }

  /// 更新优先级（拖拽排序后调用）
  /// [orderedIds] 按新顺序排列的源 ID 列表
  Future<void> reorder(List<String> orderedIds) async {
    if (_box == null) return;
    for (int i = 0; i < orderedIds.length; i++) {
      final source = _box!.get(orderedIds[i]);
      if (source != null) {
        source.priority = i;
        await source.save();
      }
    }
  }

  /// 上移一个位置
  Future<void> moveUp(String id) async {
    final sources = getAll();
    final index = sources.indexWhere((s) => s.id == id);
    if (index <= 0) return;
    final prev = sources[index - 1];
    final current = sources[index];
    final tempPriority = current.priority;
    current.priority = prev.priority;
    prev.priority = tempPriority;
    await update(current);
    await update(prev);
  }

  /// 下移一个位置
  Future<void> moveDown(String id) async {
    final sources = getAll();
    final index = sources.indexWhere((s) => s.id == id);
    if (index < 0 || index >= sources.length - 1) return;
    final next = sources[index + 1];
    final current = sources[index];
    final tempPriority = current.priority;
    current.priority = next.priority;
    next.priority = tempPriority;
    await update(current);
    await update(next);
  }

  /// 测试源的连通性
  /// 返回 (success, message, durationMs)
  Future<(bool, String, int)> testConnection(CustomApiSource source) async {
    final stopwatch = Stopwatch()..start();
    try {
      // 用一个测试 URL 验证接口可达性
      final testUrl = source.apiUrl;
      Response response;

      final headers = <String, dynamic>{};
      if (source.headersTemplate != null && source.headersTemplate!.isNotEmpty) {
        try {
          final decoded = jsonDecode(source.headersTemplate!);
          if (decoded is Map) {
            decoded.forEach((k, v) {
              headers[k.toString()] = v.toString();
            });
          }
        } catch (_) {}
      }

      if (source.method == HttpRequestMethod.post) {
        final body = source.bodyTemplate ?? {};
        response = await _dio.post(
          testUrl,
          data: body,
          options: Options(
            headers: headers,
            receiveTimeout: const Duration(seconds: 10),
            sendTimeout: const Duration(seconds: 10),
          ),
        );
      } else {
        response = await _dio.get(
          testUrl,
          options: Options(
            headers: headers,
            receiveTimeout: const Duration(seconds: 10),
            sendTimeout: const Duration(seconds: 10),
          ),
        );
      }

      stopwatch.stop();
      final statusCode = response.statusCode ?? 0;
      final success = statusCode >= 200 && statusCode < 400;
      return (success, 'HTTP $statusCode', stopwatch.elapsedMilliseconds);
    } catch (e) {
      stopwatch.stop();
      String msg = e.toString();
      if (e is DioException) {
        if (e.response != null) {
          msg = 'HTTP ${e.response?.statusCode}';
        } else if (e.type == DioExceptionType.connectionTimeout ||
            e.type == DioExceptionType.receiveTimeout ||
            e.type == DioExceptionType.sendTimeout) {
          msg = '连接超时';
        } else if (e.type == DioExceptionType.connectionError) {
          msg = '连接失败';
        } else {
          msg = '网络错误';
        }
      }
      return (false, msg, stopwatch.elapsedMilliseconds);
    }
  }

  /// 统计信息
  int get totalCount => _box?.length ?? 0;
  int get enabledCount => getEnabled().length;

  /// 按平台获取启用的源
  List<CustomApiSource> getEnabledForPlatform(String platform) {
    return getEnabled()
        .where((s) => s.supportedPlatforms.contains(platform))
        .toList();
  }

  /// 更新源的上次使用时间
  Future<void> updateLastUsed(String id) async {
    if (_box == null) return;
    final source = _box!.get(id);
    if (source == null) return;
    source.lastUsedAt = DateTime.now();
    await source.save();
  }

  /// 导出所有自定义源为 JSON 字符串
  String exportToJson() {
    final sources = getAll();
    final list = sources.map((s) => _sourceToJson(s)).toList();
    return jsonEncode({
      'version': 1,
      'exportedAt': DateTime.now().toIso8601String(),
      'count': list.length,
      'sources': list,
    });
  }

  /// 将源转换为 JSON Map
  Map<String, dynamic> _sourceToJson(CustomApiSource source) {
    return {
      'id': source.id,
      'name': source.name,
      'apiUrl': source.apiUrl,
      'method': source.method.name,
      'headersTemplate': source.headersTemplate,
      'bodyTemplate': source.bodyTemplate,
      'priority': source.priority,
      'weight': source.weight,
      'supportedPlatforms': source.supportedPlatforms,
      'enabled': source.enabled,
      'apiKeyParam': source.apiKeyParam,
      'apiKey': source.apiKey,
      'responsePath': source.responsePath,
      'remark': source.remark,
      'createdAt': source.createdAt.toIso8601String(),
      'isBuiltIn': source.isBuiltIn,
      'lastUsedAt': source.lastUsedAt?.toIso8601String(),
    };
  }

  /// 从 JSON 字符串导入自定义源
  /// 
  /// 返回导入的源数量
  Future<int> importFromJson(String jsonStr) async {
    if (_box == null) return 0;
    try {
      final decoded = jsonDecode(jsonStr);
      if (decoded is! Map) return 0;

      final sourcesData = decoded['sources'];
      if (sourcesData is! List) return 0;

      int imported = 0;
      for (final sourceData in sourcesData) {
        if (sourceData is! Map) continue;
        final source = _jsonToSource(sourceData);
        if (source != null) {
          // 避免 ID 冲突，如果已存在则生成新 ID
          if (_box!.containsKey(source.id)) {
            final newSource = source.copyWith(
              id: 'custom_${DateTime.now().millisecondsSinceEpoch}_$imported',
            );
            await _box!.put(newSource.id, newSource);
          } else {
            await _box!.put(source.id, source);
          }
          imported++;
        }
      }
      return imported;
    } catch (e) {
      debugPrint('导入自定义源失败: $e');
      return 0;
    }
  }

  /// 从 JSON Map 转换为 CustomApiSource
  CustomApiSource? _jsonToSource(Map json) {
    try {
      final methodStr = json['method'] as String? ?? 'get';
      final method = HttpRequestMethod.values.firstWhere(
        (m) => m.name == methodStr,
        orElse: () => HttpRequestMethod.get,
      );
      return CustomApiSource(
        id: json['id'] as String? ?? 'custom_${DateTime.now().millisecondsSinceEpoch}',
        name: json['name'] as String,
        apiUrl: json['apiUrl'] as String,
        method: method,
        headersTemplate: json['headersTemplate'] as String?,
        bodyTemplate: json['bodyTemplate'] as String?,
        priority: json['priority'] as int? ?? 100,
        weight: json['weight'] as int? ?? 1,
        supportedPlatforms: (json['supportedPlatforms'] as List?)?.cast<String>() ?? ['douyin', 'kuaishou'],
        enabled: json['enabled'] as bool? ?? true,
        apiKeyParam: json['apiKeyParam'] as String?,
        apiKey: json['apiKey'] as String?,
        responsePath: json['responsePath'] as String?,
        remark: json['remark'] as String?,
        createdAt: json['createdAt'] != null
            ? DateTime.parse(json['createdAt'] as String)
            : DateTime.now(),
        isBuiltIn: json['isBuiltIn'] as bool? ?? false,
        lastUsedAt: json['lastUsedAt'] != null
            ? DateTime.parse(json['lastUsedAt'] as String)
            : null,
      );
    } catch (e) {
      debugPrint('解析源 JSON 失败: $e');
      return null;
    }
  }
}
