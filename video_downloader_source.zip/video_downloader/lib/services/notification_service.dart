import 'dart:io';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:permission_handler/permission_handler.dart';

/// 通知服务
///
/// 管理下载相关的本地通知
class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  /// 获取单例实例
  static NotificationService get instance => _instance;

  final FlutterLocalNotificationsPlugin _notifications =
      FlutterLocalNotificationsPlugin();

  static const String _channelId = 'download_channel';
  static const String _channelName = '下载通知';
  static const String _channelDescription = '视频下载进度和完成通知';

  /// 通知 ID 计数器，用于生成唯一的进度通知 ID
  int _notificationIdCounter = 0;

  /// 是否已初始化
  bool _initialized = false;

  /// 用户是否已授予通知权限
  bool _hasPermission = false;
  bool get hasPermission => _hasPermission;

  /// 初始化通知服务
  Future<void> init() async {
    if (_initialized) return;

    // Android 初始化设置
    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');

    // iOS/macOS 初始化设置
    const darwinSettings = DarwinInitializationSettings(
      requestAlertPermission: false, // 改为不自动请求，统一在 requestPermission 中处理
      requestBadgePermission: false,
      requestSoundPermission: false,
    );

    const initSettings = InitializationSettings(
      android: androidSettings,
      iOS: darwinSettings,
      macOS: darwinSettings,
    );

    await _notifications.initialize(initSettings);

    // 创建 Android 通知渠道
    await _createNotificationChannel();

    // 检查当前权限状态
    _hasPermission = await _checkPermission();

    _initialized = true;
  }

  /// 检查通知权限状态
  Future<bool> _checkPermission() async {
    // 统一使用 permission_handler 检查通知权限
    final status = await Permission.notification.status;
    return status.isGranted;
  }

  /// 请求通知权限
  ///
  /// Android 13+（API 33）需要运行时申请 POST_NOTIFICATIONS 权限
  /// iOS 需要用户授权通知
  ///
  /// 返回 true 表示已授权，false 表示未授权
  Future<bool> requestPermission() async {
    if (_hasPermission) return true;

    // 统一使用 permission_handler 请求通知权限
    final status = await Permission.notification.request();
    _hasPermission = status.isGranted;
    return _hasPermission;
  }

  /// 创建下载通知渠道（Android 8.0+ 需要）
  Future<void> _createNotificationChannel() async {
    const channel = AndroidNotificationChannel(
      _channelId,
      _channelName,
      description: _channelDescription,
      importance: Importance.high,
      showBadge: true,
    );

    await _notifications
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);
  }

  /// 显示下载完成通知
  ///
  /// [id] 可选的通知 ID，用于复用同一个通知（如从进度通知更新为完成通知）。
  /// 若不提供则自动生成新 ID。
  Future<void> showDownloadComplete(String title, String filePath, {int? id}) async {
    if (!_hasPermission) return;

    const androidDetails = AndroidNotificationDetails(
      _channelId,
      _channelName,
      channelDescription: _channelDescription,
      importance: Importance.high,
      priority: Priority.high,
      icon: '@mipmap/ic_launcher',
      showProgress: false,
      autoCancel: true,
    );

    const darwinDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    const notificationDetails = NotificationDetails(
      android: androidDetails,
      iOS: darwinDetails,
      macOS: darwinDetails,
    );

    await _notifications.show(
      id ?? _generateId(),
      '下载完成',
      title,
      notificationDetails,
      payload: filePath,
    );
  }

  /// 显示下载失败通知
  ///
  /// [id] 可选的通知 ID，用于复用同一个通知（如从进度通知更新为失败通知）。
  /// 若不提供则自动生成新 ID。
  Future<void> showDownloadFailed(String title, String error, {int? id}) async {
    if (!_hasPermission) return;

    const androidDetails = AndroidNotificationDetails(
      _channelId,
      _channelName,
      channelDescription: _channelDescription,
      importance: Importance.high,
      priority: Priority.high,
      icon: '@mipmap/ic_launcher',
      showProgress: false,
      autoCancel: true,
    );

    const darwinDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    const notificationDetails = NotificationDetails(
      android: androidDetails,
      iOS: darwinDetails,
      macOS: darwinDetails,
    );

    await _notifications.show(
      id ?? _generateId(),
      '下载失败',
      '$title - $error',
      notificationDetails,
    );
  }

  /// 显示下载进度通知
  ///
  /// [id] 通知 ID，用于更新同一个通知
  /// [title] 视频标题
  /// [progress] 进度百分比（0-100）
  Future<void> showDownloadProgress(int id, String title, int progress) async {
    if (!_hasPermission) return;

    final androidDetails = AndroidNotificationDetails(
      _channelId,
      _channelName,
      channelDescription: _channelDescription,
      importance: Importance.low,
      priority: Priority.low,
      icon: '@mipmap/ic_launcher',
      showProgress: true,
      progress: progress,
      maxProgress: 100,
      indeterminate: false,
      ongoing: true,
      showWhen: false,
      autoCancel: false,
    );

    const darwinDetails = DarwinNotificationDetails(
      presentAlert: false,
      presentBadge: false,
      presentSound: false,
    );

    final notificationDetails = NotificationDetails(
      android: androidDetails,
      iOS: darwinDetails,
      macOS: darwinDetails,
    );

    await _notifications.show(
      id,
      '下载中 - ${progress}%',
      title,
      notificationDetails,
    );
  }

  /// 更新下载进度通知（带速度信息）
  ///
  /// 同一个下载任务使用相同的 [id] 来更新通知，避免创建多个通知。
  /// 通知显示进度条、下载速度和百分比。
  ///
  /// [id] 通知 ID，用于更新同一个通知
  /// [title] 视频标题
  /// [progress] 进度百分比（0-100）
  /// [speedBytesPerSecond] 下载速度（字节/秒）
  Future<void> updateDownloadProgress(
    int id,
    String title,
    int progress,
    int speedBytesPerSecond,
  ) async {
    if (!_hasPermission) return;

    // 格式化速度文本
    final speedText = _formatSpeed(speedBytesPerSecond);

    final androidDetails = AndroidNotificationDetails(
      _channelId,
      _channelName,
      channelDescription: _channelDescription,
      importance: Importance.low,
      priority: Priority.low,
      icon: '@mipmap/ic_launcher',
      showProgress: true,
      progress: progress,
      maxProgress: 100,
      indeterminate: false,
      ongoing: true,
      showWhen: false,
      autoCancel: false,
    );

    const darwinDetails = DarwinNotificationDetails(
      presentAlert: false,
      presentBadge: false,
      presentSound: false,
    );

    final notificationDetails = NotificationDetails(
      android: androidDetails,
      iOS: darwinDetails,
      macOS: darwinDetails,
    );

    await _notifications.show(
      id,
      '下载中 $progress% · $speedText',
      title,
      notificationDetails,
    );
  }

  /// 格式化下载速度为可读字符串
  String _formatSpeed(int bytesPerSecond) {
    if (bytesPerSecond <= 0) return '计算中...';
    if (bytesPerSecond < 1024) return '$bytesPerSecond B/s';
    if (bytesPerSecond < 1024 * 1024) {
      return '${(bytesPerSecond / 1024).toStringAsFixed(1)} KB/s';
    }
    return '${(bytesPerSecond / (1024 * 1024)).toStringAsFixed(1)} MB/s';
  }

  /// 取消指定 ID 的通知
  Future<void> cancelNotification(int id) async {
    await _notifications.cancel(id);
  }

  /// 取消所有通知
  Future<void> cancelAll() async {
    await _notifications.cancelAll();
  }

  /// 显示批量下载完成通知
  ///
  /// 当一批下载任务全部完成时调用，显示成功和失败的数量。
  /// [successCount] 成功数量
  /// [failCount] 失败数量
  /// [id] 可选的通知 ID，用于复用同一个通知
  Future<void> showBatchDownloadComplete(int successCount, int failCount, {int? id}) async {
    if (!_hasPermission) return;

    final total = successCount + failCount;
    final allSuccess = failCount == 0;
    final title = allSuccess ? '下载全部完成' : '下载完成（部分失败）';
    final body = allSuccess
        ? '成功下载 $successCount 个视频'
        : '成功 $successCount 个，失败 $failCount 个，共 $total 个';

    const androidDetails = AndroidNotificationDetails(
      _channelId,
      _channelName,
      channelDescription: _channelDescription,
      importance: Importance.high,
      priority: Priority.high,
      icon: '@mipmap/ic_launcher',
      showProgress: false,
      autoCancel: true,
    );

    const darwinDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    const notificationDetails = NotificationDetails(
      android: androidDetails,
      iOS: darwinDetails,
      macOS: darwinDetails,
    );

    await _notifications.show(
      id ?? _generateId(),
      title,
      body,
      notificationDetails,
    );
  }

  /// 生成唯一的通知 ID
  int _generateId() {
    _notificationIdCounter++;
    return _notificationIdCounter;
  }
}
