import 'dart:async';
import 'package:dio/dio.dart';
import '../models/api_source.dart';
import '../models/custom_api_source.dart';
import '../models/video_info.dart';
import '../utils/platform_detector.dart';
import '../utils/retry_helper.dart';
import 'parser/base_parser.dart';
import 'parser/custom_api_parser.dart';
import 'parser/douyin_parser.dart';
import 'parser/kuaishou_parser.dart';
import 'parser/xiaohongshu_parser.dart';
import 'proxy_service.dart';

/// 解析结果回调（用于统计记录）
typedef ParseResultCallback = void Function(
  String sourceId,
  String sourceName,
  bool success,
  int durationMs,
  String? errorMessage,
);

/// 单个解析源的尝试结果
class ParseAttempt {
  final String sourceId;
  final String sourceName;
  final Duration duration;
  final bool success;
  final String? errorMessage;

  ParseAttempt({
    required this.sourceId,
    required this.sourceName,
    required this.duration,
    required this.success,
    this.errorMessage,
  });
}

/// 带路由信息的解析结果
class RoutedParseResult {
  final VideoInfo videoInfo;
  final String sourceId;
  final String sourceName;
  final int attemptCount;
  final Duration totalDuration;
  final List<ParseAttempt> attempts;

  RoutedParseResult({
    required this.videoInfo,
    required this.sourceId,
    required this.sourceName,
    required this.attemptCount,
    required this.totalDuration,
    required this.attempts,
  });
}

/// 解析源配置（运行时使用）
class _RuntimeSource {
  final String id;
  final String name;
  final int priority;
  final bool enabled;
  final BaseParser parser;
  final List<String> supportedPlatforms;

  _RuntimeSource({
    required this.id,
    required this.name,
    required this.priority,
    required this.enabled,
    required this.parser,
    required this.supportedPlatforms,
  });
}

/// 多源智能解析路由器
///
/// 特性：
/// - 每个平台按优先级配置多个解析源
/// - 一个源失败时自动 fallback 到下一个源
/// - 支持回调通知当前尝试的源
/// - 内置解析器优先，其次是配置好的 API 源，最后是自定义 API
class ParserRouter {
  final DouyinParser _douyinParser = DouyinParser();
  final KuaishouParser _kuaishouParser = KuaishouParser();
  final XiaohongshuParser _xiaohongshuParser = XiaohongshuParser();

  /// 当前选中的主源 ID
  String _primarySourceId = 'builtIn';

  /// 自定义 API 解析器
  CustomApiParser? _customParser;

  /// 自定义源的配置
  ApiSource? _customSource;
  String? _customApiKey;

  /// 抖音 Cookie
  Map<String, String>? _douyinCookies;

  /// 代理服务
  ProxyService? _proxyService;

  /// 设置代理服务并应用到所有解析器
  void setProxyService(ProxyService? proxyService) {
    _proxyService = proxyService;
    if (proxyService != null) {
      // 应用到内置解析器
      _douyinParser.applyProxy(proxyService);
      _kuaishouParser.applyProxy(proxyService);
      _xiaohongshuParser.applyProxy(proxyService);
      // 应用到自定义解析器
      final customParser = _customParser;
      if (customParser != null) {
        customParser.applyProxy(proxyService);
      }
    }
  }

  /// 重试配置
  RetryConfig _retryConfig = RetryConfig.standard;

  /// 用户自定义解析源列表
  List<CustomApiSource> _customSources = [];

  /// 解析结果回调（用于统计）
  ParseResultCallback? onParseResult;

  String get primarySourceId => _primarySourceId;

  /// 设置自定义解析源列表
  void setCustomSources(List<CustomApiSource> sources) {
    _customSources = sources.where((s) => s.enabled).toList()
      ..sort((a, b) => a.priority.compareTo(b.priority));
  }

  /// 设置重试配置
  void setRetryConfig(RetryConfig config) {
    _retryConfig = config;
  }

  /// 设置主解析源
  void setPrimarySource(
    ApiSource source, {
    String? apiKey,
    String? customUrl,
  }) {
    _primarySourceId = source.id;

    if (source.id == 'custom') {
      final url = customUrl ?? source.apiUrl;
      if (url != null && url.isNotEmpty) {
        _customSource = source;
        _customApiKey = apiKey;
        _customParser = _createCustomApiParser(
          url,
          apiKeyParam: source.apiKeyParam,
          apiKey: apiKey,
        );
      } else {
        _customSource = null;
        _customParser = null;
      }
    } else if (!source.isBuiltIn) {
      _customSource = source;
      _customApiKey = apiKey;
      _customParser = _createCustomApiParser(
        source.apiUrl!,
        apiKeyParam: source.apiKeyParam,
        apiKey: apiKey,
      );
    } else {
      _customSource = null;
      _customParser = null;
    }
  }

  /// 设置抖音 Cookie
  void setDouyinCookies(Map<String, String>? cookies) {
    _douyinCookies = cookies;
    _douyinParser.setCookies(cookies);
  }

  /// 更新 API Key
  void updateApiKey(String? key) {
    _customApiKey = key;
    if (_customSource != null && _customParser != null) {
      _customParser = _createCustomApiParser(
        _customSource!.apiUrl!,
        apiKeyParam: _customSource!.apiKeyParam,
        apiKey: key,
      );
    }
  }

  /// 获取指定平台的解析源列表（按优先级排序）
  ///
  /// 优先级规则：
  /// 1. 用户选中的主源（如果支持该平台）
  /// 2. 内置解析器
  /// 3. 其他已配置的 API 源
  /// 4. 自定义 API（如果配置了且支持该平台）
  List<_RuntimeSource> _getSourcesForPlatform(VideoPlatform platform) {
    final platformId = platform.id;
    final sources = <_RuntimeSource>[];
    final addedIds = <String>{};

    void addSource(_RuntimeSource source) {
      if (addedIds.contains(source.id)) return;
      if (!source.supportedPlatforms.contains(platformId)) return;
      sources.add(source);
      addedIds.add(source.id);
    }

    // 1. 如果主源是 API 源且支持该平台，放第一位
    final primarySource = ApiSource.fromId(_primarySourceId);
    if (primarySource != null && !primarySource.isBuiltIn) {
      final parser = _buildParserForSource(primarySource);
      if (parser != null) {
        addSource(_RuntimeSource(
          id: primarySource.id,
          name: primarySource.name,
          priority: 1,
          enabled: true,
          parser: parser,
          supportedPlatforms: primarySource.supportedPlatforms,
        ));
      }
    }

    // 2. 内置解析器（始终作为可靠备选）
    final builtInParser = _getBuiltInParser(platform);
    if (builtInParser != null) {
      addSource(_RuntimeSource(
        id: 'builtIn_$platformId',
        name: '${platform.name}内置',
        priority: 2,
        enabled: true,
        parser: builtInParser,
        supportedPlatforms: [platformId],
      ));
    }

    // 3. 其他预设 API 源（跳过主源，已在第一位）
    for (final source in ApiSource.presets) {
      if (source.isBuiltIn) continue;
      if (source.id == _primarySourceId) continue;
      if (source.id == 'custom') continue;
      if (!source.supportedPlatforms.contains(platformId)) continue;

      // 只有配置了 API Key 或者不需要 Key 的源才加入
      final hasKey = _customApiKey != null && _customApiKey!.isNotEmpty;
      if (source.apiKeyRequired && !hasKey) continue;

      final parser = _createCustomApiParser(
        source.apiUrl!,
        apiKeyParam: source.apiKeyParam,
        apiKey: source.apiKeyRequired ? _customApiKey : null,
      );
      addSource(_RuntimeSource(
        id: source.id,
        name: source.name,
        priority: 3,
        enabled: true,
        parser: parser,
        supportedPlatforms: source.supportedPlatforms,
      ));
    }

    // 4. 用户自定义解析源（按优先级排序，插入到预设 API 源之后）
    for (final customSrc in _customSources) {
      if (!customSrc.supportedPlatforms.contains(platformId)) continue;
      if (customSrc.apiUrl.isEmpty) continue;

      final parser = _createCustomApiParser(
        customSrc.apiUrl,
        apiKeyParam: customSrc.apiKeyParam,
        apiKey: customSrc.apiKey,
      );
      addSource(_RuntimeSource(
        id: customSrc.id,
        name: customSrc.name,
        priority: 100 + customSrc.priority,
        enabled: customSrc.enabled,
        parser: parser,
        supportedPlatforms: customSrc.supportedPlatforms,
      ));
    }

    // 5. 旧版自定义 API 源（如果配置了且不是主源）
    if (_customParser != null &&
        _primarySourceId != 'custom' &&
        _customSource?.supportedPlatforms.contains(platformId) == true) {
      addSource(_RuntimeSource(
        id: 'custom',
        name: '自定义API',
        priority: 200,
        enabled: true,
        parser: _customParser!,
        supportedPlatforms: _customSource!.supportedPlatforms,
      ));
    }

    return sources;
  }

  /// 获取平台对应的内置解析器
  BaseParser? _getBuiltInParser(VideoPlatform platform) {
    switch (platform) {
      case VideoPlatform.douyin:
        return _douyinParser;
      case VideoPlatform.kuaishou:
        return _kuaishouParser;
      case VideoPlatform.xiaohongshu:
        return _xiaohongshuParser;
      case VideoPlatform.unknown:
        return null;
    }
  }

  /// 根据 ApiSource 构建解析器
  BaseParser? _buildParserForSource(ApiSource source) {
    if (source.isBuiltIn) return null;
    if (source.apiUrl == null || source.apiUrl!.isEmpty) return null;

    String? key;
    if (source.apiKeyRequired) {
      key = _customApiKey;
    }

    return _createCustomApiParser(
      source.apiUrl!,
      apiKeyParam: source.apiKeyParam,
      apiKey: key,
    );
  }

  /// 创建 CustomApiParser 并应用代理配置
  CustomApiParser _createCustomApiParser(
    String url, {
    String? apiKeyParam,
    String? apiKey,
  }) {
    final parser = CustomApiParser(
      url,
      apiKeyParam: apiKeyParam,
      apiKey: apiKey,
    );
    if (_proxyService != null) {
      parser.applyProxy(_proxyService!);
    }
    return parser;
  }

  /// 带 fallback 的智能解析
  ///
  /// [onSourceTry] 每次尝试新源时的回调
  Future<RoutedParseResult> parseWithFallback(
    String url, {
    VideoPlatform? platform,
    void Function(int current, int total, String sourceName)? onSourceTry,
  }) async {
    final cleanUrl = PlatformDetector.normalizeUrl(url) ?? url.trim();
    final targetPlatform = platform ?? PlatformDetector.detectPlatform(cleanUrl);

    if (targetPlatform == VideoPlatform.unknown) {
      throw _ParseRouterException(
        '无法识别平台',
        type: ParseErrorType.unsupportedPlatform,
      );
    }

    final sources = _getSourcesForPlatform(targetPlatform);
    if (sources.isEmpty) {
      throw _ParseRouterException(
        '该平台暂无可用解析源',
        type: ParseErrorType.unsupportedPlatform,
      );
    }

    final stopwatch = Stopwatch()..start();
    final attempts = <ParseAttempt>[];
    String? lastError;
    ParseErrorType lastErrorType = ParseErrorType.parseFailed;

    for (int i = 0; i < sources.length; i++) {
      final source = sources[i];
      onSourceTry?.call(i + 1, sources.length, source.name);

      final attemptStopwatch = Stopwatch()..start();
      try {
        // 使用重试机制：单个源内自动重试
        final result = await RetryHelper.execute(
          () => source.parser.parse(cleanUrl),
          config: _retryConfig,
          shouldRetry: (e) {
            // 内容不可见类错误不重试（换源也没用）
            if (e is ParseException && e.type == ParseErrorType.contentUnavailable) {
              return false;
            }
            // 网络错误类才重试
            return RetryHelper.isNetworkError(e);
          },
        );

        // 确保 platform 字段正确
        final updatedResult = result.copyWith(
          platform: targetPlatform.id,
          url: cleanUrl,
        );

        attemptStopwatch.stop();
        stopwatch.stop();

        attempts.add(ParseAttempt(
          sourceId: source.id,
          sourceName: source.name,
          duration: attemptStopwatch.elapsed,
          success: true,
        ));

        // 记录统计
        onParseResult?.call(
          source.id,
          source.name,
          true,
          attemptStopwatch.elapsedMilliseconds,
          null,
        );

        return RoutedParseResult(
          videoInfo: updatedResult,
          sourceId: source.id,
          sourceName: source.name,
          attemptCount: i + 1,
          totalDuration: stopwatch.elapsed,
          attempts: attempts,
        );
      } catch (e) {
        attemptStopwatch.stop();
        final errorMsg = e.toString().replaceAll('ParseException: ', '').replaceAll('Exception: ', '');
        lastError = errorMsg;

        if (e is ParseException) {
          lastErrorType = e.type;
        } else if (e is DioException) {
          lastErrorType = ParseErrorType.networkError;
        }

        attempts.add(ParseAttempt(
          sourceId: source.id,
          sourceName: source.name,
          duration: attemptStopwatch.elapsed,
          success: false,
          errorMessage: errorMsg,
        ));

        // 记录统计
        onParseResult?.call(
          source.id,
          source.name,
          false,
          attemptStopwatch.elapsedMilliseconds,
          errorMsg,
        );

        // 内容不可见类错误，不继续尝试（换源也没用）
        if (lastErrorType == ParseErrorType.contentUnavailable) {
          break;
        }

        // 继续尝试下一个源
      }
    }

    stopwatch.stop();

    final platformName = targetPlatform.name;
    final errorMsg = lastError ?? '未知错误';
    final sourceCount = sources.length;

    throw _ParseRouterException(
      '$platformName视频解析失败：$errorMsg\n\n'
      '已尝试 $sourceCount 个解析源均失败。\n'
      '提示：可前往「设置 → 解析设置 → 解析API源」配置更多API源。',
      type: lastErrorType,
      attempts: attempts,
    );
  }
}

/// 路由解析异常（包含尝试历史）
class _ParseRouterException implements Exception {
  final String message;
  final ParseErrorType type;
  final List<ParseAttempt>? attempts;

  _ParseRouterException(
    this.message, {
    this.type = ParseErrorType.parseFailed,
    this.attempts,
  });

  @override
  String toString() => 'ParseRouterException: $message';
}
