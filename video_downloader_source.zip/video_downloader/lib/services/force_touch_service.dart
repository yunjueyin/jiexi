import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/haptic_service.dart';

/// 重压菜单的内容类型
enum ForceTouchContentType {
  /// 视频内容
  video,

  /// 作者/用户内容
  author,

  /// 图文内容
  imageText,

  /// 下载任务
  download,

  /// 通用内容
  generic,
}

/// 重压菜单项
class ForceTouchMenuItem {
  /// 标题
  final String title;

  /// 图标
  final IconData icon;

  /// 图标颜色
  final Color? iconColor;

  /// 是否为危险操作（红色文字）
  final bool isDestructive;

  /// 点击回调
  final VoidCallback onTap;

  const ForceTouchMenuItem({
    required this.title,
    required this.icon,
    this.iconColor,
    this.isDestructive = false,
    required this.onTap,
  });
}

/// 重压检测服务
///
/// 提供长按 + 压力变化检测（如果设备支持），
/// 不支持压力传感的设备用"长按+持续按压"模拟。
///
/// 使用方式：
/// ```dart
/// ForceTouchDetector(
///   contentType: ForceTouchContentType.video,
///   onForcePress: (details) {
///     // 重压触发，显示菜单
///   },
///   child: YourWidget(),
/// )
/// ```
class ForceTouchService {
  static bool _enabled = true;
  static double _pressureThreshold = 0.7;
  static Duration _longPressDuration = const Duration(milliseconds: 600);

  /// 初始化服务设置
  static void init({
    bool enabled = true,
    double pressureThreshold = 0.7,
    Duration longPressDuration = const Duration(milliseconds: 600),
  }) {
    _enabled = enabled;
    _pressureThreshold = pressureThreshold;
    _longPressDuration = longPressDuration;
  }

  /// 更新开关
  static void setEnabled(bool enabled) {
    _enabled = enabled;
  }

  static bool get enabled => _enabled;
  static double get pressureThreshold => _pressureThreshold;
  static Duration get longPressDuration => _longPressDuration;

  /// 触发重压反馈（震动 + 声音）
  static void triggerFeedback() {
    HapticService.heavyImpact();
    SystemSound.play(SystemSoundType.click);
  }

  /// 触发轻量反馈
  static void triggerLightFeedback() {
    HapticService.lightImpact();
  }
}

/// 重压检测组件
///
/// 包裹子组件，检测长按和压力变化，达到阈值后触发回调。
/// 支持压力传感设备的真实压力检测，不支持的设备用长按模拟。
class ForceTouchDetector extends StatefulWidget {
  /// 子组件
  final Widget child;

  /// 内容类型（决定菜单选项）
  final ForceTouchContentType contentType;

  /// 重压开始触发（达到阈值时）
  final VoidCallback? onForceStart;

  /// 重压结束（手指抬起）
  final VoidCallback? onForceEnd;

  /// 按下时的 scale 动画最小值
  final double minScale;

  /// 长按回调（不支持压力时用长按模拟）
  final VoidCallback? onLongPress;

  /// 普通点击回调
  final VoidCallback? onTap;

  /// 普通双击回调
  final VoidCallback? onDoubleTap;

  const ForceTouchDetector({
    super.key,
    required this.child,
    this.contentType = ForceTouchContentType.generic,
    this.onForceStart,
    this.onForceEnd,
    this.minScale = 0.96,
    this.onLongPress,
    this.onTap,
    this.onDoubleTap,
  });

  @override
  State<ForceTouchDetector> createState() => _ForceTouchDetectorState();
}

class _ForceTouchDetectorState extends State<ForceTouchDetector>
    with SingleTickerProviderStateMixin {
  // 缩放动画
  late AnimationController _scaleController;
  late Animation<double> _scaleAnimation;

  // 长按计时器
  Timer? _longPressTimer;
  bool _forceTriggered = false;
  bool _isPressed = false;

  // 压力跟踪
  double _currentPressure = 0.0;
  bool _hasPressureData = false;

  @override
  void initState() {
    super.initState();
    _scaleController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 150),
    );
    _scaleAnimation = Tween<double>(
      begin: 1.0,
      end: widget.minScale,
    ).animate(CurvedAnimation(
      parent: _scaleController,
      curve: Curves.easeOut,
    ));
  }

  @override
  void dispose() {
    _longPressTimer?.cancel();
    _scaleController.dispose();
    super.dispose();
  }

  /// 开始长按计时
  void _startLongPressTimer() {
    _longPressTimer?.cancel();
    _longPressTimer = Timer(ForceTouchService.longPressDuration, () {
      if (_isPressed && !_forceTriggered) {
        _triggerForcePress();
      }
    });
  }

  /// 取消长按计时
  void _cancelLongPressTimer() {
    _longPressTimer?.cancel();
    _longPressTimer = null;
  }

  /// 触发重压效果
  void _triggerForcePress() {
    if (_forceTriggered) return;
    _forceTriggered = true;
    ForceTouchService.triggerFeedback();

    // 播放压缩动画
    _scaleController.forward();

    // 延迟一点后弹出菜单
    Future.delayed(const Duration(milliseconds: 100), () {
      if (mounted && _isPressed) {
        widget.onForceStart?.call();
      }
    });
  }

  /// 处理指针按下
  void _handlePointerDown(PointerDownEvent event) {
    if (!ForceTouchService.enabled) return;

    _isPressed = true;
    _forceTriggered = false;
    _currentPressure = event.pressure;
    _hasPressureData = event.pressureMin < event.pressureMax;

    // 如果支持压力传感，使用压力检测
    if (_hasPressureData && event.pressure > 0) {
      _checkPressure(event.pressure, event.pressureMax);
    } else {
      // 不支持压力传感，用长按模拟
      _startLongPressTimer();
    }
  }

  /// 处理指针移动
  void _handlePointerMove(PointerMoveEvent event) {
    if (!ForceTouchService.enabled) return;
    if (_forceTriggered) return;

    _currentPressure = event.pressure;

    if (_hasPressureData && event.pressureMax > 0) {
      _checkPressure(event.pressure, event.pressureMax);
    }
  }

  /// 检查压力是否达到阈值
  void _checkPressure(double pressure, double pressureMax) {
    final normalizedPressure = pressureMax > 0 ? pressure / pressureMax : 0;

    // 根据压力程度应用缩放
    if (normalizedPressure > 0.3) {
      final scaleProgress =
          ((normalizedPressure - 0.3) / 0.4).clamp(0.0, 1.0);
      final targetScale = 1.0 - (1.0 - widget.minScale) * scaleProgress * 0.5;
      _scaleController.value = (1.0 - targetScale) / (1.0 - widget.minScale);
    }

    // 达到阈值触发
    if (normalizedPressure >= ForceTouchService.pressureThreshold) {
      _triggerForcePress();
    }
  }

  /// 处理指针抬起
  void _handlePointerUp(PointerUpEvent event) {
    _isPressed = false;
    _cancelLongPressTimer();

    if (_forceTriggered) {
      widget.onForceEnd?.call();
    }

    // 恢复缩放
    _scaleController.reverse();
    _forceTriggered = false;
    _currentPressure = 0.0;
  }

  /// 处理指针取消
  void _handlePointerCancel(PointerCancelEvent event) {
    _isPressed = false;
    _cancelLongPressTimer();
    _scaleController.reverse();
    _forceTriggered = false;
    _currentPressure = 0.0;
  }

  @override
  Widget build(BuildContext context) {
    return Listener(
      onPointerDown: _handlePointerDown,
      onPointerMove: _handlePointerMove,
      onPointerUp: _handlePointerUp,
      onPointerCancel: _handlePointerCancel,
      child: GestureDetector(
        onTap: widget.onTap,
        onDoubleTap: widget.onDoubleTap,
        onLongPress: widget.onLongPress ??
            (ForceTouchService.enabled ? null : null),
        child: AnimatedBuilder(
          animation: _scaleAnimation,
          builder: (context, child) {
            return Transform.scale(
              scale: _scaleAnimation.value,
              child: child,
            );
          },
          child: widget.child,
        ),
      ),
    );
  }
}

/// 重压快捷菜单对话框
///
/// 带有缩放 + 弹性弹入动画的快捷菜单
class ForceTouchMenu extends StatefulWidget {
  /// 菜单项列表
  final List<ForceTouchMenuItem> items;

  /// 菜单触发位置（全局坐标）
  final Offset triggerPosition;

  /// 内容类型（用于显示图标）
  final ForceTouchContentType contentType;

  /// 标题（可选）
  final String? title;

  /// 副标题（可选）
  final String? subtitle;

  const ForceTouchMenu({
    super.key,
    required this.items,
    required this.triggerPosition,
    this.contentType = ForceTouchContentType.generic,
    this.title,
    this.subtitle,
  });

  /// 显示重压菜单
  static Future<T?> show<T>({
    required BuildContext context,
    required List<ForceTouchMenuItem> items,
    required Offset triggerPosition,
    ForceTouchContentType contentType = ForceTouchContentType.generic,
    String? title,
    String? subtitle,
  }) {
    return showGeneralDialog<T>(
      context: context,
      barrierDismissible: true,
      barrierLabel: MaterialLocalizations.of(context).modalBarrierDismissLabel,
      barrierColor: Colors.black.withOpacity(0.3),
      transitionDuration: const Duration(milliseconds: 300),
      pageBuilder: (context, animation, secondaryAnimation) {
        return ForceTouchMenu(
          items: items,
          triggerPosition: triggerPosition,
          contentType: contentType,
          title: title,
          subtitle: subtitle,
        );
      },
      transitionBuilder: (context, animation, secondaryAnimation, child) {
        return child;
      },
    );
  }

  @override
  State<ForceTouchMenu> createState() => _ForceTouchMenuState();
}

class _ForceTouchMenuState extends State<ForceTouchMenu>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 350),
    );

    // 弹性缩放动画
    _scaleAnimation = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const ElasticOutCurve(0.8),
      ),
    );

    // 淡入动画
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.0, 0.3, curve: Curves.easeOut),
      ),
    );

    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  /// 获取内容类型对应的图标
  IconData get _contentTypeIcon {
    switch (widget.contentType) {
      case ForceTouchContentType.video:
        return Icons.play_circle_filled;
      case ForceTouchContentType.author:
        return Icons.person;
      case ForceTouchContentType.imageText:
        return Icons.image;
      case ForceTouchContentType.download:
        return Icons.download;
      case ForceTouchContentType.generic:
        return Icons.more_horiz;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final screenSize = MediaQuery.of(context).size;

    // 计算菜单位置
    final menuWidth = 240.0;
    final itemHeight = 50.0;
    final headerHeight = (widget.title != null) ? 70.0 : 0.0;
    final menuHeight =
        headerHeight + widget.items.length * itemHeight + 16.0;

    // 水平位置：尽量显示在触发点附近，但不超出屏幕
    double left = widget.triggerPosition.dx - menuWidth / 2;
    left = left.clamp(16.0, screenSize.width - menuWidth - 16.0);

    // 垂直位置：优先显示在触发点上方，如果空间不够则显示在下方
    double top = widget.triggerPosition.dy - menuHeight - 20;
    if (top < MediaQuery.of(context).padding.top + 20) {
      top = widget.triggerPosition.dy + 20;
    }

    return GestureDetector(
      onTap: () => Navigator.pop(context),
      child: Material(
        color: Colors.transparent,
        child: Stack(
          children: [
            // 背景遮罩
            FadeTransition(
              opacity: _fadeAnimation,
              child: Container(
                color: Colors.black.withOpacity(0.3),
              ),
            ),
            // 菜单
            Positioned(
              left: left,
              top: top,
              child: FadeTransition(
                opacity: _fadeAnimation,
                child: ScaleTransition(
                  scale: _scaleAnimation,
                  alignment: Alignment.center,
                  child: Container(
                    width: menuWidth,
                    decoration: BoxDecoration(
                      color: isDark
                          ? const Color(0xFF1E293B)
                          : Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.2),
                          blurRadius: 20,
                          spreadRadius: -5,
                          offset: const Offset(0, 10),
                        ),
                      ],
                    ),
                    clipBehavior: Clip.antiAlias,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // 标题区域
                        if (widget.title != null) ...[
                          Padding(
                            padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
                            child: Row(
                              children: [
                                Icon(
                                  _contentTypeIcon,
                                  size: 20,
                                  color: isDark
                                      ? Colors.grey.shade400
                                      : Colors.grey.shade600,
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        widget.title!,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.w600,
                                          color: isDark
                                              ? Colors.white
                                              : Colors.black87,
                                        ),
                                      ),
                                      if (widget.subtitle != null) ...[
                                        const SizedBox(height: 2),
                                        Text(
                                          widget.subtitle!,
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: TextStyle(
                                            fontSize: 12,
                                            color: isDark
                                                ? Colors.grey.shade400
                                                : Colors.grey.shade500,
                                          ),
                                        ),
                                      ],
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Divider(
                            height: 1,
                            thickness: 0.5,
                            color: isDark
                                ? Colors.grey.shade700
                                : Colors.grey.shade200,
                          ),
                        ],
                        // 菜单项
                        ...widget.items.asMap().entries.map((entry) {
                          final index = entry.key;
                          final item = entry.value;
                          final isLast = index == widget.items.length - 1;
                          return _buildMenuItem(item, isDark, isLast);
                        }),
                        const SizedBox(height: 8),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMenuItem(
      ForceTouchMenuItem item, bool isDark, bool isLast) {
    final textColor = item.isDestructive
        ? Colors.red
        : (isDark ? Colors.white : Colors.black87);
    final iconColor = item.iconColor ??
        (item.isDestructive
            ? Colors.red
            : (isDark ? Colors.grey.shade300 : Colors.grey.shade600));

    return InkWell(
      onTap: () {
        Navigator.pop(context);
        item.onTap();
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          border: isLast
              ? null
              : Border(
                  bottom: BorderSide(
                    color: isDark
                        ? Colors.grey.shade800.withOpacity(0.5)
                        : Colors.grey.shade100,
                    width: 0.5,
                  ),
                ),
        ),
        child: Row(
          children: [
            Icon(item.icon, size: 20, color: iconColor),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                item.title,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: textColor,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
