import 'dart:convert';
import 'package:dio/dio.dart';
import '../../models/video_info.dart';
import '../../utils/platform_detector.dart';
import 'base_parser.dart';
import '../proxy_service.dart';

/// 小红书解析器
///
/// 小红书网页端解析策略：
/// 1. 分享链接通常是 xhslink.com 短链接，需要先展开获取真实地址
/// 2. 作品详情页路径：/explore/{noteId} 或 /discovery/item/{noteId}
/// 3. 页面数据嵌入在 window.__INITIAL_STATE__ 全局变量中，
///    note 数据通常位于 note.firstNoteDetail 或 note.noteDetailMap
/// 4. 实测关键：必须使用 Android Chrome UA，PC 端 UA 可能只返回页面壳
/// 5. 两步请求模式：先访问拿 Cookie（a1 等），再带 Cookie 请求获取完整数据
/// 6. 支持视频笔记（type=video）和图文笔记（type=normal）
class XiaohongshuParser extends BaseParser {
  final Dio _dio;

  /// [dio] 可注入自定义 Dio（测试用），默认自动创建
  XiaohongshuParser({Dio? dio})
      : _dio = dio ??
            Dio(BaseOptions(
              connectTimeout: const Duration(seconds: 15),
              receiveTimeout: const Duration(seconds: 20),
              validateStatus: (status) => status! < 500,
            ));

  /// UA 轮换列表：Android Chrome 为主，微信 UA 兜底
  static const List<String> _userAgents = [
    'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
    'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36 MicroMessenger/8.0.47.2560(0x28001235)',
    'Mozilla/5.0 (Linux; Android 12; MI 12) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Mobile Safari/537.36',
  ];

  @override
  String get platform => 'xiaohongshu';

  @override
  bool canParse(String url) {
    return PlatformDetector.detectPlatform(url) == VideoPlatform.xiaohongshu;
  }

  @override
  Future<VideoInfo> parse(String url) async {
    final cleanUrl = url.trim();

    // 第一步：短链接展开（xhslink.com / xhslink.cn / xhs.cn 多级跳转）
    var realUrl = cleanUrl;
    if (PlatformDetector.isShortLinkForPlatform(cleanUrl, VideoPlatform.xiaohongshu)) {
      realUrl = await _expandShortLink(cleanUrl);
    }

    // 第二步：提取笔记 ID
    final noteId = _extractNoteId(realUrl) ?? _extractNoteId(cleanUrl);
    if (noteId == null) {
      throw ParseException('无法从链接中提取笔记ID，请确认是小红书分享链接');
    }

    String? lastError;

    // 第三步：解析详情页（explore 路径优先）
    try {
      final result = await _parseDetailPage(noteId, 'explore', realUrl);
      if (result != null) return result;
    } catch (e) {
      lastError = _cleanError(e);
    }

    // 第四步：尝试 discovery/item 路径
    try {
      final result = await _parseDetailPage(noteId, 'discovery/item', realUrl);
      if (result != null) return result;
    } catch (e) {
      lastError ??= _cleanError(e);
    }

    throw ParseException(
      lastError ?? '解析失败，笔记可能已被删除或设为私密',
    );
  }

  // ==================== 短链接展开（多级跳转） ====================

  Future<String> _expandShortLink(String url) async {
    var currentUrl = url;
    for (var hop = 0; hop < 3; hop++) {
      try {
        final response = await _dio.get(
          currentUrl,
          options: Options(
            followRedirects: false,
            headers: _headers(_userAgents.first),
          ),
        );
        var location = response.headers.value('location') ?? '';
        if (location.isEmpty) {
          // 有些短链接返回 HTML 里包含跳转，尝试从页面中提取
          final html = response.data?.toString() ?? '';
          // 使用非贪婪匹配提取 refresh meta 标签中的 url
          final metaMatch = RegExp(
            r'<meta[^>]+http-equiv=.refresh.[^>]+content=[^;]+;\s*url=([^">\s]+)',
            caseSensitive: false,
          ).firstMatch(html);
          if (metaMatch != null) {
            location = metaMatch.group(1) ?? '';
          }
        }
        if (location.isEmpty) return currentUrl;
        if (location.startsWith('/')) {
          final uri = Uri.parse(currentUrl);
          location = '${uri.scheme}://${uri.host}$location';
        }
        currentUrl = location;
        // 已经到详情页就停止
        if (_extractNoteId(currentUrl) != null) return currentUrl;
      } catch (_) {
        return currentUrl;
      }
    }
    return currentUrl;
  }

  // ==================== 核心：两步 Cookie + 多UA 解析详情页 ====================

  Future<VideoInfo?> _parseDetailPage(
      String noteId, String path, String sourceUrl) async {
    final detailUrl = 'https://www.xiaohongshu.com/$path/$noteId';

    for (final ua in _userAgents) {
      // 第一步请求：拿 Cookie（a1、webId 等）
      String cookie = '';
      try {
        final first = await _dio.get(
          detailUrl,
          options: Options(headers: _headers(ua)),
        );
        final setCookies = first.headers['set-cookie'] ?? const <String>[];
        cookie = setCookies
            .map((c) => c.split(';').first.trim())
            .where((c) => c.contains('='))
            .join('; ');

        // 顺带尝试解析第一次响应（少数情况已含数据）
        final html1 = first.data?.toString() ?? '';
        final info = _tryExtractFromHtml(html1, sourceUrl);
        if (info != null) return info;
      } catch (_) {
        continue; // 换下一个 UA
      }

      if (cookie.isEmpty) continue; // 没 Cookie 大概率拿不到数据，换 UA

      // 第二步请求：带 Cookie，页面嵌入完整 note 数据
      try {
        final second = await _dio.get(
          detailUrl,
          options: Options(
            headers: {..._headers(ua), 'Cookie': cookie},
          ),
        );
        final html2 = second.data?.toString() ?? '';
        final info = _tryExtractFromHtml(html2, sourceUrl);
        if (info != null) return info;
      } catch (e) {
        if (e is ParseException) rethrow;
        // 网络异常，换下一个 UA 继续
      }
    }
    return null; // 所有 UA 都没拿到数据，让上层尝试另一种路径
  }

  // ==================== HTML 数据提取 ====================

  /// 从页面 HTML 中提取笔记数据（__INITIAL_STATE__ 多种结构）
  VideoInfo? _tryExtractFromHtml(String html, String sourceUrl) {
    if (html.isEmpty) return null;

    final initialState = _extractInitialState(html);
    if (initialState == null) return null;

    // 路径1：note.firstNoteDetail（常见结构）
    final noteData = _deepFindKey(initialState, 'firstNoteDetail');
    if (noteData is Map && _looksLikeNote(noteData)) {
      return _parseNote(noteData, sourceUrl);
    }

    // 路径2：note.noteDetailMap[noteId]（另一种结构）
    final noteDetailMap = _deepFindKey(initialState, 'noteDetailMap');
    if (noteDetailMap is Map) {
      for (final value in noteDetailMap.values) {
        if (value is Map) {
          final note = value['note'];
          if (note is Map && _looksLikeNote(note)) {
            return _parseNote(note, sourceUrl);
          }
          if (value is Map && _looksLikeNote(value)) {
            return _parseNote(value, sourceUrl);
          }
        }
      }
    }

    // 路径3：深度查找 note 对象
    final foundNote = _findNoteObject(initialState);
    if (foundNote != null) {
      return _parseNote(foundNote, sourceUrl);
    }

    return null;
  }

  /// 提取 window.__INITIAL_STATE__ JSON（括号配对法）
  Map<String, dynamic>? _extractInitialState(String html) {
    const markers = [
      'window.__INITIAL_STATE__',
      'window.__INITIAL_SSR_STATE__',
      'window.__REDUX_STATE__',
    ];

    for (final marker in markers) {
      try {
        final start = html.indexOf(marker);
        if (start < 0) continue;
        final jsonStart = html.indexOf('{', start);
        if (jsonStart < 0) continue;

        final jsonStr = _extractBalancedJson(html, jsonStart);
        if (jsonStr == null) continue;

        final data = jsonDecode(jsonStr);
        if (data is Map<String, dynamic>) return data;
      } catch (_) {
        continue;
      }
    }
    return null;
  }

  /// 括号配对提取完整 JSON（正确处理字符串内的花括号和转义）
  String? _extractBalancedJson(String text, int start) {
    var depth = 0;
    var inString = false;
    var escape = false;
    for (var i = start; i < text.length; i++) {
      final c = text[i];
      if (escape) {
        escape = false;
        continue;
      }
      if (inString) {
        if (c == '\\') {
          escape = true;
        } else if (c == '"') {
          inString = false;
        }
        continue;
      }
      if (c == '"') {
        inString = true;
      } else if (c == '{') {
        depth++;
      } else if (c == '}') {
        depth--;
        if (depth == 0) return text.substring(start, i + 1);
      }
    }
    return null;
  }

  /// 深度查找指定 key 的值（限制深度避免爆炸）
  dynamic _deepFindKey(dynamic data, String key, {int maxDepth = 8}) {
    return _deepFindKeyHelper(data, key, 0, maxDepth);
  }

  dynamic _deepFindKeyHelper(dynamic data, String key, int depth, int maxDepth) {
    if (depth > maxDepth) return null;
    if (data is Map) {
      if (data.containsKey(key)) return data[key];
      for (final value in data.values) {
        final result = _deepFindKeyHelper(value, key, depth + 1, maxDepth);
        if (result != null) return result;
      }
    } else if (data is List) {
      for (final item in data) {
        final result = _deepFindKeyHelper(item, key, depth + 1, maxDepth);
        if (result != null) return result;
      }
    }
    return null;
  }

  /// 在数据中查找真正的 note 对象（含标题和图片/视频）
  dynamic _findNoteObject(dynamic data, {int depth = 0}) {
    if (depth > 8) return null;
    if (data is Map) {
      if (_looksLikeNote(data)) return data;
      for (final value in data.values) {
        final r = _findNoteObject(value, depth: depth + 1);
        if (r != null) return r;
      }
    } else if (data is List) {
      for (final item in data) {
        final r = _findNoteObject(item, depth: depth + 1);
        if (r != null) return r;
      }
    }
    return null;
  }

  /// 判断对象是否是真正的 note（含基本标识字段）
  bool _looksLikeNote(dynamic data) {
    if (data is! Map) return false;
    // 有 imageList 或 video 字段的大概率是 note
    if (data['imageList'] is List && (data['imageList'] as List).isNotEmpty) {
      return true;
    }
    if (data['video'] is Map) return true;
    // 有 title + desc 的也可能是
    if (data['title'] != null && data['desc'] != null) {
      final images = data['images'];
      if (images is List && images.isNotEmpty) return true;
    }
    return false;
  }

  // ==================== ID 提取 ====================

  String? _extractNoteId(String url) {
    final patterns = [
      RegExp(r'/explore/([a-zA-Z0-9]+)'),
      RegExp(r'/discovery/item/([a-zA-Z0-9]+)'),
      RegExp(r'/discovery/explore/([a-zA-Z0-9]+)'),
      RegExp(r'/note/([a-zA-Z0-9]+)'),
      RegExp(r'[?&]note_id=([a-zA-Z0-9]+)'),
      RegExp(r'[?&]id=([a-zA-Z0-9]{20,})'),
    ];
    for (final p in patterns) {
      final m = p.firstMatch(url);
      if (m != null) {
        final id = m.group(1)!;
        // 过滤明显不是笔记 ID 的情况
        if (id.length >= 10 && !id.contains('.')) return id;
      }
    }
    // 兜底：去掉 query 后匹配独立路径段，避免误命中 query 参数或长路径片段
    final pathOnly = url.split('?').first;
    final fallbackMatch = RegExp(r'/([a-zA-Z0-9]{24})(?:/|$)').firstMatch(pathOnly);
    if (fallbackMatch != null) {
      final id = fallbackMatch.group(1)!;
      if (id.length >= 10 && !id.contains('.')) return id;
    }
    return null;
  }

  // ==================== note 数据解析 ====================

  VideoInfo _parseNote(dynamic note, String sourceUrl) {
    // ---- 图文/视频类型判断 ----
    final type = note['type']?.toString() ?? 'normal';
    final isVideo = type == 'video';

    // ---- 图片列表（图文笔记） ----
    List<String>? imageList;
    final imageListRaw = note['imageList'] ?? note['images_list'];
    if (imageListRaw is List && imageListRaw.isNotEmpty) {
      imageList = <String>[];
      for (final img in imageListRaw) {
        if (img is Map) {
          // 优先取 urlDefault / url 字段
          final url = img['urlDefault'] ??
              img['url'] ??
              img['url_default'] ??
              img['src'];
          if (url != null && url.toString().isNotEmpty) {
            imageList.add(url.toString());
            continue;
          }
          // 从 infoList / info_list 中取
          final infoList = img['infoList'] ?? img['info_list'];
          if (infoList is List && infoList.isNotEmpty) {
            final first = infoList.first;
            if (first is Map) {
              final u = first['url']?.toString();
              if (u != null && u.isNotEmpty) {
                imageList.add(u);
                continue;
              }
            }
          }
        } else if (img is String && img.isNotEmpty) {
          imageList.add(img);
        }
      }
      if (imageList.isEmpty) imageList = null;
    }

    // 兜底：images 字段（数组形式）
    if (imageList == null) {
      final images = note['images'];
      if (images is List && images.isNotEmpty) {
        imageList = <String>[];
        for (final img in images) {
          if (img is String) {
            imageList.add(img);
          } else if (img is Map) {
            final u = img['url'] ?? img['urlDefault'] ?? img['src'];
            if (u != null && u.toString().isNotEmpty) {
              imageList.add(u.toString());
            }
          }
        }
        if (imageList.isEmpty) imageList = null;
      }
    }

    final isImage = !isVideo && imageList != null && imageList.isNotEmpty;

    // ---- 视频地址（视频笔记） ----
    String? videoUrl;
    String? videoUrlHd;

    if (isVideo) {
      final video = note['video'];
      if (video is Map) {
        // 优先从 media.stream / media 中取
        final media = video['media'];
        if (media is Map) {
          final stream = media['stream'];
          if (stream is Map) {
            // h264 / h265 多种编码
            for (final codecKey in ['h264', 'h265']) {
              final codec = stream[codecKey];
              if (codec is List && codec.isNotEmpty) {
                for (final qualityItem in codec) {
                  if (qualityItem is Map) {
                    final masterUrl = qualityItem['masterUrl'] ??
                        qualityItem['master_url'] ??
                        qualityItem['url'];
                    if (masterUrl != null && masterUrl.toString().isNotEmpty) {
                      final u = masterUrl.toString();
                      videoUrl ??= u;
                      // 更高清的质量等级存为 hd
                      final qualityLevel =
                          qualityItem['qualityLevel']?.toString() ?? '';
                      if (qualityLevel.contains('HD') ||
                          qualityLevel.contains('1080') ||
                          qualityLevel.contains('720')) {
                        videoUrlHd = u;
                      }
                    }
                  }
                }
              }
            }
          }
          // 兜底：直接从 media 取 videoUrl
          final videoMediaUrl = media['videoUrl'] ?? media['video_url'];
          if (videoMediaUrl != null && videoMediaUrl.toString().isNotEmpty) {
            videoUrl ??= videoMediaUrl.toString();
          }
        }

        // 兜底：video.url 或 video.videoUrl
        if (videoUrl == null) {
          final directUrl = video['url'] ??
              video['videoUrl'] ??
              video['video_url'] ??
              video['playUrl'] ??
              video['play_url'];
          if (directUrl != null && directUrl.toString().isNotEmpty) {
            videoUrl = directUrl.toString();
          }
        }
      }
    }

    // ---- 封面 ----
    String cover = '';
    if (isImage && imageList != null && imageList.isNotEmpty) {
      cover = imageList.first;
    } else {
      final video = note['video'];
      if (video is Map) {
        final coverField = video['cover'] ??
            video['poster'] ??
            video['thumbnail'] ??
            video['coverUrl'] ??
            video['cover_url'];
        if (coverField is String && coverField.isNotEmpty) {
          cover = coverField;
        } else if (coverField is Map) {
          final u = coverField['url'] ?? coverField['urlDefault'];
          if (u != null && u.toString().isNotEmpty) {
            cover = u.toString();
          }
        }
      }
      // 图文也可能有专门的 cover 字段
      if (cover.isEmpty) {
        final noteCover = note['cover'] ?? note['coverUrl'];
        if (noteCover is String && noteCover.isNotEmpty) {
          cover = noteCover;
        } else if (noteCover is Map) {
          final u = noteCover['url'] ?? noteCover['urlDefault'];
          if (u != null && u.toString().isNotEmpty) {
            cover = u.toString();
          }
        }
      }
    }

    // ---- 基本信息 ----
    final id = note['noteId']?.toString() ??
        note['id']?.toString() ??
        note['objectId']?.toString() ??
        DateTime.now().millisecondsSinceEpoch.toString();

    int? durationSeconds;
    if (isVideo) {
      final video = note['video'];
      if (video is Map) {
        final d = video['duration'];
        if (d is num) durationSeconds = d.toInt();
        if (d is String) durationSeconds = int.tryParse(d);
      }
    }

    // ---- 作者信息 ----
    String author = '未知作者';
    final user = note['user'] ?? note['author'];
    if (user is Map) {
      author = user['nickname']?.toString() ??
          user['nickName']?.toString() ??
          user['name']?.toString() ??
          user['username']?.toString() ??
          '未知作者';
    }

    // ---- 标题和描述 ----
    final title = note['title']?.toString() ?? '';
    final desc = note['desc']?.toString() ?? note['description']?.toString() ?? '';
    final displayTitle = title.isNotEmpty ? title : desc;

    return VideoInfo(
      id: id,
      url: sourceUrl,
      platform: 'xiaohongshu',
      title: _cleanTitle(displayTitle),
      author: author,
      cover: cover,
      videoUrl: isImage ? null : videoUrl,
      videoUrlHd: isImage ? null : videoUrlHd,
      durationSeconds: durationSeconds,
      parsedAt: DateTime.now(),
      type: isImage ? 'image' : 'video',
      images: imageList,
    );
  }

  String _cleanTitle(String title) {
    var t = title.trim();
    if (t.isEmpty) return '无标题';
    if (t.length > 100) t = t.substring(0, 100);
    return t;
  }

  String _cleanError(Object e) {
    final msg = e.toString().replaceAll('ParseException: ', '');
    return msg.length > 100 ? '${msg.substring(0, 100)}...' : msg;
  }

  // ==================== Headers ====================

  Map<String, String> _headers(String ua) => {
        'User-Agent': ua,
        'Accept':
            'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'zh-CN,zh;q=0.9',
      };

  @override
  void applyProxy(ProxyService proxyService) {
    proxyService.applyToDio(_dio);
  }
}
