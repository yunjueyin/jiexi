import 'package:flutter/material.dart';
import '../../models/video_info.dart';
import '../proxy_service.dart';

/// 解析错误类型枚举
enum ParseErrorType {
  /// 链接格式错误
  invalidUrl,

  /// 网络问题
  networkError,

  /// 平台不支持
  unsupportedPlatform,

  /// 内容被删除/私密
  contentUnavailable,

  /// 解析失败（通用）
  parseFailed,
}

/// ParseErrorType 扩展：提供图标和标题
extension ParseErrorTypeX on ParseErrorType {
  /// 错误类型对应的图标
  IconData get icon {
    switch (this) {
      case ParseErrorType.invalidUrl:
        return Icons.link_off;
      case ParseErrorType.networkError:
        return Icons.wifi_off;
      case ParseErrorType.unsupportedPlatform:
        return Icons.help_outline;
      case ParseErrorType.contentUnavailable:
        return Icons.visibility_off;
      case ParseErrorType.parseFailed:
        return Icons.error_outline;
    }
  }

  /// 错误类型对应的标题
  String get title {
    switch (this) {
      case ParseErrorType.invalidUrl:
        return '链接格式错误';
      case ParseErrorType.networkError:
        return '网络连接失败';
      case ParseErrorType.unsupportedPlatform:
        return '不支持的平台';
      case ParseErrorType.contentUnavailable:
        return '内容不可见';
      case ParseErrorType.parseFailed:
        return '解析失败';
    }
  }
}

abstract class BaseParser {
  bool canParse(String url);
  Future<VideoInfo> parse(String url);
  String get platform;

  /// 应用代理配置到解析器的 Dio 实例
  void applyProxy(ProxyService proxyService) {}
}

class ParseException implements Exception {
  final String message;
  final int? code;
  final ParseErrorType type;

  ParseException(
    this.message, {
    this.code,
    this.type = ParseErrorType.parseFailed,
  });

  /// 错误类型对应的图标
  IconData get icon {
    switch (type) {
      case ParseErrorType.invalidUrl:
        return Icons.link_off;
      case ParseErrorType.networkError:
        return Icons.wifi_off;
      case ParseErrorType.unsupportedPlatform:
        return Icons.block;
      case ParseErrorType.contentUnavailable:
        return Icons.delete_outline;
      case ParseErrorType.parseFailed:
        return Icons.error_outline;
    }
  }

  /// 错误类型对应的标题
  String get title {
    switch (type) {
      case ParseErrorType.invalidUrl:
        return '链接格式错误';
      case ParseErrorType.networkError:
        return '网络连接失败';
      case ParseErrorType.unsupportedPlatform:
        return '暂不支持该平台';
      case ParseErrorType.contentUnavailable:
        return '内容不可用';
      case ParseErrorType.parseFailed:
        return '解析失败';
    }
  }

  @override
  String toString() => 'ParseException: $message';
}
