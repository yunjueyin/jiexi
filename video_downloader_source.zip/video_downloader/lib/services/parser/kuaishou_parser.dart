import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:dio/io.dart';
import '../../models/video_info.dart';
import '../../utils/platform_detector.dart';
import 'base_parser.dart';
import '../proxy_service.dart';

/// 快手解析器
///
/// 快手网页版现为纯客户端渲染，页面不嵌入数据。
/// 可行方案：
/// 1. 先访问快手首页获取 Cookie（did、ktrace-context 等）
/// 2. 携带 Cookie 调用 GraphQL 接口 VisionVideoDetail 获取作品数据
/// 3. 移动端页面作为备用
class KuaishouParser extends BaseParser {
  final Dio _dio;

  /// [dio] 可注入自定义 Dio（测试用），默认自动创建
  KuaishouParser({Dio? dio})
      : _dio = dio ??
            Dio(BaseOptions(
              connectTimeout: const Duration(seconds: 15),
              receiveTimeout: const Duration(seconds: 20),
              validateStatus: (status) => status! < 500,
            ));

  @override
  String get platform => 'kuaishou';

  @override
  bool canParse(String url) {
    return PlatformDetector.detectPlatform(url) == VideoPlatform.kuaishou;
  }

  @override
  Future<VideoInfo> parse(String url) async {
    final cleanUrl = url.trim();

    // 第一步：展开短链接
    var realUrl = cleanUrl;
    if (cleanUrl.contains('v.kuaishou.com') || cleanUrl.contains('v.kuaishou.cn')) {
      realUrl = await _expandShortLink(cleanUrl);
    }

    // 第二步：提取作品ID
    final photoId = _extractPhotoId(realUrl) ?? _extractPhotoId(cleanUrl);
    if (photoId == null) {
      throw ParseException('无法从链接中提取作品ID，请确认是快手分享链接');
    }

    String? lastError;

    // 第三步：GraphQL 接口（主要方案）
    try {
      final result = await _parseByGraphQL(photoId, realUrl);
      if (result != null) return result;
    } catch (e) {
      lastError = _cleanError(e);
    }

    // 第四步：移动端页面（备用方案）
    try {
      final result = await _parseMobilePage(photoId, realUrl);
      if (result != null) return result;
    } catch (e) {
      lastError ??= _cleanError(e);
    }

    throw ParseException(lastError ?? '解析失败，作品可能已被删除或设为私密');
  }

  // ==================== 短链接展开 ====================

  Future<String> _expandShortLink(String url) async {
    try {
      final response = await _dio.get(
        url,
        options: Options(
          followRedirects: false,
          headers: _mobileHeaders(),
        ),
      );
      var location = response.headers.value('location') ?? '';
      if (location.isEmpty) return url;
      if (location.startsWith('/')) {
        final uri = Uri.parse(url);
        location = '${uri.scheme}://${uri.host}$location';
      }
      return location;
    } catch (_) {
      return url;
    }
  }

  // ==================== 原始数据抓取（供数据抓取模块复用） ====================

  /// 抓取快手作品原始 photo 对象（移动端页面优先，GraphQL 兜底）。
  /// 不做 VideoInfo 映射，保留全部字段（统计/作者等）供抓取使用。
  /// 移动端页面 m.chenzhongtech.com/fw/photo/{id} 嵌入的 photo 含
  /// commentCount/shareCount/userName 等字段（2026-08 GraphQL 已裁剪这些字段）。
  Future<Map?> fetchPhotoRaw(String url) async {
    var realUrl = url.trim();
    if (realUrl.contains('v.kuaishou.com') ||
        realUrl.contains('v.kuaishou.cn')) {
      realUrl = await _expandShortLink(realUrl);
    }

    final photoId = _extractPhotoId(realUrl) ?? _extractPhotoId(url.trim());
    if (photoId == null) return null;

    // 方案1：移动端页面（数据最全，抓取场景优先）
    try {
      final photo = await _fetchPhotoFromMobilePage(photoId);
      if (photo is Map) return photo;
    } catch (_) {}

    // 方案2：GraphQL（数据较精简但稳定）
    try {
      final photo = await _fetchPhotoByGraphql(photoId);
      if (photo is Map) return photo;
    } catch (_) {}

    return null;
  }

  // ==================== GraphQL 解析（主要方案） ====================

  Future<VideoInfo?> _parseByGraphQL(String photoId, String sourceUrl) async {
    final photo = await _fetchPhotoByGraphql(photoId);
    if (photo == null) return null;
    return _parsePhoto(photo, sourceUrl);
  }

  Future<dynamic> _fetchPhotoByGraphql(String photoId) async {
    // 第一步：访问快手首页拿 Cookie
    final home = await _dio.get(
      'https://www.kuaishou.com/',
      options: Options(headers: _pcHeaders()),
    );
    final setCookies = home.headers['set-cookie'] ?? const <String>[];
    final cookiePairs = setCookies
        .map((c) => c.split(';').first.trim())
        .where((c) => c.contains('='))
        .toList();
    if (cookiePairs.isEmpty) {
      throw ParseException('未能获取到快手 Cookie，网络可能被拦截');
    }
    final cookie = cookiePairs.join('; ');

    // 第二步：调用 GraphQL（先用当前 schema 的完整查询，失败则退回精简查询）
    // 注意：variables 部分用 Dart 插值注入实际ID；query 部分的 $photoId 是
    // GraphQL 变量语法，需用 \$ 转义保持字面量
    // （2026-08 实测 schema：photo 下 originCaption/images/commentCount/
    //  shareCount/author 字段已移除，精简为下列字段）
    final queries = [
      // 当前 schema 查询（含 realLikeCount）
      '{"operationName":"VisionVideoDetail","variables":{"photoId":"$photoId","page":"detail","webPageArea":"detailxx"},"query":"query VisionVideoDetail(\$photoId: String, \$page: String, \$webPageArea: String) { visionVideoDetail(photoId: \$photoId, page: \$page, webPageArea: \$webPageArea) { status type photo { id duration timestamp caption likeCount realLikeCount viewCount coverUrl photoUrl } } }"}',
      // 精简查询（字段已实测验证可用）
      '{"operationName":"VisionVideoDetail","variables":{"photoId":"$photoId","page":"detail","webPageArea":"detailxx"},"query":"query VisionVideoDetail(\$photoId: String, \$page: String, \$webPageArea: String) { visionVideoDetail(photoId: \$photoId, page: \$page, webPageArea: \$webPageArea) { status type photo { id duration timestamp caption likeCount viewCount coverUrl photoUrl } } }"}',
    ];

    for (final q in queries) {
      try {
        final response = await _dio.post(
          'https://www.kuaishou.com/graphql',
          data: q,
          options: Options(
            headers: {
              ..._pcHeaders(),
              'Cookie': cookie,
              'Content-Type': 'application/json',
              'Origin': 'https://www.kuaishou.com',
            },
          ),
        );
        dynamic data = response.data;
        if (data is String) data = jsonDecode(data);
        if (data is! Map) continue;

        final errors = data['errors'];
        if (errors is List && errors.isNotEmpty) {
          final msg = errors[0] is Map ? errors[0]['message']?.toString() : '';
          if (msg?.contains('captcha') == true) {
            throw ParseException('快手需要人机验证，请稍后重试或切换其他解析API源');
          }
          // 字段校验错误 → 尝试下一个查询
          continue;
        }

        final detail = data['data']?['visionVideoDetail'];
        if (detail is Map) {
          final status = detail['status']?.toString();
          final p = detail['photo'];
          if (p is Map && status != null && status != '0' && status != 'null') {
            return p;
          }
          if (status == null || status == '0') {
            throw ParseException('作品不存在，可能已被删除或设为私密');
          }
        }
      } on ParseException {
        rethrow;
      } catch (_) {
        continue;
      }
    }
    return null;
  }

  // ==================== 移动端页面解析（备用） ====================

  Future<VideoInfo?> _parseMobilePage(String photoId, String sourceUrl) async {
    final photo = await _fetchPhotoFromMobilePage(photoId);
    if (photo == null) return null;
    return _parsePhoto(photo, sourceUrl);
  }

  Future<dynamic> _fetchPhotoFromMobilePage(String photoId) async {
    // 移动端分享页（可能嵌入数据）
    final urls = [
      'https://m.chenzhongtech.com/fw/photo/$photoId',
      'https://www.chenzhongtech.com/fw/photo/$photoId',
      'https://c.kuaishou.com/fw/photo/$photoId',
    ];

    for (final url in urls) {
      try {
        final first = await _dio.get(url,
            options: Options(headers: _mobileHeaders()));
        final cookies = (first.headers['set-cookie'] ?? const <String>[])
            .map((c) => c.split(';').first.trim())
            .where((c) => c.contains('='))
            .toList();

        var html = first.data?.toString() ?? '';
        var photo = _findPhotoRawInHtml(html);
        if (photo != null) return photo;

        if (cookies.isNotEmpty) {
          final second = await _dio.get(
            url,
            options: Options(
              headers: {..._mobileHeaders(), 'Cookie': cookies.join('; ')},
            ),
          );
          html = second.data?.toString() ?? '';
          photo = _findPhotoRawInHtml(html);
          if (photo != null) return photo;
        }
      } catch (_) {
        continue;
      }
    }
    return null;
  }

  /// 从页面 HTML 提取数据（INIT_STATE / __NEXT_DATA__ / pageData）
  VideoInfo? _tryExtractFromHtml(String html, String sourceUrl) {
    final photo = _findPhotoRawInHtml(html);
    if (photo == null) return null;
    return _parsePhoto(photo, sourceUrl);
  }

  /// 在页面内嵌 JSON 中查找原始 photo 对象（不映射为 VideoInfo）
  dynamic _findPhotoRawInHtml(String html) {
    if (html.isEmpty) return null;

    // 常见的数据嵌入位置
    final markers = [
      'window.__INITIAL_STATE__',
      'window.INIT_STATE',
      'window._INITIAL_STATE_',
      '__NEXT_DATA__',
      'window.pageData',
    ];

    for (final marker in markers) {
      final start = html.indexOf(marker);
      if (start < 0) continue;
      final jsonStart = html.indexOf('{', start);
      if (jsonStart < 0) continue;
      final jsonStr = _extractBalancedJson(html, jsonStart);
      if (jsonStr == null) continue;
      try {
        final data = jsonDecode(jsonStr);
        if (data is Map) {
          final photo = _findPhotoObject(data);
          if (photo != null) {
            return photo;
          }
        }
      } catch (_) {
        continue;
      }
    }
    return null;
  }

  /// 查找真正的 photo 对象（含视频或图片数据）
  dynamic _findPhotoObject(dynamic data, {int depth = 0}) {
    if (depth > 8) return null;
    if (data is Map) {
      if (_looksLikePhoto(data)) return data;
      for (final value in data.values) {
        final r = _findPhotoObject(value, depth: depth + 1);
        if (r != null) return r;
      }
    } else if (data is List) {
      for (final item in data) {
        final r = _findPhotoObject(item, depth: depth + 1);
        if (r != null) return r;
      }
    }
    return null;
  }

  bool _looksLikePhoto(dynamic data) {
    if (data is! Map) return false;
    if (data['photoUrl'] is String && (data['photoUrl'] as String).isNotEmpty) {
      return true;
    }
    if (data['mainMvUrls'] is List && (data['mainMvUrls'] as List).isNotEmpty) {
      return true;
    }
    final images = data['images'];
    if (images is List && images.isNotEmpty) return true;
    return false;
  }

  // ==================== 工具方法 ====================

  String? _extractBalancedJson(String text, int start) {
    var depth = 0;
    var inString = false;
    var escape = false;
    for (var i = start; i < text.length; i++) {
      final c = text[i];
      if (escape) {
        escape = false;
        continue;
      }
      if (inString) {
        if (c == '\\') {
          escape = true;
        } else if (c == '"') {
          inString = false;
        }
        continue;
      }
      if (c == '"') {
        inString = true;
      } else if (c == '{') {
        depth++;
      } else if (c == '}') {
        depth--;
        if (depth == 0) return text.substring(start, i + 1);
      }
    }
    return null;
  }

  dynamic _deepFindKey(dynamic data, String key, {int depth = 0}) {
    if (depth > 8) return null;
    if (data is Map) {
      if (data.containsKey(key)) return data[key];
      for (final value in data.values) {
        final r = _deepFindKey(value, key, depth: depth + 1);
        if (r != null) return r;
      }
    } else if (data is List) {
      for (final item in data) {
        final r = _deepFindKey(item, key, depth: depth + 1);
        if (r != null) return r;
      }
    }
    return null;
  }

  String? _extractPhotoId(String url) {
    final patterns = [
      RegExp(r'/short-video/([a-zA-Z0-9_-]+)'),
      RegExp(r'/fw/photo/([a-zA-Z0-9_-]+)'),
      RegExp(r'/photo/([a-zA-Z0-9_-]+)'),
      RegExp(r'/long-video/([a-zA-Z0-9_-]+)'),
      RegExp(r'[?&]photoId=([a-zA-Z0-9_-]+)'),
      RegExp(r'[?&]objectId=([a-zA-Z0-9_-]+)'),
    ];
    for (final p in patterns) {
      final m = p.firstMatch(url);
      if (m != null) {
        final id = m.group(1)!;
        // 过滤误匹配的分享参数
        if (id.length >= 5 && !id.contains('.')) return id;
      }
    }
    return null;
  }

  // ==================== photo 数据解析 ====================

  VideoInfo _parsePhoto(dynamic photo, String sourceUrl) {
    String? videoUrl;
    String? videoUrlHd;
    List<String>? imageList;
    bool isImage = false;

    // ---- 图集判断 ----
    final images = photo['images'];
    if (images is List && images.isNotEmpty) {
      imageList = <String>[];
      for (final img in images) {
        if (img is String) {
          imageList.add(img);
        } else if (img is Map) {
          final u = img['cdnUrl'] ??
              img['webpUrl'] ??
              img['url'] ??
              img['src'];
          if (u != null && u.toString().isNotEmpty) {
            imageList.add(u.toString());
          }
        }
      }
      if (imageList.isNotEmpty) {
        isImage = true;
      } else {
        imageList = null;
      }
    }

    // ---- 视频地址 ----
    if (!isImage) {
      final photoUrl = photo['photoUrl'];
      if (photoUrl is String && photoUrl.isNotEmpty) {
        videoUrl = photoUrl;
      }

      // mainMvUrls（多种清晰度）
      final mainMvUrls = photo['mainMvUrls'];
      if (mainMvUrls is List && mainMvUrls.isNotEmpty) {
        for (final mv in mainMvUrls) {
          if (mv is Map) {
            final u = mv['url']?.toString();
            if (u != null && u.isNotEmpty) {
              if (videoUrl == null) {
                videoUrl = u;
              } else if (videoUrlHd == null || u.length > videoUrlHd.length) {
                videoUrlHd = u;
              }
            }
          } else if (mv is String && videoUrl == null) {
            videoUrl = mv;
          }
        }
      }
    }

    // ---- 封面 ----
    String cover = '';
    if (isImage && imageList != null && imageList.isNotEmpty) {
      cover = imageList.first;
    } else {
      cover = photo['coverUrl']?.toString() ??
          photo['poster']?.toString() ??
          photo['thumbnail']?.toString() ??
          '';
    }

    // ---- 基本信息 ----
    final id = photo['photoId']?.toString() ??
        photo['id']?.toString() ??
        DateTime.now().millisecondsSinceEpoch.toString();

    int? durationSeconds;
    if (!isImage) {
      final d = photo['duration'];
      if (d is int) durationSeconds = d ~/ 1000;
      if (d is String) durationSeconds = int.tryParse(d) ?? null;
    }

    return VideoInfo(
      id: id,
      url: sourceUrl,
      platform: 'kuaishou',
      title: _cleanTitle(photo['caption']?.toString() ??
          photo['originCaption']?.toString() ??
          photo['title']?.toString() ??
          '无标题'),
      author: photo['userName']?.toString() ??
          photo['author']?['name']?.toString() ??
          photo['user']?['name']?.toString() ??
          '未知作者',
      cover: cover,
      videoUrl: isImage ? null : videoUrl,
      videoUrlHd: isImage ? null : videoUrlHd,
      durationSeconds: durationSeconds,
      parsedAt: DateTime.now(),
      type: isImage ? 'image' : 'video',
      images: imageList,
    );
  }

  String _cleanTitle(String title) {
    var t = title.trim();
    if (t.isEmpty) return '无标题';
    if (t.length > 100) t = t.substring(0, 100);
    return t;
  }

  String _cleanError(Object e) {
    final msg = e.toString().replaceAll('ParseException: ', '');
    return msg.length > 100 ? '${msg.substring(0, 100)}...' : msg;
  }

  // ==================== Headers ====================

  Map<String, String> _mobileHeaders() => {
        'User-Agent':
            'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'zh-CN,zh;q=0.9',
      };

  Map<String, String> _pcHeaders() => {
        'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'zh-CN,zh;q=0.9',
        'Referer': 'https://www.kuaishou.com/',
      };

  @override
  void applyProxy(ProxyService? proxyService) {
    if (proxyService != null) {
      proxyService.applyToDio(_dio);
    } else {
      _dio.httpClientAdapter = IOHttpClientAdapter();
    }
  }
}
