import 'dart:collection';
import 'package:dio/dio.dart';
import 'package:dio/io.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../../models/api_source.dart';
import '../../models/video_info.dart';
import '../../utils/platform_detector.dart';
import '../../utils/retry_helper.dart';
import '../parser_router.dart';
import '../proxy_service.dart';
import '../source_stats_service.dart';
import 'base_parser.dart';
import 'douyin_parser.dart';
import 'kuaishou_parser.dart';
import 'xiaohongshu_parser.dart';
import 'custom_api_parser.dart';

/// 解析结果包装类，包含视频信息和是否来自缓存的标记
class ParseResult {
  final VideoInfo videoInfo;
  final bool isFromCache;

  ParseResult({
    required this.videoInfo,
    this.isFromCache = false,
  });
}

class ParserService {
  static const String _cacheBoxName = 'parse_cache';
  static const Duration _cacheDuration = Duration(hours: 24);
  static const int _maxCacheSize = 100;

  final Dio _dio = Dio();
  final ParserRouter _router = ParserRouter();

  // 保留内置解析器引用，用于外部访问（如设置 Cookie）
  final DouyinParser _douyinParser = DouyinParser();
  final List<BaseParser> _builtInParsers = [];

  /// 统计服务（可选，注入后会自动记录解析结果）
  final SourceStatsService? _statsService;

  /// 内存 LRU 缓存（URL -> VideoInfo）
  final LinkedHashMap<String, VideoInfo> _memoryCache = LinkedHashMap();

  /// 上次解析是否来自缓存
  bool _lastParseFromCache = false;

  ParserService({SourceStatsService? statsService})
      : _statsService = statsService {
    _builtInParsers.addAll([
      _douyinParser,
      KuaishouParser(),
      XiaohongshuParser(),
    ]);
    // 连接统计回调
    if (_statsService != null) {
      _router.onParseResult = (sourceId, sourceName, success, durationMs, errorMessage) {
        _statsService!.recordResult(
          sourceId: sourceId,
          sourceName: sourceName,
          success: success,
          durationMs: durationMs,
          failureReason: errorMessage,
        );
      };
    }
  }

  Box<VideoInfo>? _cacheBox;
  bool _cacheInitialized = false;

  /// 上次解析是否来自缓存（用于 UI 提示）
  bool get lastParseFromCache => _lastParseFromCache;

  String? _customApiUrl;
  String? _customApiKeyParam;
  String? _customApiKey;
  CustomApiParser? _customParser;
  String _apiSourceId = 'builtIn';

  /// 代理服务
  ProxyService? _proxyService;

  /// 设置代理服务并应用到所有内部 Dio 实例
  void setProxyService(ProxyService? proxyService) {
    _proxyService = proxyService;
    if (proxyService != null) {
      proxyService.applyToDio(_dio);
      _router.setProxyService(proxyService);
      _douyinParser.applyProxy(proxyService);
    } else {
      _dio.httpClientAdapter = IOHttpClientAdapter();
      _router.setProxyService(null);
    }
  }

  /// 当前使用的 API 源 ID
  String get currentSourceId => _apiSourceId;

  /// 获取解析路由器（高级用法，如获取 fallback 详情）
  ParserRouter get router => _router;

  // ==================== 缓存相关 ====================

  /// 初始化缓存
  Future<void> _initCache() async {
    if (_cacheInitialized) return;
    try {
      _cacheBox = await Hive.openBox<VideoInfo>(_cacheBoxName);
      _cacheInitialized = true;
      // 清理过期缓存
      await _cleanExpiredCache();
    } catch (e) {
      // 打开失败时尝试删除旧数据重新打开
      try {
        await Hive.deleteBoxFromDisk(_cacheBoxName);
        _cacheBox = await Hive.openBox<VideoInfo>(_cacheBoxName);
        _cacheInitialized = true;
      } catch (_) {
        _cacheInitialized = false;
      }
    }
  }

  /// 清理过期缓存
  Future<void> _cleanExpiredCache() async {
    if (_cacheBox == null) return;
    final now = DateTime.now();
    final keysToDelete = <String>[];
    for (final key in _cacheBox!.keys) {
      final video = _cacheBox!.get(key);
      if (video != null) {
        final age = now.difference(video.parsedAt);
        if (age > _cacheDuration) {
          keysToDelete.add(key.toString());
        }
      }
    }
    for (final key in keysToDelete) {
      await _cacheBox!.delete(key);
    }
  }

  /// 从缓存获取解析结果
  /// 
  /// 返回 null 表示缓存未命中或已过期
  /// 优先从内存缓存读取，未命中再查持久化缓存
  Future<VideoInfo?> _getFromCache(String url) async {
    final cacheKey = _cacheKey(url);

    // 1. 先查内存缓存
    if (_memoryCache.containsKey(cacheKey)) {
      final cached = _memoryCache[cacheKey]!;
      // 检查是否过期
      final age = DateTime.now().difference(cached.parsedAt);
      if (age <= _cacheDuration) {
        // LRU: 移到末尾表示最近使用
        _memoryCache.remove(cacheKey);
        _memoryCache[cacheKey] = cached;
        return cached;
      } else {
        // 已过期，从内存移除
        _memoryCache.remove(cacheKey);
      }
    }

    // 2. 再查持久化缓存
    if (!_cacheInitialized) {
      await _initCache();
    }
    if (_cacheBox == null) return null;

    final cached = _cacheBox!.get(cacheKey);
    if (cached == null) return null;

    // 检查是否过期
    final age = DateTime.now().difference(cached.parsedAt);
    if (age > _cacheDuration) {
      // 已过期，删除缓存
      await _cacheBox!.delete(cacheKey);
      return null;
    }

    // 同步到内存缓存
    _addToMemoryCache(cacheKey, cached);

    return cached;
  }

  /// 添加到内存缓存（LRU 淘汰）
  void _addToMemoryCache(String key, VideoInfo video) {
    // 如果已存在，先移除（用于更新 LRU 顺序）
    if (_memoryCache.containsKey(key)) {
      _memoryCache.remove(key);
    }
    // 添加到末尾（最近使用）
    _memoryCache[key] = video;
    // 超过容量时淘汰最旧的（链表头部）
    while (_memoryCache.length > _maxCacheSize) {
      final oldestKey = _memoryCache.keys.first;
      _memoryCache.remove(oldestKey);
    }
  }

  /// 写入缓存（同时写入内存和持久化）
  Future<void> _saveToCache(VideoInfo video) async {
    final cacheKey = _cacheKey(video.url);

    // 写入内存缓存
    _addToMemoryCache(cacheKey, video);

    // 异步写入持久化缓存
    if (!_cacheInitialized) {
      await _initCache();
    }
    if (_cacheBox == null) return;

    // 如果已存在，先删除旧的
    if (_cacheBox!.containsKey(cacheKey)) {
      await _cacheBox!.delete(cacheKey);
    }

    // 检查缓存数量，如果超过限制，删除最旧的
    if (_cacheBox!.length >= _maxCacheSize) {
      await _removeOldestCache();
    }

    await _cacheBox!.put(cacheKey, video);
  }

  /// 删除最旧的缓存条目
  Future<void> _removeOldestCache() async {
    if (_cacheBox == null || _cacheBox!.isEmpty) return;

    VideoInfo? oldest;
    String? oldestKey;

    for (final key in _cacheBox!.keys) {
      final video = _cacheBox!.get(key);
      if (video != null) {
        if (oldest == null || video.parsedAt.isBefore(oldest.parsedAt)) {
          oldest = video;
          oldestKey = key.toString();
        }
      }
    }

    if (oldestKey != null) {
      await _cacheBox!.delete(oldestKey);
    }
  }

  /// 生成缓存 key
  String _cacheKey(String url) {
    // 简单使用 URL 作为 key，可以考虑 hash
    return url.trim();
  }

  /// 清除所有缓存
  Future<void> clearCache() async {
    if (!_cacheInitialized) return;
    await _cacheBox?.clear();
  }

  /// 获取缓存数量
  int get cacheSize => _cacheBox?.length ?? 0;

  /// 设置 API 源（完整 ApiSource 对象，含 apiKeyParam 等配置）
  /// 同时可传入已保存的 apiKey 和自定义 url
  void setApiSource(
    ApiSource source, {
    String? apiKey,
    String? customUrl,
  }) {
    _apiSourceId = source.id;
    if (source.isBuiltIn) {
      _customParser = null;
      _customApiUrl = null;
      _customApiKeyParam = null;
      _customApiKey = null;
      _router.setPrimarySource(source);
      return;
    }

    // 确定 API 地址：自定义源用 customUrl，预设源用 source.apiUrl
    final url = source.id == 'custom'
        ? (customUrl ?? source.apiUrl)
        : source.apiUrl;
    if (url == null || url.isEmpty) {
      _customParser = null;
      _customApiUrl = null;
      _router.setPrimarySource(source, apiKey: apiKey, customUrl: customUrl);
      return;
    }

    _customApiUrl = url;
    _customApiKeyParam = source.apiKeyParam;
    _customApiKey = apiKey;
    _customParser = CustomApiParser(
      url,
      apiKeyParam: source.apiKeyParam,
      apiKey: apiKey,
    );
    _router.setPrimarySource(source, apiKey: apiKey, customUrl: customUrl);
  }

  /// 设置自定义 API URL（兼容旧接口）
  void setCustomApiUrl(String? url) {
    _customApiUrl = url;
    if (url != null && url.isNotEmpty) {
      _customParser = CustomApiParser(
        url,
        apiKeyParam: _customApiKeyParam,
        apiKey: _customApiKey,
      );
      // 更新路由器中的自定义源
      final customSource = ApiSource.fromId('custom');
      if (customSource != null) {
        _router.setPrimarySource(customSource, apiKey: _customApiKey, customUrl: url);
      }
    } else {
      _customParser = null;
    }
  }

  /// 更新 API Key（热更新，不重建其他配置）
  void setApiKey(String? key) {
    _customApiKey = key;
    if (_customParser != null && _customApiUrl != null) {
      _customParser = CustomApiParser(
        _customApiUrl!,
        apiKeyParam: _customApiKeyParam,
        apiKey: key,
      );
    }
    _router.updateApiKey(key);
  }

  /// 设置抖音 Cookie
  /// 传入空 map 或 null 则清除，回退到自动获取 Cookie 模式
  void setDouyinCookies(Map<String, String>? cookies) {
    _douyinParser.setCookies(cookies);
    _router.setDouyinCookies(cookies);
  }

  /// 设置解析重试次数
  void setParseRetryCount(int count) {
    _router.setRetryConfig(RetryConfig(
      maxRetries: count,
      initialDelay: const Duration(milliseconds: 500),
      backoffFactor: 2.0,
      maxDelay: const Duration(seconds: 5),
    ));
  }

  /// 检测平台
  String detectPlatform(String url) {
    return PlatformDetector.detectPlatformId(url);
  }

  /// 平台名称映射为中文
  String _platformName(String platform) {
    return VideoPlatformX.fromId(platform).name;
  }

  /// 从文本中提取第一个 URL
  String? extractUrl(String text) {
    return PlatformDetector.extractUrl(text);
  }

  /// 从文本中提取所有 URL
  List<String> extractAllUrls(String text) {
    return PlatformDetector.extractAllUrls(text);
  }

  /// 从错误信息中判断错误类型
  ParseErrorType _detectErrorType(String errorMsg, String platform) {
    final lower = errorMsg.toLowerCase();
    // 内容被删除/私密
    if (lower.contains('删除') ||
        lower.contains('私密') ||
        lower.contains('不存在') ||
        lower.contains('已下架') ||
        lower.contains('不可见') ||
        lower.contains('404') ||
        lower.contains('not found')) {
      return ParseErrorType.contentUnavailable;
    }
    // 网络问题
    if (lower.contains('网络') ||
        lower.contains('连接超时') ||
        lower.contains('timeout') ||
        lower.contains('socket') ||
        lower.contains('dio') ||
        lower.contains('failed') ||
        lower.contains('无法连接') ||
        lower.contains('请求失败')) {
      return ParseErrorType.networkError;
    }
    // 链接格式错误
    if (lower.contains('链接') && (lower.contains('无效') || lower.contains('格式'))) {
      return ParseErrorType.invalidUrl;
    }
    // 不支持的平台
    if (lower.contains('不支持') || lower.contains('无法识别')) {
      return ParseErrorType.unsupportedPlatform;
    }
    return ParseErrorType.parseFailed;
  }

  /// 解析视频
  ///
  /// 自动多源 fallback：主源失败时自动尝试备用源
  /// 解析后可通过 [lastParseFromCache] 判断结果是否来自缓存
  Future<VideoInfo> parse(String url, {bool useCustomApiFirst = false, bool useCache = true}) async {
    final trimmed = url.trim();
    if (trimmed.isEmpty) {
      throw ParseException('请输入视频链接', type: ParseErrorType.invalidUrl);
    }

    // 从文本中提取纯 URL（支持带文字的分享链接）
    final cleanUrl = PlatformDetector.normalizeUrl(trimmed) ?? trimmed;
    if (cleanUrl.isEmpty || !cleanUrl.startsWith(RegExp(r'https?://', caseSensitive: false))) {
      throw ParseException('请输入有效的视频链接', type: ParseErrorType.invalidUrl);
    }

    // 先检查缓存
    if (useCache) {
      final cached = await _getFromCache(cleanUrl);
      if (cached != null) {
        _lastParseFromCache = true;
        return cached;
      }
    }

    _lastParseFromCache = false;

    try {
      // 使用多源智能路由解析
      final result = await _router.parseWithFallback(cleanUrl);

      // 解析成功，写入缓存
      if (useCache) {
        _saveToCache(result.videoInfo); // 异步写入，不等待
      }
      return result.videoInfo;
    } catch (e) {
      if (e is ParseException) {
        rethrow;
      }
      // 包装错误信息
      final platform = detectPlatform(cleanUrl);
      final platformName = _platformName(platform);
      final errorMsg = e.toString().replaceAll('ParseException: ', '').replaceAll('_ParseRouterException: ', '');
      final errorType = _detectErrorType(errorMsg, platform);
      throw ParseException(
        errorMsg,
        type: errorType,
      );
    }
  }

  /// 批量解析
  Future<List<VideoInfo>> parseBatch(List<String> urls) async {
    final results = <VideoInfo>[];
    for (var url in urls) {
      try {
        final video = await parse(url);
        results.add(video);
      } catch (e) {
        // 跳过失败的
      }
    }
    return results;
  }

  /// 展开短链接（获取真实长链接）
  Future<String> expandShortUrl(String url) async {
    final cleanUrl = url.trim();
    if (cleanUrl.isEmpty) {
      throw ParseException('请输入视频链接');
    }

    try {
      String currentUrl = cleanUrl;
      int maxRedirects = 5;
      int redirects = 0;

      while (redirects < maxRedirects) {
        try {
          final response = await _dio.head(
            currentUrl,
            options: Options(
              followRedirects: false,
              validateStatus: (status) => status! < 500,
              headers: {
                'User-Agent':
                    'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
              },
              receiveTimeout: const Duration(seconds: 10),
            ),
          );

          final location = response.headers.value('location');
          if (location == null || location.isEmpty) {
            break;
          }

          // 处理相对路径
          if (location.startsWith('/')) {
            final uri = Uri.parse(currentUrl);
            currentUrl = '${uri.scheme}://${uri.host}$location';
          } else {
            currentUrl = location;
          }
          redirects++;
        } catch (e) {
          // HEAD 请求失败，尝试 GET
          try {
            final getResponse = await _dio.get(
              currentUrl,
              options: Options(
                followRedirects: false,
                validateStatus: (status) => status! < 500,
                headers: {
                  'User-Agent':
                      'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
                },
                receiveTimeout: const Duration(seconds: 10),
              ),
            );

            final location = getResponse.headers.value('location');
            if (location == null || location.isEmpty) {
              break;
            }

            if (location.startsWith('/')) {
              final uri = Uri.parse(currentUrl);
              currentUrl = '${uri.scheme}://${uri.host}$location';
            } else {
              currentUrl = location;
            }
            redirects++;
          } catch (e2) {
            break;
          }
        }
      }

      return currentUrl;
    } catch (e) {
      return cleanUrl;
    }
  }

  /// 获取当前使用的 API 源名称
  String get currentApiSourceName {
    final source = ApiSource.fromId(_apiSourceId);
    return source?.name ?? '内置解析器';
  }
}
