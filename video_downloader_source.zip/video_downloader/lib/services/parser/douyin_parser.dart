import 'dart:convert';
import 'package:dio/dio.dart';
import '../../models/video_info.dart';
import '../../utils/platform_detector.dart';
import 'base_parser.dart';
import '../proxy_service.dart';

/// 抖音解析器
///
/// 2024 年后抖音策略变化：
/// 1. 旧 API (iesdouyin.com/web/api/v2/aweme/iteminfo) 已下线，
///    返回 HTTP 200 但响应体为空（content-length: 0），1.3.0 版本依赖该接口故失效
/// 2. 分享页必须两步请求：先拿 ttwid Cookie，再带 Cookie 请求，
///    页面才会在 _ROUTER_DATA.loaderData['video_(id)/page'].videoInfoRes 嵌入数据
/// 3. 实测关键坑：iPhone Safari UA 请求只返回页面壳（不嵌数据），
///    Android Chrome UA 才会嵌入 videoInfoRes，因此 UA 必须以 Android 为主，
///    并做微信/iPhone UA 轮换兜底
/// 4. 图文作品 aweme_type=2：images[].url_list 为无水印图，
///    download_url_list 为带水印图；其 video.play_addr 是由图片合成的
///    假视频地址（video_id 参数是一个 CDN 图片 URL），必须以 images 优先
class DouyinParser extends BaseParser {
  final bool _isInjectedDio;
  Dio _dio;

  /// 用户手动设置的抖音 Cookie（如从 WebView 登录后提取）
  /// 非空时优先使用，跳过自动获取 Cookie 的步骤
  Map<String, String> _customCookies = {};

  /// [dio] 可注入自定义 Dio（测试用），默认自动创建
  DouyinParser({Dio? dio})
      : _dio = dio ?? Dio(_baseOptions),
        _isInjectedDio = dio != null;

  /// 基础配置，用于重建 Dio 实例（清除 Cookie 时保证状态干净）
  static final BaseOptions _baseOptions = BaseOptions(
    connectTimeout: const Duration(seconds: 15),
    receiveTimeout: const Duration(seconds: 20),
    validateStatus: (status) => status! < 500,
  );

  /// UA 轮换列表：Android 实测必出数据，微信 UA 次之，iPhone 兜底
  static const List<String> _userAgents = [
    'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
    'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36 MicroMessenger/8.0.47.2560(0x28001235)',
    'Mozilla/5.0 (Linux; Android 10; MI 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.99 Mobile Safari/537.36',
  ];

  @override
  String get platform => 'douyin';

  /// 设置用户自定义 Cookie（如从 WebView 登录后提取）
  /// 传入空 map 或 null 则清除自定义 Cookie，回退到自动获取模式
  void setCookies(Map<String, String>? cookies) {
    final wasEmpty = _customCookies.isEmpty;
    _customCookies = cookies ?? {};
    // 清除 Cookie 时重建 Dio 实例，确保 HttpClient 中残留的 Cookie 被清空
    // 避免之前请求中保存的风控 Cookie 等污染后续匿名模式请求
    // （注入的 Dio 不重建，以免影响测试）
    if (_customCookies.isEmpty && !wasEmpty && !_isInjectedDio) {
      _dio = Dio(_baseOptions);
    }
  }

  @override
  bool canParse(String url) {
    return PlatformDetector.detectPlatform(url) == VideoPlatform.douyin;
  }

  @override
  Future<VideoInfo> parse(String url) async {
    final cleanUrl = url.trim();

    // 第一步：短链接展开（可能多级跳转）
    var realUrl = cleanUrl;
    if (cleanUrl.contains('v.douyin.com')) {
      realUrl = await _expandShortLink(cleanUrl);
    }

    // 第二步：提取作品ID
    final itemId = _extractItemId(realUrl) ?? _extractItemId(cleanUrl);
    if (itemId == null) {
      throw ParseException('无法从链接中提取作品ID，请确认是抖音分享链接');
    }

    String? lastError;

    // 第三步：解析分享页（/share/video/ 路径对图文作品同样有效）
    try {
      final result = await _parseSharePage(itemId, 'video', realUrl);
      if (result != null) return result;
    } catch (e) {
      lastError = _cleanError(e);
    }

    // 第四步：尝试图文专用路径（note）
    try {
      final result = await _parseSharePage(itemId, 'note', realUrl);
      if (result != null) return result;
    } catch (e) {
      lastError ??= _cleanError(e);
    }

    throw ParseException(
      lastError ?? '解析失败，作品可能已被删除或设为私密',
    );
  }

  // ==================== 短链接展开（多级跳转） ====================

  Future<String> _expandShortLink(String url) async {
    var currentUrl = url;
    for (var hop = 0; hop < 3; hop++) {
      try {
        final response = await _dio.get(
          currentUrl,
          options: Options(
            followRedirects: false,
            headers: _headers(_userAgents.first),
          ),
        );
        var location = response.headers.value('location') ?? '';
        if (location.isEmpty) return currentUrl;
        if (location.startsWith('/')) {
          final uri = Uri.parse(currentUrl);
          location = '${uri.scheme}://${uri.host}$location';
        }
        currentUrl = location;
        // 已经到 iesdouyin/douyin 的详情页就停止
        if (_extractItemId(currentUrl) != null) return currentUrl;
      } catch (_) {
        return currentUrl;
      }
    }
    return currentUrl;
  }

  // ==================== 核心：两步 Cookie + 多UA 解析分享页 ====================

  /// 将 Cookie Map 转换为 Cookie header 字符串
  String _cookieMapToString(Map<String, String> cookies) {
    return cookies.entries.map((e) => '${e.key}=${e.value}').join('; ');
  }

  Future<VideoInfo?> _parseSharePage(
      String itemId, String kind, String sourceUrl) async {
    final shareUrl = 'https://www.iesdouyin.com/share/$kind/$itemId';

    // 如果有用户自定义 Cookie，优先使用
    if (_customCookies.isNotEmpty) {
      final customCookieStr = _cookieMapToString(_customCookies);
      for (final ua in _userAgents) {
        try {
          final response = await _dio.get(
            shareUrl,
            options: Options(
              headers: {..._headers(ua), 'Cookie': customCookieStr},
            ),
          );
          final html = response.data?.toString() ?? '';
          final info = _tryExtractFromHtml(html, sourceUrl);
          if (info != null) return info;

          // 检查是否被过滤
          final routerData = _extractRouterData(html);
          if (routerData != null) {
            final reason = _findFilterReason(routerData);
            if (reason != null) {
              // 内容不存在等明确错误：直接抛出（与 Cookie 无关）
              switch (reason) {
                case 'SYSTEM_ITEM_NOT_EXIST':
                case 'item_not_exist':
                  throw ParseException('作品不存在，可能已被删除或设为私密');
                case 'delete':
                  throw ParseException('作品已被作者删除');
                case 'reviewing':
                  throw ParseException('作品审核中，暂时无法解析');
                case 'blocked':
                case 'banned':
                  throw ParseException('作品已被封禁，无法解析');
                default:
                  // 其他异常原因：可能是 Cookie 问题，继续回退
                  break;
              }
            }
          }
        } on ParseException {
          rethrow; // 内容问题直接抛出
        } catch (_) {
          // 网络等异常，换下一个 UA 继续尝试
        }
      }
      // 自定义 Cookie 全部失败，回退到匿名模式继续尝试
    }

    // 匿名模式：两步 Cookie 逻辑
    for (final ua in _userAgents) {
      // 第一步请求：拿 Cookie（ttwid 等）
      String cookie = '';
      try {
        final first = await _dio.get(
          shareUrl,
          options: Options(headers: _headers(ua)),
        );
        final setCookies = first.headers['set-cookie'] ?? const <String>[];
        cookie = setCookies
            .map((c) => c.split(';').first.trim())
            .where((c) => c.contains('='))
            .join('; ');

        // 顺带尝试解析第一次响应（少数情况已含数据）
        final html1 = first.data?.toString() ?? '';
        final info = _tryExtractFromHtml(html1, sourceUrl);
        if (info != null) return info;
      } catch (_) {
        continue; // 换下一个 UA
      }

      if (cookie.isEmpty) continue; // 没 Cookie 大概率拿不到数据，换 UA

      // 第二步请求：带 Cookie，页面嵌入 videoInfoRes
      try {
        final second = await _dio.get(
          shareUrl,
          options: Options(
            headers: {..._headers(ua), 'Cookie': cookie},
          ),
        );
        final html2 = second.data?.toString() ?? '';
        final info = _tryExtractFromHtml(html2, sourceUrl);
        if (info != null) return info;

        // 数据没拿到：检查 filter_list 给出准确原因（服务端明确判定时直接抛错）
        final routerData = _extractRouterData(html2);
        if (routerData != null) {
          final reason = _findFilterReason(routerData);
          if (reason != null) {
            switch (reason) {
              case 'SYSTEM_ITEM_NOT_EXIST':
              case 'item_not_exist':
                throw ParseException('作品不存在，可能已被删除或设为私密');
              case 'delete':
                throw ParseException('作品已被作者删除');
              case 'reviewing':
                throw ParseException('作品审核中，暂时无法解析');
              case 'blocked':
              case 'banned':
                throw ParseException('作品已被封禁，无法解析');
              default:
                throw ParseException('抖音返回异常：$reason');
            }
          }
        }
      } catch (e) {
        if (e is ParseException) rethrow;
        // 网络异常，换下一个 UA 继续
      }
    }
    return null; // 所有 UA 都没拿到数据，让上层尝试另一种 kind
  }

  // ==================== HTML 数据提取 ====================

  /// 从页面 HTML 中提取作品数据（videoInfoRes / awemeDetail 等多种格式）
  VideoInfo? _tryExtractFromHtml(String html, String sourceUrl) {
    if (html.isEmpty) return null;

    final routerData = _extractRouterData(html);
    if (routerData != null) {
      // 优先查找 videoInfoRes（新格式，内含 item_list）
      final videoInfoRes = _deepFindKey(routerData, 'videoInfoRes');
      if (videoInfoRes is Map) {
        final itemList = videoInfoRes['item_list'];
        if (itemList is List && itemList.isNotEmpty) {
          return _parseAweme(itemList[0], sourceUrl);
        }
        // item_list 为空：可能是被过滤的内容，交给上层 filter_list 逻辑
      }

      // 兜底：深度查找 awemeDetail（部分版本使用）
      final awemeDetail = _deepFindKey(routerData, 'awemeDetail');
      if (awemeDetail is Map) {
        if (_looksLikeAweme(awemeDetail)) {
          return _parseAweme(awemeDetail, sourceUrl);
        }
        final inner = _deepFindKey(awemeDetail, 'aweme');
        if (inner is Map && _looksLikeAweme(inner)) {
          return _parseAweme(inner, sourceUrl);
        }
      }

      // 兜底：直接查找 item_list
      final itemList = _deepFindKey(routerData, 'item_list');
      if (itemList is List && itemList.isNotEmpty && itemList[0] is Map) {
        return _parseAweme(itemList[0], sourceUrl);
      }
    }
    return null;
  }

  /// 提取 _ROUTER_DATA JSON（括号配对法，避免正则贪婪/嵌套问题）
  Map<String, dynamic>? _extractRouterData(String html) {
    try {
      final marker = '_ROUTER_DATA';
      final start = html.indexOf(marker);
      if (start < 0) return null;
      final jsonStart = html.indexOf('{', start);
      if (jsonStart < 0) return null;

      final jsonStr = _extractBalancedJson(html, jsonStart);
      if (jsonStr == null) return null;

      final data = jsonDecode(jsonStr);
      return data is Map<String, dynamic> ? data : null;
    } catch (_) {
      return null;
    }
  }

  /// 括号配对提取完整 JSON（正确处理字符串内的花括号和转义）
  String? _extractBalancedJson(String text, int start) {
    var depth = 0;
    var inString = false;
    var escape = false;
    for (var i = start; i < text.length; i++) {
      final c = text[i];
      if (escape) {
        escape = false;
        continue;
      }
      if (inString) {
        if (c == '\\') {
          escape = true;
        } else if (c == '"') {
          inString = false;
        }
        continue;
      }
      if (c == '"') {
        inString = true;
      } else if (c == '{') {
        depth++;
      } else if (c == '}') {
        depth--;
        if (depth == 0) return text.substring(start, i + 1);
      }
    }
    return null;
  }

  /// 深度查找指定 key 的值（限制深度避免爆炸）
  dynamic _deepFindKey(dynamic data, String key, {int maxDepth = 8}) {
    return _deepFindKeyHelper(data, key, 0, maxDepth);
  }

  dynamic _deepFindKeyHelper(dynamic data, String key, int depth, int maxDepth) {
    if (depth > maxDepth) return null;
    if (data is Map) {
      if (data.containsKey(key)) return data[key];
      for (final value in data.values) {
        final result = _deepFindKeyHelper(value, key, depth + 1, maxDepth);
        if (result != null) return result;
      }
    } else if (data is List) {
      for (final item in data) {
        final result = _deepFindKeyHelper(item, key, depth + 1, maxDepth);
        if (result != null) return result;
      }
    }
    return null;
  }

  /// 查找 filter_list 中的 filter_reason
  String? _findFilterReason(Map<String, dynamic> routerData) {
    final filterList = _deepFindKey(routerData, 'filter_list');
    if (filterList is List && filterList.isNotEmpty) {
      final first = filterList[0];
      if (first is Map) {
        return first['filter_reason']?.toString();
      }
    }
    return null;
  }

  /// 判断对象是否是真正的 aweme（含 video 或 images 数据）
  bool _looksLikeAweme(dynamic data) {
    if (data is! Map) return false;
    if (data['video'] is Map) return true;
    final images = data['images'];
    if (images is List && images.isNotEmpty) return true;
    return false;
  }

  // ==================== ID 提取 ====================

  String? _extractItemId(String url) {
    final patterns = [
      RegExp(r'/video/(\d{15,25})'),
      RegExp(r'/note/(\d{15,25})'),
      RegExp(r'slides/(\d{15,25})'),
      RegExp(r'[?&](?:item_id|aweme_id|modal_id)=(\d{15,25})'),
      RegExp(r'/(\d{15,25})/?$'), // 长链末尾纯ID
    ];
    for (final p in patterns) {
      final m = p.firstMatch(url);
      if (m != null) return m.group(1);
    }
    // 兜底：去掉 query 后再匹配，避免误命中 query 参数中的数字
    final pathOnly = url.split('?').first;
    final fallbackMatch = RegExp(r'(\d{15,25})').firstMatch(pathOnly);
    if (fallbackMatch != null) return fallbackMatch.group(1);
    return null;
  }

  // ==================== aweme 数据解析 ====================

  VideoInfo _parseAweme(dynamic aweme, String sourceUrl) {
    final video = aweme['video'];
    final author = aweme['author'];
    final images = aweme['images'];

    // ---- 图文类型判断（images 非空即图文） ----
    List<String>? imageList;
    if (images is List && images.isNotEmpty) {
      imageList = <String>[];
      for (final img in images) {
        if (img is Map) {
          // url_list 为无水印图；download_url_list 为带水印图，不用
          final urlList = img['url_list'];
          if (urlList is List && urlList.isNotEmpty) {
            final picked = _pickBestImageUrl(
                urlList.map((e) => e.toString()).toList());
            if (picked != null) {
              imageList.add(picked);
              continue;
            }
          }
          final u = img['url'] ?? img['src'];
          if (u != null && u.toString().isNotEmpty) {
            imageList.add(u.toString());
          }
        } else if (img is String && img.isNotEmpty) {
          imageList.add(img);
        }
      }
      if (imageList.isEmpty) imageList = null;
    }
    final isImage = imageList != null && imageList.isNotEmpty;

    // ---- 视频地址（图文时 video.play_addr 是图片合成的假地址，跳过） ----
    String? videoUrl;
    String? videoUrlHd;

    if (!isImage && video is Map) {
      final playAddr = video['play_addr'];
      if (playAddr is Map) {
        final urls = playAddr['url_list'];
        if (urls is List && urls.isNotEmpty) {
          videoUrl = _dedupUrl(urls.first.toString());
          if (urls.length > 1) {
            videoUrlHd = _dedupUrl(urls.last.toString());
          }
        }
      }

      // bit_rate 里找更高清的（按码率排序取最高）
      final bitRate = video['bit_rate'];
      if (bitRate is List && bitRate.isNotEmpty) {
        final sorted = bitRate.whereType<Map>().toList()
          ..sort((a, b) {
            final ab = (a['bit_rate'] as num?)?.toInt() ?? 0;
            final bb = (b['bit_rate'] as num?)?.toInt() ?? 0;
            return bb.compareTo(ab);
          });
        for (final rate in sorted) {
          final addr = rate['play_addr'] ?? rate['download_addr'];
          if (addr is Map) {
            final urls = addr['url_list'];
            if (urls is List && urls.isNotEmpty) {
              final u = _dedupUrl(urls.first.toString());
              videoUrlHd ??= u;
              videoUrl ??= u;
              break;
            }
          }
        }
      }
    }

    // ---- 封面 ----
    String cover = '';
    if (isImage) {
      cover = imageList.first;
    } else if (video is Map) {
      for (final field in ['cover', 'origin_cover', 'dynamic_cover']) {
        final cv = video[field];
        if (cv is Map) {
          final urls = cv['url_list'];
          if (urls is List && urls.isNotEmpty) {
            cover = urls.first.toString();
            break;
          }
        }
      }
    }

    // ---- 基本信息 ----
    final id = aweme['aweme_id']?.toString() ??
        aweme['item_id']?.toString() ??
        DateTime.now().millisecondsSinceEpoch.toString();

    int? durationSeconds;
    if (!isImage && video is Map) {
      final d = video['duration'];
      if (d is int) durationSeconds = d ~/ 1000;
      if (d is String) durationSeconds = (int.tryParse(d) ?? 0) ~/ 1000;
    }

    return VideoInfo(
      id: id,
      url: sourceUrl,
      platform: 'douyin',
      title: _cleanTitle(aweme['desc']?.toString() ??
          aweme['item_title']?.toString() ??
          '无标题'),
      author: author is Map
          ? (author['nickname']?.toString() ?? '未知作者')
          : (aweme['author_name']?.toString() ?? '未知作者'),
      cover: cover,
      videoUrl: isImage ? null : videoUrl,
      videoUrlHd: isImage ? null : videoUrlHd,
      durationSeconds: durationSeconds,
      parsedAt: DateTime.now(),
      type: isImage ? 'image' : 'video',
      images: imageList,
    );
  }

  /// 图片地址优选：优先 jpeg/jpg（相册兼容性好），其次取最后一个
  /// 从 url_list 中挑选最优图片地址
  ///
  /// 优先级：动图（gif/webp）> 静态图（jpeg/jpg/png）> 其他
  /// 动图优先确保图文作品中的动图不会被静态封面图覆盖
  String? _pickBestImageUrl(List<String> urls) {
    // 第一优先级：动图（gif / webp）
    for (final u in urls) {
      final lower = u.toLowerCase();
      if (lower.contains('.gif') || lower.contains('.webp')) return u;
    }
    // 第二优先级：常见静态图格式
    for (final u in urls) {
      final lower = u.toLowerCase();
      if (lower.contains('.jpeg') ||
          lower.contains('.jpg') ||
          lower.contains('.png')) return u;
    }
    // 兜底：取最后一个（通常分辨率最高）
    return urls.isNotEmpty ? urls.last : null;
  }

  /// playwm → play：抖音无水印处理
  String _dedupUrl(String url) => url.replaceAll('/playwm/', '/play/');

  String _cleanTitle(String title) {
    var t = title.trim();
    if (t.isEmpty) return '无标题';
    if (t.length > 100) t = t.substring(0, 100);
    return t;
  }

  String _cleanError(Object e) {
    final msg = e.toString().replaceAll('ParseException: ', '');
    return msg.length > 100 ? '${msg.substring(0, 100)}...' : msg;
  }

  // ==================== Headers ====================

  Map<String, String> _headers(String ua) => {
        'User-Agent': ua,
        'Accept':
            'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'zh-CN,zh;q=0.9',
      };

  @override
  void applyProxy(ProxyService proxyService) {
    proxyService.applyToDio(_dio);
  }
}
