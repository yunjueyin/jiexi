import 'dart:convert';
import 'package:dio/dio.dart';
import '../../models/video_info.dart';
import 'base_parser.dart';
import '../proxy_service.dart';

/// 第三方解析 API 客户端
///
/// 采用「宽容解析」策略：不预设固定的响应格式，
/// 而是深度遍历 JSON，按字段名语义自动提取：
/// - 标题: desc / title / caption
/// - 作者: author.nickname / author.name / nickname / author_name
/// - 封面: cover / cover_url / coverUrl / origin_cover
/// - 视频地址: video_url / videoUrl / url / play_addr.url_list / download_addr
/// - 图集: images[].url_list / images[].url / images (string list)
class CustomApiParser extends BaseParser {
  final Dio _dio;
  final String apiUrl;

  /// API Key 参数名（作为 query 参数附加），为 null 则不附加
  final String? apiKeyParam;

  /// API Key 值
  final String? apiKey;

  CustomApiParser(
    this.apiUrl, {
    this.apiKeyParam,
    this.apiKey,
  }) : _dio = Dio(BaseOptions(
          connectTimeout: const Duration(seconds: 15),
          receiveTimeout: const Duration(seconds: 30),
          validateStatus: (status) => status! < 500,
        ));

  @override
  String get platform => 'custom';

  @override
  bool canParse(String url) => url.isNotEmpty;

  @override
  Future<VideoInfo> parse(String url) async {
    dynamic data;
    try {
      final queryParams = <String, dynamic>{'url': url};
      if (apiKeyParam != null && apiKey != null && apiKey!.isNotEmpty) {
        queryParams[apiKeyParam!] = apiKey;
      }
      final response = await _dio.get(
        apiUrl,
        queryParameters: queryParams,
        options: Options(
          headers: {
            'User-Agent':
                'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36',
            'Accept': 'application/json',
          },
        ),
      );

      data = response.data;
      if (data is String) {
        data = jsonDecode(data);
      }
    } on DioException catch (e) {
      final code = e.response?.statusCode;
      final body = e.response?.data?.toString() ?? '';
      var hint = '';
      if (body.contains('error') || body.contains('message')) {
        hint = body.length > 120 ? body.substring(0, 120) : body;
      }
      throw ParseException(
          'API请求失败(${code ?? '网络错误'})${hint.isEmpty ? '' : '：$hint'}');
    } catch (e) {
      throw ParseException('API响应解析失败：${e.toString()}');
    }

    if (data is! Map) {
      throw ParseException('API返回了无法识别的数据格式');
    }

    // 检查业务错误码（常见格式：code != 0/200 视为失败）
    final code = data['code'] ?? data['status'] ?? data['status_code'];
    if (code != null && code is num && code != 0 && code != 200) {
      final msg = data['message'] ?? data['msg'] ?? data['status_msg'] ?? '未知错误';
      throw ParseException('API返回错误($code)：$msg');
    }

    return _parseResponse(data, url);
  }

  VideoInfo _parseResponse(dynamic data, String originalUrl) {
    // ---- 平台识别 ----
    var platform = _detectPlatform(data, originalUrl);

    // ---- 深度提取各字段 ----
    final title = _findString(data, ['desc', 'title', 'caption', 'item_title']) ?? '无标题';
    final author = _findAuthor(data) ?? '未知作者';
    final cover = _findCover(data) ?? '';

    // ---- 图集优先判断 ----
    final imageList = _findImages(data);

    // ---- 视频地址 ----
    String? videoUrl = _findVideoUrl(data);

    if (imageList.isEmpty && (videoUrl == null || videoUrl.isEmpty)) {
      throw ParseException('API未返回有效的视频/图片地址');
    }

    final isImage = imageList.isNotEmpty && (videoUrl == null || videoUrl.isEmpty);

    return VideoInfo(
      id: _findString(data, ['aweme_id', 'item_id', 'photoId', 'photo_id', 'id']) ??
          DateTime.now().millisecondsSinceEpoch.toString(),
      url: originalUrl,
      platform: platform,
      title: title.length > 100 ? title.substring(0, 100) : title,
      author: author,
      cover: isImage && imageList.isNotEmpty ? (cover.isEmpty ? imageList.first : cover) : cover,
      videoUrl: isImage ? null : videoUrl,
      videoUrlHd: isImage ? null : _findVideoUrlHd(data, videoUrl),
      durationSeconds: _findDuration(data),
      parsedAt: DateTime.now(),
      type: isImage ? 'image' : 'video',
      images: imageList.isNotEmpty ? imageList : null,
    );
  }

  String _detectPlatform(dynamic data, String originalUrl) {
    // 从数据里找平台标识
    final p = _findString(data, ['platform']);
    if (p != null) {
      final lower = p.toLowerCase();
      if (lower.contains('douyin')) return 'douyin';
      if (lower.contains('kuaishou') || lower.contains('ks')) return 'kuaishou';
      if (lower.contains('xiaohongshu') || lower.contains('xhs')) return 'xiaohongshu';
    }
    // 从原始链接判断 —— 优先按 host 精确匹配
    try {
      final uri = Uri.parse(originalUrl);
      final host = uri.host.toLowerCase();
      if (host.contains('douyin.com') || host.contains('iesdouyin.com')) return 'douyin';
      if (host.contains('kuaishou.com') || host.contains('chenzhongtech.com')) return 'kuaishou';
      if (host.contains('xiaohongshu.com') || host.contains('xhslink.com')) return 'xiaohongshu';
      // host 匹配不上时，降级到 path contains 判断（兼容 API 网关路径带平台标识的场景）
      final path = uri.path.toLowerCase();
      if (path.contains('douyin')) return 'douyin';
      if (path.contains('kuaishou')) return 'kuaishou';
      if (path.contains('xiaohongshu') || path.contains('xhs')) return 'xiaohongshu';
    } catch (_) {
      // URL 解析失败时降级为全串 contains 判断
      final lowerUrl = originalUrl.toLowerCase();
      if (lowerUrl.contains('douyin')) return 'douyin';
      if (lowerUrl.contains('kuaishou') || lowerUrl.contains('chenzhongtech')) return 'kuaishou';
      if (lowerUrl.contains('xiaohongshu') || lowerUrl.contains('xhs')) return 'xiaohongshu';
    }
    return 'douyin';
  }

  /// 深度查找字符串字段（按候选 key 顺序）
  String? _findString(dynamic data, List<String> keys, {int depth = 0}) {
    if (depth > 8) return null;
    if (data is Map) {
      for (final key in keys) {
        final v = data[key];
        if (v is String && v.trim().isNotEmpty && !v.startsWith('http')) {
          return v.trim();
        }
      }
      // 深入一层查找（限定常见容器）
      for (final container in ['data', 'result', 'info', 'detail', 'item', 'photo', 'aweme']) {
        if (data.containsKey(container)) {
          final r = _findString(data[container], keys, depth: depth + 1);
          if (r != null) return r;
        }
      }
    }
    return null;
  }

  /// 查找作者名
  String? _findAuthor(dynamic data, {int depth = 0}) {
    if (depth > 8) return null;
    if (data is Map) {
      final author = data['author'];
      if (author is Map) {
        for (final key in ['nickname', 'name', 'nick_name', 'user_name']) {
          final v = author[key];
          if (v is String && v.isNotEmpty) return v;
        }
      }
      if (author is String && author.isNotEmpty) return author;
      for (final key in ['nickname', 'author_name', 'userName', 'nick_name']) {
        final v = data[key];
        if (v is String && v.isNotEmpty) return v;
      }
      for (final container in ['data', 'result', 'detail', 'item']) {
        if (data.containsKey(container)) {
          final r = _findAuthor(data[container], depth: depth + 1);
          if (r != null) return r;
        }
      }
    }
    return null;
  }

  /// 查找封面
  String? _findCover(dynamic data, {int depth = 0}) {
    if (depth > 8) return null;
    if (data is Map) {
      // 直接字符串字段
      for (final key in ['cover_url', 'coverUrl', 'origin_cover', 'cover', 'poster', 'thumbnail']) {
        final v = data[key];
        if (v is String && v.startsWith('http')) return v;
        if (v is List && v.isNotEmpty && v.first is String && (v.first as String).startsWith('http')) {
          return v.first;
        }
      }
      // video.cover.url_list 结构
      final video = data['video'];
      if (video is Map) {
        for (final key in ['cover', 'origin_cover', 'dynamic_cover']) {
          final cv = video[key];
          if (cv is Map) {
            final urls = cv['url_list'];
            if (urls is List && urls.isNotEmpty && urls.first is String) {
              return urls.first.toString();
            }
          }
        }
      }
      for (final container in ['data', 'result', 'detail', 'item', 'photo']) {
        if (data.containsKey(container)) {
          final r = _findCover(data[container], depth: depth + 1);
          if (r != null) return r;
        }
      }
    }
    return null;
  }

  /// 查找图集图片列表
  List<String> _findImages(dynamic data, {int depth = 0}) {
    if (depth > 8) return const [];
    if (data is Map) {
      final images = data['images'];
      final result = _extractImageUrlList(images);
      if (result.isNotEmpty) return result;

      // item_list / item.images 结构
      final itemList = data['item_list'];
      if (itemList is List && itemList.isNotEmpty && itemList[0] is Map) {
        final r = _extractImageUrlList(itemList[0]['images']);
        if (r.isNotEmpty) return r;
      }

      for (final container in ['data', 'result', 'detail', 'item', 'photo', 'aweme']) {
        if (data.containsKey(container)) {
          final r = _findImages(data[container], depth: depth + 1);
          if (r.isNotEmpty) return r;
        }
      }
    }
    return const [];
  }

  List<String> _extractImageUrlList(dynamic images) {
    final urls = <String>[];
    if (images is List) {
      for (final img in images) {
        if (img is String && img.startsWith('http')) {
          urls.add(img);
        } else if (img is Map) {
          final urlList = img['url_list'];
          if (urlList is List && urlList.isNotEmpty) {
            // 图文取最后一个（通常为原图）
            final last = urlList.last;
            if (last is String && last.startsWith('http')) {
              urls.add(last);
              continue;
            }
          }
          final u = img['url'] ?? img['cdnUrl'] ?? img['webpUrl'] ?? img['src'];
          if (u is String && u.startsWith('http')) urls.add(u);
        }
      }
    }
    return urls;
  }

  /// 查找视频地址
  String? _findVideoUrl(dynamic data, {int depth = 0}) {
    if (depth > 8) return null;
    if (data is Map) {
      // 顶层扁平字段
      for (final key in ['video_url', 'videoUrl', 'url', 'play_url', 'playUrl', 'nwm_url', 'no_watermark_url']) {
        final v = data[key];
        if (v is String && v.startsWith('http') && (v.contains('.mp4') || v.contains('play') || v.contains('video'))) {
          return v;
        }
      }
      // video.play_addr.url_list 结构
      final video = data['video'];
      if (video is Map) {
        for (final field in ['download_addr', 'play_addr']) {
          final addr = video[field];
          if (addr is Map) {
            final urls = addr['url_list'];
            if (urls is List && urls.isNotEmpty && urls.first is String) {
              return urls.first.toString();
            }
            final u = addr['url'];
            if (u is String && u.startsWith('http')) return u;
          }
        }
        // bit_rate
        final bitRate = video['bit_rate'];
        if (bitRate is List && bitRate.isNotEmpty && bitRate[0] is Map) {
          final addr = bitRate[0]['play_addr'];
          if (addr is Map) {
            final urls = addr['url_list'];
            if (urls is List && urls.isNotEmpty && urls.first is String) {
              return urls.first.toString();
            }
          }
        }
      }
      // mainMvUrls（快手）
      final mainMvUrls = data['mainMvUrls'];
      if (mainMvUrls is List && mainMvUrls.isNotEmpty && mainMvUrls[0] is Map) {
        final u = mainMvUrls[0]['url'];
        if (u is String && u.startsWith('http')) return u;
      }

      for (final container in ['data', 'result', 'detail', 'item', 'photo', 'aweme']) {
        if (data.containsKey(container)) {
          final r = _findVideoUrl(data[container], depth: depth + 1);
          if (r != null) return r;
        }
      }
    }
    return null;
  }

  String? _findVideoUrlHd(dynamic data, String? standardUrl) {
    final hd = _findStringHttp(data, ['video_url_hd', 'hd_url', 'hdUrl']);
    if (hd != null) return hd;
    if (standardUrl != null) {
      // 抖音 playwm→play 的地址通常同源，标记相同质量
      return null;
    }
    return null;
  }

  String? _findStringHttp(dynamic data, List<String> keys, {int depth = 0}) {
    if (depth > 6) return null;
    if (data is Map) {
      for (final key in keys) {
        final v = data[key];
        if (v is String && v.startsWith('http')) return v;
      }
      for (final container in ['data', 'result', 'detail', 'item', 'photo', 'video']) {
        if (data.containsKey(container)) {
          final r = _findStringHttp(data[container], keys, depth: depth + 1);
          if (r != null) return r;
        }
      }
    }
    return null;
  }

  int? _findDuration(dynamic data, {int depth = 0}) {
    if (depth > 6) return null;
    if (data is Map) {
      final d = data['duration'];
      if (d is int) {
        return _normalizeDuration(d);
      }
      final video = data['video'];
      if (video is Map && video['duration'] is int) {
        final dv = video['duration'] as int;
        return _normalizeDuration(dv);
      }
      for (final container in ['data', 'result', 'detail', 'item', 'photo']) {
        if (data.containsKey(container)) {
          final r = _findDuration(data[container], depth: depth + 1);
          if (r != null) return r;
        }
      }
    }
    return null;
  }

  /// 将 duration 统一为秒
  ///
  /// 判断逻辑（保守策略）：
  /// - duration <= 0：返回 null（无效值）
  /// - duration > 86400（一天的秒数）：认为是毫秒值，除以 1000
  /// - 否则：按秒处理，直接返回
  ///
  /// 这样长视频（如 3 小时 = 10800 秒）不会被误判为毫秒。
  int? _normalizeDuration(int duration) {
    if (duration <= 0) return null;
    if (duration > 86400) return duration ~/ 1000;
    return duration;
  }

  @override
  void applyProxy(ProxyService proxyService) {
    proxyService.applyToDio(_dio);
  }
}
