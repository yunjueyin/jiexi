import 'dart:io';
import 'package:dio/dio.dart';
import 'package:dio/io.dart';
import 'package:flutter/foundation.dart';

/// 代理配置服务
///
/// 功能：
/// - 管理全局代理配置
/// - 应用代理配置到 Dio 实例
/// - 测试代理连通性
/// - 通知监听者配置变更
class ProxyService extends ChangeNotifier {
  bool _enabled = false;
  String _type = 'http'; // http / https / socks5
  String _host = '';
  int _port = 8080;
  String? _username;
  String? _password;
  List<String> _bypassDomains = [];

  bool get enabled => _enabled;
  String get type => _type;
  String get host => _host;
  int get port => _port;
  String? get username => _username;
  String? get password => _password;
  List<String> get bypassDomains => List.unmodifiable(_bypassDomains);

  /// 更新代理配置
  void updateConfig({
    bool? enabled,
    String? type,
    String? host,
    int? port,
    String? username,
    String? password,
    List<String>? bypassDomains,
  }) {
    _enabled = enabled ?? _enabled;
    _type = type ?? _type;
    _host = host ?? _host;
    _port = port ?? _port;
    _username = username ?? _username;
    _password = password ?? _password;
    _bypassDomains = bypassDomains ?? _bypassDomains;
    notifyListeners();
  }

  /// 代理是否可用（配置有效且已开启）
  bool get isAvailable =>
      _enabled && _host.isNotEmpty && _port > 0;

  /// 获取代理地址字符串（如 "PROXY 127.0.0.1:8080"）
  String get _proxyString {
    if (!isAvailable) return 'DIRECT';
    switch (_type) {
      case 'https':
        return 'HTTPS $_host:$_port';
      case 'socks5':
        return 'SOCKS5 $_host:$_port';
      case 'http':
      default:
        return 'PROXY $_host:$_port';
    }
  }

  /// 判断指定 URL 是否应该绕过代理
  bool _shouldBypass(String url) {
    if (_bypassDomains.isEmpty) return false;
    try {
      final uri = Uri.parse(url);
      final host = uri.host.toLowerCase();
      for (final domain in _bypassDomains) {
        final d = domain.trim().toLowerCase();
        if (d.isEmpty) continue;
        if (host == d || host.endsWith('.$d')) {
          return true;
        }
      }
    } catch (_) {}
    return false;
  }

  /// 创建一个配置了代理的 Dio 实例
  Dio createDio([BaseOptions? options]) {
    final dio = Dio(options);
    applyToDio(dio);
    return dio;
  }

  /// 将当前代理配置应用到指定的 Dio 实例
  ///
  /// 支持 HTTP/HTTPS/SOCKS5 代理类型
  void applyToDio(Dio dio) {
    if (!isAvailable) {
      // 代理关闭，清除代理配置
      dio.httpClientAdapter = IOHttpClientAdapter(
        createHttpClient: () {
          final client = HttpClient();
          client.findProxy = (uri) => 'DIRECT';
          return client;
        },
      );
      return;
    }

    dio.httpClientAdapter = IOHttpClientAdapter(
      createHttpClient: () {
        final client = HttpClient();

        // 设置代理
        client.findProxy = (uri) {
          // 检查是否在绕过列表中
          if (_shouldBypass(uri.toString())) {
            return 'DIRECT';
          }
          return _proxyString;
        };

        // 代理认证（用户名密码）
        if (_username != null && _username!.isNotEmpty) {
          client.addProxyCredentials(
            _host,
            _port,
            'Basic',
            HttpClientBasicCredentials(_username!, _password ?? ''),
          );
        }

        return client;
      },
    );
  }

  /// 测试代理连通性
  ///
  /// 返回 (success, latencyMs, errorMessage)
  Future<(bool success, int latencyMs, String? error)> testConnection({
    String testUrl = 'https://www.google.com',
    Duration timeout = const Duration(seconds: 10),
  }) async {
    if (!isAvailable) {
      return (false, 0, '代理未启用或配置不完整');
    }

    final dio = createDio(BaseOptions(
      connectTimeout: timeout,
      receiveTimeout: timeout,
    ));

    final stopwatch = Stopwatch()..start();

    try {
      final response = await dio.head(testUrl);
      stopwatch.stop();
      final statusCode = response.statusCode ?? 0;
      if (statusCode >= 200 && statusCode < 500) {
        return (true, stopwatch.elapsedMilliseconds, null);
      }
      return (false, stopwatch.elapsedMilliseconds, '服务器返回状态码: $statusCode');
    } on DioException catch (e) {
      stopwatch.stop();
      final msg = e.message ?? '连接失败';
      return (false, stopwatch.elapsedMilliseconds, msg);
    } catch (e) {
      stopwatch.stop();
      return (false, stopwatch.elapsedMilliseconds, e.toString());
    } finally {
      dio.close();
    }
  }

  /// 获取当前代理状态描述
  String get statusText {
    if (!_enabled) return '未启用';
    if (_host.isEmpty) return '未配置地址';
    return '$_type://$_host:$_port';
  }
}
