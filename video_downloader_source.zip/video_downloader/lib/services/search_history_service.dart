import 'package:shared_preferences/shared_preferences.dart';

/// 搜索历史服务
///
/// 管理搜索历史记录的存储、读取、添加和删除。
/// 最多保留 20 条历史记录，按时间倒序排列（最新的在前）。
class SearchHistoryService {
  static const String _keySearchHistory = 'search_history';
  static const int _maxHistoryCount = 20;

  late SharedPreferences _prefs;
  List<String> _history = [];

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    _history = _prefs.getStringList(_keySearchHistory) ?? [];
  }

  /// 获取搜索历史列表（最新的在前）
  List<String> get history => List.unmodifiable(_history);

  /// 添加搜索历史
  ///
  /// 如果关键词已存在，将其移到最前面。
  /// 如果超过最大数量，删除最旧的记录。
  Future<void> addHistory(String keyword) async {
    final trimmed = keyword.trim();
    if (trimmed.isEmpty) return;

    // 移除已存在的相同关键词
    _history.remove(trimmed);
    // 插入到最前面
    _history.insert(0, trimmed);
    // 限制最大数量
    if (_history.length > _maxHistoryCount) {
      _history = _history.sublist(0, _maxHistoryCount);
    }
    await _prefs.setStringList(_keySearchHistory, _history);
  }

  /// 删除单条搜索历史
  Future<void> removeHistory(String keyword) async {
    _history.remove(keyword);
    await _prefs.setStringList(_keySearchHistory, _history);
  }

  /// 清空所有搜索历史
  Future<void> clearHistory() async {
    _history = [];
    await _prefs.remove(_keySearchHistory);
  }

  /// 是否有搜索历史
  bool get hasHistory => _history.isNotEmpty;
}
