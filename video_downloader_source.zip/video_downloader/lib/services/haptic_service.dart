import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../providers/settings_provider.dart';

/// 触觉反馈服务
///
/// 根据设置决定是否执行震动反馈
/// 使用前需要确保已经通过 [init] 传入了 SettingsProvider 上下文
/// 或者使用 [setSettings] 方法直接设置开关和强度
class HapticService {
  static bool _enabled = false;
  static String _level = 'medium';

  /// 从 SettingsProvider 初始化设置
  static void initFromProvider(SettingsProvider provider) {
    _enabled = provider.hapticFeedbackEnabled;
    _level = provider.hapticFeedbackLevel;
  }

  /// 直接设置触觉反馈参数
  static void setSettings({bool? enabled, String? level}) {
    if (enabled != null) _enabled = enabled;
    if (level != null) _level = level;
  }

  /// 轻量触觉反馈
  static void lightImpact() {
    if (!_enabled) return;
    HapticFeedback.lightImpact();
  }

  /// 中等触觉反馈
  static void mediumImpact() {
    if (!_enabled) return;
    HapticFeedback.mediumImpact();
  }

  /// 重度触觉反馈
  static void heavyImpact() {
    if (!_enabled) return;
    HapticFeedback.heavyImpact();
  }

  /// 根据当前设置的强度执行触觉反馈
  static void impact() {
    if (!_enabled) return;
    switch (_level) {
      case 'light':
        HapticFeedback.lightImpact();
        break;
      case 'heavy':
        HapticFeedback.heavyImpact();
        break;
      case 'medium':
      default:
        HapticFeedback.mediumImpact();
        break;
    }
  }

  /// 选择反馈（用于列表项点击等场景）
  static void selectionClick() {
    if (!_enabled) return;
    HapticFeedback.selectionClick();
  }

  /// 振动反馈
  static void vibrate() {
    if (!_enabled) return;
    HapticFeedback.vibrate();
  }
}
