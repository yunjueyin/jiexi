import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:quick_actions/quick_actions.dart';

/// 快捷方式导航目标
enum ShortcutAction {
  parse, // 一键解析
  crawl, // 批量抓取
  downloads, // 下载管理
}

/// 桌面快捷方式服务
///
/// 支持 Android App Shortcuts，提供三个快捷方式：
/// 1. 一键解析 - 打开首页并聚焦输入框
/// 2. 批量抓取 - 打开批量抓取页
/// 3. 下载管理 - 打开下载页
class QuickActionsService {
  static final QuickActionsService _instance = QuickActionsService._internal();
  factory QuickActionsService() => _instance;
  QuickActionsService._internal();

  final QuickActions _quickActions = const QuickActions();
  bool _initialized = false;

  /// 快捷方式点击事件流
  final StreamController<ShortcutAction> _actionController =
      StreamController<ShortcutAction>.broadcast();

  Stream<ShortcutAction> get onActionStream => _actionController.stream;

  /// 初始快捷方式（应用冷启动时的快捷方式）
  ShortcutAction? initialAction;

  /// 初始化快捷方式
  Future<void> init() async {
    if (_initialized) return;
    if (kIsWeb) return; // Web 平台不支持

    try {
      _quickActions.initialize((shortcutType) {
        final action = _parseActionType(shortcutType);
        if (action != null) {
          initialAction ??= action; // 记录第一个 action 作为初始动作
          _actionController.add(action);
        }
      });
      _initialized = true;
    } catch (e) {
      debugPrint('QuickActions init failed: $e');
    }
  }

  /// 解析快捷方式类型
  ShortcutAction? _parseActionType(String type) {
    switch (type) {
      case 'action_parse':
        return ShortcutAction.parse;
      case 'action_crawl':
        return ShortcutAction.crawl;
      case 'action_downloads':
        return ShortcutAction.downloads;
      default:
        return null;
    }
  }

  /// 设置所有快捷方式
  Future<void> setShortcuts() async {
    if (!_initialized) return;
    if (kIsWeb) return;

    try {
      await _quickActions.setShortcutItems(<ShortcutItem>[
        ShortcutItem(
          type: 'action_parse',
          localizedTitle: '一键解析',
          icon: 'ic_launcher',
        ),
        ShortcutItem(
          type: 'action_crawl',
          localizedTitle: '批量抓取',
          icon: 'ic_launcher',
        ),
        ShortcutItem(
          type: 'action_downloads',
          localizedTitle: '下载管理',
          icon: 'ic_launcher',
        ),
      ]);
    } catch (e) {
      debugPrint('QuickActions setShortcuts failed: $e');
    }
  }

  /// 清除所有快捷方式
  Future<void> clearShortcuts() async {
    if (!_initialized) return;
    if (kIsWeb) return;

    try {
      await _quickActions.clearShortcutItems();
    } catch (e) {
      debugPrint('QuickActions clearShortcuts failed: $e');
    }
  }

  /// 重置初始动作（在处理完初始导航后调用）
  void resetInitialAction() {
    initialAction = null;
  }
}
