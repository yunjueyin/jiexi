import 'package:flutter/foundation.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:uuid/uuid.dart';
import '../models/convert_queue_item.dart';
import 'convert_service.dart';

/// 转换队列服务
///
/// 管理链接转换队列，支持持久化存储，App 重启后可继续处理
class ConvertQueueService extends ChangeNotifier {
  static const String _boxName = 'convert_queue';
  Box<ConvertQueueItem>? _box;
  final ConvertService _convertService = ConvertService();
  final _uuid = const Uuid();

  /// 是否正在处理队列
  bool _isProcessing = false;
  bool get isProcessing => _isProcessing;

  /// 并发数
  final int concurrency = 2;

  /// 当前处理的任务索引
  int _currentTaskIndex = 0;

  bool get isInitialized => _box != null;

  Future<void> init() async {
    if (_box != null) return;
    try {
      _box = await Hive.openBox<ConvertQueueItem>(_boxName);
    } catch (e) {
      try {
        await Hive.deleteBoxFromDisk(_boxName);
        _box = await Hive.openBox<ConvertQueueItem>(_boxName);
      } catch (_) {
        rethrow;
      }
    }
  }

  /// 获取所有队列项（按创建时间升序）
  List<ConvertQueueItem> getAll() {
    if (_box == null) return [];
    final list = _box!.values.toList();
    list.sort((a, b) => a.createdAt.compareTo(b.createdAt));
    return list;
  }

  /// 获取待处理的任务
  List<ConvertQueueItem> get pendingItems {
    return getAll().where((item) => item.status == ConvertQueueStatus.pending).toList();
  }

  /// 获取正在处理的任务
  List<ConvertQueueItem> get processingItems {
    return getAll().where((item) => item.status == ConvertQueueStatus.processing).toList();
  }

  /// 获取已完成的任务
  List<ConvertQueueItem> get completedItems {
    return getAll().where((item) => item.status == ConvertQueueStatus.completed).toList();
  }

  /// 获取失败的任务
  List<ConvertQueueItem> get failedItems {
    return getAll().where((item) => item.status == ConvertQueueStatus.failed).toList();
  }

  /// 待处理数量
  int get pendingCount => pendingItems.length;

  /// 正在处理数量
  int get processingCount => processingItems.length;

  /// 已完成数量
  int get completedCount => completedItems.length;

  /// 失败数量
  int get failedCount => failedItems.length;

  /// 总数量
  int get totalCount => _box?.length ?? 0;

  /// 添加任务到队列
  Future<ConvertQueueItem> addTask({
    required String url,
    required ConvertQueueType type,
    String? videoTitle,
    String? source,
  }) async {
    if (_box == null) {
      throw StateError('ConvertQueueService not initialized');
    }
    final id = 'queue_${_uuid.v4()}';
    final item = ConvertQueueItem(
      id: id,
      originalUrl: url.trim(),
      convertType: type,
      videoTitle: videoTitle,
      source: source,
    );
    await _box!.put(id, item);
    notifyListeners();

    // 如果没有在处理中，启动处理
    if (!_isProcessing) {
      startProcessing();
    }
    return item;
  }

  /// 批量添加任务
  Future<List<ConvertQueueItem>> addTasks({
    required List<String> urls,
    required ConvertQueueType type,
    String? source,
  }) async {
    final items = <ConvertQueueItem>[];
    for (final url in urls) {
      if (url.trim().isEmpty) continue;
      final item = await addTask(url: url, type: type, source: source);
      items.add(item);
    }
    return items;
  }

  /// 删除任务
  Future<void> removeTask(String id) async {
    if (_box == null) return;
    await _box!.delete(id);
    notifyListeners();
  }

  /// 清除已完成的任务
  Future<void> clearCompleted() async {
    if (_box == null) return;
    final completedIds = completedItems.map((item) => item.id).toList();
    await _box!.deleteAll(completedIds);
    notifyListeners();
  }

  /// 清除所有任务
  Future<void> clearAll() async {
    if (_box == null) return;
    await _box!.clear();
    notifyListeners();
  }

  /// 重试失败的任务
  Future<void> retryFailed() async {
    if (_box == null) return;
    final failed = failedItems;
    for (final item in failed) {
      item.status = ConvertQueueStatus.pending;
      item.errorMessage = null;
      item.startedAt = null;
      item.completedAt = null;
      await item.save();
    }
    notifyListeners();

    if (!_isProcessing) {
      startProcessing();
    }
  }

  /// 开始处理队列
  void startProcessing() {
    if (_isProcessing) return;
    if (pendingItems.isEmpty && processingItems.isEmpty) return;

    _isProcessing = true;
    notifyListeners();

    _processQueue();
  }

  /// 暂停处理队列
  void pauseProcessing() {
    _isProcessing = false;
    notifyListeners();
  }

  /// 处理队列（内部方法）
  Future<void> _processQueue() async {
    while (_isProcessing && pendingItems.isNotEmpty) {
      final pending = pendingItems;
      if (pending.isEmpty) break;

      // 限制并发数
      final currentProcessing = processingItems.length;
      if (currentProcessing >= concurrency) {
        // 等待正在处理的任务完成
        await Future.delayed(const Duration(milliseconds: 200));
        continue;
      }

      // 取下一个待处理任务
      final nextTask = pending.first;
      await _processSingleTask(nextTask);
    }

    // 等待所有正在处理的任务完成
    while (_isProcessing && processingItems.isNotEmpty) {
      await Future.delayed(const Duration(milliseconds: 200));
    }

    _isProcessing = false;
    notifyListeners();
  }

  /// 处理单个任务
  Future<void> _processSingleTask(ConvertQueueItem task) async {
    // 更新状态为处理中
    task.status = ConvertQueueStatus.processing;
    task.startedAt = DateTime.now();
    await task.save();
    notifyListeners();

    try {
      late ConvertResultItem result;

      if (task.convertType == ConvertQueueType.toShort) {
        result = await _convertService.toShort(task.originalUrl);
      } else {
        result = await _convertService.toLong(task.originalUrl);
      }

      if (result.success) {
        task.status = ConvertQueueStatus.completed;
        task.resultUrl = result.resultUrl;
        task.platform = result.platform;
        task.completedAt = DateTime.now();
      } else {
        task.status = ConvertQueueStatus.failed;
        task.errorMessage = result.errorMessage;
        task.completedAt = DateTime.now();
      }
    } catch (e) {
      task.status = ConvertQueueStatus.failed;
      task.errorMessage = e.toString().replaceAll('Exception: ', '');
      task.completedAt = DateTime.now();
    }

    await task.save();
    notifyListeners();
  }

  /// 刷新队列（重新加载数据）
  Future<void> refresh() async {
    notifyListeners();
  }
}
