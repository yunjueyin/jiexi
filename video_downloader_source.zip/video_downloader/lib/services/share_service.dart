import 'dart:async';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';

/// 分享与剪贴板服务
///
/// 提供两种方式获取视频链接：
/// 1. 监听 App 生命周期，从后台回到前台时检测剪贴板
/// 2. 接收系统分享的文本（通过 MethodChannel 从原生层获取）
class ShareService with WidgetsBindingObserver {
  static const _channel = MethodChannel('com.example.video_downloader/share');

  final StreamController<String> _urlController = StreamController<String>.broadcast();
  String? _lastClipboardText;
  String? _lastDetectedUrl;
  bool _enabled = true;

  /// 接收到视频链接的 Stream
  Stream<String> get onUrlReceived => _urlController.stream;

  /// 是否启用剪贴板自动检测
  bool get enabled => _enabled;

  /// 上次检测到的视频链接
  String? get lastDetectedUrl => _lastDetectedUrl;

  /// 设置是否启用剪贴板检测
  set enabled(bool value) {
    _enabled = value;
  }

  /// 初始化服务
  Future<void> init() async {
    WidgetsBinding.instance.addObserver(this);
    // 初始检查一次剪贴板（注意：此时可能还没有订阅者，所以结果会缓存在 _lastDetectedUrl）
    await _checkClipboard(silent: true);
    // 检查初始分享（App 由分享启动）
    await _checkInitialShare();
  }

  /// 检查初始分享内容
  Future<void> _checkInitialShare() async {
    try {
      final result = await _channel.invokeMethod<String>('getInitialShare');
      if (result != null && result.isNotEmpty) {
        final url = _extractUrl(result);
        if (url != null) {
          _lastDetectedUrl = url;
          _urlController.add(url);
        }
      }
    } catch (_) {
      // MethodChannel 不可用，忽略
    }
  }

  /// 监听 App 生命周期变化
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && _enabled) {
      _checkClipboard();
    }
  }

  /// 检查剪贴板内容
  /// [silent] 为 true 时只更新缓存，不广播（用于初始化阶段）
  Future<void> _checkClipboard({bool silent = false}) async {
    try {
      final data = await Clipboard.getData('text/plain');
      final text = data?.text ?? '';

      // 如果内容和上次一样，跳过（避免重复提示）
      if (text == _lastClipboardText || text.isEmpty) {
        return;
      }

      _lastClipboardText = text;
      final url = _extractUrl(text);
      if (url != null && _isVideoUrl(url)) {
        _lastDetectedUrl = url;
        if (!silent) {
          _urlController.add(url);
        }
      }
    } catch (_) {
      // 忽略剪贴板错误
    }
  }

  /// 手动触发剪贴板检测，并返回检测到的 URL
  /// 用于页面初始化时主动获取剪贴板内容
  Future<String?> checkClipboardNow() async {
    try {
      final data = await Clipboard.getData('text/plain');
      final text = data?.text ?? '';
      if (text.isEmpty) return null;

      _lastClipboardText = text;
      final url = _extractUrl(text);
      if (url != null && _isVideoUrl(url)) {
        _lastDetectedUrl = url;
        return url;
      }
    } catch (_) {
      // 忽略剪贴板错误
    }
    return null;
  }

  /// 获取上次检测到的 URL（如果有）
  String? getLastUrl() {
    return _lastDetectedUrl;
  }

  /// 清除上次检测记录
  void clearLastUrl() {
    _lastDetectedUrl = null;
    _lastClipboardText = null;
  }

  /// 判断是否是支持的视频平台链接
  bool _isVideoUrl(String url) {
    return url.contains('douyin.com') ||
           url.contains('iesdouyin.com') ||
           url.contains('kuaishou.com') ||
           url.contains('gifshow.com') ||
           url.contains('xiaohongshu.com') ||
           url.contains('xhslink.com') ||
           url.contains('xhslink.cn');
  }

  /// 从文本中提取 URL
  String? _extractUrl(String text) {
    final regExp = RegExp(
      r'https?://[^\s]+',
      caseSensitive: false,
    );
    final match = regExp.firstMatch(text);
    return match?.group(0);
  }

  /// 销毁服务
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _urlController.close();
  }
}
