import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

/// 主题模式
enum AppThemeMode {
  /// 浅色
  light,

  /// 深色
  dark,

  /// 跟随系统
  system,

  /// 定时切换（日落后深色，日出后浅色）
  scheduled,
}

/// 主题模式扩展
extension AppThemeModeX on AppThemeMode {
  String get label {
    switch (this) {
      case AppThemeMode.light:
        return '浅色';
      case AppThemeMode.dark:
        return '深色';
      case AppThemeMode.system:
        return '跟随系统';
      case AppThemeMode.scheduled:
        return '定时切换';
    }
  }

  static AppThemeMode fromString(String? value) {
    switch (value) {
      case 'dark':
        return AppThemeMode.dark;
      case 'system':
        return AppThemeMode.system;
      case 'scheduled':
        return AppThemeMode.scheduled;
      case 'light':
      default:
        return AppThemeMode.light;
    }
  }

  String get storageValue {
    switch (this) {
      case AppThemeMode.light:
        return 'light';
      case AppThemeMode.dark:
        return 'dark';
      case AppThemeMode.system:
        return 'system';
      case AppThemeMode.scheduled:
        return 'scheduled';
    }
  }
}

/// 主题管理器
///
/// 支持跟随系统主题变化、定时切换深浅主题。
class ThemeManager {
  /// 当前是否为深色模式（计算后的值）
  static bool _isDark = false;

  /// 系统主题变化回调
  static VoidCallback? onSystemThemeChanged;

  /// 定时器（用于定时切换主题）
  static Timer? _scheduledTimer;

  /// 获取当前是否为深色模式
  static bool get isDark => _isDark;

  /// 根据设置计算当前是否应该使用深色模式
  static bool computeDarkMode({
    required String themeMode,
    required String sunsetTime,
    required String sunriseTime,
  }) {
    // OLED 纯黑模式也属于深色
    if (themeMode == 'oled') return true;

    final mode = AppThemeModeX.fromString(themeMode);

    switch (mode) {
      case AppThemeMode.light:
        return false;
      case AppThemeMode.dark:
        return true;
      case AppThemeMode.system:
        // 跟随系统
        final brightness = SchedulerBinding.instance.platformDispatcher.platformBrightness;
        return brightness == Brightness.dark;
      case AppThemeMode.scheduled:
        return _isScheduledDark(sunsetTime, sunriseTime);
    }
  }

  /// 判断当前时间是否在日落后（应使用深色模式）
  static bool _isScheduledDark(String sunsetTime, String sunriseTime) {
    final now = TimeOfDay.now();

    TimeOfDay parseTime(String timeStr) {
      final parts = timeStr.split(':');
      return TimeOfDay(
        hour: int.parse(parts[0]),
        minute: int.parse(parts[1]),
      );
    }

    final sunset = parseTime(sunsetTime);
    final sunrise = parseTime(sunriseTime);

    final nowMinutes = now.hour * 60 + now.minute;
    final sunsetMinutes = sunset.hour * 60 + sunset.minute;
    final sunriseMinutes = sunrise.hour * 60 + sunrise.minute;

    if (sunsetMinutes >= sunriseMinutes) {
      // 正常情况：日落 > 日出（比如 18:30 到 06:30 是晚上）
      // 晚上时段：日落时间到次日日出时间
      return nowMinutes >= sunsetMinutes || nowMinutes < sunriseMinutes;
    } else {
      // 异常情况：日落 < 日出（比如跨天设置）
      return nowMinutes >= sunsetMinutes && nowMinutes < sunriseMinutes;
    }
  }

  /// 更新当前深色模式状态
  static void updateDarkMode(bool isDark) {
    _isDark = isDark;
  }

  /// 启动定时主题切换检查
  ///
  /// 每分钟检查一次是否需要切换主题
  static void startScheduledCheck({
    required String themeMode,
    required String sunsetTime,
    required sunriseTime,
    required ValueChanged<bool> onThemeChanged,
  }) {
    _scheduledTimer?.cancel();

    if (AppThemeModeX.fromString(themeMode) != AppThemeMode.scheduled) {
      return;
    }

    // 立即检查一次
    final shouldBeDark = _isScheduledDark(sunsetTime, sunriseTime);
    if (shouldBeDark != _isDark) {
      _isDark = shouldBeDark;
      onThemeChanged(shouldBeDark);
    }

    // 每分钟检查一次
    _scheduledTimer = Timer.periodic(const Duration(minutes: 1), (_) {
      final shouldBeDark = _isScheduledDark(sunsetTime, sunriseTime);
      if (shouldBeDark != _isDark) {
        _isDark = shouldBeDark;
        onThemeChanged(shouldBeDark);
      }
    });
  }

  /// 停止定时检查
  static void stopScheduledCheck() {
    _scheduledTimer?.cancel();
    _scheduledTimer = null;
  }
}
