import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'package:intl/intl.dart';
import '../models/crawl_record.dart';
import '../models/video_info.dart';
import '../models/custom_api_source.dart';
import '../models/app_settings.dart';
import 'crawl_history_service.dart';
import 'history_service.dart';
import 'custom_source_service.dart';
import 'settings_service.dart';

/// 数据备份与恢复服务
///
/// 支持导出/导入全部应用数据，包括：
/// - 解析历史
/// - 抓取历史（含收藏）
/// - 自定义解析源
/// - 设置项
class DataBackupService {
  final CrawlHistoryService crawlHistoryService;
  final HistoryService historyService;
  final CustomSourceService customSourceService;
  final SettingsService settingsService;

  DataBackupService({
    required this.crawlHistoryService,
    required this.historyService,
    required this.customSourceService,
    required this.settingsService,
  });

  /// 导出全部数据为 JSON
  ///
  /// 返回备份文件路径
  Future<String> exportAllData() async {
    final backupData = <String, dynamic>{
      'version': 1,
      'exportedAt': DateTime.now().toIso8601String(),
      'exportType': 'full_backup',
      // 抓取历史
      'crawlHistory': _exportCrawlHistory(),
      // 解析历史
      'parseHistory': _exportParseHistory(),
      // 自定义源
      'customSources': _exportCustomSources(),
      // 设置
      'settings': _exportSettings(),
    };

    const encoder = JsonEncoder.withIndent('  ');
    final jsonStr = encoder.convert(backupData);

    // 保存到临时目录
    final tempDir = await getTemporaryDirectory();
    final fileName =
        'video_downloader_backup_${DateFormat('yyyyMMdd_HHmmss').format(DateTime.now())}.json';
    final filePath = '${tempDir.path}/$fileName';
    final file = File(filePath);
    await file.writeAsString(jsonStr);

    return filePath;
  }

  /// 从 JSON 文件导入数据
  ///
  /// [filePath] JSON 文件路径
  /// [mode] 导入模式：'merge'（合并，已存在的ID跳过）或 'overwrite'（覆盖，先清空再导入）
  ///
  /// 返回导入结果汇总
  Future<Map<String, dynamic>> importFromFile(
    String filePath, {
    String mode = 'merge',
    void Function(double progress)? onProgress,
  }) async {
    final result = <String, dynamic>{
      'success': true,
      'crawlHistoryImported': 0,
      'crawlHistorySkipped': 0,
      'parseHistoryImported': 0,
      'parseHistorySkipped': 0,
      'customSourcesImported': 0,
      'customSourcesSkipped': 0,
      'settingsImported': false,
      'error': null,
    };

    try {
      final file = File(filePath);
      final content = await file.readAsString();
      final data = jsonDecode(content) as Map<String, dynamic>;

      final totalSteps = 4;
      var currentStep = 0;

      // 覆盖模式：先清空
      if (mode == 'overwrite') {
        await crawlHistoryService.clearAll();
        // 解析历史清空
        try {
          final parseRecords = historyService.getAll();
          for (final r in parseRecords) {
            await historyService.remove(r.id);
          }
        } catch (_) {}
        // 自定义源清空
        try {
          final sources = customSourceService.getAll();
          for (final s in sources) {
            await customSourceService.remove(s.id);
          }
        } catch (_) {}
      }

      // 1. 导入抓取历史
      currentStep++;
      onProgress?.call(currentStep / totalSteps);
      if (data['crawlHistory'] != null) {
        final crawlResult = await _importCrawlHistory(
          List<Map<String, dynamic>>.from(data['crawlHistory']),
          mode: mode,
        );
        result['crawlHistoryImported'] = crawlResult['imported'];
        result['crawlHistorySkipped'] = crawlResult['skipped'];
      }

      // 2. 导入解析历史
      currentStep++;
      onProgress?.call(currentStep / totalSteps);
      if (data['parseHistory'] != null) {
        final parseResult = await _importParseHistory(
          List<Map<String, dynamic>>.from(data['parseHistory']),
          mode: mode,
        );
        result['parseHistoryImported'] = parseResult['imported'];
        result['parseHistorySkipped'] = parseResult['skipped'];
      }

      // 3. 导入自定义源
      currentStep++;
      onProgress?.call(currentStep / totalSteps);
      if (data['customSources'] != null) {
        final sourceResult = await _importCustomSources(
          List<Map<String, dynamic>>.from(data['customSources']),
          mode: mode,
        );
        result['customSourcesImported'] = sourceResult['imported'];
        result['customSourcesSkipped'] = sourceResult['skipped'];
      }

      // 4. 导入设置
      currentStep++;
      onProgress?.call(currentStep / totalSteps);
      if (data['settings'] != null) {
        final settingsImported = await _importSettings(
          Map<String, dynamic>.from(data['settings']),
        );
        result['settingsImported'] = settingsImported;
      }

      onProgress?.call(1.0);
    } catch (e) {
      result['success'] = false;
      result['error'] = e.toString();
      debugPrint('导入数据失败: $e');
    }

    return result;
  }

  /// 清除所有数据
  ///
  /// 包括：解析历史、抓取历史、自定义源
  /// 注意：设置项不清除
  Future<void> clearAllData() async {
    // 清空抓取历史
    await crawlHistoryService.clearAll();
    // 清空解析历史
    try {
      final records = historyService.getAll();
      for (final r in records) {
        await historyService.remove(r.id);
      }
    } catch (_) {}
    // 清空自定义源
    try {
      final sources = customSourceService.getAll();
      for (final s in sources) {
        await customSourceService.remove(s.id);
      }
    } catch (_) {}
  }

  // ==================== 导出方法 ====================

  List<Map<String, dynamic>> _exportCrawlHistory() {
    try {
      final records = crawlHistoryService.getAll();
      return records.map((r) => r.toJson()).toList();
    } catch (e) {
      debugPrint('导出抓取历史失败: $e');
      return [];
    }
  }

  List<Map<String, dynamic>> _exportParseHistory() {
    try {
      final records = historyService.getAll();
      return records.map((r) {
        return {
          'id': r.id,
          'url': r.url,
          'platform': r.platform,
          'title': r.title,
          'cover': r.cover,
          'videoUrl': r.videoUrl,
          'videoUrlHd': r.videoUrlHd,
          'author': r.author,
          'durationSeconds': r.durationSeconds,
          'parsedAt': r.parsedAt.toIso8601String(),
          'isFavorite': r.isFavorite,
          'favoritedAt': r.favoritedAt?.toIso8601String(),
          'favoriteFolderId': r.favoriteFolderId,
          'type': r.type,
          'images': r.images,
        };
      }).toList();
    } catch (e) {
      debugPrint('导出解析历史失败: $e');
      return [];
    }
  }

  List<Map<String, dynamic>> _exportCustomSources() {
    try {
      final sources = customSourceService.getAll();
      return sources.map((s) {
        return {
          'id': s.id,
          'name': s.name,
          'apiUrl': s.apiUrl,
          'method': s.method.name,
          'headersTemplate': s.headersTemplate,
          'bodyTemplate': s.bodyTemplate,
          'responsePath': s.responsePath,
          'priority': s.priority,
          'weight': s.weight,
          'supportedPlatforms': s.supportedPlatforms,
          'enabled': s.enabled,
          'apiKeyParam': s.apiKeyParam,
          'apiKey': s.apiKey,
          'remark': s.remark,
          'isBuiltIn': s.isBuiltIn,
          'lastUsedAt': s.lastUsedAt?.toIso8601String(),
          'createdAt': s.createdAt.toIso8601String(),
        };
      }).toList();
    } catch (e) {
      debugPrint('导出自定义源失败: $e');
      return [];
    }
  }

  Map<String, dynamic> _exportSettings() {
    try {
      final settings = settingsService.getSettings();
      return {
        'defaultQuality': settings.defaultQuality,
        'customApiUrl': settings.customApiUrl,
        'apiSourceId': settings.apiSourceId,
        'downloadPath': settings.downloadPath,
        'wifiOnly': settings.wifiOnly,
        'autoParseClipboard': settings.autoParseClipboard,
        'autoDownloadOnShare': settings.autoDownloadOnShare,
        'uidResolveServiceUrl': settings.uidResolveServiceUrl,
        'downloadSoundEnabled': settings.downloadSoundEnabled,
        'downloadSoundType': settings.downloadSoundType,
        'downloadCompleteAction': settings.downloadCompleteAction,
        'organizeByPlatform': settings.organizeByPlatform,
        'hapticFeedbackEnabled': settings.hapticFeedbackEnabled,
        'hapticFeedbackLevel': settings.hapticFeedbackLevel,
        'downloadNotificationEnabled': settings.downloadNotificationEnabled,
        'autoPasteAndDownload': settings.autoPasteAndDownload,
        'clipboardDetectionEnabled': settings.clipboardDetectionEnabled,
        'crawlIntervalMs': settings.crawlIntervalMs,
        'crawlJitterMs': settings.crawlJitterMs,
        'uiDensity': settings.uiDensity,
        'parseRetryCount': settings.parseRetryCount,
        'crawlRetryCount': settings.crawlRetryCount,
        'downloadConcurrency': settings.downloadConcurrency,
        'themeMode': settings.themeMode,
        'themeColor': settings.themeColor,
        'autoRetryOnFailure': settings.autoRetryOnFailure,
        'maxRetryCount': settings.maxRetryCount,
        'compactListMode': settings.compactListMode,
        'largeFontMode': settings.largeFontMode,
      };
    } catch (e) {
      debugPrint('导出设置失败: $e');
      return {};
    }
  }

  // ==================== 导入方法 ====================

  Future<Map<String, int>> _importCrawlHistory(
    List<Map<String, dynamic>> records, {
    required String mode,
  }) async {
    var imported = 0;
    var skipped = 0;

    for (final json in records) {
      try {
        final id = json['id'] as String;
        // 合并模式：已存在则跳过
        if (mode == 'merge' && crawlHistoryService.getById(id) != null) {
          skipped++;
          continue;
        }

        final record = CrawlRecord(
          id: id,
          url: json['url'] ?? '',
          platform: json['platform'] ?? 'unknown',
          crawlType: json['crawlType'] ?? 'video',
          crawledAt: DateTime.tryParse(json['crawledAt'] ?? '') ?? DateTime.now(),
          data: Map<String, dynamic>.from(json['data'] ?? {}),
          rawData: json['rawData'] != null
              ? Map<String, dynamic>.from(json['rawData'])
              : null,
          batchId: json['batchId'],
          batchTotal: json['batchTotal'] ?? 0,
          batchCompleted: json['batchCompleted'] ?? 0,
          batchCursor: json['batchCursor'],
          batchUrls: json['batchUrls'] != null
              ? List<String>.from(json['batchUrls'])
              : null,
          batchCurrentIndex: json['batchCurrentIndex'] ?? 0,
          batchFields: json['batchFields'] != null
              ? List<String>.from(json['batchFields'])
              : null,
          batchIsAuthor: json['batchIsAuthor'],
          batchStatus: json['batchStatus'],
          isFavorite: json['isFavorite'] ?? false,
          favoritedAt: json['favoritedAt'] != null
              ? DateTime.tryParse(json['favoritedAt'])
              : null,
          favoriteFolderId: json['favoriteFolderId'],
        );
        await crawlHistoryService.addRecord(record);
        imported++;
      } catch (e) {
        skipped++;
        debugPrint('导入抓取历史记录失败: $e');
      }
    }

    return {'imported': imported, 'skipped': skipped};
  }

  Future<Map<String, int>> _importParseHistory(
    List<Map<String, dynamic>> records, {
    required String mode,
  }) async {
    var imported = 0;
    var skipped = 0;

    for (final json in records) {
      try {
        final id = json['id'] as String;
        // 合并模式：已存在则跳过
        if (mode == 'merge') {
          try {
            final existing = historyService.getById(id);
            if (existing != null) {
              skipped++;
              continue;
            }
          } catch (_) {}
        }

        final videoInfo = VideoInfo(
          id: id,
          url: json['url'] ?? '',
          platform: json['platform'] ?? 'unknown',
          title: json['title'] ?? '',
          cover: json['cover'] ?? '',
          videoUrl: json['videoUrl'],
          videoUrlHd: json['videoUrlHd'],
          author: json['author'] ?? '',
          durationSeconds: json['durationSeconds'] ?? 0,
          parsedAt:
              DateTime.tryParse(json['parsedAt'] ?? '') ?? DateTime.now(),
          isFavorite: json['isFavorite'] ?? false,
          favoritedAt: json['favoritedAt'] != null
              ? DateTime.tryParse(json['favoritedAt'])
              : null,
          favoriteFolderId: json['favoriteFolderId'],
          type: json['type'] ?? 'video',
          images: json['images'] != null
              ? List<String>.from(json['images'])
              : null,
        );
        await historyService.add(videoInfo);
        imported++;
      } catch (e) {
        skipped++;
        debugPrint('导入解析历史记录失败: $e');
      }
    }

    return {'imported': imported, 'skipped': skipped};
  }

  Future<Map<String, int>> _importCustomSources(
    List<Map<String, dynamic>> sources, {
    required String mode,
  }) async {
    var imported = 0;
    var skipped = 0;

    for (final json in sources) {
      try {
        final id = json['id'] as String;
        // 合并模式：已存在则跳过
        if (mode == 'merge') {
          try {
            final existing = customSourceService.getById(id);
            if (existing != null) {
              skipped++;
              continue;
            }
          } catch (_) {}
        }

        final methodStr = json['method'] ?? 'get';
        final method = HttpRequestMethod.values.firstWhere(
          (m) => m.name == methodStr,
          orElse: () => HttpRequestMethod.get,
        );
        final source = CustomApiSource(
          id: id,
          name: json['name'] ?? '',
          apiUrl: json['apiUrl'] ?? '',
          method: method,
          headersTemplate: json['headersTemplate'],
          bodyTemplate: json['bodyTemplate'],
          responsePath: json['responsePath'],
          priority: json['priority'] ?? 100,
          weight: json['weight'] ?? 1,
          supportedPlatforms: json['supportedPlatforms'] != null
              ? List<String>.from(json['supportedPlatforms'])
              : const ['douyin', 'kuaishou'],
          enabled: json['enabled'] ?? true,
          apiKeyParam: json['apiKeyParam'],
          apiKey: json['apiKey'],
          remark: json['remark'],
          isBuiltIn: json['isBuiltIn'] ?? false,
          lastUsedAt: json['lastUsedAt'] != null
              ? DateTime.tryParse(json['lastUsedAt'])
              : null,
          createdAt:
              DateTime.tryParse(json['createdAt'] ?? '') ?? DateTime.now(),
        );
        await customSourceService.add(source);
        imported++;
      } catch (e) {
        skipped++;
        debugPrint('导入自定义源失败: $e');
      }
    }

    return {'imported': imported, 'skipped': skipped};
  }

  Future<bool> _importSettings(Map<String, dynamic> settings) async {
    try {
      // 设置项通过 settingsService 设置
      // 注意：只导入部分关键设置，避免导入敏感信息（如 API Key）
      if (settings.containsKey('defaultQuality')) {
        await settingsService.setDefaultQuality(settings['defaultQuality']);
      }
      if (settings.containsKey('apiSourceId')) {
        await settingsService.setApiSourceId(settings['apiSourceId']);
      }
      if (settings.containsKey('wifiOnly') != null) {
        await settingsService.setWifiOnly(settings['wifiOnly'] ?? false);
      }
      if (settings.containsKey('autoParseClipboard') != null) {
        await settingsService
            .setAutoParseClipboard(settings['autoParseClipboard'] ?? false);
      }
      if (settings.containsKey('crawlIntervalMs') != null) {
        await settingsService
            .setCrawlIntervalMs(settings['crawlIntervalMs'] ?? 1000);
      }
      if (settings.containsKey('crawlJitterMs') != null) {
        await settingsService
            .setCrawlJitterMs(settings['crawlJitterMs'] ?? 500);
      }
      if (settings.containsKey('uiDensity')) {
        await settingsService.setUiDensity(settings['uiDensity'] ?? 'standard');
      }
      if (settings.containsKey('themeMode')) {
        await settingsService.setThemeMode(settings['themeMode'] ?? 'light');
      }
      if (settings.containsKey('themeColor')) {
        await settingsService.setThemeColor(settings['themeColor'] ?? 'cyan');
      }
      if (settings.containsKey('autoRetryOnFailure')) {
        await settingsService
            .setAutoRetryOnFailure(settings['autoRetryOnFailure'] ?? true);
      }
      if (settings.containsKey('maxRetryCount')) {
        await settingsService
            .setMaxRetryCount(settings['maxRetryCount'] ?? 3);
      }
      if (settings.containsKey('compactListMode')) {
        await settingsService
            .setCompactListMode(settings['compactListMode'] ?? false);
      }
      if (settings.containsKey('largeFontMode')) {
        await settingsService
            .setLargeFontMode(settings['largeFontMode'] ?? false);
      }
      return true;
    } catch (e) {
      debugPrint('导入设置失败: $e');
      return false;
    }
  }
}
