import 'dart:async';
import 'package:sensors_plus/sensors_plus.dart';
import 'package:flutter/services.dart';

/// 摇一摇检测服务
///
/// 监听加速度传感器，检测用户摇一摇手机的动作。
/// 使用前需要调用 [startListening] 开始监听，
/// 不再使用时调用 [stopListening] 停止监听以节省电量。
class ShakeService {
  /// 摇一摇阈值（加速度变化量，m/s²）
  static const double _shakeThreshold = 15.0;

  /// 两次摇一摇之间的最小间隔（毫秒），防止连续触发
  static const int _minShakeIntervalMs = 1500;

  /// 是否正在监听
  bool _isListening = false;

  /// 上一次触发摇一摇的时间
  int _lastShakeTime = 0;

  /// 上一次的加速度值
  double _lastX = 0.0;
  double _lastY = 0.0;
  double _lastZ = 0.0;

  /// 是否有上一次的值（用于跳过第一次采样）
  bool _hasLastValue = false;

  /// 摇一摇事件流控制器
  final StreamController<void> _shakeController = StreamController<void>.broadcast();

  /// 加速度传感器订阅
  StreamSubscription<AccelerometerEvent>? _accelerometerSubscription;

  /// 摇一摇事件流
  Stream<void> get onShake => _shakeController.stream;

  /// 是否正在监听
  bool get isListening => _isListening;

  /// 开始监听摇一摇
  ///
  /// 调用后会开始监听加速度传感器，当检测到摇一摇动作时，
  /// 会通过 [onShake] 流发送事件。
  void startListening() {
    if (_isListening) return;

    _isListening = true;
    _hasLastValue = false;

    _accelerometerSubscription = accelerometerEventStream().listen(
      (AccelerometerEvent event) {
        if (!_hasLastValue) {
          _lastX = event.x;
          _lastY = event.y;
          _lastZ = event.z;
          _hasLastValue = true;
          return;
        }

        // 计算加速度变化量
        final deltaX = (event.x - _lastX).abs();
        final deltaY = (event.y - _lastY).abs();
        final deltaZ = (event.z - _lastZ).abs();

        // 总变化量
        final totalDelta = deltaX + deltaY + deltaZ;

        // 更新上一次的值
        _lastX = event.x;
        _lastY = event.y;
        _lastZ = event.z;

        // 检测是否达到摇一摇阈值
        if (totalDelta >= _shakeThreshold) {
          final now = DateTime.now().millisecondsSinceEpoch;
          if (now - _lastShakeTime > _minShakeIntervalMs) {
            _lastShakeTime = now;
            _shakeController.add(null);
          }
        }
      },
      onError: (_) {
        // 忽略传感器错误
      },
    );
  }

  /// 停止监听摇一摇
  void stopListening() {
    if (!_isListening) return;

    _accelerometerSubscription?.cancel();
    _accelerometerSubscription = null;
    _isListening = false;
    _hasLastValue = false;
  }

  /// 触发震动反馈（轻量）
  static void vibrateLight() {
    HapticFeedback.lightImpact();
  }

  /// 触发震动反馈（中等）
  static void vibrateMedium() {
    HapticFeedback.mediumImpact();
  }

  /// 释放资源
  void dispose() {
    stopListening();
    _shakeController.close();
  }
}
