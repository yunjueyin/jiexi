import 'dart:io';
import 'package:hive/hive.dart';
import '../models/transcode_task.dart';

/// 转码服务
///
/// 提供视频/音频格式转换和压缩功能。
///
/// 注意：当前版本使用简化实现（文件复制+重命名），
/// 后续可接入 ffmpeg_kit_flutter 实现真实转码。
/// 接口设计已预留 ffmpeg 集成位置。
class TranscodeService {
  static const String _boxName = 'transcode_tasks';
  Box<TranscodeTask>? _box;

  List<TranscodeTask> _tasks = [];
  final Set<String> _activeTasks = {};
  final Map<String, bool> _cancelFlags = {};

  /// 支持的视频格式
  static const List<String> supportedVideoFormats = ['mp4', 'mov', 'mkv', 'avi'];

  /// 支持的音频格式
  static const List<String> supportedAudioFormats = ['mp3', 'aac', 'm4a', 'wav'];

  /// 支持的分辨率
  static const List<String> supportedResolutions = ['original', '720p', '480p', '360p'];

  /// 进度回调
  Function(TranscodeTask)? onProgress;
  Function(TranscodeTask)? onComplete;
  Function(TranscodeTask, String)? onError;

  /// 初始化持久化存储
  Future<void> init() async {
    _box ??= await Hive.openBox<TranscodeTask>(_boxName);
    _tasks = _box!.values.toList();
    _tasks.sort((a, b) => b.createdAt.compareTo(a.createdAt));

    // 上次退出时正在处理的任务标记为失败
    for (final task in _tasks) {
      if (task.status == TranscodeStatus.processing ||
          task.status == TranscodeStatus.queued) {
        task.status = TranscodeStatus.failed;
        task.errorMessage = '转码中断，请重新开始';
      }
    }
    if (_box != null) {
      for (final task in _tasks) {
        await _box!.put(task.id, task);
      }
    }
  }

  List<TranscodeTask> get tasks => List.unmodifiable(_tasks);

  /// 保存任务
  Future<void> _saveTask(TranscodeTask task) async {
    try {
      await _box?.put(task.id, task);
    } catch (_) {}
  }

  /// 删除任务
  Future<void> _deleteTask(String taskId) async {
    try {
      await _box?.delete(taskId);
    } catch (_) {}
  }

  /// 创建视频格式转换任务
  Future<TranscodeTask> createVideoConvertTask({
    required String sourcePath,
    required String outputDir,
    required String targetFormat,
    String? videoCover,
    String? videoTitle,
  }) async {
    final sourceFile = File(sourcePath);
    if (!await sourceFile.exists()) {
      throw Exception('源文件不存在');
    }

    final sourceFileName = sourceFile.uri.pathSegments.last;
    final baseName = sourceFileName.replaceAll(RegExp(r'\.[^.]+$'), '');
    final outputFileName = '$baseName.$targetFormat';
    final outputPath = '$outputDir/$outputFileName';

    final task = TranscodeTask(
      id: 'tc_${DateTime.now().millisecondsSinceEpoch}',
      sourcePath: sourcePath,
      outputPath: outputPath,
      sourceFileName: sourceFileName,
      outputFileName: outputFileName,
      transcodeType: 'video',
      targetFormat: targetFormat,
      createdAt: DateTime.now(),
      sourceSizeBytes: await sourceFile.length(),
      videoCover: videoCover,
      videoTitle: videoTitle,
    );

    _tasks.insert(0, task);
    _saveTask(task);
    _processQueue();

    return task;
  }

  /// 创建音频格式转换任务
  Future<TranscodeTask> createAudioConvertTask({
    required String sourcePath,
    required String outputDir,
    required String targetFormat,
    String? videoCover,
    String? videoTitle,
  }) async {
    final sourceFile = File(sourcePath);
    if (!await sourceFile.exists()) {
      throw Exception('源文件不存在');
    }

    final sourceFileName = sourceFile.uri.pathSegments.last;
    final baseName = sourceFileName.replaceAll(RegExp(r'\.[^.]+$'), '');
    final outputFileName = '$baseName.$targetFormat';
    final outputPath = '$outputDir/$outputFileName';

    final task = TranscodeTask(
      id: 'tc_${DateTime.now().millisecondsSinceEpoch}',
      sourcePath: sourcePath,
      outputPath: outputPath,
      sourceFileName: sourceFileName,
      outputFileName: outputFileName,
      transcodeType: 'audio',
      targetFormat: targetFormat,
      createdAt: DateTime.now(),
      sourceSizeBytes: await sourceFile.length(),
      videoCover: videoCover,
      videoTitle: videoTitle,
    );

    _tasks.insert(0, task);
    _saveTask(task);
    _processQueue();

    return task;
  }

  /// 创建视频压缩任务
  Future<TranscodeTask> createVideoCompressTask({
    required String sourcePath,
    required String outputDir,
    required String targetFormat,
    String resolution = '720p',
    int? bitrate,
    String? videoCover,
    String? videoTitle,
  }) async {
    final sourceFile = File(sourcePath);
    if (!await sourceFile.exists()) {
      throw Exception('源文件不存在');
    }

    final sourceFileName = sourceFile.uri.pathSegments.last;
    final baseName = sourceFileName.replaceAll(RegExp(r'\.[^.]+$'), '');
    final outputFileName = '${baseName}_$resolution.$targetFormat';
    final outputPath = '$outputDir/$outputFileName';

    final task = TranscodeTask(
      id: 'tc_${DateTime.now().millisecondsSinceEpoch}',
      sourcePath: sourcePath,
      outputPath: outputPath,
      sourceFileName: sourceFileName,
      outputFileName: outputFileName,
      transcodeType: 'videoCompress',
      targetFormat: targetFormat,
      targetResolution: resolution,
      targetBitrate: bitrate,
      createdAt: DateTime.now(),
      sourceSizeBytes: await sourceFile.length(),
      videoCover: videoCover,
      videoTitle: videoTitle,
    );

    _tasks.insert(0, task);
    _saveTask(task);
    _processQueue();

    return task;
  }

  void _processQueue() {
    final queuedTasks = _tasks.where((t) => t.status == TranscodeStatus.queued).toList();
    for (var task in queuedTasks) {
      if (_activeTasks.isNotEmpty) break; // 简化版：一次只处理一个任务
      _startTranscode(task);
    }
  }

  /// 执行转码（简化实现：文件复制+重命名，模拟进度）
  Future<void> _startTranscode(TranscodeTask task) async {
    if (_activeTasks.contains(task.id)) return;
    _activeTasks.add(task.id);
    _cancelFlags[task.id] = false;

    task.status = TranscodeStatus.processing;
    task.progress = 0.0;
    _saveTask(task);
    onProgress?.call(task);

    try {
      final sourceFile = File(task.sourcePath);
      final outputFile = File(task.outputPath);

      // 确保输出目录存在
      final outputDir = Directory(outputFile.parent.path);
      if (!await outputDir.exists()) {
        await outputDir.create(recursive: true);
      }

      // 简化实现：模拟转码进度，实际是文件复制
      // 真实场景下这里应该调用 ffmpeg_kit_flutter
      final fileSize = await sourceFile.length();
      final chunkSize = fileSize ~/ 20; // 分成 20 段模拟进度

      final rafSource = await sourceFile.open();
      final rafOutput = await outputFile.open(mode: FileMode.write);

      try {
        int bytesProcessed = 0;
        while (bytesProcessed < fileSize) {
          // 检查是否被取消
          if (_cancelFlags[task.id] == true) {
            throw _TranscodeCancelException();
          }

          final remaining = fileSize - bytesProcessed;
          final readSize = remaining < chunkSize ? remaining : chunkSize;

          final chunk = await rafSource.read(readSize);
          await rafOutput.writeFrom(chunk);

          bytesProcessed += readSize;
          task.progress = bytesProcessed / fileSize;
          _saveTask(task);
          onProgress?.call(task);

          // 模拟转码耗时（让进度可见）
          await Future.delayed(const Duration(milliseconds: 50));
        }
      } finally {
        await rafSource.close();
        await rafOutput.close();
      }

      // 转码完成
      task.status = TranscodeStatus.completed;
      task.progress = 1.0;
      task.completedAt = DateTime.now();
      task.outputSizeBytes = await outputFile.length();
      _saveTask(task);
      onComplete?.call(task);
    } on _TranscodeCancelException {
      task.status = TranscodeStatus.canceled;
      task.errorMessage = '已取消';
      _saveTask(task);

      // 清理不完整的输出文件
      try {
        final outputFile = File(task.outputPath);
        if (await outputFile.exists()) {
          await outputFile.delete();
        }
      } catch (_) {}

      onProgress?.call(task);
    } catch (e) {
      task.status = TranscodeStatus.failed;
      task.errorMessage = e.toString().replaceAll('Exception: ', '');
      _saveTask(task);
      onError?.call(task, task.errorMessage!);
    } finally {
      _activeTasks.remove(task.id);
      _cancelFlags.remove(task.id);
      _processQueue();
    }
  }

  /// 取消转码任务
  void cancelTask(String taskId) {
    final task = _tasks.firstWhere((t) => t.id == taskId, orElse: () => throw '任务不存在');
    if (task.status == TranscodeStatus.processing) {
      _cancelFlags[taskId] = true;
    } else if (task.status == TranscodeStatus.queued) {
      task.status = TranscodeStatus.canceled;
      _saveTask(task);
      onProgress?.call(task);
    }
  }

  /// 删除转码任务
  void removeTask(String taskId, {bool deleteFile = false}) {
    final task = _tasks.firstWhere((t) => t.id == taskId, orElse: () => throw '任务不存在');
    if (task.status == TranscodeStatus.processing) {
      _cancelFlags[taskId] = true;
    }
    _tasks.remove(task);
    _deleteTask(taskId);

    if (deleteFile && task.status == TranscodeStatus.completed) {
      try {
        final file = File(task.outputPath);
        if (file.existsSync()) {
          file.deleteSync();
        }
      } catch (_) {}
    }
  }

  /// 清空已完成的转码记录
  void clearCompleted() {
    final toRemove = _tasks
        .where((t) =>
            t.status == TranscodeStatus.completed ||
            t.status == TranscodeStatus.failed ||
            t.status == TranscodeStatus.canceled)
        .toList();
    _tasks.removeWhere((t) =>
        t.status == TranscodeStatus.completed ||
        t.status == TranscodeStatus.failed ||
        t.status == TranscodeStatus.canceled);
    for (final task in toRemove) {
      _deleteTask(task.id);
    }
  }

  // ===== 以下是 FFmpeg 集成预留接口 =====

  /// 构建 FFmpeg 命令（视频格式转换）
  // ignore: unused_element
  List<String> _buildVideoConvertCommand(
    String inputPath,
    String outputPath,
    String targetFormat,
  ) {
    return [
      '-i', inputPath,
      '-c:v', 'copy',
      '-c:a', 'copy',
      '-y',
      outputPath,
    ];
  }

  /// 构建 FFmpeg 命令（音频格式转换）
  // ignore: unused_element
  List<String> _buildAudioConvertCommand(
    String inputPath,
    String outputPath,
    String targetFormat,
  ) {
    return [
      '-i', inputPath,
      '-vn',
      '-c:a', _getAudioCodec(targetFormat),
      '-y',
      outputPath,
    ];
  }

  /// 构建 FFmpeg 命令（视频压缩）
  // ignore: unused_element
  List<String> _buildVideoCompressCommand(
    String inputPath,
    String outputPath,
    String targetFormat,
    String resolution,
    int? bitrate,
  ) {
    final args = <String>['-i', inputPath];

    // 分辨率
    if (resolution != 'original') {
      final height = int.tryParse(resolution.replaceAll('p', '')) ?? 720;
      args.addAll(['-vf', 'scale=-2:$height']);
    }

    // 码率
    if (bitrate != null && bitrate > 0) {
      args.addAll(['-b:v', '${bitrate}k']);
    }

    args.addAll(['-c:a', 'copy', '-y', outputPath]);
    return args;
  }

  String _getAudioCodec(String format) {
    switch (format) {
      case 'mp3':
        return 'libmp3lame';
      case 'aac':
        return 'aac';
      case 'm4a':
        return 'aac';
      case 'wav':
        return 'pcm_s16le';
      default:
        return 'copy';
    }
  }
}

/// 转码取消异常
class _TranscodeCancelException implements Exception {
  @override
  String toString() => '转码已取消';
}
