import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/app_settings.dart';

class SettingsService {
  static const String _keyDefaultQuality = 'default_quality';
  static const String _keyCustomApiUrl = 'custom_api_url';
  static const String _keyApiSourceId = 'api_source_id';
  static const String _keyDownloadPath = 'download_path';
  static const String _keyWifiOnly = 'wifi_only';
  static const String _keyThemeMode = 'theme_mode';
  static const String _keyThemeColor = 'theme_color';
  static const String _keyAutoParseClipboard = 'auto_parse_clipboard';
  static const String _keyAutoDownloadOnShare = 'auto_download_on_share';
  static const String _keyApiKeys = 'api_keys';
  static const String _keyUidResolveServiceUrl = 'uid_resolve_service_url';
  static const String _keyDownloadSoundEnabled = 'download_sound_enabled';
  static const String _keyDownloadSoundType = 'download_sound_type';
  static const String _keyDownloadCompleteAction = 'download_complete_action';
  static const String _keyOrganizeByPlatform = 'organize_by_platform';
  static const String _keyDouyinCookies = 'douyin_cookies';
  static const String _keyHapticFeedbackEnabled = 'haptic_feedback_enabled';
  static const String _keyHapticFeedbackLevel = 'haptic_feedback_level';
  static const String _keyDownloadNotificationEnabled = 'download_notification_enabled';
  static const String _keyAutoPasteAndDownload = 'auto_paste_and_download';
  static const String _keyClipboardDetectionEnabled = 'clipboard_detection_enabled';
  static const String _keyCrawlIntervalMs = 'crawl_interval_ms';
  static const String _keyCrawlJitterMs = 'crawl_jitter_ms';
  static const String _keyDouyinCookiesBackup = 'douyin_cookies_backup';
  static const String _keyUiDensity = 'ui_density';
  static const String _keyParseRetryCount = 'parse_retry_count';
  static const String _keyCrawlRetryCount = 'crawl_retry_count';
  static const String _keyDownloadConcurrency = 'download_concurrency';
  static const String _keyShakeToParseEnabled = 'shake_to_parse_enabled';
  static const String _keyPrivacyLockEnabled = 'privacy_lock_enabled';
  static const String _keyPrivacyLockScope = 'privacy_lock_scope';
  static const String _keyPrivacyUnlockMethod = 'privacy_unlock_method';
  static const String _keyPrivacyPasswordHash = 'privacy_password_hash';
  static const String _keyPrivacyAutoLockDelay = 'privacy_auto_lock_delay';
  static const String _keyThemeSunsetTime = 'theme_sunset_time';
  static const String _keyThemeSunriseTime = 'theme_sunrise_time';
  static const String _keyTwoFingerGestureEnabled = 'two_finger_gesture_enabled';
  static const String _keyBatchGuideShown = 'batch_guide_shown';
  static const String _keyDisclaimerShown = 'disclaimer_shown';
  static const String _keyHapticOnDownloadComplete = 'haptic_on_download_complete';
  static const String _keyHapticOnDownloadFailed = 'haptic_on_download_failed';
  static const String _keyDefaultAudioFormat = 'default_audio_format';

  // ==================== 智能分类存储 ====================
  static const String _keyStorageOrganizeMode = 'storage_organize_mode';
  static const String _keyStorageDateFormat = 'storage_date_format';
  static const String _keyStorageNamingRule = 'storage_naming_rule';

  // ==================== 代理设置 ====================
  static const String _keyProxyEnabled = 'proxy_enabled';
  static const String _keyProxyType = 'proxy_type';
  static const String _keyProxyHost = 'proxy_host';
  static const String _keyProxyPort = 'proxy_port';
  static const String _keyProxyUsername = 'proxy_username';
  static const String _keyProxyPassword = 'proxy_password';
  static const String _keyProxyBypassDomains = 'proxy_bypass_domains';

  // ==================== 手势交互 ====================
  static const String _keyForceTouchEnabled = 'force_touch_enabled';
  static const String _keyBottomNavConfig = 'bottom_nav_config';

  // ==================== 自动清理下载记录 ====================
  static const String _keyAutoCleanDownloadsEnabled = 'auto_clean_downloads_enabled';
  static const String _keyAutoCleanMode = 'auto_clean_mode';
  static const String _keyAutoCleanDays = 'auto_clean_days';
  static const String _keyAutoCleanMaxCount = 'auto_clean_max_count';
  static const String _keyAutoCleanDeleteFiles = 'auto_clean_delete_files';

  // ==================== 下载失败自动重试 ====================
  static const String _keyAutoRetryOnFailure = 'auto_retry_on_failure';
  static const String _keyMaxRetryCount = 'max_retry_count';

  // ==================== 列表紧凑模式 ====================
  static const String _keyCompactListMode = 'compact_list_mode';

  // ==================== 下载完成自动保存到相册 ====================
  static const String _keyAutoSaveToGallery = 'auto_save_to_gallery';

  // ==================== 大字体模式 ====================
  static const String _keyLargeFontMode = 'large_font_mode';

  // ==================== 新手引导 ====================
  static const String _keyGuideShown = 'guide_shown';

  // ==================== 智能粘贴 ====================
  static const String _keySmartPasteAppendMode = 'smart_paste_append_mode';

  // ==================== UI 动效与提示 ====================
  static const String _keyParallaxEnabled = 'parallax_enabled';
  static const String _keyGestureHintsShown = 'gesture_hints_shown';
  static const String _keyFontSizeScale = 'font_size_scale';

  // ==================== 常用设置点击统计 ====================
  static const String _keyQuickSettingClickCounts = 'quick_setting_click_counts';

  late SharedPreferences _prefs;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  AppSettings getSettings() {
    final apiKeysJson = _prefs.getString(_keyApiKeys);
    Map<String, String> apiKeys = {};
    if (apiKeysJson != null && apiKeysJson.isNotEmpty) {
      try {
        final decoded = jsonDecode(apiKeysJson);
        if (decoded is Map) {
          apiKeys = decoded.map((k, v) => MapEntry(k.toString(), v.toString()));
        }
      } catch (_) {}
    }
    final douyinCookiesJson = _prefs.getString(_keyDouyinCookies);
    Map<String, String> douyinCookies = {};
    if (douyinCookiesJson != null && douyinCookiesJson.isNotEmpty) {
      try {
        final decoded = jsonDecode(douyinCookiesJson);
        if (decoded is Map) {
          douyinCookies = decoded.map((k, v) => MapEntry(k.toString(), v.toString()));
        }
      } catch (_) {}
    }
    return AppSettings(
      defaultQuality: _prefs.getString(_keyDefaultQuality) ?? 'original',
      customApiUrl: _prefs.getString(_keyCustomApiUrl),
      apiSourceId: _prefs.getString(_keyApiSourceId) ?? 'builtIn',
      downloadPath: _prefs.getString(_keyDownloadPath) ?? '',
      wifiOnly: _prefs.getBool(_keyWifiOnly) ?? false,
      themeMode: _prefs.getString(_keyThemeMode) ?? (_prefs.getBool('dark_mode') == true ? 'dark' : 'light'),
      themeColor: _prefs.getString(_keyThemeColor) ?? 'cyan',
      autoParseClipboard: _prefs.getBool(_keyAutoParseClipboard) ?? true,
      autoDownloadOnShare: _prefs.getBool(_keyAutoDownloadOnShare) ?? false,
      uidResolveServiceUrl: _prefs.getString(_keyUidResolveServiceUrl),
      apiKeys: apiKeys,
      downloadSoundEnabled: _prefs.getBool(_keyDownloadSoundEnabled) ?? true,
      downloadSoundType: _prefs.getString(_keyDownloadSoundType) ?? 'ding',
      downloadCompleteAction: _prefs.getString(_keyDownloadCompleteAction) ?? 'none',
      organizeByPlatform: _prefs.getBool(_keyOrganizeByPlatform) ?? true,
      douyinCookies: douyinCookies,
      hapticFeedbackEnabled: _prefs.getBool(_keyHapticFeedbackEnabled) ?? false,
      hapticFeedbackLevel: _prefs.getString(_keyHapticFeedbackLevel) ?? 'medium',
      downloadNotificationEnabled: _prefs.getBool(_keyDownloadNotificationEnabled) ?? true,
      autoPasteAndDownload: _prefs.getBool(_keyAutoPasteAndDownload) ?? false,
      clipboardDetectionEnabled: _prefs.getBool(_keyClipboardDetectionEnabled) ?? true,
      crawlIntervalMs: _prefs.getInt(_keyCrawlIntervalMs) ?? 1000,
      crawlJitterMs: _prefs.getInt(_keyCrawlJitterMs) ?? 500,
      uiDensity: _prefs.getString(_keyUiDensity) ?? 'standard',
      parseRetryCount: _prefs.getInt(_keyParseRetryCount) ?? 2,
      crawlRetryCount: _prefs.getInt(_keyCrawlRetryCount) ?? 2,
      downloadConcurrency: _prefs.getInt(_keyDownloadConcurrency) ?? 2,
      shakeToParseEnabled: _prefs.getBool(_keyShakeToParseEnabled) ?? false,
      privacyLockEnabled: _prefs.getBool(_keyPrivacyLockEnabled) ?? false,
      privacyLockScope: _prefs.getString(_keyPrivacyLockScope) ?? 'favorites',
      privacyUnlockMethod: _prefs.getString(_keyPrivacyUnlockMethod) ?? 'biometric',
      privacyPasswordHash: _prefs.getString(_keyPrivacyPasswordHash),
      privacyAutoLockDelay: _prefs.getInt(_keyPrivacyAutoLockDelay) ?? 0,
      themeSunsetTime: _prefs.getString(_keyThemeSunsetTime) ?? '18:30',
      themeSunriseTime: _prefs.getString(_keyThemeSunriseTime) ?? '06:30',
      twoFingerGestureEnabled: _prefs.getBool(_keyTwoFingerGestureEnabled) ?? false,
      batchGuideShown: _prefs.getBool(_keyBatchGuideShown) ?? false,
      disclaimerShown: _prefs.getBool(_keyDisclaimerShown) ?? false,
      hapticOnDownloadComplete: _prefs.getBool(_keyHapticOnDownloadComplete) ?? true,
      hapticOnDownloadFailed: _prefs.getBool(_keyHapticOnDownloadFailed) ?? true,
      defaultAudioFormat: _prefs.getString(_keyDefaultAudioFormat) ?? 'mp3',
      storageOrganizeMode: _prefs.getString(_keyStorageOrganizeMode) ??
          (_prefs.getBool(_keyOrganizeByPlatform) ?? true ? 'platform' : 'flat'),
      storageDateFormat: _prefs.getString(_keyStorageDateFormat) ?? 'yyyyMMdd',
      storageNamingRule: _prefs.getString(_keyStorageNamingRule) ?? 'title',
      proxyEnabled: _prefs.getBool(_keyProxyEnabled) ?? false,
      proxyType: _prefs.getString(_keyProxyType) ?? 'http',
      proxyHost: _prefs.getString(_keyProxyHost) ?? '',
      proxyPort: _prefs.getInt(_keyProxyPort) ?? 8080,
      proxyUsername: _prefs.getString(_keyProxyUsername),
      proxyPassword: _prefs.getString(_keyProxyPassword),
      proxyBypassDomains: _prefs.getStringList(_keyProxyBypassDomains) ?? [],
      parallaxEnabled: _prefs.getBool(_keyParallaxEnabled) ?? true,
      gestureHintsShown: _prefs.getStringList(_keyGestureHintsShown)?.toSet() ?? {},
      fontSizeScale: _prefs.getString(_keyFontSizeScale) ?? 'medium',
      forceTouchEnabled: _prefs.getBool(_keyForceTouchEnabled) ?? true,
      bottomNavConfigJson: _prefs.getString(_keyBottomNavConfig) ?? '',
      // 自动清理下载记录
      autoCleanDownloadsEnabled: _prefs.getBool(_keyAutoCleanDownloadsEnabled) ?? false,
      autoCleanMode: _prefs.getString(_keyAutoCleanMode) ?? 'days',
      autoCleanDays: _prefs.getInt(_keyAutoCleanDays) ?? 30,
      autoCleanMaxCount: _prefs.getInt(_keyAutoCleanMaxCount) ?? 200,
      autoCleanDeleteFiles: _prefs.getBool(_keyAutoCleanDeleteFiles) ?? false,
      // 下载失败自动重试
      autoRetryOnFailure: _prefs.getBool(_keyAutoRetryOnFailure) ?? true,
      maxRetryCount: _prefs.getInt(_keyMaxRetryCount) ?? 3,
      // 列表紧凑模式
      compactListMode: _prefs.getBool(_keyCompactListMode) ?? false,
      // 下载完成自动保存到相册
      autoSaveToGallery: _prefs.getBool(_keyAutoSaveToGallery) ?? true,
      // 大字体模式
      largeFontMode: _prefs.getBool(_keyLargeFontMode) ?? false,
      // 新手引导
      guideShown: _prefs.getBool(_keyGuideShown) ?? false,
      // 智能粘贴模式
      smartPasteAppendMode: _prefs.getBool(_keySmartPasteAppendMode) ?? true,
    );
  }

  Future<void> saveSettings(AppSettings settings) async {
    await _prefs.setString(_keyDefaultQuality, settings.defaultQuality);
    if (settings.customApiUrl != null) {
      await _prefs.setString(_keyCustomApiUrl, settings.customApiUrl!);
    } else {
      await _prefs.remove(_keyCustomApiUrl);
    }
    await _prefs.setString(_keyApiSourceId, settings.apiSourceId);
    await _prefs.setString(_keyDownloadPath, settings.downloadPath);
    await _prefs.setBool(_keyWifiOnly, settings.wifiOnly);
    await _prefs.setString(_keyThemeMode, settings.themeMode);
    await _prefs.setString(_keyThemeColor, settings.themeColor);
    await _prefs.setBool(_keyAutoParseClipboard, settings.autoParseClipboard);
    await _prefs.setBool(_keyAutoDownloadOnShare, settings.autoDownloadOnShare);
    if (settings.uidResolveServiceUrl != null && settings.uidResolveServiceUrl!.isNotEmpty) {
      await _prefs.setString(_keyUidResolveServiceUrl, settings.uidResolveServiceUrl!);
    } else {
      await _prefs.remove(_keyUidResolveServiceUrl);
    }
    await _prefs.setString(_keyApiKeys, jsonEncode(settings.apiKeys));
    await _prefs.setBool(_keyDownloadSoundEnabled, settings.downloadSoundEnabled);
    await _prefs.setString(_keyDownloadSoundType, settings.downloadSoundType);
    await _prefs.setString(_keyDownloadCompleteAction, settings.downloadCompleteAction);
    await _prefs.setBool(_keyOrganizeByPlatform, settings.organizeByPlatform);
    await _prefs.setString(_keyDouyinCookies, jsonEncode(settings.douyinCookies));
    await _prefs.setBool(_keyHapticFeedbackEnabled, settings.hapticFeedbackEnabled);
    await _prefs.setString(_keyHapticFeedbackLevel, settings.hapticFeedbackLevel);
    await _prefs.setBool(_keyDownloadNotificationEnabled, settings.downloadNotificationEnabled);
    await _prefs.setBool(_keyAutoPasteAndDownload, settings.autoPasteAndDownload);
    await _prefs.setBool(_keyClipboardDetectionEnabled, settings.clipboardDetectionEnabled);
    await _prefs.setInt(_keyCrawlIntervalMs, settings.crawlIntervalMs);
    await _prefs.setInt(_keyCrawlJitterMs, settings.crawlJitterMs);
    await _prefs.setString(_keyUiDensity, settings.uiDensity);
    await _prefs.setInt(_keyParseRetryCount, settings.parseRetryCount);
    await _prefs.setInt(_keyCrawlRetryCount, settings.crawlRetryCount);
    await _prefs.setInt(_keyDownloadConcurrency, settings.downloadConcurrency);
    await _prefs.setBool(_keyShakeToParseEnabled, settings.shakeToParseEnabled);
    await _prefs.setBool(_keyPrivacyLockEnabled, settings.privacyLockEnabled);
    await _prefs.setString(_keyPrivacyLockScope, settings.privacyLockScope);
    await _prefs.setString(_keyPrivacyUnlockMethod, settings.privacyUnlockMethod);
    if (settings.privacyPasswordHash != null && settings.privacyPasswordHash!.isNotEmpty) {
      await _prefs.setString(_keyPrivacyPasswordHash, settings.privacyPasswordHash!);
    } else {
      await _prefs.remove(_keyPrivacyPasswordHash);
    }
    await _prefs.setInt(_keyPrivacyAutoLockDelay, settings.privacyAutoLockDelay);
    await _prefs.setString(_keyThemeSunsetTime, settings.themeSunsetTime);
    await _prefs.setString(_keyThemeSunriseTime, settings.themeSunriseTime);
    await _prefs.setBool(_keyTwoFingerGestureEnabled, settings.twoFingerGestureEnabled);
    await _prefs.setBool(_keyBatchGuideShown, settings.batchGuideShown);
    await _prefs.setBool(_keyDisclaimerShown, settings.disclaimerShown);
    await _prefs.setBool(_keyHapticOnDownloadComplete, settings.hapticOnDownloadComplete);
    await _prefs.setBool(_keyHapticOnDownloadFailed, settings.hapticOnDownloadFailed);
    await _prefs.setString(_keyDefaultAudioFormat, settings.defaultAudioFormat);
    // 智能分类存储
    await _prefs.setString(_keyStorageOrganizeMode, settings.storageOrganizeMode);
    await _prefs.setString(_keyStorageDateFormat, settings.storageDateFormat);
    await _prefs.setString(_keyStorageNamingRule, settings.storageNamingRule);
    await _prefs.setBool(_keyProxyEnabled, settings.proxyEnabled);
    await _prefs.setString(_keyProxyType, settings.proxyType);
    await _prefs.setString(_keyProxyHost, settings.proxyHost);
    await _prefs.setInt(_keyProxyPort, settings.proxyPort);
    if (settings.proxyUsername != null && settings.proxyUsername!.isNotEmpty) {
      await _prefs.setString(_keyProxyUsername, settings.proxyUsername!);
    } else {
      await _prefs.remove(_keyProxyUsername);
    }
    if (settings.proxyPassword != null && settings.proxyPassword!.isNotEmpty) {
      await _prefs.setString(_keyProxyPassword, settings.proxyPassword!);
    } else {
      await _prefs.remove(_keyProxyPassword);
    }
    await _prefs.setStringList(_keyProxyBypassDomains, settings.proxyBypassDomains);
    // UI 动效与提示
    await _prefs.setBool(_keyParallaxEnabled, settings.parallaxEnabled);
    await _prefs.setStringList(_keyGestureHintsShown, settings.gestureHintsShown.toList());
    await _prefs.setString(_keyFontSizeScale, settings.fontSizeScale);
    // 手势交互
    await _prefs.setBool(_keyForceTouchEnabled, settings.forceTouchEnabled);
    await _prefs.setString(_keyBottomNavConfig, settings.bottomNavConfigJson);
    // 自动清理下载记录
    await _prefs.setBool(_keyAutoCleanDownloadsEnabled, settings.autoCleanDownloadsEnabled);
    await _prefs.setString(_keyAutoCleanMode, settings.autoCleanMode);
    await _prefs.setInt(_keyAutoCleanDays, settings.autoCleanDays);
    await _prefs.setInt(_keyAutoCleanMaxCount, settings.autoCleanMaxCount);
    await _prefs.setBool(_keyAutoCleanDeleteFiles, settings.autoCleanDeleteFiles);
    // 下载失败自动重试
    await _prefs.setBool(_keyAutoRetryOnFailure, settings.autoRetryOnFailure);
    await _prefs.setInt(_keyMaxRetryCount, settings.maxRetryCount);
    // 列表紧凑模式
    await _prefs.setBool(_keyCompactListMode, settings.compactListMode);
    // 下载完成自动保存到相册
    await _prefs.setBool(_keyAutoSaveToGallery, settings.autoSaveToGallery);
    // 大字体模式
    await _prefs.setBool(_keyLargeFontMode, settings.largeFontMode);
    // 新手引导
    await _prefs.setBool(_keyGuideShown, settings.guideShown);
    // 智能粘贴模式
    await _prefs.setBool(_keySmartPasteAppendMode, settings.smartPasteAppendMode);
  }

  Future<void> setDefaultQuality(String quality) async {
    await _prefs.setString(_keyDefaultQuality, quality);
  }

  Future<void> setCustomApiUrl(String? url) async {
    if (url != null && url.isNotEmpty) {
      await _prefs.setString(_keyCustomApiUrl, url);
    } else {
      await _prefs.remove(_keyCustomApiUrl);
    }
  }

  Future<void> setApiSourceId(String id) async {
    await _prefs.setString(_keyApiSourceId, id);
  }

  Future<void> setDownloadPath(String path) async {
    await _prefs.setString(_keyDownloadPath, path);
  }

  Future<void> setWifiOnly(bool value) async {
    await _prefs.setBool(_keyWifiOnly, value);
  }

  Future<void> setThemeMode(String mode) async {
    await _prefs.setString(_keyThemeMode, mode);
  }

  Future<void> setThemeColor(String color) async {
    await _prefs.setString(_keyThemeColor, color);
  }

  Future<void> setAutoParseClipboard(bool value) async {
    await _prefs.setBool(_keyAutoParseClipboard, value);
  }

  Future<void> setAutoDownloadOnShare(bool value) async {
    await _prefs.setBool(_keyAutoDownloadOnShare, value);
  }

  Future<void> setAutoPasteAndDownload(bool value) async {
    await _prefs.setBool(_keyAutoPasteAndDownload, value);
  }

  Future<void> setClipboardDetectionEnabled(bool value) async {
    await _prefs.setBool(_keyClipboardDetectionEnabled, value);
  }

  Future<void> setUidResolveServiceUrl(String? url) async {
    if (url != null && url.isNotEmpty) {
      await _prefs.setString(_keyUidResolveServiceUrl, url);
    } else {
      await _prefs.remove(_keyUidResolveServiceUrl);
    }
  }

  Future<void> setApiKey(String sourceId, String? key) async {
    final settings = getSettings();
    final newKeys = Map<String, String>.from(settings.apiKeys);
    if (key == null || key.isEmpty) {
      newKeys.remove(sourceId);
    } else {
      newKeys[sourceId] = key;
    }
    await _prefs.setString(_keyApiKeys, jsonEncode(newKeys));
  }

  String? getApiKey(String sourceId) {
    return getSettings().apiKeys[sourceId];
  }

  Future<void> setDownloadSoundEnabled(bool value) async {
    await _prefs.setBool(_keyDownloadSoundEnabled, value);
  }

  Future<void> setDownloadSoundType(String type) async {
    await _prefs.setString(_keyDownloadSoundType, type);
  }

  Future<void> setDownloadCompleteAction(String action) async {
    await _prefs.setString(_keyDownloadCompleteAction, action);
  }

  Future<void> setOrganizeByPlatform(bool value) async {
    await _prefs.setBool(_keyOrganizeByPlatform, value);
  }

  Future<void> setDouyinCookies(Map<String, String> cookies) async {
    await _prefs.setString(_keyDouyinCookies, jsonEncode(cookies));
  }

  Future<void> clearDouyinCookies() async {
    await _prefs.remove(_keyDouyinCookies);
  }

  Future<void> setHapticFeedbackEnabled(bool value) async {
    await _prefs.setBool(_keyHapticFeedbackEnabled, value);
  }

  Future<void> setHapticFeedbackLevel(String level) async {
    await _prefs.setString(_keyHapticFeedbackLevel, level);
  }

  Future<void> setDownloadNotificationEnabled(bool value) async {
    await _prefs.setBool(_keyDownloadNotificationEnabled, value);
  }

  Future<void> setCrawlIntervalMs(int ms) async {
    await _prefs.setInt(_keyCrawlIntervalMs, ms);
  }

  Future<void> setCrawlJitterMs(int ms) async {
    await _prefs.setInt(_keyCrawlJitterMs, ms);
  }

  // ==================== Cookie 备份与恢复 ====================

  Future<void> setDouyinCookiesBackup(Map<String, String> cookies) async {
    await _prefs.setString(_keyDouyinCookiesBackup, jsonEncode(cookies));
  }

  Future<Map<String, String>?> getDouyinCookiesBackup() async {
    final jsonStr = _prefs.getString(_keyDouyinCookiesBackup);
    if (jsonStr == null || jsonStr.isEmpty) return null;
    try {
      final decoded = jsonDecode(jsonStr);
      if (decoded is Map) {
        return decoded.map((k, v) => MapEntry(k.toString(), v.toString()));
      }
    } catch (_) {}
    return null;
  }

  Future<bool> hasDouyinCookiesBackup() async {
    return _prefs.containsKey(_keyDouyinCookiesBackup);
  }

  Future<void> clearDouyinCookiesBackup() async {
    await _prefs.remove(_keyDouyinCookiesBackup);
  }

  Future<void> setUiDensity(String density) async {
    await _prefs.setString(_keyUiDensity, density);
  }

  Future<void> setParseRetryCount(int count) async {
    await _prefs.setInt(_keyParseRetryCount, count);
  }

  Future<void> setCrawlRetryCount(int count) async {
    await _prefs.setInt(_keyCrawlRetryCount, count);
  }

  Future<void> setDownloadConcurrency(int concurrency) async {
    await _prefs.setInt(_keyDownloadConcurrency, concurrency);
  }

  Future<void> setShakeToParseEnabled(bool value) async {
    await _prefs.setBool(_keyShakeToParseEnabled, value);
  }

  Future<void> setPrivacyLockEnabled(bool value) async {
    await _prefs.setBool(_keyPrivacyLockEnabled, value);
  }

  Future<void> setPrivacyLockScope(String scope) async {
    await _prefs.setString(_keyPrivacyLockScope, scope);
  }

  Future<void> setPrivacyUnlockMethod(String method) async {
    await _prefs.setString(_keyPrivacyUnlockMethod, method);
  }

  /// 设置隐私锁密码（传入明文密码，内部自动哈希存储）
  Future<void> setPrivacyPassword(String password) async {
    final hash = _hashPassword(password);
    await _prefs.setString(_keyPrivacyPasswordHash, hash);
  }

  /// 清除隐私锁密码
  Future<void> clearPrivacyPassword() async {
    await _prefs.remove(_keyPrivacyPasswordHash);
  }

  /// 验证隐私锁密码是否正确
  bool verifyPrivacyPassword(String password) {
    final storedHash = _prefs.getString(_keyPrivacyPasswordHash);
    if (storedHash == null || storedHash.isEmpty) return false;
    final inputHash = _hashPassword(password);
    return inputHash == storedHash;
  }

  /// 是否已设置密码
  bool get hasPrivacyPassword {
    final hash = _prefs.getString(_keyPrivacyPasswordHash);
    return hash != null && hash.isNotEmpty;
  }

  Future<void> setPrivacyAutoLockDelay(int delaySeconds) async {
    await _prefs.setInt(_keyPrivacyAutoLockDelay, delaySeconds);
  }

  /// 使用 SHA256 对密码进行哈希
  String _hashPassword(String password) {
    final bytes = utf8.encode(password);
    final digest = sha256.convert(bytes);
    return digest.toString();
  }

  Future<void> setThemeSunsetTime(String time) async {
    await _prefs.setString(_keyThemeSunsetTime, time);
  }

  Future<void> setThemeSunriseTime(String time) async {
    await _prefs.setString(_keyThemeSunriseTime, time);
  }

  Future<void> setTwoFingerGestureEnabled(bool value) async {
    await _prefs.setBool(_keyTwoFingerGestureEnabled, value);
  }

  Future<void> setBatchGuideShown(bool value) async {
    await _prefs.setBool(_keyBatchGuideShown, value);
  }

  Future<void> setDisclaimerShown(bool value) async {
    await _prefs.setBool(_keyDisclaimerShown, value);
  }

  Future<void> setHapticOnDownloadComplete(bool value) async {
    await _prefs.setBool(_keyHapticOnDownloadComplete, value);
  }

  Future<void> setHapticOnDownloadFailed(bool value) async {
    await _prefs.setBool(_keyHapticOnDownloadFailed, value);
  }

  Future<void> setDefaultAudioFormat(String format) async {
    await _prefs.setString(_keyDefaultAudioFormat, format);
  }

  // ==================== 智能分类存储 ====================

  Future<void> setStorageOrganizeMode(String mode) async {
    await _prefs.setString(_keyStorageOrganizeMode, mode);
  }

  Future<void> setStorageDateFormat(String format) async {
    await _prefs.setString(_keyStorageDateFormat, format);
  }

  Future<void> setStorageNamingRule(String rule) async {
    await _prefs.setString(_keyStorageNamingRule, rule);
  }

  // ==================== 代理设置 ====================

  Future<void> setProxyEnabled(bool value) async {
    await _prefs.setBool(_keyProxyEnabled, value);
  }

  Future<void> setProxyType(String type) async {
    await _prefs.setString(_keyProxyType, type);
  }

  Future<void> setProxyHost(String host) async {
    await _prefs.setString(_keyProxyHost, host);
  }

  Future<void> setProxyPort(int port) async {
    await _prefs.setInt(_keyProxyPort, port);
  }

  Future<void> setProxyUsername(String? username) async {
    if (username != null && username.isNotEmpty) {
      await _prefs.setString(_keyProxyUsername, username);
    } else {
      await _prefs.remove(_keyProxyUsername);
    }
  }

  Future<void> setProxyPassword(String? password) async {
    if (password != null && password.isNotEmpty) {
      await _prefs.setString(_keyProxyPassword, password);
    } else {
      await _prefs.remove(_keyProxyPassword);
    }
  }

  Future<void> setProxyBypassDomains(List<String> domains) async {
    await _prefs.setStringList(_keyProxyBypassDomains, domains);
  }

  // ==================== UI 动效与提示 ====================

  Future<void> setParallaxEnabled(bool value) async {
    await _prefs.setBool(_keyParallaxEnabled, value);
  }

  Future<void> setGestureHintShown(String pageKey) async {
    final shown = _prefs.getStringList(_keyGestureHintsShown)?.toSet() ?? {};
    shown.add(pageKey);
    await _prefs.setStringList(_keyGestureHintsShown, shown.toList());
  }

  Future<void> resetGestureHints() async {
    await _prefs.remove(_keyGestureHintsShown);
  }

  Future<void> setFontSizeScale(String scale) async {
    await _prefs.setString(_keyFontSizeScale, scale);
  }

  // ==================== 手势交互 ====================

  Future<void> setForceTouchEnabled(bool value) async {
    await _prefs.setBool(_keyForceTouchEnabled, value);
  }

  Future<void> setBottomNavConfig(String configJson) async {
    await _prefs.setString(_keyBottomNavConfig, configJson);
  }

  // ==================== 自动清理下载记录 ====================

  Future<void> setAutoCleanDownloadsEnabled(bool value) async {
    await _prefs.setBool(_keyAutoCleanDownloadsEnabled, value);
  }

  Future<void> setAutoCleanMode(String mode) async {
    await _prefs.setString(_keyAutoCleanMode, mode);
  }

  Future<void> setAutoCleanDays(int days) async {
    await _prefs.setInt(_keyAutoCleanDays, days);
  }

  Future<void> setAutoCleanMaxCount(int count) async {
    await _prefs.setInt(_keyAutoCleanMaxCount, count);
  }

  Future<void> setAutoCleanDeleteFiles(bool value) async {
    await _prefs.setBool(_keyAutoCleanDeleteFiles, value);
  }

  // ==================== 下载失败自动重试 ====================

  Future<void> setAutoRetryOnFailure(bool value) async {
    await _prefs.setBool(_keyAutoRetryOnFailure, value);
  }

  Future<void> setMaxRetryCount(int count) async {
    await _prefs.setInt(_keyMaxRetryCount, count);
  }

  // ==================== 列表紧凑模式 ====================

  Future<void> setCompactListMode(bool value) async {
    await _prefs.setBool(_keyCompactListMode, value);
  }

  // ==================== 下载完成自动保存到相册 ====================

  Future<void> setAutoSaveToGallery(bool value) async {
    await _prefs.setBool(_keyAutoSaveToGallery, value);
  }

  // ==================== 大字体模式 ====================

  Future<void> setLargeFontMode(bool value) async {
    await _prefs.setBool(_keyLargeFontMode, value);
  }

  // ==================== 常用设置点击统计 ====================

  /// 获取常用设置点击次数字典
  Map<String, int> getQuickSettingClickCounts() {
    final jsonStr = _prefs.getString(_keyQuickSettingClickCounts);
    if (jsonStr == null || jsonStr.isEmpty) return {};
    try {
      final decoded = jsonDecode(jsonStr);
      if (decoded is Map) {
        return decoded.map((k, v) => MapEntry(k.toString(), (v as num).toInt()));
      }
    } catch (_) {}
    return {};
  }

  /// 增加指定设置项的点击次数
  Future<void> incrementQuickSettingClick(String sectionKey) async {
    final counts = getQuickSettingClickCounts();
    counts[sectionKey] = (counts[sectionKey] ?? 0) + 1;
    await _prefs.setString(_keyQuickSettingClickCounts, jsonEncode(counts));
  }

  /// 设置新手引导是否已展示
  Future<void> setGuideShown(bool shown) async {
    await _prefs.setBool(_keyGuideShown, shown);
  }

  Future<void> setSmartPasteAppendMode(bool value) async {
    await _prefs.setBool(_keySmartPasteAppendMode, value);
  }
}
