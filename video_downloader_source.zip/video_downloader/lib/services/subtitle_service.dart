import 'dart:io';

/// 字幕格式
enum SubtitleFormat {
  srt, // SubRip 格式
  vtt, // WebVTT 格式
}

/// 字幕提取结果
class SubtitleExtractResult {
  /// 是否成功
  final bool success;

  /// 输出文件路径
  final String? outputPath;

  /// 字幕格式
  final SubtitleFormat format;

  /// 提示信息（如"无内嵌字幕"）
  final String? message;

  /// 是否为占位文件（视频没有内嵌字幕时生成的说明文件）
  final bool isPlaceholder;

  SubtitleExtractResult({
    required this.success,
    this.outputPath,
    required this.format,
    this.message,
    this.isPlaceholder = false,
  });
}

/// 字幕提取服务
///
/// 提供从视频中提取内嵌字幕的功能。
///
/// 注意：当前版本未启用 FFmpeg（ffmpeg_kit_flutter 已注释），
/// 无法检测视频是否包含内嵌字幕，也无法真实提取字幕。
/// 后续接入 ffmpeg_kit_flutter 后可实现完整功能。
class SubtitleService {
  /// 是否启用了 FFmpeg（用于字幕检测与提取）
  ///
  /// 当前项目中 ffmpeg_kit_flutter 依赖被注释，
  /// 因此无法使用 ffprobe 检测内嵌字幕。
  static const bool _ffmpegEnabled = false;

  /// 支持的字幕格式
  static const List<SubtitleFormat> supportedFormats = [
    SubtitleFormat.srt,
    SubtitleFormat.vtt,
  ];

  /// 检查视频是否包含内嵌字幕
  ///
  /// 返回值：
  /// - `true`：检测到内嵌字幕
  /// - `false`：未检测到内嵌字幕
  /// - `null`：无法检测（FFmpeg 未启用）
  ///
  /// 真实场景下应该用 ffprobe 分析视频流信息。
  /// 当前 FFmpeg 未启用，始终返回 null。
  Future<bool?> hasEmbeddedSubtitles(String videoPath) async {
    if (!_ffmpegEnabled) {
      // FFmpeg 未启用，无法检测
      return null;
    }
    // TODO: 接入 ffmpeg_kit_flutter 后，使用 ffprobe 检查字幕流
    // 例如: ffprobe -v error -select_streams s -show_entries stream=index -of csv=p=0 input.mp4
    return false;
  }

  /// 从视频中提取字幕
  ///
  /// 如果视频没有内嵌字幕，会生成一个占位说明文件。
  Future<SubtitleExtractResult> extractSubtitles({
    required String videoPath,
    required String outputDir,
    SubtitleFormat format = SubtitleFormat.srt,
  }) async {
    final videoFile = File(videoPath);
    if (!await videoFile.exists()) {
      return SubtitleExtractResult(
        success: false,
        format: format,
        message: '视频文件不存在',
      );
    }

    // 确保输出目录存在
    final dir = Directory(outputDir);
    if (!await dir.exists()) {
      await dir.create(recursive: true);
    }

    final videoFileName = videoFile.uri.pathSegments.last;
    final baseName = videoFileName.replaceAll(RegExp(r'\.[^.]+$'), '');
    final ext = format == SubtitleFormat.srt ? 'srt' : 'vtt';
    final outputPath = '$outputDir/$baseName.$ext';

    // 检查是否有内嵌字幕
    final hasSubs = await hasEmbeddedSubtitles(videoPath);

    if (hasSubs == null) {
      // FFmpeg 未启用，无法检测是否有内嵌字幕
      // 抛出明确异常，而不是静默生成占位文件
      return SubtitleExtractResult(
        success: false,
        format: format,
        message: '未检测到内嵌字幕（FFmpeg 未启用）',
      );
    }

    if (hasSubs) {
      // 有内嵌字幕：真实提取（预留 FFmpeg 实现）
      // 这里应该调用 FFmpeg 提取字幕流
      // 例如: ffmpeg -i input.mp4 -map 0:s:0 output.srt

      // 简化版：生成一个示例字幕文件（模拟提取成功）
      await _generateSampleSubtitle(outputPath, format);

      return SubtitleExtractResult(
        success: true,
        outputPath: outputPath,
        format: format,
        message: '字幕提取成功',
      );
    } else {
      // 没有内嵌字幕：生成占位说明文件
      await _generatePlaceholderSubtitle(outputPath, format, baseName);

      return SubtitleExtractResult(
        success: false,
        outputPath: outputPath,
        format: format,
        message: '该视频没有检测到内嵌字幕',
        isPlaceholder: true,
      );
    }
  }

  /// 生成示例字幕文件（模拟提取成功）
  Future<void> _generateSampleSubtitle(
    String outputPath,
    SubtitleFormat format,
  ) async {
    final file = File(outputPath);
    String content;

    if (format == SubtitleFormat.srt) {
      content = '''1
00:00:01,000 --> 00:00:04,000
这是一个示例字幕

2
00:00:05,000 --> 00:00:08,000
字幕提取功能演示

3
00:00:09,000 --> 00:00:12,000
欢迎使用视频下载器
''';
    } else {
      content = '''WEBVTT

00:00:01.000 --> 00:00:04.000
这是一个示例字幕

00:00:05.000 --> 00:00:08.000
字幕提取功能演示

00:00:09.000 --> 00:00:12.000
欢迎使用视频下载器
''';
    }

    await file.writeAsString(content);
  }

  /// 生成占位说明文件
  Future<void> _generatePlaceholderSubtitle(
    String outputPath,
    SubtitleFormat format,
    String videoName,
  ) async {
    final file = File(outputPath);
    String content;

    if (format == SubtitleFormat.srt) {
      content = '''1
00:00:00,000 --> 00:00:03,000
【提示】此视频未检测到内嵌字幕

2
00:00:04,000 --> 00:00:07,000
视频名称：$videoName

3
00:00:08,000 --> 00:00:11,000
如需字幕，请尝试其他来源
''';
    } else {
      content = '''WEBVTT

NOTE
此视频未检测到内嵌字幕
视频名称：$videoName
如需字幕，请尝试其他来源

00:00:00.000 --> 00:00:03.000
【提示】此视频未检测到内嵌字幕

00:00:04.000 --> 00:00:07.000
视频名称：$videoName
''';
    }

    await file.writeAsString(content);
  }

  /// 获取字幕格式的显示名称
  static String formatName(SubtitleFormat format) {
    switch (format) {
      case SubtitleFormat.srt:
        return 'SRT';
      case SubtitleFormat.vtt:
        return 'VTT';
    }
  }

  /// 从字符串解析字幕格式
  static SubtitleFormat parseFormat(String format) {
    switch (format.toLowerCase()) {
      case 'vtt':
        return SubtitleFormat.vtt;
      case 'srt':
      default:
        return SubtitleFormat.srt;
    }
  }
}
