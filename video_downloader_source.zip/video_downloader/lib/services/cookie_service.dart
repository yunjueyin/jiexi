import 'dart:convert';
import 'package:hive_flutter/hive_flutter.dart';
import '../models/cookie_profile.dart';

/// Cookie 管理服务
///
/// 提供 Cookie 档案的 CRUD、有效期检查、自动标记失效等功能
class CookieService {
  static const String _boxName = 'cookie_profiles';
  Box<CookieProfile>? _box;

  bool get isInitialized => _box != null;

  Future<void> init() async {
    if (_box != null) return;
    try {
      _box = await Hive.openBox<CookieProfile>(_boxName);
    } catch (e) {
      try {
        await Hive.deleteBoxFromDisk(_boxName);
        _box = await Hive.openBox<CookieProfile>(_boxName);
      } catch (_) {
        rethrow;
      }
    }
    // 初始化时刷新所有 Cookie 状态
    _refreshAllStatus();
  }

  /// 刷新所有 Cookie 的状态（检查是否过期）
  void _refreshAllStatus() {
    if (_box == null) return;
    bool changed = false;
    for (final profile in _box!.values) {
      final newStatus = profile.computeStatus();
      if (newStatus != profile.status) {
        profile.status = newStatus;
        profile.save();
        changed = true;
      }
    }
    if (changed) {
      // 触发值监听
      _box!.put('_refresh_ts', CookieProfile(
        id: '_refresh_ts',
        platform: 'system',
        name: '',
        cookieString: '',
        createdAt: DateTime.now(),
      )..delete());
    }
  }

  /// 获取所有 Cookie 档案
  List<CookieProfile> getAll() {
    if (_box == null) return [];
    final list = _box!.values.where((p) => !p.id.startsWith('_')).toList();
    list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return list;
  }

  /// 按平台获取
  List<CookieProfile> getByPlatform(String platform) {
    return getAll().where((p) => p.platform == platform).toList();
  }

  /// 获取指定平台的有效 Cookie（优先返回最近使用的）
  CookieProfile? getActiveForPlatform(String platform) {
    final profiles = getByPlatform(platform);
    // 先刷新状态
    for (final p in profiles) {
      p.refreshStatus();
    }
    // 有效状态优先，按最后使用时间倒序
    final active = profiles.where((p) => p.status == CookieStatus.active).toList();
    if (active.isNotEmpty) {
      active.sort((a, b) {
        final aTime = a.lastUsedAt ?? a.createdAt;
        final bTime = b.lastUsedAt ?? b.createdAt;
        return bTime.compareTo(aTime);
      });
      return active.first;
    }
    // 没有有效则返回即将过期的
    final expiring = profiles.where((p) => p.status == CookieStatus.expiringSoon).toList();
    if (expiring.isNotEmpty) {
      expiring.sort((a, b) {
        final aTime = a.lastUsedAt ?? a.createdAt;
        final bTime = b.lastUsedAt ?? b.createdAt;
        return bTime.compareTo(aTime);
      });
      return expiring.first;
    }
    return null;
  }

  /// 根据 ID 获取
  CookieProfile? getById(String id) {
    if (_box == null) return null;
    return _box!.get(id);
  }

  /// 添加 Cookie 档案
  Future<void> add(CookieProfile profile) async {
    if (_box == null) return;
    profile.refreshStatus();
    await _box!.put(profile.id, profile);
  }

  /// 更新 Cookie 档案
  Future<void> update(CookieProfile profile) async {
    if (_box == null) return;
    profile.refreshStatus();
    await _box!.put(profile.id, profile);
  }

  /// 删除 Cookie 档案
  Future<void> remove(String id) async {
    if (_box == null) return;
    await _box!.delete(id);
  }

  /// 清除所有
  Future<void> clear() async {
    if (_box == null) return;
    await _box!.clear();
  }

  /// 标记使用
  Future<void> markUsed(String id) async {
    if (_box == null) return;
    final profile = _box!.get(id);
    if (profile == null) return;
    profile.lastUsedAt = DateTime.now();
    await profile.save();
  }

  /// 检查并标记过期的 Cookie
  /// 返回状态发生变化的档案数量
  int checkExpirations() {
    if (_box == null) return 0;
    int changed = 0;
    for (final profile in _box!.values) {
      if (profile.id.startsWith('_')) continue;
      final newStatus = profile.computeStatus();
      if (newStatus != profile.status) {
        profile.status = newStatus;
        profile.save();
        changed++;
      }
    }
    return changed;
  }

  /// 获取各状态的数量统计
  Map<CookieStatus, int> getStatusCounts() {
    final counts = <CookieStatus, int>{
      CookieStatus.active: 0,
      CookieStatus.expiringSoon: 0,
      CookieStatus.expired: 0,
    };
    for (final profile in getAll()) {
      profile.refreshStatus();
      counts[profile.status] = (counts[profile.status] ?? 0) + 1;
    }
    return counts;
  }

  // ==================== 导入/导出 ====================

  /// 导出所有 Cookie 为 JSON 字符串
  String exportAllJson() {
    final profiles = getAll();
    final list = profiles.map((p) => {
      'id': p.id,
      'platform': p.platform,
      'name': p.name,
      'cookieString': p.cookieString,
      'createdAt': p.createdAt.toIso8601String(),
      'expiresAt': p.expiresAt?.toIso8601String(),
      'lastUsedAt': p.lastUsedAt?.toIso8601String(),
      'status': p.status.index,
      'remark': p.remark,
    }).toList();

    const encoder = JsonEncoder.withIndent('  ');
    return encoder.convert({
      'exportType': 'cookie_profiles',
      'exportedAt': DateTime.now().toIso8601String(),
      'count': list.length,
      'profiles': list,
    });
  }

  /// 从 JSON 字符串导入 Cookie
  /// 返回成功导入的数量
  Future<int> importFromJson(String jsonStr) async {
    if (_box == null) return 0;
    int count = 0;
    try {
      final decoded = jsonDecode(jsonStr);
      List<dynamic> profilesData;
      if (decoded is Map && decoded['profiles'] is List) {
        profilesData = decoded['profiles'] as List;
      } else if (decoded is List) {
        profilesData = decoded;
      } else {
        return 0;
      }

      for (final item in profilesData) {
        if (item is! Map) continue;
        try {
          final id = item['id']?.toString() ?? 'cookie_${DateTime.now().millisecondsSinceEpoch}_$count';
          final platform = item['platform']?.toString() ?? 'douyin';
          final name = item['name']?.toString() ?? '导入的Cookie';
          final cookieString = item['cookieString']?.toString() ?? '';
          if (cookieString.isEmpty) continue;

          final createdAt = item['createdAt'] != null
              ? DateTime.tryParse(item['createdAt'].toString()) ?? DateTime.now()
              : DateTime.now();
          final expiresAt = item['expiresAt'] != null
              ? DateTime.tryParse(item['expiresAt'].toString())
              : null;
          final lastUsedAt = item['lastUsedAt'] != null
              ? DateTime.tryParse(item['lastUsedAt'].toString())
              : null;
          final remark = item['remark']?.toString();

          final profile = CookieProfile(
            id: id,
            platform: platform,
            name: name,
            cookieString: cookieString,
            createdAt: createdAt,
            expiresAt: expiresAt,
            lastUsedAt: lastUsedAt,
            remark: remark,
          );
          profile.refreshStatus();
          await _box!.put(id, profile);
          count++;
        } catch (_) {
          continue;
        }
      }
    } catch (_) {
      return 0;
    }
    return count;
  }
}
