import 'package:hive/hive.dart';
import '../models/convert_record.dart';

/// 转换历史记录服务（Hive 持久化）
class ConvertHistoryService {
  static const String _boxName = 'convert_history';
  Box<ConvertRecord>? _box;

  Future<void> init() async {
    _box ??= await Hive.openBox<ConvertRecord>(_boxName);
  }

  Box<ConvertRecord> get box {
    if (_box == null) {
      throw StateError('ConvertHistoryService not initialized');
    }
    return _box!;
  }

  /// 获取所有转换记录（按时间倒序）
  List<ConvertRecord> getAll() {
    final list = box.values.toList();
    list.sort((a, b) => b.convertedAt.compareTo(a.convertedAt));
    return list;
  }

  /// 分页获取转换记录
  ///
  /// [page] 页码，从 0 开始
  /// [pageSize] 每页数量
  /// 返回当前页的数据列表（按时间倒序）
  List<ConvertRecord> getPage(int page, {int pageSize = 20}) {
    final list = getAll();
    final start = page * pageSize;
    if (start >= list.length) return [];
    final end = (start + pageSize).clamp(0, list.length);
    return list.sublist(start, end);
  }

  /// 获取转短链记录
  List<ConvertRecord> getShortRecords() {
    return getAll().where((r) => r.isToShort).toList();
  }

  /// 获取转长链记录
  List<ConvertRecord> getLongRecords() {
    return getAll().where((r) => r.isToLong).toList();
  }

  /// 添加记录
  Future<void> addRecord(ConvertRecord record) async {
    await box.put(record.id, record);
  }

  /// 批量添加记录
  Future<void> addRecords(List<ConvertRecord> records) async {
    for (final record in records) {
      await box.put(record.id, record);
    }
  }

  /// 删除单条记录
  Future<void> removeRecord(String id) async {
    await box.delete(id);
  }

  /// 清空所有记录
  Future<void> clearAll() async {
    await box.clear();
  }

  /// 清空转短链记录
  Future<void> clearShortRecords() async {
    final keys = box.values.where((r) => r.isToShort).map((r) => r.id).toList();
    await box.deleteAll(keys);
  }

  /// 清空转长链记录
  Future<void> clearLongRecords() async {
    final keys = box.values.where((r) => r.isToLong).map((r) => r.id).toList();
    await box.deleteAll(keys);
  }

  /// 记录总数
  int get count => box.length;
}
