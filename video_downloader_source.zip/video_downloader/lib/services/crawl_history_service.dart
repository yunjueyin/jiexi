import 'dart:convert';
import 'package:hive/hive.dart';
import '../models/crawl_record.dart';
import '../models/top10_works_result.dart';

/// 抓取历史记录服务（Hive 持久化）
class CrawlHistoryService {
  static const String _boxName = 'crawl_history';
  Box<CrawlRecord>? _box;

  Future<void> init() async {
    _box ??= await Hive.openBox<CrawlRecord>(_boxName);
  }

  Box<CrawlRecord> get box {
    if (_box == null) {
      throw StateError('CrawlHistoryService not initialized');
    }
    return _box!;
  }

  /// 获取所有抓取记录（按时间倒序）
  /// 自动过滤掉批次进度记录（内部使用，不展示给用户）
  List<CrawlRecord> getAll() {
    final list = box.values.where((r) => !r.isBatchProgress).toList();
    list.sort((a, b) => b.crawledAt.compareTo(a.crawledAt));
    return list;
  }

  /// 分页获取抓取记录
  ///
  /// [page] 页码，从 0 开始
  /// [pageSize] 每页数量
  /// 返回当前页的数据列表（已排除批次进度记录，按时间倒序）
  List<CrawlRecord> getPage(int page, {int pageSize = 20}) {
    final list = getAll();
    final start = page * pageSize;
    if (start >= list.length) return [];
    final end = (start + pageSize).clamp(0, list.length);
    return list.sublist(start, end);
  }

  /// 获取作者抓取记录
  List<CrawlRecord> getAuthorRecords() {
    return getAll().where((r) => r.isAuthor).toList();
  }

  /// 获取视频抓取记录
  List<CrawlRecord> getVideoRecords() {
    return getAll().where((r) => r.isVideo).toList();
  }

  /// 添加记录
  Future<void> addRecord(CrawlRecord record) async {
    await box.put(record.id, record);
  }

  /// 删除单条记录
  Future<void> removeRecord(String id) async {
    await box.delete(id);
  }

  /// 清空所有记录
  Future<void> clearAll() async {
    await box.clear();
  }

  /// 清空作者抓取记录
  Future<void> clearAuthorRecords() async {
    final authorKeys = box.values.where((r) => r.isAuthor).map((r) => r.id).toList();
    await box.deleteAll(authorKeys);
  }

  /// 清空视频抓取记录
  Future<void> clearVideoRecords() async {
    final videoKeys = box.values.where((r) => r.isVideo).map((r) => r.id).toList();
    await box.deleteAll(videoKeys);
  }

  /// 添加前10作品记录（转换为 CrawlRecord 存储）
  Future<void> addTop10Record(Top10WorksResult result) async {
    final record = CrawlRecord(
      id: result.id,
      url: result.url,
      platform: result.platform,
      crawlType: 'top10',
      crawledAt: result.crawledAt,
      data: {
        'authorId': result.authorId,
        'authorName': result.authorName,
        'authorAvatar': result.authorAvatar,
        'workCount': result.workCount,
        'totalLikes': result.totalLikes,
        'totalCollects': result.totalCollects,
        'totalComments': result.totalComments,
        'avgLikes': result.avgLikes,
        'avgCollects': result.avgCollects,
        'avgComments': result.avgComments,
        'medianLikes': result.medianLikes,
        'medianCollects': result.medianCollects,
        'medianComments': result.medianComments,
        'publishSpanDays': result.publishSpanDays,
      },
      rawData: {
        'works': result.works
            .map((w) => {
                  'videoId': w.videoId,
                  'title': w.title,
                  'cover': w.cover,
                  'likeCount': w.likeCount,
                  'collectCount': w.collectCount,
                  'commentCount': w.commentCount,
                  'publishTime': w.publishTime.toIso8601String(),
                  'shareCount': w.shareCount,
                  'playCount': w.playCount,
                })
            .toList(),
      },
    );
    await box.put(record.id, record);
  }

  /// 清空前10作品记录
  Future<void> clearTop10Records() async {
    final keys = box.values.where((r) => r.isTop10).map((r) => r.id).toList();
    await box.deleteAll(keys);
  }

  /// 记录总数（排除批次进度记录）
  int get count => box.values.where((r) => !r.isBatchProgress).length;

  // ==================== 断点续传：批次进度管理 ====================

  /// 批次进度记录的 ID 前缀
  static const String _batchProgressPrefix = 'batch_progress_';

  /// 生成批次进度记录的 ID
  static String batchProgressId(String batchId) => '$_batchProgressPrefix$batchId';

  /// 保存/更新批次进度
  Future<void> saveBatchProgress(CrawlRecord progress) async {
    assert(progress.isBatchProgress, '只能保存批次进度记录（crawlType 应为 batch_progress）');
    await box.put(progress.id, progress);
  }

  /// 获取指定批次的进度记录
  CrawlRecord? getBatchProgress(String batchId) {
    final key = batchProgressId(batchId);
    return box.get(key);
  }

  /// 根据 ID 获取单条记录
  CrawlRecord? getById(String id) {
    return box.get(id);
  }

  /// 获取未完成的批次进度（作者抓取）
  CrawlRecord? getIncompleteAuthorBatchProgress() {
    try {
      return box.values.firstWhere(
        (r) => r.isBatchProgress &&
            r.batchIsAuthor == true &&
            (r.batchStatus == 'in_progress' || r.batchStatus == 'interrupted'),
      );
    } catch (_) {
      return null;
    }
  }

  /// 获取未完成的批次进度（视频抓取）
  CrawlRecord? getIncompleteVideoBatchProgress() {
    try {
      return box.values.firstWhere(
        (r) => r.isBatchProgress &&
            r.batchIsAuthor == false &&
            (r.batchStatus == 'in_progress' || r.batchStatus == 'interrupted'),
      );
    } catch (_) {
      return null;
    }
  }

  /// 获取所有未完成的批次进度
  List<CrawlRecord> getAllIncompleteBatchProgress() {
    return box.values
        .where((r) =>
            r.isBatchProgress &&
            (r.batchStatus == 'in_progress' || r.batchStatus == 'interrupted'))
        .toList();
  }

  /// 更新批次进度（完成一个后调用）
  Future<void> updateBatchProgress({
    required String batchId,
    required int currentIndex,
    required int completed,
    String? cursor,
    String? status,
  }) async {
    final key = batchProgressId(batchId);
    final progress = box.get(key);
    if (progress == null) return;

    final updated = progress.copyWith(
      batchCurrentIndex: currentIndex,
      batchCompleted: completed,
      batchCursor: cursor ?? progress.batchCursor,
      batchStatus: status ?? progress.batchStatus,
    );
    await box.put(key, updated);
  }

  /// 标记批次为已中断（应用退出/网络断开时调用）
  Future<void> markBatchInterrupted(String batchId) async {
    final key = batchProgressId(batchId);
    final progress = box.get(key);
    if (progress == null) return;

    final updated = progress.copyWith(batchStatus: 'interrupted');
    await box.put(key, updated);
  }

  /// 标记批次为已完成（抓取全部完成后调用）
  Future<void> markBatchCompleted(String batchId) async {
    final key = batchProgressId(batchId);
    final progress = box.get(key);
    if (progress == null) return;

    final updated = progress.copyWith(
      batchStatus: 'completed',
      batchCompleted: progress.batchTotal,
      batchCurrentIndex: progress.batchTotal,
    );
    await box.put(key, updated);
  }

  /// 清除批次进度记录（抓取完成且用户确认后调用）
  Future<void> clearBatchProgress(String batchId) async {
    final key = batchProgressId(batchId);
    await box.delete(key);
  }

  /// 清除所有批次进度记录
  Future<void> clearAllBatchProgress() async {
    final keys = box.values
        .where((r) => r.isBatchProgress)
        .map((r) => r.id)
        .toList();
    await box.deleteAll(keys);
  }

  // ==================== 搜索功能 ====================

  /// 按关键词、平台、抓取类型、日期范围搜索抓取历史
  ///
  /// [keyword] 关键词，匹配 data 中的 nickname、title、url 等字段
  /// [platform] 平台过滤，可选
  /// [crawlType] 抓取类型过滤，可选
  /// [startDate] 起始日期，可选
  /// [endDate] 结束日期，可选
  /// 返回匹配的 CrawlRecord 列表，按时间倒序
  List<CrawlRecord> searchCrawl(
    String keyword, {
    String? platform,
    String? crawlType,
    DateTime? startDate,
    DateTime? endDate,
  }) {
    final lowerKeyword = keyword.toLowerCase();

    var results = box.values.where((record) {
      // 排除批次进度记录
      if (record.isBatchProgress) return false;

      // 关键词匹配：data 中的 nickname、title、url 等字段
      bool matchKeyword = lowerKeyword.isEmpty;
      if (!matchKeyword) {
        // 检查 URL
        if (record.url.toLowerCase().contains(lowerKeyword)) {
          matchKeyword = true;
        } else {
          // 检查 data 中的常见文本字段
          for (final key in _searchableFields) {
            final value = record.data[key];
            if (value != null &&
                value.toString().toLowerCase().contains(lowerKeyword)) {
              matchKeyword = true;
              break;
            }
          }
        }
      }
      if (!matchKeyword) return false;

      // 平台过滤
      if (platform != null && record.platform != platform) return false;

      // 抓取类型过滤
      if (crawlType != null && record.crawlType != crawlType) return false;

      // 日期范围过滤
      if (startDate != null && record.crawledAt.isBefore(startDate)) return false;
      if (endDate != null && record.crawledAt.isAfter(endDate)) return false;

      return true;
    }).toList();

    results.sort((a, b) => b.crawledAt.compareTo(a.crawledAt));
    return results;
  }

  /// 搜索时匹配的 data 字段名
  static const List<String> _searchableFields = [
    'nickname',
    'authorName',
    'title',
    'desc',
    'url',
    'shareUrl',
    'uid',
    'uniqueId',
    'videoId',
    'awemeId',
    'signature',
    'description',
  ];

  // ==================== 收藏功能 ====================

  /// 切换收藏状态
  Future<void> toggleFavorite(String id, {String? folderId}) async {
    final record = box.get(id);
    if (record == null) return;

    final newIsFavorite = !record.isFavorite;
    final updated = record.copyWith(
      isFavorite: newIsFavorite,
      favoritedAt: newIsFavorite ? DateTime.now() : null,
      favoriteFolderId: newIsFavorite ? folderId : null,
      clearFavoriteFolderId: !newIsFavorite,
    );
    await box.put(id, updated);
  }

  /// 添加收藏（指定分组）
  Future<void> addToFavorites(String id, {String? folderId}) async {
    final record = box.get(id);
    if (record == null) return;
    if (record.isFavorite && record.favoriteFolderId == folderId) return;

    final updated = record.copyWith(
      isFavorite: true,
      favoritedAt: DateTime.now(),
      favoriteFolderId: folderId,
      clearFavoriteFolderId: folderId == null,
    );
    await box.put(id, updated);
  }

  /// 移动收藏到指定分组
  Future<void> moveToFolder(String id, String? folderId) async {
    final record = box.get(id);
    if (record == null || !record.isFavorite) return;

    final updated = record.copyWith(
      favoriteFolderId: folderId,
      clearFavoriteFolderId: folderId == null,
    );
    await box.put(id, updated);
  }

  /// 批量移动收藏到指定分组
  Future<void> moveBatchToFolder(List<String> ids, String? folderId) async {
    if (ids.isEmpty) return;
    for (final id in ids) {
      final record = box.get(id);
      if (record == null || !record.isFavorite) continue;
      final updated = record.copyWith(
        favoriteFolderId: folderId,
        clearFavoriteFolderId: folderId == null,
      );
      await box.put(id, updated);
    }
  }

  /// 获取所有收藏（排除批次进度记录）
  List<CrawlRecord> getFavorites() {
    final list = box.values
        .where((r) => !r.isBatchProgress && r.isFavorite)
        .toList();
    list.sort((a, b) {
      // 按收藏时间倒序，收藏时间为空则按抓取时间倒序
      final aTime = a.favoritedAt ?? a.crawledAt;
      final bTime = b.favoritedAt ?? b.crawledAt;
      return bTime.compareTo(aTime);
    });
    return list;
  }

  /// 按分组获取收藏
  List<CrawlRecord> getFavoritesByFolder(String? folderId) {
    final list = box.values.where((r) {
      if (r.isBatchProgress || !r.isFavorite) return false;
      return r.favoriteFolderId == folderId;
    }).toList();
    list.sort((a, b) {
      final aTime = a.favoritedAt ?? a.crawledAt;
      final bTime = b.favoritedAt ?? b.crawledAt;
      return bTime.compareTo(aTime);
    });
    return list;
  }

  /// 获取指定分组的第一条收藏封面
  String? getFolderCover(String? folderId) {
    final favorites = getFavoritesByFolder(folderId);
    if (favorites.isEmpty) return null;
    for (final record in favorites) {
      final cover = record.data['cover']?.toString();
      if (cover != null && cover.isNotEmpty) return cover;
      final avatar = record.data['avatar']?.toString();
      if (avatar != null && avatar.isNotEmpty) return avatar;
    }
    return null;
  }

  /// 取消某个分组下的所有收藏的分组关联（删除分组时调用）
  Future<void> clearFolderAssociation(String folderId,
      {bool deleteFavorites = false}) async {
    final recordsInFolder = box.values
        .where((r) => !r.isBatchProgress && r.isFavorite && r.favoriteFolderId == folderId)
        .toList();
    for (final record in recordsInFolder) {
      if (deleteFavorites) {
        final updated = record.copyWith(
          isFavorite: false,
          favoritedAt: null,
          favoriteFolderId: null,
          clearFavoritedAt: true,
          clearFavoriteFolderId: true,
        );
        await box.put(record.id, updated);
      } else {
        final updated = record.copyWith(
          favoriteFolderId: null,
          clearFavoriteFolderId: true,
        );
        await box.put(record.id, updated);
      }
    }
  }

  /// 判断是否收藏
  bool isFavorite(String id) {
    final record = box.get(id);
    return record?.isFavorite ?? false;
  }

  // ==================== 批量管理 ====================

  /// 批量删除
  Future<void> removeBatch(List<String> ids) async {
    await box.deleteAll(ids);
  }

  /// 批量收藏/取消收藏
  ///
  /// 如果所有指定记录都已收藏，则批量取消收藏
  /// 否则批量设为已收藏
  Future<void> toggleFavoriteBatch(List<String> ids) async {
    if (ids.isEmpty) return;

    // 判断当前是否全部已收藏
    final allFavorited = ids.every((id) => isFavorite(id));
    final newIsFavorite = !allFavorited;
    final now = DateTime.now();

    for (final id in ids) {
      final record = box.get(id);
      if (record == null) continue;
      final updated = record.copyWith(
        isFavorite: newIsFavorite,
        favoritedAt: newIsFavorite ? now : null,
      );
      await box.put(id, updated);
    }
  }

  // ==================== 批量导出 ====================

  /// 批量导出指定记录为 JSON 字符串
  ///
  /// 返回格式化的 JSON 文本，包含记录的完整信息
  String exportBatch(List<String> ids) {
    if (ids.isEmpty) return '';

    final records = <Map<String, dynamic>>[];
    for (final id in ids) {
      final record = box.get(id);
      if (record == null) continue;
      records.add({
        'id': record.id,
        'url': record.url,
        'platform': record.platform,
        'platformName': record.platformName,
        'crawlType': record.crawlType,
        'typeLabel': record.typeLabel,
        'crawledAt': record.crawledAt.toIso8601String(),
        'data': record.data,
        'rawData': record.rawData,
        'batchId': record.batchId,
        'isFavorite': record.isFavorite,
        'favoritedAt': record.favoritedAt?.toIso8601String(),
      });
    }

    const encoder = JsonEncoder.withIndent('  ');
    return encoder.convert({
      'exportType': 'crawl_history',
      'exportedAt': DateTime.now().toIso8601String(),
      'count': records.length,
      'records': records,
    });
  }
}
