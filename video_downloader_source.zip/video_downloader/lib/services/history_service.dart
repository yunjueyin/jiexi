import 'dart:convert';
import 'package:hive_flutter/hive_flutter.dart';
import '../models/video_info.dart';

class HistoryService {
  static const String _boxName = 'video_history';
  Box<VideoInfo>? _box;

  bool get isInitialized => _box != null;

  Future<void> init() async {
    if (_box != null) return;
    try {
      _box = await Hive.openBox<VideoInfo>(_boxName);
    } catch (e) {
      // 打开失败时尝试删除旧数据重新打开
      try {
        await Hive.deleteBoxFromDisk(_boxName);
        _box = await Hive.openBox<VideoInfo>(_boxName);
      } catch (_) {
        rethrow;
      }
    }
  }

  List<VideoInfo> getAll() {
    if (_box == null) return [];
    final list = _box!.values.toList();
    list.sort((a, b) => b.parsedAt.compareTo(a.parsedAt));
    return list;
  }

  /// 分页获取历史记录
  /// 
  /// [page] 页码，从 0 开始
  /// [pageSize] 每页数量
  /// 返回当前页的数据列表
  List<VideoInfo> getPage(int page, {int pageSize = 20}) {
    if (_box == null) return [];
    final list = _box!.values.toList();
    list.sort((a, b) => b.parsedAt.compareTo(a.parsedAt));
    final start = page * pageSize;
    if (start >= list.length) return [];
    final end = (start + pageSize).clamp(0, list.length);
    return list.sublist(start, end);
  }

  /// 获取总记录数
  int get totalCount => _box?.length ?? 0;

  List<VideoInfo> getRecent({int limit = 10}) {
    final list = getAll();
    return list.take(limit).toList();
  }

  Future<void> add(VideoInfo video) async {
    if (_box == null) return;
    if (_box!.containsKey(video.id)) {
      await _box!.delete(video.id);
    }
    await _box!.put(video.id, video);
  }

  Future<void> remove(String id) async {
    if (_box == null) return;
    await _box!.delete(id);
  }

  Future<void> clear() async {
    if (_box == null) return;
    await _box!.clear();
  }

  bool exists(String id) {
    if (_box == null) return false;
    return _box!.containsKey(id);
  }

  VideoInfo? getById(String id) {
    if (_box == null) return null;
    return _box!.get(id);
  }

  // ==================== 搜索功能 ====================

  /// 按关键词、平台、日期范围搜索解析历史
  ///
  /// [keyword] 关键词，匹配视频标题、作者昵称、URL
  /// [platform] 平台过滤，可选
  /// [startDate] 起始日期，可选
  /// [endDate] 结束日期，可选
  /// 返回匹配的 VideoInfo 列表，按时间倒序
  List<VideoInfo> search(
    String keyword, {
    String? platform,
    DateTime? startDate,
    DateTime? endDate,
  }) {
    if (_box == null) return [];
    final lowerKeyword = keyword.toLowerCase();

    var results = _box!.values.where((video) {
      // 关键词匹配：标题、作者、URL
      final matchKeyword = lowerKeyword.isEmpty ||
          video.title.toLowerCase().contains(lowerKeyword) ||
          video.author.toLowerCase().contains(lowerKeyword) ||
          video.url.toLowerCase().contains(lowerKeyword);

      // 平台过滤
      final matchPlatform =
          platform == null || video.platform == platform;

      // 日期范围过滤
      final matchStartDate =
          startDate == null || !video.parsedAt.isBefore(startDate);
      final matchEndDate =
          endDate == null || !video.parsedAt.isAfter(endDate);

      return matchKeyword && matchPlatform && matchStartDate && matchEndDate;
    }).toList();

    results.sort((a, b) => b.parsedAt.compareTo(a.parsedAt));
    return results;
  }

  // ==================== 收藏功能 ====================

  /// 切换收藏状态
  Future<void> toggleFavorite(String id, {String? folderId}) async {
    if (_box == null) return;
    final video = _box!.get(id);
    if (video == null) return;

    final newIsFavorite = !video.isFavorite;
    final updated = video.copyWith(
      isFavorite: newIsFavorite,
      favoritedAt: newIsFavorite ? DateTime.now() : null,
      favoriteFolderId: newIsFavorite ? folderId : null,
      clearFavoriteFolderId: !newIsFavorite,
    );
    await _box!.put(id, updated);
  }

  /// 添加收藏（指定分组）
  Future<void> addToFavorites(String id, {String? folderId}) async {
    if (_box == null) return;
    final video = _box!.get(id);
    if (video == null) return;
    if (video.isFavorite && video.favoriteFolderId == folderId) return;

    final updated = video.copyWith(
      isFavorite: true,
      favoritedAt: DateTime.now(),
      favoriteFolderId: folderId,
      clearFavoriteFolderId: folderId == null,
    );
    await _box!.put(id, updated);
  }

  /// 移动收藏到指定分组
  Future<void> moveToFolder(String id, String? folderId) async {
    if (_box == null) return;
    final video = _box!.get(id);
    if (video == null || !video.isFavorite) return;

    final updated = video.copyWith(
      favoriteFolderId: folderId,
      clearFavoriteFolderId: folderId == null,
    );
    await _box!.put(id, updated);
  }

  /// 批量移动收藏到指定分组
  Future<void> moveBatchToFolder(List<String> ids, String? folderId) async {
    if (_box == null || ids.isEmpty) return;
    for (final id in ids) {
      final video = _box!.get(id);
      if (video == null || !video.isFavorite) continue;
      final updated = video.copyWith(
        favoriteFolderId: folderId,
        clearFavoriteFolderId: folderId == null,
      );
      await _box!.put(id, updated);
    }
  }

  /// 获取所有收藏
  List<VideoInfo> getFavorites() {
    if (_box == null) return [];
    final list = _box!.values.where((v) => v.isFavorite).toList();
    list.sort((a, b) {
      // 按收藏时间倒序，收藏时间为空则按解析时间倒序
      final aTime = a.favoritedAt ?? a.parsedAt;
      final bTime = b.favoritedAt ?? b.parsedAt;
      return bTime.compareTo(aTime);
    });
    return list;
  }

  /// 按分组获取收藏
  ///
  /// [folderId] 为 null 时获取默认分组（favoriteFolderId 为 null 的收藏）
  List<VideoInfo> getFavoritesByFolder(String? folderId) {
    if (_box == null) return [];
    final list = _box!.values.where((v) {
      if (!v.isFavorite) return false;
      return v.favoriteFolderId == folderId;
    }).toList();
    list.sort((a, b) {
      final aTime = a.favoritedAt ?? a.parsedAt;
      final bTime = b.favoritedAt ?? b.parsedAt;
      return bTime.compareTo(aTime);
    });
    return list;
  }

  /// 获取指定分组的第一条收藏封面
  String? getFolderCover(String? folderId) {
    final favorites = getFavoritesByFolder(folderId);
    if (favorites.isEmpty) return null;
    for (final video in favorites) {
      if (video.cover.isNotEmpty) return video.cover;
    }
    return null;
  }

  /// 取消某个分组下的所有收藏的分组关联（删除分组时调用）
  ///
  /// [deleteFavorites] 为 true 时同时删除收藏状态
  Future<void> clearFolderAssociation(String folderId,
      {bool deleteFavorites = false}) async {
    if (_box == null) return;
    final videosInFolder = _box!.values
        .where((v) => v.isFavorite && v.favoriteFolderId == folderId)
        .toList();
    for (final video in videosInFolder) {
      if (deleteFavorites) {
        final updated = video.copyWith(
          isFavorite: false,
          favoritedAt: null,
          favoriteFolderId: null,
          clearFavoritedAt: true,
          clearFavoriteFolderId: true,
        );
        await _box!.put(video.id, updated);
      } else {
        // 移到默认分组（folderId = null）
        final updated = video.copyWith(
          favoriteFolderId: null,
          clearFavoriteFolderId: true,
        );
        await _box!.put(video.id, updated);
      }
    }
  }

  /// 判断是否收藏
  bool isFavorite(String id) {
    if (_box == null) return false;
    final video = _box!.get(id);
    return video?.isFavorite ?? false;
  }

  // ==================== 批量管理 ====================

  /// 批量删除
  Future<void> removeBatch(List<String> ids) async {
    if (_box == null) return;
    await _box!.deleteAll(ids);
  }

  /// 批量收藏/取消收藏
  ///
  /// 如果所有指定记录都已收藏，则批量取消收藏
  /// 否则批量设为已收藏
  Future<void> toggleFavoriteBatch(List<String> ids) async {
    if (_box == null || ids.isEmpty) return;

    // 判断当前是否全部已收藏
    final allFavorited = ids.every((id) => isFavorite(id));
    final newIsFavorite = !allFavorited;
    final now = DateTime.now();

    for (final id in ids) {
      final video = _box!.get(id);
      if (video == null) continue;
      final updated = video.copyWith(
        isFavorite: newIsFavorite,
        favoritedAt: newIsFavorite ? now : null,
      );
      await _box!.put(id, updated);
    }
  }

  // ==================== 批量导出 ====================

  /// 批量导出指定记录为 JSON 字符串
  ///
  /// 返回格式化的 JSON 文本，包含记录的完整信息
  String exportBatch(List<String> ids) {
    if (_box == null || ids.isEmpty) return '';

    final records = <Map<String, dynamic>>[];
    for (final id in ids) {
      final video = _box!.get(id);
      if (video == null) continue;
      records.add({
        'id': video.id,
        'url': video.url,
        'platform': video.platform,
        'platformName': video.platformName,
        'title': video.title,
        'author': video.author,
        'cover': video.cover,
        'videoUrl': video.videoUrl,
        'videoUrlHd': video.videoUrlHd,
        'durationSeconds': video.durationSeconds,
        'type': video.type,
        'typeName': video.typeName,
        'images': video.images,
        'parsedAt': video.parsedAt.toIso8601String(),
        'isFavorite': video.isFavorite,
        'favoritedAt': video.favoritedAt?.toIso8601String(),
      });
    }

    const encoder = JsonEncoder.withIndent('  ');
    return encoder.convert({
      'exportType': 'parse_history',
      'exportedAt': DateTime.now().toIso8601String(),
      'count': records.length,
      'records': records,
    });
  }
}
