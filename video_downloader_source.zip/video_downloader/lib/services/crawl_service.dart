import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:dio/dio.dart';
import 'package:dio/io.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import '../models/api_source.dart';
import '../models/crawl_record.dart';
import '../models/top10_works_result.dart';
import '../models/video_info.dart';
import '../utils/platform_detector.dart';
import '../utils/retry_helper.dart';
import 'crawl/share_page_extractor.dart';
import 'crawl/douyin_uid_service.dart';
import 'crawl/webview_crawler_service.dart';
import 'parser/kuaishou_parser.dart';
import 'parser/parser_service.dart';
import 'proxy_service.dart';

/// 抓取异常
class CrawlException implements Exception {
  final String message;
  CrawlException(this.message);

  @override
  String toString() => 'CrawlException: $message';
}

/// 作者可抓取字段定义（统一版，已废弃）
///
/// 请使用 [CrawlFieldConfigs.getFields] 按平台获取对应字段。
/// 保留此类仅为向后兼容旧代码。
@Deprecated('Use CrawlFieldConfigs.getFields instead')
class AuthorCrawlFields {
  static const all = <CrawlFieldConfig>[
    // 2026-08 起抖音不再对外返回数字 uid：
    // 抓取时按 uid → short_id → sec_uid 回退链取值，保证该字段始终有值
    CrawlFieldConfig('uid', '作者UID/SecUid', true),
    CrawlFieldConfig('uniqueId', '抖音号', true),
    CrawlFieldConfig('nickname', '昵称', true),
    CrawlFieldConfig('avatar', '头像', false),
    CrawlFieldConfig('signature', '简介', true),
    CrawlFieldConfig('followerCount', '粉丝数', true),
    CrawlFieldConfig('followingCount', '关注数', true),
    CrawlFieldConfig('totalFavorited', '总获赞', true),
    CrawlFieldConfig('awemeCount', '作品数', true),
    CrawlFieldConfig('favoriteCount', '收藏数', false),
  ];
}

/// 视频可抓取字段定义（统一版，已废弃）
///
/// 请使用 [CrawlFieldConfigs.getFields] 按平台获取对应字段。
/// 保留此类仅为向后兼容旧代码。
@Deprecated('Use CrawlFieldConfigs.getFields instead')
class VideoCrawlFields {
  static const all = <CrawlFieldConfig>[
    CrawlFieldConfig('videoId', '视频ID', true),
    CrawlFieldConfig('title', '标题/描述', true),
    CrawlFieldConfig('cover', '封面图', false),
    CrawlFieldConfig('diggCount', '点赞数', true),
    CrawlFieldConfig('commentCount', '评论数', true),
    CrawlFieldConfig('shareCount', '分享数', true),
    CrawlFieldConfig('collectCount', '收藏数', true),
    // 播放数：2026-08 实测抖音对匿名请求恒返回 0（官方政策：仅作者本人可见），
    // 抓不到时显示占位符 —；快手 viewCount 正常时可以抓到
    CrawlFieldConfig('playCount', '播放数（抖音不公开）', false),
    CrawlFieldConfig('duration', '时长', true),
    CrawlFieldConfig('createTime', '发布时间', true),
    CrawlFieldConfig('authorUid', '作者UID', false),
    CrawlFieldConfig('authorUniqueId', '作者抖音号', true),
    CrawlFieldConfig('authorNickname', '作者昵称', true),
    CrawlFieldConfig('authorAvatar', '作者头像', false),
    CrawlFieldConfig('videoUrl', '视频地址', false),
    CrawlFieldConfig('videoUrlHd', '高清视频地址', false),
  ];
}

class CrawlFieldConfig {
  final String key;
  final String label;
  final bool defaultSelected;
  const CrawlFieldConfig(this.key, this.label, this.defaultSelected);
}

/// 各平台可抓取的字段配置
///
/// 不同平台实际能抓取到的字段不同，在此集中管理。
/// 使用 [getFields] 根据平台和类型（作者/视频）获取对应的字段列表。
class CrawlFieldConfigs {
  /// 获取指定平台和类型的字段列表
  static List<CrawlFieldConfig> getFields(String platform, {required bool isAuthor}) {
    switch (platform) {
      case 'douyin':
        return isAuthor ? _douyinAuthorFields : _douyinVideoFields;
      case 'kuaishou':
        return isAuthor ? _kuaishouAuthorFields : _kuaishouVideoFields;
      case 'xiaohongshu':
        return isAuthor ? _xiaohongshuAuthorFields : _xiaohongshuVideoFields;
      default:
        return [];
    }
  }

  /// 获取默认选中的字段 key 集合
  static Set<String> getDefaultSelectedKeys(String platform, {required bool isAuthor}) {
    final fields = getFields(platform, isAuthor: isAuthor);
    return fields.where((f) => f.defaultSelected).map((f) => f.key).toSet();
  }

  // ==================== 抖音字段 ====================

  static const List<CrawlFieldConfig> _douyinAuthorFields = [
    CrawlFieldConfig('uid', '作者UID/SecUid', true),
    CrawlFieldConfig('uniqueId', '抖音号', true),
    CrawlFieldConfig('nickname', '昵称', true),
    CrawlFieldConfig('avatar', '头像', false),
    CrawlFieldConfig('signature', '简介', true),
    CrawlFieldConfig('followerCount', '粉丝数', true),
    CrawlFieldConfig('followingCount', '关注数', true),
    CrawlFieldConfig('totalFavorited', '总获赞', true),
    CrawlFieldConfig('awemeCount', '作品数', true),
    CrawlFieldConfig('favoriteCount', '收藏数', false),
  ];

  static const List<CrawlFieldConfig> _douyinVideoFields = [
    CrawlFieldConfig('videoId', '视频ID', true),
    CrawlFieldConfig('title', '标题/描述', true),
    CrawlFieldConfig('cover', '封面图', false),
    CrawlFieldConfig('diggCount', '点赞数', true),
    CrawlFieldConfig('commentCount', '评论数', true),
    CrawlFieldConfig('shareCount', '分享数', true),
    CrawlFieldConfig('collectCount', '收藏数', true),
    CrawlFieldConfig('playCount', '播放数（抖音不公开）', false),
    CrawlFieldConfig('duration', '时长', true),
    CrawlFieldConfig('createTime', '发布时间', true),
    CrawlFieldConfig('authorUid', '作者UID', false),
    CrawlFieldConfig('authorUniqueId', '作者抖音号', true),
    CrawlFieldConfig('authorNickname', '作者昵称', true),
    CrawlFieldConfig('authorAvatar', '作者头像', false),
    CrawlFieldConfig('videoUrl', '视频地址', false),
    CrawlFieldConfig('videoUrlHd', '高清视频地址', false),
  ];

  // ==================== 快手字段 ====================

  static const List<CrawlFieldConfig> _kuaishouAuthorFields = [
    CrawlFieldConfig('uid', '用户ID', true),
    CrawlFieldConfig('uniqueId', '快手号', true),
    CrawlFieldConfig('nickname', '昵称', true),
    CrawlFieldConfig('avatar', '头像', false),
    CrawlFieldConfig('signature', '简介', true),
    CrawlFieldConfig('followerCount', '粉丝数', true),
    CrawlFieldConfig('followingCount', '关注数', true),
    CrawlFieldConfig('totalFavorited', '总获赞', true),
    CrawlFieldConfig('awemeCount', '作品数', true),
  ];

  static const List<CrawlFieldConfig> _kuaishouVideoFields = [
    CrawlFieldConfig('videoId', '视频ID', true),
    CrawlFieldConfig('title', '标题/描述', true),
    CrawlFieldConfig('cover', '封面图', false),
    CrawlFieldConfig('diggCount', '点赞数', true),
    CrawlFieldConfig('commentCount', '评论数', true),
    CrawlFieldConfig('shareCount', '分享数', true),
    CrawlFieldConfig('collectCount', '收藏数', true),
    CrawlFieldConfig('playCount', '播放数', true),
    CrawlFieldConfig('duration', '时长', true),
    CrawlFieldConfig('createTime', '发布时间', true),
    CrawlFieldConfig('authorUid', '作者ID', false),
    CrawlFieldConfig('authorUniqueId', '作者快手号', true),
    CrawlFieldConfig('authorNickname', '作者昵称', true),
    CrawlFieldConfig('authorAvatar', '作者头像', false),
    CrawlFieldConfig('videoUrl', '视频地址', false),
    CrawlFieldConfig('videoUrlHd', '高清视频地址', false),
  ];

  // ==================== 小红书字段 ====================

  static const List<CrawlFieldConfig> _xiaohongshuAuthorFields = [
    CrawlFieldConfig('authorUid', '用户ID', true),
    CrawlFieldConfig('redId', '小红书号', true),
    CrawlFieldConfig('authorNickname', '昵称', true),
    CrawlFieldConfig('authorAvatar', '头像', false),
    CrawlFieldConfig('authorDesc', '简介', true),
    CrawlFieldConfig('followerCount', '粉丝数', true),
    CrawlFieldConfig('followingCount', '关注数', true),
    CrawlFieldConfig('likedCount', '总获赞', true),
    CrawlFieldConfig('noteCount', '笔记数', true),
    CrawlFieldConfig('gender', '性别', false),
  ];

  static const List<CrawlFieldConfig> _xiaohongshuVideoFields = [
    CrawlFieldConfig('noteId', '笔记ID', true),
    CrawlFieldConfig('title', '标题', true),
    CrawlFieldConfig('desc', '描述', true),
    CrawlFieldConfig('cover', '封面图', false),
    CrawlFieldConfig('likedCount', '点赞数', true),
    CrawlFieldConfig('commentCount', '评论数', true),
    CrawlFieldConfig('shareCount', '分享数', true),
    CrawlFieldConfig('collectCount', '收藏数', true),
    CrawlFieldConfig('type', '笔记类型（图文/视频）', true),
    CrawlFieldConfig('time', '发布时间', true),
    CrawlFieldConfig('userId', '作者ID', false),
    CrawlFieldConfig('nickname', '作者昵称', true),
    CrawlFieldConfig('images', '图片列表', false),
    CrawlFieldConfig('videoUrl', '视频地址', false),
  ];
}

/// 抓取服务
///
/// 抓取策略（按优先级）：
/// 1. 第三方 API（已配置时，数据最全）
/// 2. 内置分享页抓取（官方分享页 SSR 数据，含统计数据）
/// 3. 内置解析器（复用 ParserService，基础信息兜底）
/// 4. 直接抓取页面 HTML 提取

/// 作者视频抓取结果
///
/// 包含视频记录列表、分页游标、是否还有更多数据等信息。
class AuthorVideosResult {
  /// 抓取到的视频记录列表
  final List<CrawlRecord> videos;

  /// 下一页游标（null 表示没有更多）
  final String? nextCursor;

  /// 是否还有更多视频
  final bool hasMore;

  /// 作者 ID（用于保存检查点）
  final String authorId;

  /// 作者昵称
  final String? nickname;

  /// 本次抓取到的最新视频发布时间
  final DateTime? latestPublishTime;

  /// 本次抓取到的最新视频 ID
  final String? latestVideoId;

  /// 是否因为增量检查而提前停止（遇到了旧视频）
  final bool stoppedByIncremental;

  AuthorVideosResult({
    required this.videos,
    this.nextCursor,
    this.hasMore = false,
    required this.authorId,
    this.nickname,
    this.latestPublishTime,
    this.latestVideoId,
    this.stoppedByIncremental = false,
  });
}

class CrawlService {
  final bool _isInjectedDio;
  Dio _dio;
  final ParserService _parserService;
  final KuaishouParser _kuaishouParser = KuaishouParser();
  final DouyinUidService _uidService = DouyinUidService();
  ApiSource? _currentSource;
  String? _apiKey;
  String? _customUrl;

  /// 代理服务
  ProxyService? _proxyService;

  /// 设置代理服务并应用到所有内部 Dio 实例
  void setProxyService(ProxyService? proxyService) {
    _proxyService?.removeListener(_onProxyChanged);
    _proxyService = proxyService;
    if (proxyService != null) {
      proxyService.applyToDio(_dio);
      proxyService.addListener(_onProxyChanged);
      // 同步到内部服务
      _parserService.setProxyService(proxyService);
      _kuaishouParser.applyProxy(proxyService);
      _uidService.applyProxy(proxyService);
    } else {
      _dio.httpClientAdapter = IOHttpClientAdapter();
      _parserService.setProxyService(null);
      _kuaishouParser.applyProxy(null);
      _uidService.applyProxy(null);
    }
  }

  void _onProxyChanged() {
    _proxyService?.applyToDio(_dio);
  }

  /// 用户手动设置的抖音 Cookie（如从 WebView 登录后提取）
  /// 非空时优先使用，跳过自动获取 Cookie 的步骤
  Map<String, String> _douyinCookies = {};

  /// 批量抓取间隔时间（毫秒）
  int _crawlIntervalMs = 1000;

  /// 抓取间隔随机抖动范围（毫秒）
  int _crawlJitterMs = 500;

  final Random _random = Random();

  /// UA 轮换：Android Chrome 实测稳定，微信/iPhone 兜底
  static const List<String> _userAgents = [
    'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
    'Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',
    'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36 MicroMessenger/8.0.47.2560(0x28001235)',
  ];

  /// [dio] 可注入自定义 Dio（测试用），默认自动创建
  CrawlService({Dio? dio, ParserService? parserService})
      : _dio = dio ?? Dio(),
        _parserService = parserService ?? ParserService(),
        _isInjectedDio = dio != null {
    _dio.options = BaseOptions(
      headers: _headers(_userAgents.first),
      followRedirects: true,
      maxRedirects: 10,
      connectTimeout: const Duration(seconds: 20),
      receiveTimeout: const Duration(seconds: 20),
      validateStatus: (status) => status! < 500,
    );
  }

  /// 基础配置，用于重建 Dio 实例（清除 Cookie 时保证状态干净）
  BaseOptions get _baseOptions => BaseOptions(
        headers: _headers(_userAgents.first),
        followRedirects: true,
        maxRedirects: 10,
        connectTimeout: const Duration(seconds: 20),
        receiveTimeout: const Duration(seconds: 20),
        validateStatus: (status) => status! < 500,
      );

  /// 设置 API 源
  void setApiSource(ApiSource source, {String? apiKey, String? customUrl}) {
    _currentSource = source;
    _apiKey = apiKey;
    _customUrl = customUrl;
    _parserService.setApiSource(
      source,
      apiKey: apiKey,
      customUrl: source.id == 'custom' ? customUrl : null,
    );
  }

  /// 设置 UID 补全服务 URL（如 Supabase Edge Function）
  void setUidResolveService(String? url) {
    _uidService.customServiceUrl = url;
  }

  /// 设置抖音自定义 Cookie
  /// 传入空 map 或 null 则清除，回退到自动获取 Cookie 模式
  void setDouyinCookies(Map<String, String>? cookies) {
    final wasEmpty = _douyinCookies.isEmpty;
    _douyinCookies = cookies ?? {};
    // 同步给内部解析服务
    _parserService.setDouyinCookies(cookies);
    // 清除 Cookie 时重建 Dio 实例，确保 HttpClient 中残留的 Cookie 被清空
    // 避免之前请求中保存的风控 Cookie 等污染后续匿名模式请求
    // （注入的 Dio 不重建，以免影响测试）
    if (_douyinCookies.isEmpty && !wasEmpty && !_isInjectedDio) {
      _dio = Dio(_baseOptions);
    }
  }

  /// 设置批量抓取间隔时间（毫秒）
  void setCrawlInterval(int ms) {
    _crawlIntervalMs = ms < 0 ? 0 : ms;
  }

  /// 设置抓取间隔随机抖动范围（毫秒）
  void setCrawlJitter(int ms) {
    _crawlJitterMs = ms < 0 ? 0 : ms;
  }

  /// 重试配置
  RetryConfig _retryConfig = RetryConfig.standard;

  /// 抓取状态回调（供 UI 展示进度提示，如「正在通过内置浏览器抓取…」）
  void Function(String message)? onCrawlStatus;

  /// 上报抓取状态（空消息表示清除提示）
  void _reportStatus(String message) => onCrawlStatus?.call(message);

  /// 设置抓取重试次数
  void setCrawlRetryCount(int count) {
    _retryConfig = RetryConfig(
      maxRetries: count,
      initialDelay: const Duration(milliseconds: 800),
      backoffFactor: 2.0,
      maxDelay: const Duration(seconds: 8),
    );
  }

  /// 判断作者/作品列表抓取异常是否值得重试
  ///
  /// WebView 抓取给出的定性结论（需登录/风控受限/作者无作品/用户取消/安全验证）
  /// 重试不会改变结果，反而会重复等待多个完整超时周期（最长数分钟），
  /// 应直接向用户展示精确提示；其余按网络错误常规判断。
  static bool _shouldRetryCrawl(Exception e) {
    final msg = e.toString();
    const definitive = [
      '登录',
      '风控',
      '暂无公开作品',
      '已取消',
      '安全验证',
      '当前平台不支持',
      '进行中',
    ];
    for (final kw in definitive) {
      if (msg.contains(kw)) return false;
    }
    return RetryHelper.isNetworkError(e);
  }

  /// 计算带随机抖动的实际延迟时间（毫秒）
  int _calcDelayMs() {
    if (_crawlIntervalMs <= 0) return 0;
    final jitter = _crawlJitterMs > 0
        ? _random.nextInt(_crawlJitterMs + 1)
        : 0;
    return _crawlIntervalMs + jitter;
  }

  bool get _hasThirdPartyApi {
    final source = _currentSource;
    if (source == null) return false;
    if (source.isBuiltIn) return false;
    if (source.id == 'custom') {
      return _customUrl != null && _customUrl!.isNotEmpty;
    }
    return source.apiUrl != null && source.apiUrl!.isNotEmpty;
  }

  // ==================== 平台能力声明 ====================

  /// 支持作者抓取的平台
  static const List<String> supportedAuthorPlatforms = [
    'douyin',
    'kuaishou',
    'xiaohongshu',
  ];

  /// 支持视频抓取的平台
  static const List<String> supportedVideoPlatforms = [
    'douyin',
    'kuaishou',
    'xiaohongshu',
  ];

  /// 所有支持的平台
  static const List<String> allSupportedPlatforms = [
    'douyin',
    'kuaishou',
    'xiaohongshu',
  ];

  /// 检查平台是否支持作者抓取
  static bool isAuthorSupported(String platform) {
    return supportedAuthorPlatforms.contains(platform);
  }

  /// 检查平台是否支持视频抓取
  static bool isVideoSupported(String platform) {
    return supportedVideoPlatforms.contains(platform);
  }

  /// 检查平台是否支持抓取（作者或视频任一支持即可）
  static bool isPlatformSupported(String platform) {
    return allSupportedPlatforms.contains(platform);
  }

  /// 智能抓取：自动识别链接类型（作者/视频）并调用对应方法
  ///
  /// 返回 [CrawlRecord]，crawlType 为 'author' 或 'video'
  Future<CrawlRecord> crawlSmart(String url, {List<String>? fields}) async {
    final cleanUrl = extractUrl(url) ?? url.trim();
    final expandedUrl = await expandShortUrl(cleanUrl);
    final platform = detectPlatform(expandedUrl);
    final linkType = detectCrawlType(expandedUrl);

    if (platform == 'unknown') {
      throw CrawlException('无法识别链接所属平台，请确认是抖音、快手或小红书的分享链接');
    }

    if (linkType == 'author') {
      if (!isAuthorSupported(platform)) {
        throw CrawlException('${VideoPlatformX.fromId(platform).name}暂不支持作者抓取');
      }
      return await crawlAuthor(expandedUrl, fields: fields);
    } else {
      if (!isVideoSupported(platform)) {
        throw CrawlException('${VideoPlatformX.fromId(platform).name}暂不支持视频抓取');
      }
      return await crawlVideo(expandedUrl, fields: fields);
    }
  }

  String detectPlatform(String url) {
    return PlatformDetector.detectPlatformId(url);
  }

  /// 从文本中正则提取第一个 http/https URL。
  /// 用于处理用户粘贴的带文字内容（如"复制这条链接 xxx https://... 在抖音打开"）。
  static String? extractUrl(String text) {
    return PlatformDetector.extractUrl(text);
  }

  /// 判断链接抓取类型：作者主页 → author，视频 → video
  static String detectCrawlType(String url) {
    final type = PlatformDetector.detectLinkType(url);
    switch (type) {
      case LinkType.author:
        return 'author';
      case LinkType.video:
        return 'video';
      case LinkType.unknown:
        return 'video';
    }
  }

  /// 从 URL 提取抖音 secUid（作者主页链接）
  static String? extractSecUid(String url) {
    final patterns = [
      RegExp(r'/share/user/([A-Za-z0-9_-]{15,})'),
      RegExp(r'/user/([A-Za-z0-9_-]{15,})'),
      RegExp(r'[?&]sec_uid=([A-Za-z0-9_-]{15,})'),
    ];
    for (final p in patterns) {
      final m = p.firstMatch(url);
      if (m != null) {
        final id = m.group(1)!;
        // 排除纯数字 uid 路径误判（如 share/user/88445518961）
        if (!RegExp(r'^\d+$').hasMatch(id)) return id;
      }
    }
    return null;
  }

  /// 从 URL 提取抖音数字 uid（作者主页链接）
  ///
  /// 抖音作者分享链接有时直接带纯数字 uid，如：
  /// - https://www.iesdouyin.com/share/user/88445518961
  /// - https://www.douyin.com/user/88445518961
  /// 注意：仅当路径段为纯数字时才视为 uid，否则为 secUid。
  static String? extractDouyinUidFromUrl(String url) {
    final patterns = [
      RegExp(r'/share/user/(\d{6,})'),
      RegExp(r'/user/(\d{6,})'),
    ];
    for (final p in patterns) {
      final m = p.firstMatch(url);
      if (m != null) {
        final id = m.group(1)!;
        if (RegExp(r'^\d+$').hasMatch(id)) return id;
      }
    }
    return null;
  }

  /// 从 URL 提取快手用户 ID（作者主页链接）
  static String? extractKuaishouUserId(String url) {
    final patterns = [
      RegExp(r'/profile/([A-Za-z0-9_-]{5,})'),
      RegExp(r'/fw/user/([A-Za-z0-9_-]{5,})'),
      RegExp(r'/u/([A-Za-z0-9_-]{10,})'),
      RegExp(r'[?&]userId=([A-Za-z0-9_-]{5,})'),
      RegExp(r'[?&]principalId=([A-Za-z0-9_-]{5,})'),
    ];
    for (final p in patterns) {
      final m = p.firstMatch(url);
      if (m != null) return m.group(1);
    }
    return null;
  }

  /// 从 URL 提取小红书用户 ID
  static String? extractXiaohongshuUserId(String url) {
    final patterns = [
      RegExp(r'/user/profile/([A-Za-z0-9_-]{10,})'),
      RegExp(r'/profile/([A-Za-z0-9_-]{10,})'),
      RegExp(r'/user/([A-Za-z0-9_-]{10,})'),
      RegExp(r'[?&]user_id=([A-Za-z0-9_-]{10,})'),
      RegExp(r'[?&]uid=([A-Za-z0-9_-]{10,})'),
    ];
    for (final p in patterns) {
      final m = p.firstMatch(url);
      if (m != null) return m.group(1);
    }
    return null;
  }

  /// 从 URL 提取抖音作品 ID
  static String? extractDouyinAwemeId(String url) {
    final patterns = [
      RegExp(r'/(?:share/)?video/(\d{15,25})'),
      RegExp(r'/(?:share/)?note/(\d{15,25})'),
      RegExp(r'/slides/(\d{15,25})'),
      RegExp(r'[?&](?:item_id|aweme_id|modal_id)=(\d{15,25})'),
    ];
    for (final p in patterns) {
      final m = p.firstMatch(url);
      if (m != null) return m.group(1);
    }
    return null;
  }

  /// 按用户选择过滤字段；数据非空但过滤结果为空时抛出可读异常
  static Map<String, dynamic> applyFieldSelection(
      Map<String, dynamic> data, List<String>? selected) {
    final filtered = SharePageExtractor.filterFields(data, selected);
    // 如果原始数据为空（完全没抓到任何东西），且用户选了字段，提示抓取失败
    if (data.isEmpty &&
        selected != null &&
        selected.isNotEmpty) {
      throw CrawlException(
        '抓取失败，未能获取到任何数据。\n'
        '请检查链接是否正确，或尝试切换抓取源。',
      );
    }
    return filtered;
  }

  /// 展开短链接（GET 跟随 302，兼容 v.douyin.com / v.kuaishou.com）
  Future<String> expandShortUrl(String url) async {
    var current = url.trim();
    for (var hop = 0; hop < 5; hop++) {
      if (!_isShortLink(current)) return current;
      try {
        final response = await _dio.get(
          current,
          options: Options(followRedirects: false),
        );
        var location = response.headers.value('location') ?? '';
        if (location.isEmpty) return current;
        if (location.startsWith('/')) {
          final uri = Uri.parse(current);
          location = '${uri.scheme}://${uri.host}$location';
        }
        current = location;
      } catch (_) {
        return current;
      }
    }
    return current;
  }

  static bool _isShortLink(String url) =>
      PlatformDetector.isShortLink(url);

  // ==================== 作者抓取 ====================

  /// 抓取作者信息
  ///
  /// [url] 作者主页链接
  /// [fields] 需要抓取的字段列表
  /// [incremental] 是否增量模式：为 true 时会同时抓取作者的新视频
  /// [lastVideoPublishTime] 上次抓取的最新视频发布时间（增量模式使用）
  /// [lastVideoId] 上次抓取的最新视频 ID（增量模式使用，精确去重）
  /// [cursor] 分页游标，用于断点续抓（增量/续抓模式使用）
  /// [videoCount] 增量模式下每页抓取的视频数量
  ///
  /// 当 incremental=true 时，返回的 CrawlRecord 中：
  /// - data 包含作者基本信息
  /// - rawData 中额外包含 'incrementalVideos'（增量视频列表）、
  ///   'nextCursor'（下一页游标）、'hasMoreVideos'（是否还有更多）、
  ///   'stoppedByIncremental'（是否因遇到旧视频而停止）等字段
  Future<CrawlRecord> crawlAuthor(
    String url, {
    List<String>? fields,
    bool incremental = false,
    DateTime? lastVideoPublishTime,
    String? lastVideoId,
    String? cursor,
    int videoCount = 20,
  }) async {
    return RetryHelper.execute(
      () => _crawlAuthorInternal(
        url,
        fields: fields,
        incremental: incremental,
        lastVideoPublishTime: lastVideoPublishTime,
        lastVideoId: lastVideoId,
        cursor: cursor,
        videoCount: videoCount,
      ),
      config: _retryConfig,
      shouldRetry: (e) => RetryHelper.isNetworkError(e),
    );
  }

  Future<CrawlRecord> _crawlAuthorInternal(
    String url, {
    List<String>? fields,
    bool incremental = false,
    DateTime? lastVideoPublishTime,
    String? lastVideoId,
    String? cursor,
    int videoCount = 20,
  }) async {
    final cleanUrl = extractUrl(url) ?? url.trim();
    final expandedUrl = await expandShortUrl(cleanUrl);
    final platform = detectPlatform(expandedUrl);
    final id = 'author_${DateTime.now().millisecondsSinceEpoch}';
    final errors = <String>[];

    Map<String, dynamic> data = {};

    // 策略1: 第三方 API
    if (_hasThirdPartyApi) {
      try {
        data.addAll(await _crawlAuthorViaApi(expandedUrl, platform));
      } catch (e) {
        errors.add('API抓取: ${_formatError(e)}');
      }
    }

    // 策略2: 内置分享页抓取
    if (data.isEmpty) {
      try {
        data.addAll(await _crawlAuthorFromSharePage(expandedUrl, platform));
      } catch (e) {
        errors.add('分享页抓取: ${_formatError(e)}');
      }
    }

    // 策略3: 直接抓取链接页面 HTML
    if (data.isEmpty) {
      try {
        final html = await _fetchPage(expandedUrl);
        data.addAll(SharePageExtractor.douyinAuthorFromHtml(html));
        // 页面标题兜底（作者页标题通常为 "昵称的主页"）
        final nickname = _nicknameFromTitle(html);
        if (data.isEmpty && nickname != null) {
          data['nickname'] = nickname;
        }
      } catch (e) {
        errors.add('页面提取: ${_formatError(e)}');
      }
    }

    if (data.isEmpty) {
      throw CrawlException(_buildErrorMessage('作者数据抓取失败', errors, isAuthor: true));
    }

    final fullData = Map<String, dynamic>.from(data);
    final filteredData = applyFieldSelection(data, fields);

    // 增量模式：抓取作者的新视频
    if (incremental) {
      try {
        final videosResult = await crawlAuthorVideos(
          expandedUrl,
          fields: fields,
          cursor: cursor,
          count: videoCount,
          incremental: true,
          lastVideoPublishTime: lastVideoPublishTime,
          lastVideoId: lastVideoId,
        );
        // 将增量视频结果存入 rawData，供上层使用
        fullData['incrementalVideos'] = videosResult.videos;
        fullData['nextCursor'] = videosResult.nextCursor;
        fullData['hasMoreVideos'] = videosResult.hasMore;
        fullData['stoppedByIncremental'] = videosResult.stoppedByIncremental;
        fullData['latestPublishTime'] = videosResult.latestPublishTime;
        fullData['latestVideoId'] = videosResult.latestVideoId;
        fullData['authorIdForCheckpoint'] = videosResult.authorId;
        fullData['nicknameForCheckpoint'] = videosResult.nickname;
      } catch (e) {
        // 增量视频抓取失败不影响作者信息的返回
        fullData['incrementalError'] = e.toString();
      }
    }

    return CrawlRecord(
      id: id,
      url: expandedUrl,
      platform: platform,
      crawlType: 'author',
      crawledAt: DateTime.now(),
      data: filteredData,
      rawData: fullData,
    );
  }

  /// 内置作者抓取：
  /// 抖音：user/info API（实测公开可用）→ 分享页 SSR 兜底
  /// 快手：GraphQL visionProfile → 移动端页面兜底
  Future<Map<String, dynamic>> _crawlAuthorFromSharePage(
      String url, String platform) async {
    if (platform == 'douyin') {
      final secUid = extractSecUid(url);
      if (secUid == null) {
        throw CrawlException(
            '无法从链接中识别作者ID，请确认是作者主页链接（含 /user/ 或 sec_uid）');
      }

      // 先从 URL 中提取数字 uid（如 share/user/88445518961）
      final urlUid = extractDouyinUidFromUrl(url);

      // 策略A: user/info API（无需 Cookie，2026-08 实测可用）
      // 注意：该接口不返回数字 uid，mapAuthorNode 内已按
      // uid → short_id → sec_uid 回退链填充 uid 字段
      try {
        final data = await _fetchDouyinUserInfo(secUid);
        if (data.isNotEmpty) {
          // 优先用 URL 中提取的数字 uid（如 share/user/88445518961）
          if (urlUid != null && urlUid.isNotEmpty) {
            data['uid'] = urlUid;
            data.remove('uidIsSecUid');
          }
          // uid 不是纯数字时（可能是 short_id 或 sec_uid 回退值），
          // 通过 DouyinUidService 四级级联尝试获取真实数字 uid
          final currentUid = data['uid']?.toString();
          final hasNumericUid = currentUid != null &&
              currentUid.isNotEmpty &&
              currentUid != '0' &&
              RegExp(r'^\d+$').hasMatch(currentUid);
          if (!hasNumericUid) {
            try {
              final realUid = await _uidService.fetchUid(secUid);
              if (realUid != null && realUid.isNotEmpty) {
                data['uid'] = realUid;
                data.remove('uidIsSecUid');
              }
            } catch (_) {
              // 失败不影响主结果，静默降级，继续使用回退值
            }
          }
          _finalizeAuthorUid(data);
          return data;
        }
      } catch (_) {}

      // 策略B: 分享页 SSR（可能被风控拦截，兜底）
      final html =
          await _fetchPageTwoStep('https://www.iesdouyin.com/share/user/$secUid');
      final data = SharePageExtractor.douyinAuthorFromHtml(html);
      // 从 URL 提取的 uid 补充进去
      if (urlUid != null && urlUid.isNotEmpty) {
        data['uid'] = urlUid;
      }
      if (data.isEmpty) {
        throw CrawlException(
            '分享页未嵌入作者数据（可能被风控拦截或需要验证）');
      }
      // uid 不是纯数字时，同样尝试通过级联服务补全
      final currentUid = data['uid']?.toString();
      final hasNumericUid = currentUid != null &&
          currentUid.isNotEmpty &&
          currentUid != '0' &&
          RegExp(r'^\d+$').hasMatch(currentUid);
      if (!hasNumericUid) {
        try {
          final realUid = await _uidService.fetchUid(secUid);
          if (realUid != null && realUid.isNotEmpty) {
            data['uid'] = realUid;
            data.remove('uidIsSecUid');
          }
        } catch (_) {}
      }
      _finalizeAuthorUid(data);
      return data;
    }

    if (platform == 'kuaishou') {
      final userId = extractKuaishouUserId(url);
      final errors = <String>[];

      // 策略A: GraphQL visionProfile
      // （2026-08 匿名请求多返回 null，保留尝试，部分账号/网络仍可用）
      if (userId != null) {
        try {
          final data = await _fetchKuaishouProfile(userId);
          if (data.isNotEmpty) return data;
        } catch (e) {
          errors.add('GraphQL: ${_formatError(e)}');
        }

        // 策略B: live_api 用户信息（移动端页面所用接口，部分网络可用）
        try {
          final data = await _fetchKuaishouLiveUserInfo(userId);
          if (data.isNotEmpty) return data;
        } catch (e) {
          errors.add('live_api: ${_formatError(e)}');
        }
      }

      // 策略C: 移动端页面兜底
      try {
        final html = await _fetchPageTwoStep(url);
        final json = SharePageExtractor.extractAnyJson(html);
        if (json != null) {
          final data = SharePageExtractor.authorFromJson(json);
          if (data.isNotEmpty) return data;
        }
        errors.add('页面未嵌入作者数据');
      } catch (e) {
        errors.add('页面抓取: ${_formatError(e)}');
      }

      throw CrawlException(
        '快手作者数据已被平台限制匿名访问（网页端需登录/验证）：'
        '${errors.join('；')}。'
        '请在抓取页顶部切换为第三方 API 源后重试。',
      );
    }

    if (platform == 'xiaohongshu') {
      final userId = extractXiaohongshuUserId(url);
      if (userId == null) {
        throw CrawlException(
            '无法从链接中识别用户ID，请确认是小红书作者主页链接（含 /user/profile/）');
      }

      // 策略：两步 Cookie 访问作者主页，从 __INITIAL_STATE__ 提取用户信息
      final profileUrl = 'https://www.xiaohongshu.com/user/profile/$userId';
      try {
        final html = await _fetchPageTwoStep(profileUrl);
        final data = _extractXiaohongshuUserFromHtml(html);
        if (data.isNotEmpty) return data;
      } catch (e) {
        throw CrawlException('小红书作者主页获取失败：${_formatError(e)}');
      }

      throw CrawlException(
          '小红书作者页面未提取到用户数据（可能被平台风控或需要登录验证）');
    }

    throw CrawlException('不支持的平台：$platform');
  }

  /// 抖音作者信息收尾：uid 字段只保留纯数字 UID。
  ///
  /// 抓不到真实数字 UID（或当前值实为 sec_uid/short_id）时，直接移除
  /// uid 字段，避免把 sec_uid 当作 UID 展示/导出。
  void _finalizeAuthorUid(Map<String, dynamic> data) {
    data.remove('uidIsSecUid');
    final uid = data['uid']?.toString();
    final isValidNumeric = uid != null &&
        uid.isNotEmpty &&
        uid != '0' &&
        RegExp(r'^\d+$').hasMatch(uid);
    if (!isValidNumeric) {
      data.remove('uid');
      // 避免 sec_uid 误入 uid 相关展示
      data.remove('sec_uid');
    } else {
      data['uid'] = uid;
    }
  }

  /// 抖音 user/info API（sec_uid → 用户公开信息）
  Future<Map<String, dynamic>> _fetchDouyinUserInfo(String secUid) async {
    final response = await _dio.get(
      'https://www.iesdouyin.com/web/api/v2/user/info/',
      queryParameters: {'sec_uid': secUid},
      options: Options(headers: _headers(_userAgents.first)),
    );
    dynamic data = response.data;
    if (data is String) data = jsonDecode(data);
    if (data is! Map) return {};
    return SharePageExtractor.douyinAuthorFromUserInfoApi(data);
  }

  /// 从抖音视频列表 API 提取作者数字 uid
  ///
  /// user/info API 不返回数字 uid，但 aweme/post 接口返回的每条视频
  /// 都带有 author.uid 字段。本方法取第一条视频的 author.uid 作为补充。
  ///
  /// 返回 null 表示获取失败（静默降级，不影响主结果）。
  Future<String?> _fetchDouyinAuthorUidFromAwemeList(String secUid) async {
    try {
      final response = await _dio.get(
        'https://www.iesdouyin.com/web/api/v2/aweme/post/',
        queryParameters: {
          'sec_uid': secUid,
          'count': 1,
          'max_cursor': 0,
        },
        options: Options(headers: _headers(_userAgents.first)),
      );
      dynamic data = response.data;
      if (data is String) data = jsonDecode(data);
      if (data is! Map) return null;

      final awemeList = data['aweme_list'];
      if (awemeList is List && awemeList.isNotEmpty) {
        final firstAweme = awemeList.first;
        if (firstAweme is Map) {
          final author = firstAweme['author'];
          if (author is Map) {
            final uid = author['uid']?.toString();
            if (uid != null && uid.isNotEmpty && uid != '0') {
              // 确保是纯数字 uid（sec_uid 是 base64 编码的长字符串）
              if (RegExp(r'^\d+$').hasMatch(uid)) {
                return uid;
              }
            }
          }
        }
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  /// 通过视频详情 API 获取作者数字 uid
  ///
  /// 策略：先从 aweme/post 拿一个视频 ID，再调用 aweme/iteminfo 详情接口，
  /// 从详情的 author.uid 提取数字 UID。aweme/iteminfo 接口有时比
  /// aweme/post 更容易通过风控（不同接口策略不同）。
  ///
  /// 返回 null 表示获取失败（静默降级，不影响主结果）。
  Future<String?> _fetchDouyinUidFromItemDetail(String secUid) async {
    try {
      // 第一步：先获取一个视频 ID
      final listResponse = await _dio.get(
        'https://www.iesdouyin.com/web/api/v2/aweme/post/',
        queryParameters: {
          'sec_uid': secUid,
          'count': 1,
          'max_cursor': 0,
        },
        options: Options(headers: _headers(_userAgents.first)),
      );
      dynamic listData = listResponse.data;
      if (listData is String) listData = jsonDecode(listData);
      if (listData is! Map) return null;

      final awemeList = listData['aweme_list'];
      if (awemeList is! List || awemeList.isEmpty) return null;

      final firstAweme = awemeList.first;
      if (firstAweme is! Map) return null;

      final awemeId = firstAweme['aweme_id']?.toString() ??
          firstAweme['awemeId']?.toString();
      if (awemeId == null || awemeId.isEmpty) return null;

      // 第二步：调用视频详情 API 获取更完整的 author 信息
      final detailResponse = await _dio.get(
        'https://www.iesdouyin.com/web/api/v2/aweme/iteminfo/',
        queryParameters: {
          'item_ids': awemeId,
        },
        options: Options(headers: _headers(_userAgents.first)),
      );
      dynamic detailData = detailResponse.data;
      if (detailData is String) detailData = jsonDecode(detailData);
      if (detailData is! Map) return null;

      final itemList = detailData['item_list'];
      if (itemList is List && itemList.isNotEmpty) {
        final item = itemList.first;
        if (item is Map) {
          final author = item['author'];
          if (author is Map) {
            final uid = author['uid']?.toString();
            if (uid != null && uid.isNotEmpty && uid != '0') {
              if (RegExp(r'^\d+$').hasMatch(uid)) {
                return uid;
              }
            }
          }
        }
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  /// 从网页版 aweme/post 接口获取作者 uid（带 Cookie，可能返回更完整数据）
  ///
  /// 使用 douyin.com 域名的网页版接口，配合两步 Cookie 请求，
  /// 有时能拿到 iesdouyin 接口拿不到的数据。
  Future<String?> _fetchDouyinUidFromWebPost(String secUid) async {
    try {
      // 先访问首页拿 Cookie
      final homeResponse = await _dio.get(
        'https://www.douyin.com/',
        options: Options(headers: _headers(_userAgents.first)),
      );
      final setCookies = homeResponse.headers['set-cookie'] ?? const <String>[];
      final cookie = setCookies
          .map((c) => c.split(';').first.trim())
          .where((c) => c.contains('='))
          .join('; ');

      if (cookie.isEmpty) return null;

      // 调用网页版接口
      final response = await _dio.get(
        'https://www.douyin.com/aweme/v1/web/aweme/post/',
        queryParameters: {
          'sec_user_id': secUid,
          'count': 1,
          'max_cursor': 0,
          'aid': 6383,
        },
        options: Options(headers: {
          ..._headers(_userAgents.first),
          'Cookie': cookie,
          'Referer': 'https://www.douyin.com/',
        }),
      );

      dynamic data = response.data;
      if (data is String) data = jsonDecode(data);
      if (data is! Map) return null;

      final awemeList = data['aweme_list'];
      if (awemeList is List && awemeList.isNotEmpty) {
        final firstAweme = awemeList.first;
        if (firstAweme is Map) {
          final author = firstAweme['author'];
          if (author is Map) {
            final uid = author['uid']?.toString();
            if (uid != null && uid.isNotEmpty && uid != '0') {
              if (RegExp(r'^\d+$').hasMatch(uid)) {
                return uid;
              }
            }
          }
        }
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  /// 通过抖音号（uniqueId）搜索获取用户 uid
  ///
  /// 使用搜索建议接口，通过抖音号反查 uid。
  /// 注意：搜索接口可能有风控限制，作为最后兜底尝试。
  Future<String?> _fetchDouyinUidByUniqueId(String uniqueId) async {
    try {
      final response = await _dio.get(
        'https://www.iesdouyin.com/web/api/v2/search/suggest/',
        queryParameters: {
          'keyword': uniqueId,
          'type': 1, // 用户搜索
          'count': 5,
        },
        options: Options(headers: _headers(_userAgents.first)),
      );

      dynamic data = response.data;
      if (data is String) data = jsonDecode(data);
      if (data is! Map) return null;

      final userList = data['user_list'] ?? data['sug_list'];
      if (userList is List && userList.isNotEmpty) {
        for (final user in userList) {
          if (user is Map) {
            final userInfo = user['user_info'] ?? user;
            if (userInfo is Map) {
              final uid = userInfo['uid']?.toString() ??
                  userInfo['user_id']?.toString();
              final nickname = userInfo['unique_id']?.toString() ??
                  userInfo['uniqueId']?.toString() ??
                  userInfo['nickname']?.toString();
              // 匹配抖音号（精确匹配优先）
              if (uid != null &&
                  uid.isNotEmpty &&
                  uid != '0' &&
                  RegExp(r'^\d+$').hasMatch(uid)) {
                if (nickname != null &&
                    nickname.toLowerCase() == uniqueId.toLowerCase()) {
                  return uid; // 精确匹配直接返回
                }
              }
            }
          }
        }
        // 没有精确匹配，返回第一个有效 uid
        for (final user in userList) {
          if (user is Map) {
            final userInfo = user['user_info'] ?? user;
            if (userInfo is Map) {
              final uid = userInfo['uid']?.toString() ??
                  userInfo['user_id']?.toString();
              if (uid != null &&
                  uid.isNotEmpty &&
                  uid != '0' &&
                  RegExp(r'^\d+$').hasMatch(uid)) {
                return uid;
              }
            }
          }
        }
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  /// 从作者分享页取第一个视频，通过视频分享页解析获取 author.uid
  ///
  /// 策略：
  /// 1. 先访问作者分享页，从 SSR 数据中提取第一个视频 ID
  /// 2. 用视频分享页的两步 Cookie 逻辑解析该视频（与 DouyinParser 同一套已验证的逻辑）
  /// 3. 从视频 aweme 数据的 author.uid 中提取数字 UID
  ///
  /// 优势：视频分享页的解析逻辑经过大量验证，稳定性高于直接调 API
  Future<String?> _fetchDouyinUidFromFirstVideoSharePage(String secUid) async {
    try {
      // 第一步：从作者分享页提取第一个视频 ID
      String? firstAwemeId;
      final authorUrl = 'https://www.iesdouyin.com/share/user/$secUid';
      final authorHtml = await _fetchPageTwoStep(authorUrl);

      // 从 HTML 中找第一个视频 ID（多种模式匹配）
      final patterns = [
        RegExp(r'/video/(\d{15,25})'),
        RegExp(r'/note/(\d{15,25})'),
        RegExp(r'"aweme_id"\s*:\s*"(\d{15,25})"'),
        RegExp(r'"awemeId"\s*:\s*"(\d{15,25})"'),
        RegExp(r'"item_id"\s*:\s*"(\d{15,25})"'),
      ];
      for (final pattern in patterns) {
        final match = pattern.firstMatch(authorHtml);
        if (match != null) {
          firstAwemeId = match.group(1);
          break;
        }
      }

      if (firstAwemeId == null || firstAwemeId.isEmpty) {
        // 再试试从内嵌 JSON 中找
        final json = SharePageExtractor.extractAnyJson(authorHtml);
        if (json != null) {
          final itemList = SharePageExtractor.deepFindKey(json, 'aweme_list') ??
              SharePageExtractor.deepFindKey(json, 'item_list');
          if (itemList is List && itemList.isNotEmpty) {
            final first = itemList.first;
            if (first is Map) {
              firstAwemeId = first['aweme_id']?.toString() ??
                  first['awemeId']?.toString() ??
                  first['item_id']?.toString();
            }
          }
        }
      }

      if (firstAwemeId == null || firstAwemeId.isEmpty) return null;

      // 第二步：用视频分享页的两步 Cookie 逻辑解析（与 DouyinParser 完全相同的逻辑）
      final videoShareUrl = 'https://www.iesdouyin.com/share/video/$firstAwemeId';

      for (final ua in _userAgents) {
        // 第一步：拿 Cookie
        String cookie = '';
        try {
          final first = await _dio.get(
            videoShareUrl,
            options: Options(headers: _headers(ua)),
          );
          final setCookies = first.headers['set-cookie'] ?? const <String>[];
          cookie = setCookies
              .map((c) => c.split(';').first.trim())
              .where((c) => c.contains('='))
              .join('; ');

          // 第一次响应可能已有数据，顺便试试
          final html1 = first.data?.toString() ?? '';
          final uid1 = _extractUidFromVideoHtml(html1);
          if (uid1 != null) return uid1;
        } catch (_) {
          continue;
        }

        if (cookie.isEmpty) continue;

        // 第二步：带 Cookie 请求
        try {
          final second = await _dio.get(
            videoShareUrl,
            options: Options(
              headers: {..._headers(ua), 'Cookie': cookie},
            ),
          );
          final html2 = second.data?.toString() ?? '';
          final uid2 = _extractUidFromVideoHtml(html2);
          if (uid2 != null) return uid2;
        } catch (_) {
          // 网络异常，换下一个 UA
        }
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  /// 从视频分享页 HTML 中提取 author.uid
  String? _extractUidFromVideoHtml(String html) {
    if (html.isEmpty) return null;

    // 先尝试从内嵌 JSON 中提取
    final json = SharePageExtractor.extractAnyJson(html);
    if (json != null) {
      // 找 videoInfoRes.item_list[0].author.uid
      final videoInfoRes = SharePageExtractor.deepFindKey(json, 'videoInfoRes');
      if (videoInfoRes is Map) {
        final itemList = videoInfoRes['item_list'];
        if (itemList is List && itemList.isNotEmpty) {
          final item = itemList.first;
          if (item is Map) {
            final author = item['author'];
            if (author is Map) {
              final uid = author['uid']?.toString();
              if (uid != null && uid.isNotEmpty && uid != '0' &&
                  RegExp(r'^\d+$').hasMatch(uid)) {
                return uid;
              }
            }
          }
        }
      }
      // 兜底：深度找 awemeDetail
      final awemeDetail = SharePageExtractor.deepFindKey(json, 'awemeDetail');
      if (awemeDetail is Map) {
        final author = SharePageExtractor.deepFindKey(awemeDetail, 'author');
        if (author is Map) {
          final uid = author['uid']?.toString();
          if (uid != null && uid.isNotEmpty && uid != '0' &&
              RegExp(r'^\d+$').hasMatch(uid)) {
            return uid;
          }
        }
      }
    }

    // 最后用正则兜底
    final matches = RegExp(r'"uid"\s*:\s*"(\d{5,25})"').allMatches(html);
    for (final m in matches) {
      final uid = m.group(1);
      if (uid != null && uid.isNotEmpty && uid != '0' &&
          RegExp(r'^\d+$').hasMatch(uid)) {
        return uid;
      }
    }
    return null;
  }

  /// 检查数据中是否已有任何可用的 uid 标识
  /// （数字 uid、short_id 或回退填充的 sec_uid 都算，
  ///  用于决定是否还需要请求已下线的补充接口）
  bool _hasAnyUid(Map<String, dynamic> data) {
    final uid = data['uid']?.toString();
    return uid != null && uid.isNotEmpty && uid != '0';
  }

  /// 快手 GraphQL visionProfile（userId → 用户公开信息）
  Future<Map<String, dynamic>> _fetchKuaishouProfile(String userId) async {
    // 第一步：访问首页拿 Cookie
    final home = await _dio.get(
      'https://www.kuaishou.com/',
      options: Options(headers: _pcHeaders()),
    );
    final setCookies = home.headers['set-cookie'] ?? const <String>[];
    final cookie = setCookies
        .map((c) => c.split(';').first.trim())
        .where((c) => c.contains('='))
        .join('; ');
    if (cookie.isEmpty) return {};

    // 第二步：visionProfile 查询（2026-08 实测 schema）
    final response = await _dio.post(
      'https://www.kuaishou.com/graphql',
      data:
          '{"operationName":"visionProfile","variables":{"userId":"$userId"},"query":"query visionProfile(\$userId: String) { visionProfile(userId: \$userId) { userProfile { profile { user_id user_name headurl } ownerCount { fan photo follow } } } }"}',
      options: Options(headers: {
        ..._pcHeaders(),
        'Cookie': cookie,
        'Content-Type': 'application/json',
        'Origin': 'https://www.kuaishou.com',
      }),
    );
    dynamic data = response.data;
    if (data is String) data = jsonDecode(data);
    if (data is! Map) return {};
    final errors = data['errors'];
    if (errors is List && errors.isNotEmpty) return {};
    return SharePageExtractor.kuaishouAuthorFromGraphql(data);
  }

  /// 快手移动端用户信息接口（m.chenzhongtech.com 页面实际调用）：
  /// GET live.kuaishou.com/live_api/baseuser/userinfo/byid?principalId=xx
  /// 返回 data.userInfo（昵称/头像/ID；粉丝数等需登录，匿名多为空）。
  /// 部分网络（如数据中心 IP）会触发人机验证 result=400002，此时跳过。
  Future<Map<String, dynamic>> _fetchKuaishouLiveUserInfo(String userId) async {
    final response = await _dio.get(
      'https://live.kuaishou.com/live_api/baseuser/userinfo/byid',
      queryParameters: {'principalId': userId, 'caver': '2'},
      options: Options(headers: {
        ..._headers(_userAgents.first),
        'Referer': 'https://m.chenzhongtech.com/',
        'X-Requested-With': 'com.smile.gifmaker',
      }),
    );
    dynamic data = response.data;
    if (data is String) data = jsonDecode(data);
    if (data is! Map) return {};
    final payload = data['data'];
    if (payload is! Map) return {};
    final result = SharePageExtractor.toInt(payload['result']);
    if (result != 1) {
      // 400002 = 人机验证；其他非 1 结果同样视为不可用
      return {};
    }
    return SharePageExtractor.kuaishouAuthorFromLiveApi(payload);
  }

  // ==================== 视频抓取 ====================

  Future<CrawlRecord> crawlVideo(String url, {List<String>? fields}) async {
    return RetryHelper.execute(
      () => _crawlVideoInternal(url, fields: fields),
      config: _retryConfig,
      shouldRetry: (e) => RetryHelper.isNetworkError(e),
    );
  }

  Future<CrawlRecord> _crawlVideoInternal(String url, {List<String>? fields}) async {
    final cleanUrl = extractUrl(url) ?? url.trim();
    final expandedUrl = await expandShortUrl(cleanUrl);
    final platform = detectPlatform(expandedUrl);
    final id = 'video_${DateTime.now().millisecondsSinceEpoch}';
    final errors = <String>[];

    Map<String, dynamic> data = {};

    // 策略1: 第三方 API
    if (_hasThirdPartyApi) {
      try {
        data.addAll(await _crawlVideoViaApi(expandedUrl, platform));
      } catch (e) {
        errors.add('API抓取: ${_formatError(e)}');
      }
    }

    // 策略2: 内置分享页抓取（完整统计数据）
    if (data.isEmpty) {
      try {
        data.addAll(await _crawlVideoFromSharePage(expandedUrl, platform));
      } catch (e) {
        errors.add('分享页抓取: ${_formatError(e)}');
      }
    }

    // 策略3: 内置解析器兜底（基础信息，与首页解析一致）
    if (data.isEmpty) {
      try {
        final videoInfo = await _parserService.parse(expandedUrl);
        data.addAll(_videoInfoToMap(videoInfo));
      } catch (e) {
        errors.add('基础解析: ${_formatError(e)}');
      }
    }

    // 策略4: HTML 补充统计数据（ParserService 兜底后追加统计字段）
    // - data 为空时：用分享页 / 移动端页面作为最终兜底
    // - data 非空时：只补充缺失字段（点赞/评论/分享等）
    try {
      var extraData = <String, dynamic>{};
      if (platform == 'douyin') {
        // 优先用 videoId 构造 SSR 分享页（数据最全）
        final vid = data['videoId']?.toString() ??
            extractDouyinAwemeId(expandedUrl);
        if (vid != null && vid.isNotEmpty) {
          try {
            final html = await _fetchPageTwoStep(
                'https://www.iesdouyin.com/share/video/$vid');
            extraData = SharePageExtractor.douyinVideoFromHtml(html);
          } catch (_) {
            // 分享页失败时再试原始页面
            final html = await _fetchPage(expandedUrl);
            extraData = SharePageExtractor.douyinVideoFromHtml(html);
          }
        } else {
          final html = await _fetchPage(expandedUrl);
          extraData = SharePageExtractor.douyinVideoFromHtml(html);
        }
      } else if (platform == 'kuaishou') {
        // 快手：优先用 fetchPhotoRaw 拿完整数据（含统计）
        final photo = await _kuaishouParser.fetchPhotoRaw(expandedUrl);
        if (photo is Map) {
          extraData = SharePageExtractor.kuaishouVideoFromPhoto(photo);
        } else {
          final h = await _fetchPage(expandedUrl);
          extraData = SharePageExtractor.kuaishouVideoFromHtml(h);
        }
      }
      // 合并：只补充缺失字段，不覆盖已有数据
      extraData.forEach((key, value) {
        if (!data.containsKey(key)) {
          data[key] = value;
        }
      });
    } catch (e) {
      errors.add('页面提取: ${_formatError(e)}');
    }

    if (data.isEmpty) {
      throw CrawlException(_buildErrorMessage('视频数据抓取失败', errors, isAuthor: false));
    }

    // 抖音视频：作者 UID 不是纯数字时，通过级联服务补全真实数字 uid
    if (platform == 'douyin') {
      final authorUid = data['authorUid']?.toString();
      final hasNumericAuthorUid = authorUid != null &&
          authorUid.isNotEmpty &&
          authorUid != '0' &&
          RegExp(r'^\d+$').hasMatch(authorUid);
      if (!hasNumericAuthorUid) {
        final secUid = data['authorSecUid']?.toString();
        if (secUid != null && secUid.isNotEmpty) {
          try {
            final realUid = await _uidService.fetchUid(secUid);
            if (realUid != null && realUid.isNotEmpty) {
              data['authorUid'] = realUid;
            }
          } catch (_) {
            // 失败不影响主结果，静默降级
          }
        }
      }
    }

    final fullData = Map<String, dynamic>.from(data);
    final filteredData = applyFieldSelection(data, fields);

    return CrawlRecord(
      id: id,
      url: expandedUrl,
      platform: platform,
      crawlType: 'video',
      crawledAt: DateTime.now(),
      data: filteredData,
      rawData: fullData,
    );
  }

  /// 批量抓取
  ///
  /// 逐行解析每个 URL，自动判断作者/视频类型，收集所有结果（成功和失败均记录）。
  /// 失败的记录：data 中包含 error 和 status 字段。
  Future<List<CrawlRecord>> crawlBatch(List<String> urls,
      {List<String>? fields, String source = 'builtin'}) async {
    final results = <CrawlRecord>[];
    var index = 0;

    for (final line in urls) {
      index++;
      final trimmed = line.trim();
      if (trimmed.isEmpty) continue;

      // 清洗 URL
      final cleanUrl = extractUrl(trimmed) ?? trimmed;
      if (!cleanUrl.startsWith('http://') && !cleanUrl.startsWith('https://')) {
        results.add(
          CrawlRecord(
            id: 'batch_${DateTime.now().millisecondsSinceEpoch}_$index',
            url: trimmed,
            platform: 'unknown',
            crawlType: detectCrawlType(cleanUrl),
            crawledAt: DateTime.now(),
            data: {
              'error': '无效的链接格式',
              'status': 'failed',
            },
            rawData: null,
          ),
        );
        continue;
      }

      // 判断抓取类型
      final crawlType = detectCrawlType(cleanUrl);

      try {
        CrawlRecord record;
        if (crawlType == 'author') {
          record = await crawlAuthor(cleanUrl, fields: fields);
        } else {
          record = await crawlVideo(cleanUrl, fields: fields);
        }
        results.add(record);
      } catch (e) {
        final platform = detectPlatform(cleanUrl);
        results.add(
          CrawlRecord(
            id: 'batch_${DateTime.now().millisecondsSinceEpoch}_$index',
            url: cleanUrl,
            platform: platform,
            crawlType: crawlType,
            crawledAt: DateTime.now(),
            data: {
              'error': e.toString().replaceAll('CrawlException: ', ''),
              'status': 'failed',
            },
            rawData: null,
          ),
        );
      }

      // 抓取间隔 + 随机抖动，避免风控
      final delayMs = _calcDelayMs();
      if (delayMs > 0 && index < urls.length) {
        await Future.delayed(Duration(milliseconds: delayMs));
      }
    }

    return results;
  }

  // ==================== 断点续传支持 ====================

  /// 创建批次进度记录（用于断点续传的初始状态）
  ///
  /// [batchId] 批次唯一标识
  /// [urls] 全部待抓取 URL 列表
  /// [fields] 选中的抓取字段
  /// [isAuthor] 是否为作者批量抓取
  static CrawlRecord createBatchProgressRecord({
    required String batchId,
    required List<String> urls,
    List<String>? fields,
    required bool isAuthor,
  }) {
    return CrawlRecord(
      id: 'batch_progress_$batchId',
      url: '',
      platform: 'batch',
      crawlType: 'batch_progress',
      crawledAt: DateTime.now(),
      data: {},
      batchId: batchId,
      batchTotal: urls.length,
      batchCompleted: 0,
      batchCurrentIndex: 0,
      batchUrls: List.unmodifiable(urls),
      batchFields: fields != null ? List.unmodifiable(fields) : null,
      batchIsAuthor: isAuthor,
      batchStatus: 'in_progress',
    );
  }

  /// 带进度回调的批量抓取（支持从指定索引开始，用于断点续传）
  ///
  /// [urls] 待抓取 URL 列表
  /// [startIndex] 起始索引（断点续传时从该索引继续）
  /// [fields] 选中的抓取字段
  /// [isAuthor] 是否为作者抓取（false 为视频抓取）
  /// [batchId] 批次 ID
  /// [onProgress] 每完成一个 URL 后的回调，参数为（当前索引，结果记录）
  /// [shouldContinue] 回调返回 false 时停止抓取（用于支持取消操作）
  ///
  /// 返回所有抓取结果（从 startIndex 开始的部分）
  Future<List<CrawlRecord>> crawlBatchWithCallback(
    List<String> urls, {
    int startIndex = 0,
    List<String>? fields,
    required bool isAuthor,
    required String batchId,
    void Function(int index, CrawlRecord record)? onProgress,
    bool Function()? shouldContinue,
  }) async {
    final results = <CrawlRecord>[];

    for (var i = startIndex; i < urls.length; i++) {
      // 检查是否需要停止（支持取消/暂停）
      if (shouldContinue != null && !shouldContinue()) {
        break;
      }

      final trimmed = urls[i].trim();
      if (trimmed.isEmpty) continue;

      // 清洗 URL
      final cleanUrl = extractUrl(trimmed) ?? trimmed;
      if (!cleanUrl.startsWith('http://') && !cleanUrl.startsWith('https://')) {
        final record = CrawlRecord(
          id: 'batch_${DateTime.now().millisecondsSinceEpoch}_$i',
          url: trimmed,
          platform: 'unknown',
          crawlType: isAuthor ? 'author' : 'video',
          crawledAt: DateTime.now(),
          data: {
            'error': '无效的链接格式',
            'status': 'failed',
          },
          rawData: null,
          batchId: batchId,
        );
        results.add(record);
        onProgress?.call(i, record);
        continue;
      }

      try {
        CrawlRecord record;
        if (isAuthor) {
          record = await crawlAuthor(cleanUrl, fields: fields);
        } else {
          record = await crawlVideo(cleanUrl, fields: fields);
        }
        // 注入 batchId
        final recordWithBatch = record.copyWith(batchId: batchId);
        results.add(recordWithBatch);
        onProgress?.call(i, recordWithBatch);
      } catch (e) {
        final platform = detectPlatform(cleanUrl);
        final record = CrawlRecord(
          id: 'batch_${DateTime.now().millisecondsSinceEpoch}_$i',
          url: cleanUrl,
          platform: platform,
          crawlType: isAuthor ? 'author' : 'video',
          crawledAt: DateTime.now(),
          data: {
            'error': e.toString().replaceAll('CrawlException: ', ''),
            'status': 'failed',
          },
          rawData: null,
          batchId: batchId,
        );
        results.add(record);
        onProgress?.call(i, record);
      }

      // 抓取间隔 + 随机抖动，避免风控
      final delayMs = _calcDelayMs();
      if (delayMs > 0 && i < urls.length - 1) {
        await Future.delayed(Duration(milliseconds: delayMs));
      }
    }

    return results;
  }

  /// 从批次进度记录恢复抓取
  ///
  /// 从进度记录中读取 URL 列表、当前索引、字段选择等信息，
  /// 从中断位置继续抓取。
  ///
  /// [progress] 批次进度记录（从 CrawlHistoryService 获取）
  /// [onProgress] 每完成一个 URL 后的回调
  /// [shouldContinue] 回调返回 false 时停止抓取
  ///
  /// 返回新抓取的结果列表（不包含之前已完成的）
  Future<List<CrawlRecord>> resumeBatchCrawl(
    CrawlRecord progress, {
    void Function(int index, CrawlRecord record)? onProgress,
    bool Function()? shouldContinue,
  }) async {
    assert(progress.isBatchProgress, 'progress 必须是批次进度记录');
    assert(progress.batchUrls != null, '批次进度记录必须包含 URL 列表');
    assert(progress.batchId != null, '批次进度记录必须包含 batchId');

    final urls = progress.batchUrls!;
    final startIndex = progress.batchCurrentIndex;
    final fields = progress.batchFields;
    final isAuthor = progress.batchIsAuthor ?? false;
    final batchId = progress.batchId!;

    return crawlBatchWithCallback(
      urls,
      startIndex: startIndex,
      fields: fields,
      isAuthor: isAuthor,
      batchId: batchId,
      onProgress: onProgress,
      shouldContinue: shouldContinue,
    );
  }

  /// 内置视频抓取：抖音走分享页 share/video/{id}（含 statistics），
  /// 快手走 GraphQL VisionVideoDetail 原始数据
  Future<Map<String, dynamic>> _crawlVideoFromSharePage(
      String url, String platform) async {
    if (platform == 'douyin') {
      final itemId = extractDouyinAwemeId(url);
      if (itemId == null) {
        throw CrawlException('无法从链接中提取作品ID，请确认是视频分享链接');
      }
      final html =
          await _fetchPageTwoStep('https://www.iesdouyin.com/share/video/$itemId');
      final data = SharePageExtractor.douyinVideoFromHtml(html);
      if (data.isEmpty) {
        throw CrawlException('分享页未嵌入视频数据（可能被风控拦截或需要验证）');
      }
      return data;
    }

    if (platform == 'kuaishou') {
      final photo = await _kuaishouParser.fetchPhotoRaw(url);
      if (photo == null) {
        throw CrawlException('未能获取快手作品数据');
      }
      final data = SharePageExtractor.kuaishouVideoFromPhoto(photo);
      if (data.isEmpty) {
        throw CrawlException('快手作品数据格式不支持');
      }
      return data;
    }

    if (platform == 'xiaohongshu') {
      // 小红书笔记抓取：直接复用解析器获取完整数据
      final videoInfo = await _parserService.parse(url);
      final data = _videoInfoToMap(videoInfo);
      if (data.isEmpty) {
        throw CrawlException('小红书笔记解析失败');
      }
      // 补充图文类型标识
      if (videoInfo.isImage) {
        data['type'] = 'image';
        data['imageCount'] = videoInfo.imageCount;
        data['images'] = videoInfo.images;
      }
      return data;
    }

    throw CrawlException('不支持的平台：$platform');
  }

  /// VideoInfo 转为 Map（解析器兜底时的基础数据）
  Map<String, dynamic> _videoInfoToMap(VideoInfo info) {
    return {
      'videoId': info.id,
      'title': info.title,
      if (info.cover.isNotEmpty) 'cover': info.cover,
      'authorNickname': info.author,
      if (info.videoUrl != null && info.videoUrl!.isNotEmpty)
        'videoUrl': info.videoUrl,
      if (info.videoUrlHd != null && info.videoUrlHd!.isNotEmpty)
        'videoUrlHd': info.videoUrlHd,
      if (info.durationSeconds != null && info.durationSeconds! > 0)
        'duration': info.durationSeconds,
    };
  }

  // ==================== 错误信息 ====================

  String _buildErrorMessage(String title, List<String> errors,
      {required bool isAuthor}) {
    final buffer = StringBuffer(title);
    if (errors.isNotEmpty) {
      buffer.write('：\n');
      buffer.write(errors.take(3).join('\n'));
    }
    buffer.write(
        '\n\n提示：内置解析器在部分网络环境（如异地/代理IP）可能被平台风控拦截，'
        '可切换第三方 API 源重试。');
    return buffer.toString();
  }

  String _formatError(dynamic e) {
    if (e is DioException) {
      if (e.type == DioExceptionType.connectionTimeout) return '连接超时';
      if (e.type == DioExceptionType.receiveTimeout) return '响应超时';
      if (e.response != null) return 'HTTP ${e.response?.statusCode}';
      return '网络错误';
    }
    final msg = e.toString();
    return msg
        .replaceAll('CrawlException: ', '')
        .replaceAll('ParseException: ', '');
  }

  // ==================== 第三方 API ====================

  Future<Map<String, dynamic>> _crawlAuthorViaApi(
      String url, String platform) async {
    final source = _currentSource!;
    final apiUrl = source.id == 'custom'
        ? (_customUrl ?? source.apiUrl)
        : source.apiUrl;
    if (apiUrl == null || apiUrl.isEmpty) throw CrawlException('API未配置');

    final params = <String, dynamic>{
      'url': url,
      'type': 'author',
    };
    if (source.apiKeyParam != null && _apiKey != null) {
      params[source.apiKeyParam!] = _apiKey!;
    }

    final response = await _dio.get(apiUrl, queryParameters: params);
    if (response.statusCode != 200) {
      throw CrawlException('HTTP ${response.statusCode}');
    }

    return _parseAuthorApiResponse(response.data);
  }

  Future<Map<String, dynamic>> _crawlVideoViaApi(
      String url, String platform) async {
    final source = _currentSource!;
    final apiUrl = source.id == 'custom'
        ? (_customUrl ?? source.apiUrl)
        : source.apiUrl;
    if (apiUrl == null || apiUrl.isEmpty) throw CrawlException('API未配置');

    final params = <String, dynamic>{
      'url': url,
      'type': 'info',
    };
    if (source.apiKeyParam != null && _apiKey != null) {
      params[source.apiKeyParam!] = _apiKey!;
    }

    final response = await _dio.get(apiUrl, queryParameters: params);
    if (response.statusCode != 200) {
      throw CrawlException('HTTP ${response.statusCode}');
    }

    return _parseVideoApiResponse(response.data);
  }

  Map<String, dynamic> _parseAuthorApiResponse(dynamic result) {
    final data = <String, dynamic>{};
    if (result is Map<String, dynamic>) {
      final author = result['author'] ??
          result['data'] ??
          result['user_info'] ??
          result['userInfo'] ??
          result;
      if (author is Map<String, dynamic>) {
        _copyField(author, data, 'uid', ['uid', 'user_id', 'userId']);
        _copyField(author, data, 'secUid', ['sec_uid', 'secUid']);
        _copyField(author, data, 'nickname',
            ['nickname', 'name', 'user_name', 'username']);
        _copyField(author, data, 'avatar',
            ['avatar', 'avatar_larger', 'avatar_thumb', 'avatarMedium']);
        _copyField(author, data, 'signature',
            ['signature', 'description', 'bio', 'desc']);
        _copyField(author, data, 'followerCount',
            ['follower_count', 'followerCount', 'fans_count', 'fansCount']);
        _copyField(author, data, 'followingCount',
            ['following_count', 'followingCount', 'follow_count', 'followCount']);
        _copyField(author, data, 'totalFavorited',
            ['total_favorited', 'totalFavorited', 'like_count', 'totalLikes']);
        _copyField(author, data, 'awemeCount',
            ['aweme_count', 'awemeCount', 'video_count', 'videoCount']);
        _copyField(author, data, 'favoriteCount',
            ['favorite_count', 'favoriteCount']);
      }
    }
    if (data.isEmpty) throw CrawlException('API返回格式不支持');
    return data;
  }

  Map<String, dynamic> _parseVideoApiResponse(dynamic result) {
    final data = <String, dynamic>{};
    if (result is Map<String, dynamic>) {
      final video = result['video'] ??
          result['data'] ??
          result['aweme_detail'] ??
          result;
      if (video is Map<String, dynamic>) {
        _copyField(video, data, 'videoId',
            ['video_id', 'videoId', 'aweme_id', 'awemeId']);
        _copyField(video, data, 'title',
            ['title', 'desc', 'description', 'share_title']);
        _copyField(video, data, 'cover',
            ['cover', 'cover_url', 'dynamic_cover', 'origin_cover']);
        _copyField(video, data, 'diggCount',
            ['digg_count', 'diggCount', 'like_count', 'likeCount']);
        _copyField(video, data, 'commentCount',
            ['comment_count', 'commentCount']);
        _copyField(video, data, 'shareCount',
            ['share_count', 'shareCount']);
        _copyField(video, data, 'collectCount',
            ['collect_count', 'collectCount', 'favorite_count']);
        _copyField(
            video, data, 'playCount', ['play_count', 'playCount', 'view_count', 'viewCount', 'play_count_v2', 'play_num', 'view_num']);
        _copyField(video, data, 'duration',
            ['duration', 'duration_ms', 'durationSeconds', 'videoDuration']);
        _copyField(video, data, 'createTime',
            ['create_time', 'createTime', 'publish_time', 'publishTime']);
        // 作者信息
        final author = video['author'] ??
            video['author_info'] ?? video['authorInfo'];
        if (author is Map<String, dynamic>) {
          _copyField(author, data, 'authorUid', ['uid', 'user_id']);
          _copyField(author, data, 'authorNickname',
              ['nickname', 'name', 'author_name']);
          _copyField(author, data, 'authorAvatar',
              ['avatar', 'avatar_larger']);
        }
      }
    }
    if (data.isEmpty) throw CrawlException('API返回格式不支持');
    return data;
  }

  void _copyField(Map<String, dynamic> src, Map<String, dynamic> dst,
      String dstKey, List<String> srcKeys) {
    for (final key in srcKeys) {
      if (src.containsKey(key) && src[key] != null) {
        dst[dstKey] = src[key];
        return;
      }
    }
  }

  // ==================== 页面抓取 ====================

  /// 将 Cookie Map 转换为 Cookie header 字符串
  String _cookieMapToString(Map<String, String> cookies) {
    return cookies.entries.map((e) => '${e.key}=${e.value}').join('; ');
  }

  /// 两步 Cookie 请求分享页（多 UA 轮换）：
  /// 第一步拿 ttwid 等 Cookie，第二步带 Cookie 请求才能拿到 SSR 数据
  /// 如果设置了自定义 Cookie，则直接使用自定义 Cookie
  Future<String> _fetchPageTwoStep(String url) async {
    // 有自定义 Cookie 时直接使用
    if (_douyinCookies.isNotEmpty) {
      final customCookieStr = _cookieMapToString(_douyinCookies);
      for (final ua in _userAgents) {
        try {
          final response = await _dio.get(
            url,
            options: Options(
              headers: {..._headers(ua), 'Cookie': customCookieStr},
            ),
          );
          final html = response.data?.toString() ?? '';
          if (_hasEmbeddedData(html)) return html;
          // 最后一次的结果也返回，由上层判断
          if (ua == _userAgents.last) return html;
        } catch (_) {
          continue;
        }
      }
      // 自定义 Cookie 全部失败，回退到匿名模式继续
    }

    // 匿名模式：两步 Cookie 逻辑
    for (final ua in _userAgents) {
      String cookie = '';
      try {
        final first = await _dio.get(url, options: Options(headers: _headers(ua)));
        final setCookies = first.headers['set-cookie'] ?? const <String>[];
        cookie = setCookies
            .map((c) => c.split(';').first.trim())
            .where((c) => c.contains('='))
            .join('; ');
        final html1 = first.data?.toString() ?? '';
        // 少数情况第一次响应已含数据
        if (_hasEmbeddedData(html1)) return html1;
      } catch (_) {
        continue; // 换下一个 UA
      }

      if (cookie.isEmpty) continue; // 没有大概率拿不到数据，换 UA

      try {
        final second = await _dio.get(
          url,
          options: Options(headers: {..._headers(ua), 'Cookie': cookie}),
        );
        final html2 = second.data?.toString() ?? '';
        if (_hasEmbeddedData(html2)) return html2;
        // 最后一次尝试的结果也返回，由上层提取判断
        if (ua == _userAgents.last) return html2;
      } catch (_) {
        continue;
      }
    }
    throw CrawlException('分享页请求失败');
  }

  /// 页面是否嵌入了可提取的数据。
  ///
  /// 必须检查"具体内容标记"而非仅存在内嵌 JSON：
  /// 无 Cookie 的首次响应也带空的 _ROUTER_DATA（loaderData 为空），
  /// 若据此提前返回会跳过带 Cookie 的第二次请求，导致统计数据丢失
  /// （2026-08 实测抖音视频分享页首响应无 item_list，二响应才有）。
  bool _hasEmbeddedData(String html) {
    // 抖音视频：item_list 内含具体作品
    if (html.contains('"item_list"') && html.contains('"aweme_id"')) {
      return true;
    }
    // 抖音作者：userInfo / userInfos 节点
    if (html.contains('"userInfos"') || html.contains('"userInfo"')) {
      return true;
    }
    // 快手移动页：photo 数据
    if (html.contains('"mainMvUrls"') || html.contains('"photoUrl"')) {
      return true;
    }
    // 小红书：__INITIAL_STATE__ 内嵌数据
    if (html.contains('__INITIAL_STATE__') ||
        html.contains('__INITIAL_SSR_STATE__')) {
      return true;
    }
    return false;
  }

  Future<String> _fetchPage(String url) async {
    try {
      final response = await _dio.get(
        url,
        options: Options(headers: {
          'Referer': 'https://www.douyin.com/',
        }),
      );
      if (response.statusCode == null || response.statusCode! >= 400) {
        throw CrawlException('HTTP ${response.statusCode}');
      }
      return response.data.toString();
    } on DioException catch (e) {
      if (e.type == DioExceptionType.connectionTimeout) {
        throw CrawlException('连接超时');
      }
      if (e.type == DioExceptionType.receiveTimeout) {
        throw CrawlException('响应超时');
      }
      if (e.response != null) {
        throw CrawlException('HTTP ${e.response?.statusCode}');
      }
      throw CrawlException('网络错误');
    }
  }

  /// 从 <title> 提取作者昵称兜底（作者页标题通常为 "昵称的主页"）
  String? _nicknameFromTitle(String html) {
    final m = RegExp(r'<title>([^<]{1,100})</title>').firstMatch(html);
    if (m == null) return null;
    var t = m.group(1)!.trim();
    t = t.split(RegExp(r'[-—|｜]')).first.trim();
    t = t.replaceFirst(RegExp(r'(的)?(个人)?主页$'), '').trim();
    if (t.isEmpty ||
        t == '抖音' ||
        t == '快手' ||
        t.toLowerCase().contains('verify') ||
        t.toLowerCase().contains('login')) {
      return null;
    }
    return t;
  }

  Map<String, String> _headers(String ua) => {
        'User-Agent': ua,
        'Accept':
            'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
      };

  /// PC 端请求头（快手 GraphQL 需要）
  Map<String, String> _pcHeaders() => {
        'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'zh-CN,zh;q=0.9',
        'Referer': 'https://www.kuaishou.com/',
      };

  // ==================== 小红书作者提取 ====================

  /// 从小红书作者主页 HTML 中提取用户信息
  Map<String, dynamic> _extractXiaohongshuUserFromHtml(String html) {
    final result = <String, dynamic>{};

    // 提取 __INITIAL_STATE__ JSON
    final state = _extractXiaohongshuInitialState(html);
    if (state == null) {
      // 兜底：从 <title> 提取昵称
      final nickname = _nicknameFromTitle(html);
      if (nickname != null) {
        result['authorNickname'] = nickname;
      }
      return result;
    }

    // 深度查找用户数据对象
    final userData = _deepFindXiaohongshuUser(state);
    if (userData == null) return result;

    // 基本信息
    final userId = userData['userId']?.toString() ??
        userData['id']?.toString() ??
        userData['user_id']?.toString();
    if (userId != null) result['authorUid'] = userId;

    final nickname = userData['nickname']?.toString() ??
        userData['nickName']?.toString() ??
        userData['name']?.toString() ??
        userData['username']?.toString();
    if (nickname != null) result['authorNickname'] = nickname;

    final avatar = userData['avatar']?.toString() ??
        userData['avatarUrl']?.toString() ??
        userData['image']?.toString();
    if (avatar != null && avatar.isNotEmpty) result['authorAvatar'] = avatar;

    // 简介
    final desc = userData['desc']?.toString() ??
        userData['description']?.toString() ??
        userData['bio']?.toString();
    if (desc != null && desc.isNotEmpty) result['authorDesc'] = desc;

    // 统计数据
    final stats = userData['stats'] ?? userData['statistics'];
    if (stats is Map) {
      final follows = stats['follows'] ?? stats['followCount'] ?? stats['following'];
      final fans = stats['fans'] ?? stats['fanCount'] ?? stats['followers'];
      final liked = stats['liked'] ?? stats['likedCount'] ?? stats['total_likes'];
      final notes = stats['notes'] ?? stats['noteCount'] ?? stats['total_notes'];
      if (follows != null) result['followingCount'] = follows;
      if (fans != null) result['followerCount'] = fans;
      if (liked != null) result['likedCount'] = liked;
      if (notes != null) result['noteCount'] = notes;
    }

    // 直接在 userData 上的统计字段
    if (userData['follows'] != null) result['followingCount'] = userData['follows'];
    if (userData['fans'] != null) result['followerCount'] = userData['fans'];
    if (userData['liked'] != null) result['likedCount'] = userData['liked'];
    if (userData['notes'] != null) result['noteCount'] = userData['notes'];

    // 性别
    final gender = userData['gender'] ?? userData['sex'];
    if (gender != null) result['gender'] = gender;

    // 地区
    final ip = userData['ipLocation'] ?? userData['ip_location'];
    if (ip != null && ip.toString().isNotEmpty) result['ipLocation'] = ip.toString();

    return result;
  }

  /// 提取小红书页面的 window.__INITIAL_STATE__ JSON
  Map<String, dynamic>? _extractXiaohongshuInitialState(String html) {
    const markers = [
      'window.__INITIAL_STATE__',
      'window.__INITIAL_SSR_STATE__',
      'window.__REDUX_STATE__',
    ];

    for (final marker in markers) {
      try {
        final start = html.indexOf(marker);
        if (start < 0) continue;
        final jsonStart = html.indexOf('{', start);
        if (jsonStart < 0) continue;

        final jsonStr = _extractBalancedJson(html, jsonStart);
        if (jsonStr == null) continue;

        final data = jsonDecode(jsonStr);
        if (data is Map<String, dynamic>) return data;
      } catch (_) {
        continue;
      }
    }
    return null;
  }

  /// 括号配对提取完整 JSON
  String? _extractBalancedJson(String text, int start) {
    var depth = 0;
    var inString = false;
    var escape = false;
    for (var i = start; i < text.length; i++) {
      final c = text[i];
      if (escape) {
        escape = false;
        continue;
      }
      if (inString) {
        if (c == '\\') {
          escape = true;
        } else if (c == '"') {
          inString = false;
        }
        continue;
      }
      if (c == '"') {
        inString = true;
      } else if (c == '{') {
        depth++;
      } else if (c == '}') {
        depth--;
        if (depth == 0) return text.substring(start, i + 1);
      }
    }
    return null;
  }

  /// 在小红书状态数据中深度查找用户对象
  Map<String, dynamic>? _deepFindXiaohongshuUser(dynamic data, {int depth = 0}) {
    if (depth > 10) return null;
    if (data is Map) {
      // 识别用户对象：有 nickname + userId/avatar 等字段
      if (_looksLikeXiaohongshuUser(data)) {
        return Map<String, dynamic>.from(data);
      }
      for (final value in data.values) {
        final result = _deepFindXiaohongshuUser(value, depth: depth + 1);
        if (result != null) return result;
      }
    } else if (data is List) {
      for (final item in data) {
        final result = _deepFindXiaohongshuUser(item, depth: depth + 1);
        if (result != null) return result;
      }
    }
    return null;
  }

  /// 判断是否像小红书用户对象
  bool _looksLikeXiaohongshuUser(dynamic data) {
    if (data is! Map) return false;
    final hasNickname = data['nickname'] != null || data['nickName'] != null;
    final hasUserId = data['userId'] != null || data['user_id'] != null || data['id'] != null;
    final hasAvatar = data['avatar'] != null || data['avatarUrl'] != null;
    // 有昵称 + (用户ID 或 头像) 大概率是用户对象
    return hasNickname && (hasUserId || hasAvatar);
  }

  // ==================== 作者视频列表抓取（支持增量与分页续抓） ====================

  /// 分页抓取作者视频列表
  ///
  /// [url] 作者主页链接
  /// [fields] 需要抓取的字段
  /// [cursor] 分页游标，首次传 null 或 '0'
  /// [count] 每页数量
  /// [incremental] 是否增量模式
  /// [lastVideoPublishTime] 上次抓取的最新视频发布时间（增量模式使用）
  /// [lastVideoId] 上次抓取的最新视频 ID（增量模式使用，精确去重）
  ///
  /// 返回 [AuthorVideosResult]，包含视频列表、下一页游标等信息。
  Future<AuthorVideosResult> crawlAuthorVideos(
    String url, {
    List<String>? fields,
    String? cursor,
    int count = 20,
    bool incremental = false,
    DateTime? lastVideoPublishTime,
    String? lastVideoId,
  }) async {
    return RetryHelper.execute(
      () => _crawlAuthorVideosInternal(
        url,
        fields: fields,
        cursor: cursor,
        count: count,
        incremental: incremental,
        lastVideoPublishTime: lastVideoPublishTime,
        lastVideoId: lastVideoId,
      ),
      config: _retryConfig,
      shouldRetry: _shouldRetryCrawl,
    );
  }

  /// 抓取作者前10条作品并计算统计数据
  ///
  /// 复用 [crawlAuthorVideos] 获取最近发布的 10 条作品，
  /// 然后计算点赞/收藏/评论的总数、平均数、中位数。
  Future<Top10WorksResult> crawlTop10Works(String url, {String? platform}) async {
    return RetryHelper.execute(
      () => _crawlTop10WorksInternal(url, platform: platform),
      config: _retryConfig,
      shouldRetry: _shouldRetryCrawl,
    );
  }

  Future<Top10WorksResult> _crawlTop10WorksInternal(String url, {String? platform}) async {
    final cleanUrl = extractUrl(url) ?? url.trim();
    final expandedUrl = await expandShortUrl(cleanUrl);
    final detectedPlatform = platform ?? detectPlatform(expandedUrl);

    // 抓取作者的前10条视频（不做字段过滤，保留全部数据用于统计）
    final videosResult = await crawlAuthorVideos(
      expandedUrl,
      count: 10,
    );

    if (videosResult.videos.isEmpty) {
      throw CrawlException(
        '未获取到作品数据\n\n'
        '可能原因：\n'
        '1. 抖音接口风控限制（匿名访问受限）\n'
        '2. 作者账号设置了私密权限\n'
        '3. 网络环境问题\n\n'
        '建议：\n'
        '• 切换到「设置-解析源」使用第三方 API\n'
        '• 在「设置-抖音Cookie」中填入登录 Cookie\n'
        '• 确认作者主页链接是否正确',
      );
    }

    // 将 CrawlRecord 转换为 Top10Work 列表
    final works = <Top10Work>[];
    for (final record in videosResult.videos) {
      final rawData = record.rawData ?? record.data;
      final videoId = rawData['videoId']?.toString() ??
          rawData['awemeId']?.toString() ??
          record.id;
      final title = rawData['title']?.toString() ??
          rawData['desc']?.toString() ??
          '';
      final cover = rawData['cover']?.toString() ?? '';
      final likeCount = _parseInt(rawData['diggCount'] ?? rawData['likeCount']);
      final collectCount = _parseInt(rawData['collectCount']);
      final commentCount = _parseInt(rawData['commentCount']);
      final shareCount = rawData['shareCount'] != null
          ? _parseInt(rawData['shareCount'])
          : null;
      final playCount = rawData['playCount'] != null
          ? _parseInt(rawData['playCount'])
          : null;
      final publishTime = _parseVideoCreateTime(
            rawData['createTime'] ?? rawData['publishTime'] ?? rawData['time'],
          ) ??
          record.crawledAt;

      works.add(Top10Work(
        videoId: videoId,
        title: title,
        cover: cover,
        likeCount: likeCount,
        collectCount: collectCount,
        commentCount: commentCount,
        publishTime: publishTime,
        shareCount: shareCount,
        playCount: playCount,
      ));
    }

    // 计算统计数据
    final likeCounts = works.map((w) => w.likeCount).toList();
    final collectCounts = works.map((w) => w.collectCount).toList();
    final commentCounts = works.map((w) => w.commentCount).toList();

    final totalLikes = likeCounts.fold<int>(0, (sum, e) => sum + e);
    final totalCollects = collectCounts.fold<int>(0, (sum, e) => sum + e);
    final totalComments = commentCounts.fold<int>(0, (sum, e) => sum + e);

    final count = works.length;
    final avgLikes = count > 0 ? totalLikes / count : 0.0;
    final avgCollects = count > 0 ? totalCollects / count : 0.0;
    final avgComments = count > 0 ? totalComments / count : 0.0;

    final medianLikes = _calculateMedian(likeCounts);
    final medianCollects = _calculateMedian(collectCounts);
    final medianComments = _calculateMedian(commentCounts);

    // 获取作者头像（从第一条视频的 rawData 中提取）
    String? authorAvatar;
    if (videosResult.videos.isNotEmpty) {
      final rawData = videosResult.videos.first.rawData;
      if (rawData != null) {
        authorAvatar = rawData['authorAvatar']?.toString() ??
            rawData['avatar']?.toString();
        final author = rawData['author'];
        if (author is Map && authorAvatar == null) {
          authorAvatar = author['avatar']?.toString() ??
              author['avatarThumb']?.toString();
        }
      }
    }

    return Top10WorksResult(
      id: 'top10_${DateTime.now().millisecondsSinceEpoch}',
      url: expandedUrl,
      platform: detectedPlatform,
      authorId: videosResult.authorId,
      authorName: videosResult.nickname ?? '未知作者',
      authorAvatar: authorAvatar,
      works: works,
      totalLikes: totalLikes,
      totalCollects: totalCollects,
      totalComments: totalComments,
      avgLikes: avgLikes,
      avgCollects: avgCollects,
      avgComments: avgComments,
      medianLikes: medianLikes,
      medianCollects: medianCollects,
      medianComments: medianComments,
      crawledAt: DateTime.now(),
    );
  }

  /// 计算中位数
  double _calculateMedian(List<int> values) {
    if (values.isEmpty) return 0.0;
    final sorted = List<int>.from(values)..sort();
    final n = sorted.length;
    if (n % 2 == 1) {
      return sorted[n ~/ 2].toDouble();
    } else {
      return (sorted[n ~/ 2 - 1] + sorted[n ~/ 2]) / 2.0;
    }
  }

  /// 安全解析 int
  int _parseInt(dynamic value) {
    if (value == null) return 0;
    if (value is int) return value;
    if (value is double) return value.toInt();
    if (value is String) return int.tryParse(value) ?? 0;
    return 0;
  }

  Future<AuthorVideosResult> _crawlAuthorVideosInternal(
    String url, {
    List<String>? fields,
    String? cursor,
    int count = 20,
    bool incremental = false,
    DateTime? lastVideoPublishTime,
    String? lastVideoId,
  }) async {
    final cleanUrl = extractUrl(url) ?? url.trim();
    final expandedUrl = await expandShortUrl(cleanUrl);
    final platform = detectPlatform(expandedUrl);

    List<Map<String, dynamic>> videoList = [];
    String? nextCursor;
    bool hasMore = false;
    String authorId = '';
    String? nickname;

    // 策略1: 第三方 API
    if (_hasThirdPartyApi) {
      try {
        final result = await _crawlAuthorVideosViaApi(
          expandedUrl,
          platform,
          cursor: cursor,
          count: count,
        );
        videoList = result['videos'] as List<Map<String, dynamic>>;
        nextCursor = result['nextCursor'] as String?;
        hasMore = result['hasMore'] as bool;
        authorId = result['authorId']?.toString() ?? '';
        nickname = result['nickname']?.toString();
      } catch (_) {
        // API 失败，降级到内置
      }
    }

    // 策略2: 内置 API 抓取
    if (videoList.isEmpty) {
      if (platform == 'douyin') {
        final secUid = extractSecUid(expandedUrl);
        if (secUid == null) {
          throw CrawlException('无法从链接中识别作者ID');
        }
        final result = await _fetchDouyinAwemeList(
          secUid,
          cursor: cursor,
          count: count,
        );
        videoList = result['videos'] as List<Map<String, dynamic>>;
        nextCursor = result['nextCursor'] as String?;
        hasMore = result['hasMore'] as bool;
        authorId = secUid;
        // 从第一条视频提取昵称
        if (videoList.isNotEmpty) {
          final firstVideo = videoList.first;
          final author = firstVideo['author'];
          if (author is Map) {
            nickname = author['nickname']?.toString();
            // 尝试获取数字 uid
            final uid = author['uid']?.toString();
            if (uid != null && uid.isNotEmpty && uid != '0' && RegExp(r'^\d+$').hasMatch(uid)) {
              authorId = uid;
            }
          }
        }
      } else {
        // 其他平台暂不支持内置视频列表抓取
        throw CrawlException('当前平台暂不支持作者视频列表抓取，请切换到第三方 API 源');
      }
    }

    // 增量过滤：遇到旧视频时停止
    final filteredVideos = <Map<String, dynamic>>[];
    bool stoppedByIncremental = false;
    DateTime? latestPublishTime;
    String? latestVideoId;

    for (var i = 0; i < videoList.length; i++) {
      final video = videoList[i];
      final videoId = video['videoId']?.toString() ?? video['awemeId']?.toString() ?? '';
      final createTime = _parseVideoCreateTime(video['createTime']);

      // 记录第一条（最新）视频的信息
      if (i == 0) {
        latestPublishTime = createTime;
        latestVideoId = videoId;
      }

      // 增量模式：检查是否遇到旧视频
      if (incremental) {
        // 精确匹配：遇到上次的最后一个视频 ID，停止
        if (lastVideoId != null && lastVideoId.isNotEmpty && videoId == lastVideoId) {
          stoppedByIncremental = true;
          break;
        }
        // 时间判断：发布时间早于上次最新时间，停止
        if (lastVideoPublishTime != null && createTime != null && !createTime.isAfter(lastVideoPublishTime)) {
          stoppedByIncremental = true;
          break;
        }
      }

      filteredVideos.add(video);
    }

    // 如果因为增量停止了，hasMore 设为 false（后面的都是旧的）
    if (stoppedByIncremental) {
      hasMore = false;
      nextCursor = null;
    }

    // 转换为 CrawlRecord 列表
    final records = filteredVideos.map((videoData) {
      final videoId = videoData['videoId']?.toString() ?? videoData['awemeId']?.toString() ?? '';
      final filteredData = applyFieldSelection(videoData, fields);
      return CrawlRecord(
        id: 'video_${DateTime.now().millisecondsSinceEpoch}_$videoId',
        url: videoData['shareUrl']?.toString() ?? expandedUrl,
        platform: platform,
        crawlType: 'video',
        crawledAt: DateTime.now(),
        data: filteredData,
        rawData: videoData,
      );
    }).toList();

    return AuthorVideosResult(
      videos: records,
      nextCursor: nextCursor,
      hasMore: hasMore,
      authorId: authorId,
      nickname: nickname,
      latestPublishTime: latestPublishTime,
      latestVideoId: latestVideoId,
      stoppedByIncremental: stoppedByIncremental,
    );
  }

  /// 解析视频发布时间
  DateTime? _parseVideoCreateTime(dynamic value) {
    if (value == null) return null;
    if (value is DateTime) return value;
    if (value is int) {
      // 时间戳（秒）
      if (value > 1000000000000) {
        // 毫秒
        return DateTime.fromMillisecondsSinceEpoch(value);
      } else {
        // 秒
        return DateTime.fromMillisecondsSinceEpoch(value * 1000);
      }
    }
    if (value is String) {
      final intValue = int.tryParse(value);
      if (intValue != null) {
        return _parseVideoCreateTime(intValue);
      }
      return DateTime.tryParse(value);
    }
    return null;
  }

  /// 第三方 API 抓取作者视频列表
  Future<Map<String, dynamic>> _crawlAuthorVideosViaApi(
    String url,
    String platform, {
    String? cursor,
    int count = 20,
  }) async {
    final source = _currentSource!;
    final apiUrl = source.id == 'custom'
        ? (_customUrl ?? source.apiUrl)
        : source.apiUrl;
    if (apiUrl == null || apiUrl.isEmpty) throw CrawlException('API未配置');

    final params = <String, dynamic>{
      'url': url,
      'type': 'author_works',
      'count': count,
    };
    if (cursor != null && cursor.isNotEmpty) {
      params['cursor'] = cursor;
    }
    if (source.apiKeyParam != null && _apiKey != null) {
      params[source.apiKeyParam!] = _apiKey!;
    }

    final response = await _dio.get(apiUrl, queryParameters: params);
    if (response.statusCode != 200) {
      throw CrawlException('HTTP ${response.statusCode}');
    }

    final result = response.data;
    final videos = <Map<String, dynamic>>[];
    String? nextCursor;
    bool hasMore = false;
    String? authorId;
    String? nickname;

    if (result is Map<String, dynamic>) {
      final data = result['data'] ?? result;
      final list = data['list'] ?? data['videos'] ?? data['aweme_list'] ?? [];
      if (list is List) {
        for (final item in list) {
          if (item is Map<String, dynamic>) {
            videos.add(_normalizeVideoData(item, platform));
          }
        }
      }
      nextCursor = data['nextCursor']?.toString() ??
          data['cursor']?.toString() ??
          data['max_cursor']?.toString();
      hasMore = data['hasMore'] == true ||
          data['has_more'] == true ||
          (nextCursor != null && nextCursor.isNotEmpty && nextCursor != '0');
      authorId = data['authorId']?.toString() ?? data['uid']?.toString();
      nickname = data['nickname']?.toString() ?? data['authorName']?.toString();
    }

    return {
      'videos': videos,
      'nextCursor': nextCursor,
      'hasMore': hasMore,
      'authorId': authorId,
      'nickname': nickname,
    };
  }

  /// 抖音 aweme/post 接口抓取视频列表
  ///
  /// 多级降级策略：
  ///   1. WebView 真实浏览器抓取 —— 主策略（自动通过 JSVMP 风控挑战）
  ///   2. iesdouyin Web API —— 历史接口（快速尝试）
  ///   3. snssdk App API —— 移动端 App 接口
  ///   4. 作者分享页 SSR —— 兜底方案
  Future<Map<String, dynamic>> _fetchDouyinAwemeList(
    String secUid, {
    String? cursor,
    int count = 20,
  }) async {
    final maxCursor = cursor ?? '0';
    final ua = _userAgents.first;
    final errors = <String>[];

    // 策略1: WebView 真实浏览器抓取（主策略，最可靠）
    //
    // 抖音已对纯 HTTP 客户端启用 JSVMP 风控挑战（2026-09 实测：
    // iesdouyin API 返回空、用户主页返回挑战页），任何请求头伪装均无效。
    // 只有真实浏览器内核能执行挑战 JS 并通过风控拿到 SSR 数据。
    // 移动端设备使用用户真实网络环境，成功率远高于服务端代理。
    if (WebviewCrawlerService.isAvailable) {
      try {
        _reportStatus('正在通过内置浏览器访问作者主页…');
        final rawList = await WebviewCrawlerService.instance!.crawlAuthorPosts(
          secUid,
          count: count,
          // 注入用户在「设置-抖音Cookie」保存的登录态：
          // 未登录时作品接口会被风控返回空数据
          cookies: _douyinCookies.isNotEmpty ? _douyinCookies.entries.map((e) => '${e.key}=${e.value}').join('; ') : null,
          onStatus: _reportStatus,
        );
        if (rawList.isNotEmpty) {
          _reportStatus('');
          final videos = <Map<String, dynamic>>[];
          for (var i = 0; i < rawList.length && i < count; i++) {
            videos.add(_normalizeDouyinAwemeData(rawList[i]));
          }
          return {
            'videos': videos,
            'nextCursor': null,
            'hasMore': false,
          };
        }
        errors.add('浏览器抓取未提取到数据');
      } catch (e) {
        final msg = e.toString().replaceAll('DouyinWebviewCrawlException: ', '');
        // 定性结论（作者无公开作品）：接口已返回合法空列表，
        // 无需继续尝试其它策略，直接给出精确提示
        if (msg.contains('暂无公开作品')) {
          throw CrawlException(msg);
        }
        // 登录/风控提示：保留提示文案，继续尝试后续策略，
        // 全部失败后以本提示作为最终错误信息
        errors.add(msg);
      } finally {
        _reportStatus('');
      }
    } else {
      errors.add('当前平台不支持浏览器抓取');
    }

    // 策略2: iesdouyin Web API（历史接口，快速尝试）
    try {
      final apiResult = await _fetchDouyinAwemeListViaWebApi(
        secUid,
        cursor: maxCursor,
        count: count,
        ua: ua,
      );
      if (apiResult['videos'].isNotEmpty) {
        return apiResult;
      }
    } catch (_) {
      // 失败，继续下一个策略
    }

    // 策略3: snssdk App API
    // 移动端环境下（用户真实设备 IP）通常不会被风控
    try {
      final appResult = await _fetchDouyinAwemeListViaAppApi(
        secUid,
        cursor: maxCursor,
        count: count,
      );
      if (appResult['videos'].isNotEmpty) {
        return appResult;
      }
    } catch (_) {
      // 失败，继续下一个策略
    }

    // 策略4: 作者分享页 SSR（兜底方案）
    try {
      final sharePageResult = await _fetchDouyinAwemeListFromSharePage(
        secUid,
        count: count,
      );
      if (sharePageResult['videos'].isNotEmpty) {
        return sharePageResult;
      }
    } catch (_) {
      // 全部失败
    }

    if (errors.isNotEmpty) {
      throw CrawlException('未获取到作品数据：${errors.first}');
    }
    return {
      'videos': <Map<String, dynamic>>[],
      'nextCursor': null,
      'hasMore': false,
    };
  }

  /// 通过 iesdouyin Web API 获取作品列表
  Future<Map<String, dynamic>> _fetchDouyinAwemeListViaWebApi(
    String secUid, {
    required String cursor,
    required int count,
    required String ua,
  }) async {
    // 获取 Cookie：优先使用自定义 Cookie，否则用两步法获取
    String cookie = '';
    if (_douyinCookies.isNotEmpty) {
      cookie = _cookieMapToString(_douyinCookies);
    } else {
      try {
        final homeResponse = await _dio.get(
          'https://www.douyin.com/',
          options: Options(headers: _headers(ua)),
        );
        final setCookies = homeResponse.headers['set-cookie'] ?? const <String>[];
        cookie = setCookies
            .map((c) => c.split(';').first)
            .where((c) => c.contains('='))
            .join('; ');
      } catch (_) {}
    }

    final headers = <String, String>{
      ..._headers(ua),
      'Accept': 'application/json, text/plain, */*',
      'Referer': 'https://www.douyin.com/',
      'Origin': 'https://www.douyin.com',
    };
    if (cookie.isNotEmpty) {
      headers['Cookie'] = cookie;
    }

    // 尝试多个 API 端点
    final endpoints = [
      'https://www.iesdouyin.com/web/api/v2/aweme/post/',
      'https://www.douyin.com/aweme/v1/web/aweme/post/',
    ];

    for (final endpoint in endpoints) {
      try {
        final response = await _dio.get(
          endpoint,
          queryParameters: {
            'sec_uid': secUid,
            'count': count,
            'max_cursor': cursor,
            'aid': '6383',
          },
          options: Options(headers: headers),
        );

        dynamic data = response.data;
        if (data is String) data = jsonDecode(data);
        if (data is! Map) continue;

        // status_code 非 0 表示 API 调用失败（如 11110 需要 dytk、被风控等）
        final statusCode = data['status_code'];
        if (statusCode != null && statusCode != 0) continue;

        final videos = <Map<String, dynamic>>[];
        final awemeList = data['aweme_list'];
        if (awemeList is List) {
          for (final item in awemeList) {
            if (item is Map<String, dynamic>) {
              videos.add(_normalizeDouyinAwemeData(item));
            }
          }
        }

        if (videos.isNotEmpty) {
          final nextMaxCursor = data['max_cursor']?.toString();
          final hasMore = data['has_more'] == true ||
              (nextMaxCursor != null && nextMaxCursor.isNotEmpty && nextMaxCursor != '0');
          return {
            'videos': videos,
            'nextCursor': nextMaxCursor,
            'hasMore': hasMore,
          };
        }
      } catch (_) {
        // 当前端点失败，尝试下一个
        continue;
      }
    }

    // 所有端点都失败
    return {
      'videos': <Map<String, dynamic>>[],
      'nextCursor': null,
      'hasMore': false,
    };
  }

  /// 通过 snssdk App API 获取作品列表
  ///
  /// 使用 App 接口在移动端设备上通常更稳定，
  /// 因为用户的真实设备 IP 不容易被风控。
  Future<Map<String, dynamic>> _fetchDouyinAwemeListViaAppApi(
    String secUid, {
    required String cursor,
    required int count,
  }) async {
    const appUA =
        'com.ss.android.ugc.aweme/260103 (Linux; U; Android 14; Pixel 8 Build/UP1A.231005.007)';

    // 生成随机设备标识（每次请求不同，降低风控概率）
    final deviceId = _generateRandomDigits(16);
    final iid = _generateRandomDigits(11);
    final openudid = _generateRandomHex(16);
    final ts = (DateTime.now().millisecondsSinceEpoch ~/ 1000).toString();

    final params = <String, String>{
      'version_name': '26.1.3',
      'version_code': '260103',
      'app_name': 'aweme',
      'app_version': '26.1.3',
      'channel': 'google_play',
      'device_platform': 'android',
      'device_type': 'Pixel 8',
      'device_brand': 'google',
      'os_version': '14',
      'os_api': '34',
      'ssmix': 'a',
      'manifest_version_code': '260103',
      'update_version_code': '260103',
      'resolution': '1080*2400',
      'dpi': '420',
      'language': 'zh',
      'app_language': 'zh',
      'region': 'CN',
      'sys_region': 'CN',
      'carrier_region': 'CN',
      'ac': 'wifi',
      'aid': '1128',
      'device_id': deviceId,
      'iid': iid,
      'openudid': openudid,
      'uuid': deviceId,
      'ts': ts,
      'sec_user_id': secUid,
      'max_cursor': cursor,
      'count': count.toString(),
    };

    final headers = <String, String>{
      'User-Agent': appUA,
      'X-Gorgon': '00000000000000000000000000000000',
      'X-Khronos': ts,
    };

    // 尝试多个 App API 主机
    final hosts = [
      'api3-normal-c-lf.amemv.com',
      'api-hl.amemv.com',
      'api.amemv.com',
    ];

    for (final host in hosts) {
      try {
        final response = await _dio.get(
          'https://$host/aweme/v1/aweme/post/',
          queryParameters: params,
          options: Options(headers: headers),
        );

        dynamic data = response.data;
        if (data is String) data = jsonDecode(data);
        if (data is! Map) continue;

        final statusCode = data['status_code'];
        if (statusCode != null && statusCode != 0) continue;

        final videos = <Map<String, dynamic>>[];
        final awemeList = data['aweme_list'];
        if (awemeList is List) {
          for (final item in awemeList) {
            if (item is Map<String, dynamic>) {
              videos.add(_normalizeDouyinAwemeData(item));
            }
          }
        }

        if (videos.isNotEmpty) {
          final nextMaxCursor = data['max_cursor']?.toString();
          final hasMore = data['has_more'] == true ||
              (nextMaxCursor != null && nextMaxCursor.isNotEmpty && nextMaxCursor != '0');
          return {
            'videos': videos,
            'nextCursor': nextMaxCursor,
            'hasMore': hasMore,
          };
        }
      } catch (_) {
        // 当前 host 失败，尝试下一个
        continue;
      }
    }

    // 所有 host 都失败，返回空（由外层触发降级）
    return {
      'videos': <Map<String, dynamic>>[],
      'nextCursor': null,
      'hasMore': false,
    };
  }

  /// 生成指定长度的随机数字字符串
  String _generateRandomDigits(int length) {
    final r = DateTime.now().microsecondsSinceEpoch;
    final s = r.toString();
    if (s.length >= length) return s.substring(s.length - length);
    return s.padLeft(length, '0');
  }

  /// 生成指定长度的随机十六进制字符串
  String _generateRandomHex(int length) {
    final chars = '0123456789abcdef';
    final r = DateTime.now().microsecondsSinceEpoch;
    final result = StringBuffer();
    var n = r;
    for (var i = 0; i < length; i++) {
      result.write(chars[n % 16]);
      n = n ~/ 16 + i * 7;
    }
    return result.toString();
  }

  /// 从作者分享页 SSR 数据中提取作品列表（兜底方案）
  ///
  /// 注意：不使用通用的 _fetchPageTwoStep，因为其 _hasEmbeddedData 判断
  /// 会把"有 userInfo 节点"误判为有完整数据，导致跳过带 Cookie 的
  /// 第二次请求。这里以"有视频列表（item_list + aweme_id）"作为
  /// 有效数据的判断标准。
  Future<Map<String, dynamic>> _fetchDouyinAwemeListFromSharePage(
    String secUid, {
    required int count,
  }) async {
    final authorUrl = 'https://www.iesdouyin.com/share/user/$secUid';

    // 判断页面是否含有效视频列表数据
    bool hasVideoList(String html) =>
        html.contains('"item_list"') && html.contains('"aweme_id"');

    String? html;

    // 有自定义 Cookie 时优先使用
    if (_douyinCookies.isNotEmpty) {
      final customCookieStr = _cookieMapToString(_douyinCookies);
      for (final ua in _userAgents) {
        try {
          final response = await _dio.get(
            authorUrl,
            options: Options(
              headers: {..._headers(ua), 'Cookie': customCookieStr},
            ),
          );
          final h = response.data?.toString() ?? '';
          if (hasVideoList(h)) {
            html = h;
            break;
          }
          if (ua == _userAgents.last) html = h; // 保留最后一次结果
        } catch (_) {
          continue;
        }
      }
    }

    // 匿名模式：两步 Cookie 逻辑
    if (html == null || !hasVideoList(html)) {
      for (final ua in _userAgents) {
        String cookie = '';
        String? html1;
        try {
          final first = await _dio.get(authorUrl, options: Options(headers: _headers(ua)));
          final setCookies = first.headers['set-cookie'] ?? const <String>[];
          cookie = setCookies
              .map((c) => c.split(';').first.trim())
              .where((c) => c.contains('='))
              .join('; ');
          html1 = first.data?.toString() ?? '';
          // 极少数情况第一次就有完整视频数据
          if (hasVideoList(html1)) {
            html = html1;
            break;
          }
        } catch (_) {
          continue;
        }

        if (cookie.isEmpty) {
          // 没有 Cookie 大概率拿不到数据，但保留 html1 作为最后兜底
          if (ua == _userAgents.last && html == null) html = html1;
          continue;
        }

        try {
          final second = await _dio.get(
            authorUrl,
            options: Options(headers: {..._headers(ua), 'Cookie': cookie}),
          );
          final html2 = second.data?.toString() ?? '';
          if (hasVideoList(html2)) {
            html = html2;
            break;
          }
          if (ua == _userAgents.last && html == null) html = html2;
        } catch (_) {
          if (ua == _userAgents.last && html == null) html = html1;
          continue;
        }
      }
    }

    if (html == null) {
      throw CrawlException('作者分享页请求失败');
    }

    final rawList = SharePageExtractor.douyinVideoListFromHtml(html);
    final videos = <Map<String, dynamic>>[];

    for (var i = 0; i < rawList.length && i < count; i++) {
      videos.add(_normalizeDouyinAwemeData(rawList[i]));
    }

    return {
      'videos': videos,
      'nextCursor': null,
      'hasMore': false,
    };
  }

  /// 标准化抖音 aweme 数据
  Map<String, dynamic> _normalizeDouyinAwemeData(Map<String, dynamic> aweme) {
    final result = <String, dynamic>{};

    // 视频 ID
    result['videoId'] = aweme['aweme_id'] ?? aweme['awemeId'] ?? '';
    result['awemeId'] = aweme['aweme_id'] ?? aweme['awemeId'] ?? '';

    // 标题/描述
    result['title'] = aweme['desc'] ?? aweme['title'] ?? '';
    result['desc'] = aweme['desc'] ?? aweme['title'] ?? '';

    // 封面
    final coverList = aweme['cover']?['url_list'];
    if (coverList is List && coverList.isNotEmpty) {
      result['cover'] = coverList.first;
    }

    // 统计数据
    final statistics = aweme['statistics'];
    if (statistics is Map) {
      result['diggCount'] = statistics['digg_count'] ?? 0;
      result['commentCount'] = statistics['comment_count'] ?? 0;
      result['shareCount'] = statistics['share_count'] ?? 0;
      result['playCount'] = statistics['play_count'] ?? 0;
      result['collectCount'] = statistics['collect_count'] ?? 0;
    }

    // 时长
    result['duration'] = aweme['duration'] ?? 0;

    // 发布时间
    result['createTime'] = aweme['create_time'];

    // 作者信息
    final author = aweme['author'];
    if (author is Map) {
      result['authorUid'] = author['uid'] ?? author['sec_uid'];
      result['authorSecUid'] = author['sec_uid'];
      result['authorUniqueId'] = author['unique_id'];
      result['authorNickname'] = author['nickname'];
      result['authorAvatar'] = author['avatar_thumb']?['url_list']?.first ??
          author['avatar_medium']?['url_list']?.first;
      result['author'] = author;
    }

    // 分享链接
    result['shareUrl'] = aweme['share_url'] ?? '';

    // 视频地址
    final video = aweme['video'];
    if (video is Map) {
      final playAddr = video['play_addr']?['url_list'];
      if (playAddr is List && playAddr.isNotEmpty) {
        result['videoUrl'] = playAddr.first;
      }
      final downloadAddr = video['download_addr']?['url_list'];
      if (downloadAddr is List && downloadAddr.isNotEmpty) {
        result['videoUrlHd'] = downloadAddr.first;
      }
    }

    return result;
  }

  /// 标准化视频数据（统一字段名）
  Map<String, dynamic> _normalizeVideoData(Map<String, dynamic> video, String platform) {
    if (platform == 'douyin') {
      return _normalizeDouyinAwemeData(video);
    }
    // 其他平台直接返回，字段名由 API 决定
    return Map<String, dynamic>.from(video);
  }
}
