@echo off
chcp 65001 >nul
title 无水印视频下载器 - Windows 构建工具
echo ========================================
echo   无水印视频下载器 - Windows 构建工具
echo ========================================
echo.

echo [1/4] 检查 Flutter 环境...
where flutter >nul 2>&1
if %errorlevel% neq 0 (
    echo     错误: 未找到 Flutter SDK
    echo     请先安装 Flutter: https://docs.flutter.dev/get-started/install/windows
    pause
    exit /b 1
)
echo     Flutter 已安装
echo.

echo [2/4] 获取依赖...
call flutter pub get
if %errorlevel% neq 0 (
    echo     错误: 依赖获取失败
    pause
    exit /b 1
)
echo     依赖获取成功
echo.

echo [3/4] 构建 Windows Release 版本...
call flutter build windows --release
if %errorlevel% neq 0 (
    echo     错误: 构建失败
    pause
    exit /b 1
)
echo     构建成功！
echo.

echo ========================================
echo   构建完成！
echo ========================================
echo.
echo   可执行文件位置:
echo   %cd%\build\windows\x64\runner\Release\video_downloader.exe
echo.
echo   便携式版本: 将整个 Release 文件夹复制出来即可使用
echo.

echo 是否打开构建产物文件夹? (Y/N)
set /p open=
if /i "%open%"=="Y" (
    explorer build\windows\x64\runner\Release
)

echo.
pause
