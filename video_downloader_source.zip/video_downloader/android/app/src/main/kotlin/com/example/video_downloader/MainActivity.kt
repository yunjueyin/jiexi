package com.example.video_downloader

import android.content.ContentValues
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.io.FileInputStream
import java.io.OutputStream

class MainActivity : FlutterActivity() {
    private val CHANNEL = "com.example.video_downloader/media"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "scanFile" -> {
                    val path = call.argument<String>("path")
                    val mimeType = call.argument<String>("mimeType")
                    if (path != null) {
                        scanFile(path, mimeType)
                        result.success(true)
                    } else {
                        result.error("INVALID_ARGUMENT", "path is required", null)
                    }
                }
                "insertMedia" -> {
                    val path = call.argument<String>("path")
                    val mimeType = call.argument<String>("mimeType")
                    val title = call.argument<String>("title")
                    if (path != null && mimeType != null) {
                        val success = insertMedia(path, mimeType, title)
                        result.success(success)
                    } else {
                        result.error("INVALID_ARGUMENT", "path and mimeType are required", null)
                    }
                }
                "getDCIMDirectory" -> {
                    val dcimDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM)
                    val appDir = File(dcimDir, "VideoDownloader")
                    if (!appDir.exists()) {
                        appDir.mkdirs()
                    }
                    result.success(appDir.absolutePath)
                }
                "getPicturesDirectory" -> {
                    val picDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                    val appDir = File(picDir, "VideoDownloader")
                    if (!appDir.exists()) {
                        appDir.mkdirs()
                    }
                    result.success(appDir.absolutePath)
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun scanFile(path: String, mimeType: String?) {
        try {
            val file = File(path)
            if (!file.exists()) return
            MediaScannerConnection.scanFile(
                context,
                arrayOf(path),
                if (mimeType != null) arrayOf(mimeType) else null
            ) { _, _ -> }
        } catch (e: Exception) {
            // 忽略扫描失败
        }
    }

    /**
     * 使用 MediaStore API 将文件插入媒体库，确保相册可见
     * 这是 Android 10+ 上最可靠的方式
     */
    private fun insertMedia(path: String, mimeType: String, title: String?): Boolean {
        return try {
            val file = File(path)
            if (!file.exists()) return false

            val isVideo = mimeType.startsWith("video/")
            val contentResolver = contentResolver

            val contentValues = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
                put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                put(MediaStore.MediaColumns.SIZE, file.length())
                put(MediaStore.MediaColumns.DATE_MODIFIED, file.lastModified() / 1000)
                if (title != null) {
                    put(MediaStore.MediaColumns.TITLE, title)
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    // Android 10+: 设置相对路径
                    val relativePath = if (isVideo) {
                        Environment.DIRECTORY_DCIM + "/VideoDownloader"
                    } else {
                        Environment.DIRECTORY_PICTURES + "/VideoDownloader"
                    }
                    put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
            }

            val collection = if (isVideo) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                } else {
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                }
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                } else {
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                }
            }

            val uri = contentResolver.insert(collection, contentValues) ?: return false

            // 写入文件数据
            val outputStream: OutputStream? = contentResolver.openOutputStream(uri)
            if (outputStream == null) {
                contentResolver.delete(uri, null, null)
                return false
            }

            FileInputStream(file).use { input ->
                outputStream.use { output ->
                    input.copyTo(output)
                }
            }

            // 结束 pending 状态
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                contentValues.clear()
                contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
                contentResolver.update(uri, contentValues, null, null)
            }

            true
        } catch (e: Exception) {
            // 失败则回退到 MediaScannerConnection
            try {
                scanFile(path, mimeType)
            } catch (_: Exception) {}
            false
        }
    }
}
