# 功能增强与 UI/UX 全面优化实施计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 为视频下载器应用增加多源智能路由、抓取增强、收藏夹、历史搜索、下载通知、全面 UI 优化和交互体验升级。

**Architecture:** 分六大阶段实施，从基础设施到上层 UI，每个阶段独立可测试。核心改动集中在服务层（解析/抓取/转换）和状态管理层（Provider），UI 层通过 Consumer/Selector 响应式更新。

**Tech Stack:** Flutter + Dart, Provider 状态管理, Dio 网络请求, Hive/SharedPreferences 本地持久化, flutter_local_notifications 通知, Just Audio 触觉反馈

---

## 阶段总览

| 阶段 | 主题 | 核心任务 |
|------|------|---------|
| 一 | 核心基础设施 | 多源智能路由、自动重试、Tab 缓存 |
| 二 | 抓取功能增强 | 实时预览、增量抓取、持久化断点续传、预估时间 |
| 三 | 链接转换增强 | 批量互转、链接有效性校验 |
| 四 | 历史与收藏 | 历史搜索、批量管理、收藏夹 |
| 五 | 下载体验升级 | 下载进度/速度、通知、并发控制 |
| 六 | UI/UX 全面打磨 | 动画、手势、全面屏适配、智能粘贴、长按菜单等 |

---

## 阶段一：核心基础设施

### Task 1.1：多源智能路由框架

**Files:**
- Modify: `lib/services/parser_route.dart`（新建解析路由服务）
- Modify: `lib/services/parser_service.dart`
- Modify: `lib/services/crawl_service.dart`
- Create: `lib/models/parser_source.dart`

**背景**：当前每个平台只有一个解析源，失败就直接报错。需要为每个平台配置多个备用源，失败时自动 fallback。

- [ ] **Step 1: 定义解析源模型**

在 `lib/models/parser_source.dart` 中创建：

```dart
/// 解析源配置
class ParserSource {
  final String id;           // 源唯一标识，如 'douyin_source1'
  final String name;         // 显示名称，如 '抖音源A'
  final VideoPlatform platform;
  final int priority;        // 优先级，数字越小越先尝试
  final bool enabled;        // 是否启用
  final String type;         // 'builtin' 或 'api'
  final String? endpoint;    // API 源的地址
  final int timeoutSeconds;  // 超时时间

  const ParserSource({
    required this.id,
    required this.name,
    required this.platform,
    required this.priority,
    this.enabled = true,
    this.type = 'builtin',
    this.endpoint,
    this.timeoutSeconds = 15,
  });
}

/// 解析结果（带源信息）
class RoutedParseResult {
  final VideoInfo videoInfo;
  final String sourceId;     // 实际使用的源
  final int attemptCount;    // 尝试次数
  final Duration totalDuration;

  RoutedParseResult({
    required this.videoInfo,
    required this.sourceId,
    required this.attemptCount,
    required this.totalDuration,
  });
}
```

- [ ] **Step 2: 为每个平台配置多源列表**

在 `lib/services/parser_route.dart` 中创建 `ParserRouter` 类：

```dart
class ParserRouter {
  /// 获取指定平台的解析源列表（按优先级排序）
  static List<ParserSource> getSourcesForPlatform(VideoPlatform platform) {
    switch (platform) {
      case VideoPlatform.douyin:
        return const [
          ParserSource(id: 'douyin_builtin', name: '抖音内置', platform: VideoPlatform.douyin, priority: 1, type: 'builtin'),
          ParserSource(id: 'douyin_api1', name: '抖音备用API', platform: VideoPlatform.douyin, priority: 2, type: 'api', endpoint: 'https://api.example.com/douyin'),
          ParserSource(id: 'douyin_api2', name: '抖音第三方源', platform: VideoPlatform.douyin, priority: 3, type: 'api', endpoint: 'https://api2.example.com/douyin'),
        ];
      case VideoPlatform.kuaishou:
        return const [
          ParserSource(id: 'kuaishou_builtin', name: '快手内置', platform: VideoPlatform.kuaishou, priority: 1, type: 'builtin'),
          ParserSource(id: 'kuaishou_api1', name: '快手备用API', platform: VideoPlatform.kuaishou, priority: 2, type: 'api', endpoint: 'https://api.example.com/kuaishou'),
        ];
      case VideoPlatform.xiaohongshu:
        return const [
          ParserSource(id: 'xhs_builtin', name: '小红书内置', platform: VideoPlatform.xiaohongshu, priority: 1, type: 'builtin'),
          ParserSource(id: 'xhs_api1', name: '小红书备用API', platform: VideoPlatform.xiaohongshu, priority: 2, type: 'api', endpoint: 'https://api.example.com/xhs'),
        ];
      case VideoPlatform.unknown:
        return [];
    }
  }
}
```

> 注意：备用 API 源暂时用占位地址，重点是先把路由框架搭好，后续可以替换为真实接口。内置源（builtin）是当前已有的解析逻辑。

- [ ] **Step 3: 实现智能路由解析方法**

在 `ParserRouter` 中添加 `parseWithFallback` 方法：

```dart
/// 带 fallback 的解析
static Future<RoutedParseResult> parseWithFallback(
  String url, {
  VideoPlatform? platform,
  void Function(int current, int total, String sourceName)? onSourceTry,
}) async {
  final targetPlatform = platform ?? PlatformDetector.detectPlatform(url);
  if (targetPlatform == VideoPlatform.unknown) {
    throw Exception('无法识别平台');
  }

  final sources = getSourcesForPlatform(targetPlatform)
      .where((s) => s.enabled)
      .toList()
    ..sort((a, b) => a.priority.compareTo(b.priority));

  if (sources.isEmpty) {
    throw Exception('该平台暂无可用解析源');
  }

  final stopwatch = Stopwatch()..start();
  Exception? lastError;

  for (int i = 0; i < sources.length; i++) {
    final source = sources[i];
    onSourceTry?.call(i + 1, sources.length, source.name);

    try {
      VideoInfo result;
      if (source.type == 'builtin') {
        result = await _parseWithBuiltin(url, targetPlatform);
      } else {
        result = await _parseWithApi(url, source);
      }

      stopwatch.stop();
      return RoutedParseResult(
        videoInfo: result,
        sourceId: source.id,
        attemptCount: i + 1,
        totalDuration: stopwatch.elapsed,
      );
    } catch (e) {
      lastError = e is Exception ? e : Exception(e.toString());
      // 继续尝试下一个源
    }
  }

  stopwatch.stop();
  throw Exception('所有解析源均失败：${lastError?.message ?? "未知错误"}');
}

static Future<VideoInfo> _parseWithBuiltin(String url, VideoPlatform platform) async {
  // 调用现有 ParserService 的解析逻辑
  // 需要从 ParserService 中抽出各平台内置解析方法
  final service = ParserService();
  return service.parse(url, platform.id);
}

static Future<VideoInfo> _parseWithApi(String url, ParserSource source) async {
  // API 源解析（占位实现，后续接入真实 API）
  final dio = Dio();
  try {
    final response = await dio.get(
      source.endpoint!,
      queryParameters: {'url': url},
      options: Options(
        sendTimeout: Duration(seconds: source.timeoutSeconds),
        receiveTimeout: Duration(seconds: source.timeoutSeconds),
      ),
    );
    // TODO: 根据实际 API 返回格式解析
    throw Exception('API 源暂未实现');
  } finally {
    dio.close();
  }
}
```

- [ ] **Step 4: 在 ParserService 中集成路由**

修改 `ParserService.parse()` 方法，内部委托给 `ParserRouter.parseWithFallback()`。

修改 `lib/services/parser_service.dart` 中的 `parse` 方法，保留原方法签名，但内部使用路由：

```dart
Future<VideoInfo> parse(String url, String source) async {
  final platform = PlatformDetector.detectPlatform(url);
  final result = await ParserRouter.parseWithFallback(url, platform: platform);
  return result.videoInfo;
}
```

- [ ] **Step 5: 验证编译通过**

运行 `flutter analyze`，确保无 error。

### Task 1.2：自动重试机制

**Files:**
- Create: `lib/utils/retry_helper.dart`
- Modify: `lib/services/parser_service.dart`
- Modify: `lib/services/crawl_service.dart`
- Modify: `lib/services/convert_service.dart`
- Modify: `lib/providers/settings_provider.dart`（加重试次数设置）

- [ ] **Step 1: 创建重试工具类**

```dart
/// 重试配置
class RetryConfig {
  final int maxRetries;        // 最大重试次数
  final Duration initialDelay; // 初始延迟
  final double backoffFactor;  // 退避因子（如 2.0 表示每次延迟翻倍）
  final Duration maxDelay;     // 最大延迟

  const RetryConfig({
    this.maxRetries = 2,
    this.initialDelay = const Duration(seconds: 1),
    this.backoffFactor = 2.0,
    this.maxDelay = const Duration(seconds: 10),
  });
}

/// 重试工具
class RetryHelper {
  /// 带重试的执行
  static Future<T> executeWithRetry<T>(
    Future<T> Function() action, {
    RetryConfig config = const RetryConfig(),
    bool Function(Exception e)? shouldRetry,
    void Function(int attempt, Exception e)? onRetry,
  }) async {
    int attempt = 0;
    Exception? lastError;

    while (attempt <= config.maxRetries) {
      try {
        return await action();
      } on Exception catch (e) {
        lastError = e;
        attempt++;

        if (attempt > config.maxRetries) rethrow;
        if (shouldRetry != null && !shouldRetry(e)) rethrow;

        final delayMs = (config.initialDelay.inMilliseconds *
                pow(config.backoffFactor, attempt - 1))
            .toInt();
        final delay = Duration(
          milliseconds: delayMs.clamp(0, config.maxDelay.inMilliseconds),
        );

        onRetry?.call(attempt, e);
        await Future.delayed(delay);
      }
    }

    throw lastError!;
  }
}
```

- [ ] **Step 2: 在设置中增加重试次数配置**

在 `SettingsProvider` 中增加 `parseRetryCount`、`crawlRetryCount`（默认 2 次），并在设置页增加对应选项。

- [ ] **Step 3: 解析服务集成重试**

在 `ParserRouter.parseWithFallback` 中，每个源的解析都加上重试包装。

- [ ] **Step 4: 抓取服务集成重试**

在 `CrawlService` 的单条抓取逻辑中加入重试，抓取失败时按配置自动重试。

- [ ] **Step 5: 验证编译通过**

### Task 1.3：Tab 缓存（状态保持）

**Files:**
- Modify: `lib/pages/home_page.dart`
- Modify: `lib/pages/crawl/crawl_page.dart`
- Modify: `lib/pages/convert/convert_page.dart`
- Modify: `lib/main.dart`（主框架）

- [ ] **Step 1: 用 IndexedStack + AutomaticKeepAliveClientMixin 替换直接切换**

在主页面框架中，将原来的 `body: _pages[_currentIndex]` 改为 `IndexedStack`，配合 `PageStorageKey` 保持各页面状态。

```dart
body: IndexedStack(
  index: _currentIndex,
  children: [
    HomePage(key: const PageStorageKey('home')),
    CrawlPage(key: const PageStorageKey('crawl')),
    ConvertPage(key: const PageStorageKey('convert')),
    SettingsPage(key: const PageStorageKey('settings')),
  ],
),
```

- [ ] **Step 2: 各页面使用 AutomaticKeepAliveClientMixin**

确保三个主要页面的 State 都 `with AutomaticKeepAliveClientMixin`，`build` 方法调用 `super.build(context)`。

- [ ] **Step 3: 验证编译通过**

---

## 阶段二：抓取功能增强

### Task 2.1：抓取结果实时预览

**Files:**
- Modify: `lib/services/crawl_service.dart`
- Modify: `lib/pages/crawl/crawl_page.dart`
- Create: `lib/models/crawl_progress.dart`

- [ ] **Step 1: 定义抓取进度模型**

```dart
/// 单条抓取状态
enum CrawlItemStatus { pending, crawling, success, failed, skipped }

/// 单条抓取进度
class CrawlItemProgress {
  final String url;
  final CrawlItemStatus status;
  final Map<String, dynamic>? data;  // 成功时的数据
  final String? errorMessage;        // 失败时的错误
  final int retryCount;

  CrawlItemProgress({
    required this.url,
    this.status = CrawlItemStatus.pending,
    this.data,
    this.errorMessage,
    this.retryCount = 0,
  });

  CrawlItemProgress copyWith({
    CrawlItemStatus? status,
    Map<String, dynamic>? data,
    String? errorMessage,
    int? retryCount,
  }) {
    return CrawlItemProgress(
      url: url,
      status: status ?? this.status,
      data: data ?? this.data,
      errorMessage: errorMessage ?? this.errorMessage,
      retryCount: retryCount ?? this.retryCount,
    );
  }
}

/// 整体抓取进度
class CrawlBatchProgress {
  final List<CrawlItemProgress> items;
  final int totalCount;
  final int successCount;
  final int failCount;
  final int pendingCount;
  final Duration elapsed;

  CrawlBatchProgress({
    required this.items,
    required this.totalCount,
    required this.successCount,
    required this.failCount,
    required this.pendingCount,
    required this.elapsed,
  });

  double get progress => totalCount == 0 ? 0 : successCount / totalCount;
}
```

- [ ] **Step 2: 改造 CrawlService 支持流式进度回调**

为 `smartCrawl` 和 `crawlAuthorVideos` 等方法增加 `onProgress` 回调参数，每完成一条就调用一次。

```dart
Stream<CrawlBatchProgress> crawlStream(
  List<String> urls, {
  String platform = 'douyin',
  bool isAuthor = false,
  List<String> fields = const [],
  int maxConcurrent = 3,
  RetryConfig retryConfig = const RetryConfig(),
}) {
  // 使用 StreamController 创建流式进度
  final controller = StreamController<CrawlBatchProgress>();
  // ... 实现逻辑
  return controller.stream;
}
```

- [ ] **Step 3: 抓取页 UI 改造为实时展示**

将抓取结果区域改为 `ListView.builder`，用 `StreamBuilder` 监听进度流，抓到一条就渲染一条。

每条结果项显示：
- 状态图标（加载中/成功/失败）
- 标题或描述
- 关键字段摘要（如点赞数、评论数）

- [ ] **Step 4: 验证编译通过**

### Task 2.2：抓取预估时间

**Files:**
- Modify: `lib/services/crawl_service.dart`
- Modify: `lib/pages/crawl/crawl_page.dart`

- [ ] **Step 1: 在 CrawlBatchProgress 中增加预估时间**

```dart
Duration get estimatedRemaining {
  if (successCount == 0) return Duration.zero;
  final avgPerItem = elapsed.inMilliseconds / successCount;
  final remainingMs = avgPerItem * pendingCount;
  return Duration(milliseconds: remainingMs.round());
}

String get remainingText {
  if (successCount == 0) return '计算中...';
  final remaining = estimatedRemaining;
  if (remaining.inSeconds < 60) return '约 ${remaining.inSeconds} 秒';
  if (remaining.inMinutes < 60) return '约 ${remaining.inMinutes} 分钟';
  return '约 ${remaining.inHours} 小时 ${remaining.inMinutes % 60} 分';
}
```

- [ ] **Step 2: 在抓取页顶部进度条旁显示预估时间**

在进度条右侧增加"剩余约 X 分钟"文字。

- [ ] **Step 3: 验证编译通过**

### Task 2.3：增量抓取

**Files:**
- Modify: `lib/services/crawl_service.dart`
- Modify: `lib/providers/crawl_history_provider.dart`
- Modify: `lib/pages/crawl/crawl_page.dart`

- [ ] **Step 1: 定义增量抓取策略**

增量抓取基于"上次该作者最新一条内容的时间/ID"来判断：

```dart
/// 增量抓取结果
class IncrementalCrawlResult {
  final int totalNewItems;       // 新增内容数
  final String? lastItemId;      // 最新内容 ID
  final DateTime? lastItemTime;  // 最新内容时间
  final List<Map<String, dynamic>> newItems;
}
```

- [ ] **Step 2: 保存每个作者的上次抓取锚点**

在 `CrawlHistoryProvider` 中增加方法：
- `getLastCrawlAnchor(String platform, String authorId)` → 返回上次最新内容的 ID 和时间
- `saveCrawlAnchor(String platform, String authorId, String lastItemId, DateTime lastItemTime)`

用 Hive 或 SharedPreferences 持久化。

- [ ] **Step 3: 在作者抓取逻辑中增加增量模式**

当检测到该作者之前抓取过时，询问用户是否增量抓取（或设置默认增量）。抓取时遇到已抓取过的内容（通过 ID 匹配）就停止。

- [ ] **Step 4: 抓取页 UI 增加增量抓取选项**

在作者抓取模式下，增加一个"仅抓取新内容"开关，默认开启。

- [ ] **Step 5: 验证编译通过**

### Task 2.4：持久化断点续传

**Files:**
- Create: `lib/models/crawl_checkpoint.dart`
- Modify: `lib/services/crawl_service.dart`
- Modify: `lib/pages/crawl/crawl_page.dart`

- [ ] **Step 1: 定义检查点模型**

```dart
@HiveType(typeId: 5)
class CrawlCheckpoint extends HiveObject {
  @HiveField(0)
  final String id;              // 检查点唯一 ID

  @HiveField(1)
  final String platform;        // 平台

  @HiveField(2)
  final bool isAuthor;          // 作者抓取还是视频抓取

  @HiveField(3)
  final List<String> remainingUrls;  // 剩余未完成的 URL

  @HiveField(4)
  final List<Map<String, dynamic>> completedItems;  // 已完成的数据

  @HiveField(5)
  final List<String> failedUrls;     // 失败的 URL

  @HiveField(6)
  final List<String> selectedFields; // 选中的字段

  @HiveField(7)
  final DateTime createdAt;    // 创建时间

  @HiveField(8)
  final DateTime updatedAt;    // 最后更新时间

  CrawlCheckpoint({
    required this.id,
    required this.platform,
    required this.isAuthor,
    required this.remainingUrls,
    required this.completedItems,
    required this.failedUrls,
    required this.selectedFields,
    required this.createdAt,
    required this.updatedAt,
  });
}
```

- [ ] **Step 2: 注册 Hive Adapter**

在 `main.dart` 中注册 `CrawlCheckpointAdapter`。

- [ ] **Step 3: 抓取过程中定期保存检查点**

每完成 5 条或每 30 秒保存一次检查点到 Hive。

- [ ] **Step 4: 应用启动时检查未完成任务**

进入抓取页时，检查是否有未完成的检查点，弹出"发现未完成的抓取任务，是否继续？"提示。

- [ ] **Step 5: 完成后清理检查点**

抓取全部完成后删除对应的检查点。

- [ ] **Step 6: 验证编译通过**

---

## 阶段三：链接转换增强

### Task 3.1：批量互转（智能判断短/长链）

**Files:**
- Modify: `lib/services/convert_service.dart`
- Modify: `lib/pages/convert/convert_page.dart`

- [ ] **Step 1: 新增智能转换方法**

在 `ConvertService` 中增加 `normalizeToStandard()` 方法：

```dart
/// 智能标准化：自动判断每条链接是短链还是长链，统一输出为标准格式
Future<List<ConvertResultItem>> normalizeToStandard(List<String> urls) async {
  final results = <ConvertResultItem>[];
  for (final url in urls) {
    final cleanUrl = PlatformDetector.normalizeUrl(url);
    if (cleanUrl == null || cleanUrl.isEmpty) {
      results.add(ConvertResultItem(
        originalUrl: url,
        success: false,
        errorMessage: '无效链接',
      ));
      continue;
    }

    final platform = PlatformDetector.detectPlatform(cleanUrl);
    if (platform == VideoPlatform.unknown) {
      results.add(ConvertResultItem(
        originalUrl: url,
        success: false,
        errorMessage: '无法识别平台',
      ));
      continue;
    }

    final isShort = PlatformDetector.isShortLinkForPlatform(cleanUrl, platform);
    if (isShort) {
      // 短链 → 先展开，再标准化
      final result = await toLong(cleanUrl);
      results.add(result.copyWith(originalUrl: url));
    } else {
      // 长链 → 直接标准化
      final result = await toShort(cleanUrl);
      results.add(result.copyWith(originalUrl: url));
    }
  }
  return results;
}
```

- [ ] **Step 2: 在 ConvertResultItem 中增加 copyWith**

```dart
ConvertResultItem copyWith({
  String? originalUrl,
  String? resultUrl,
  String? platform,
  bool? success,
  String? errorMessage,
}) {
  return ConvertResultItem(
    originalUrl: originalUrl ?? this.originalUrl,
    resultUrl: resultUrl ?? this.resultUrl,
    platform: platform ?? this.platform,
    success: success ?? this.success,
    errorMessage: errorMessage ?? this.errorMessage,
  );
}
```

- [ ] **Step 3: 转换页调整**

"标准链接" Tab 下，按钮文字改为"标准化为标准链接"，内部调用 `normalizeToStandard`，自动处理混合输入。

- [ ] **Step 4: 验证编译通过**

### Task 3.2：链接有效性校验

**Files:**
- Modify: `lib/services/convert_service.dart`
- Modify: `lib/pages/convert/convert_page.dart`

- [ ] **Step 1: 增加 HEAD 请求校验方法**

```dart
/// 校验链接是否可访问（HEAD 请求，轻量）
Future<bool> validateLink(String url) async {
  final dio = Dio();
  try {
    final response = await dio.head(
      url,
      options: Options(
        sendTimeout: const Duration(seconds: 5),
        receiveTimeout: const Duration(seconds: 5),
        followRedirects: true,
        maxRedirects: 5,
      ),
    );
    return response.statusCode != null && response.statusCode! < 400;
  } catch (_) {
    return false;
  } finally {
    dio.close();
  }
}
```

- [ ] **Step 2: 转换结果增加有效性标记**

在 `ConvertResultItem` 中增加 `bool? validated` 字段。

- [ ] **Step 3: 转换页增加"校验链接有效性"开关**

默认关闭（因为会增加耗时），用户可手动开启。开启后转换完成后自动校验每条结果。

- [ ] **Step 4: 结果列表显示校验状态**

校验通过显示绿色 ✓，不通过显示红色 ✗，校验中显示灰色 ⏳。

- [ ] **Step 5: 验证编译通过**

---

## 阶段四：历史与收藏

### Task 4.1：历史记录搜索

**Files:**
- Modify: `lib/providers/parse_history_provider.dart`
- Modify: `lib/providers/crawl_history_provider.dart`
- Modify: `lib/providers/convert_history_provider.dart`
- Create: `lib/widgets/search_bar.dart`
- Modify: 各历史页面

- [ ] **Step 1: 为各历史 Provider 增加搜索方法**

```dart
// 解析历史搜索
List<ParseRecord> searchRecords(String keyword, {
  String? platform,
  DateTime? startDate,
  DateTime? endDate,
}) {
  return records.where((r) {
    // 关键词匹配（标题、描述、链接）
    final kw = keyword.toLowerCase();
    bool matchKeyword = keyword.isEmpty ||
        r.title.toLowerCase().contains(kw) ||
        r.desc.toLowerCase().contains(kw) ||
        r.url.toLowerCase().contains(kw);

    // 平台匹配
    bool matchPlatform = platform == null || r.platform == platform;

    // 日期范围匹配
    bool matchDate = true;
    if (startDate != null) {
      matchDate = matchDate && r.createdAt.isAfter(startDate);
    }
    if (endDate != null) {
      matchDate = matchDate && r.createdAt.isBefore(endDate);
    }

    return matchKeyword && matchPlatform && matchDate;
  }).toList();
}
```

三个 Provider 都添加类似方法。

- [ ] **Step 2: 创建通用搜索栏组件**

```dart
class SearchTopBar extends StatelessWidget implements PreferredSizeWidget {
  final TextEditingController controller;
  final String hintText;
  final VoidCallback? onSearch;
  final VoidCallback? onClear;
  final List<Widget> actions; // 筛选按钮等

  const SearchTopBar({
    super.key,
    required this.controller,
    this.hintText = '搜索...',
    this.onSearch,
    this.onClear,
    this.actions = const [],
  });
}
```

带平台筛选下拉和日期筛选。

- [ ] **Step 3: 各历史页面集成搜索**

在 AppBar 中增加搜索图标按钮，点击后展开搜索栏。

- [ ] **Step 4: 验证编译通过**

### Task 4.2：历史记录批量管理

**Files:**
- Modify: 各历史页面
- Modify: 各历史 Provider

- [ ] **Step 1: 增加多选模式**

在各历史页面增加"多选模式"：
- 长按某条记录进入多选模式
- AppBar 变为多选工具栏（选中数量、全选、删除、导出、收藏）
- 底部操作栏：批量删除、批量导出、批量收藏

- [ ] **Step 2: Provider 增加批量操作方法**

```dart
Future<void> batchDelete(List<String> ids);
Future<void> batchToggleFavorite(List<String> ids);
Future<String> batchExport(List<String> ids, ExportFormat format);
```

- [ ] **Step 3: 验证编译通过**

### Task 4.3：收藏夹功能

**Files:**
- Modify: `lib/models/parse_record.dart`（增加 isFavorite 字段）
- Modify: `lib/providers/parse_history_provider.dart`
- Modify: `lib/providers/crawl_history_provider.dart`
- Modify: `lib/pages/home_page.dart`（解析结果增加收藏按钮）
- Create: `lib/pages/favorites_page.dart`

- [ ] **Step 1: 数据模型增加收藏字段**

在 `ParseRecord`、`CrawlRecord`、`ConvertRecord` 中增加 `bool isFavorite` 字段（默认 false）。

- [ ] **Step 2: Provider 增加收藏相关方法**

```dart
void toggleFavorite(String id);
List<ParseRecord> get favoriteRecords;
```

- [ ] **Step 3: 结果卡片增加收藏按钮**

解析结果、抓取结果等卡片右上角增加收藏图标（空心/实心星星）。

- [ ] **Step 4: 收藏夹页面**

新建收藏夹页面，Tab 形式分为：
- 解析收藏
- 抓取收藏
- 转换收藏

支持搜索、批量管理。

- [ ] **Step 5: 验证编译通过**

---

## 阶段五：下载体验升级

### Task 5.1：下载速度与进度显示

**Files:**
- Create: `lib/services/download_service.dart`
- Create: `lib/providers/download_provider.dart`
- Modify: `lib/pages/home_page.dart`

- [ ] **Step 1: 创建下载任务模型**

```dart
enum DownloadStatus { pending, downloading, paused, completed, failed, canceled }

class DownloadTask {
  final String id;
  final String url;
  final String fileName;
  final String savePath;
  final int totalBytes;
  final int receivedBytes;
  final DownloadStatus status;
  final double speed; // bytes per second
  final String? errorMessage;
  final VideoPlatform platform;
  final String videoTitle;

  // 计算属性
  double get progress => totalBytes == 0 ? 0 : receivedBytes / totalBytes;
  String get speedText => _formatSpeed(speed);
  String get remainingText => _estimateRemaining();
}
```

- [ ] **Step 2: 实现下载服务**

用 Dio 的下载功能 + onReceiveProgress 回调实现实时进度和速度计算。

```dart
class DownloadService {
  final Map<String, DownloadTask> _tasks = {};
  final StreamController<DownloadTask> _taskController = StreamController.broadcast();

  Stream<DownloadTask> get taskStream => _taskController.stream;

  Future<void> startDownload(String url, String savePath, {
    required String fileName,
    required String videoTitle,
    required VideoPlatform platform,
  }) async {
    // 实现下载逻辑，定期通过 stream 推送进度
    // 速度计算：记录上次收到的字节数和时间戳，计算差值
  }

  void pauseDownload(String taskId) { ... }
  void resumeDownload(String taskId) { ... }
  void cancelDownload(String taskId) { ... }
}
```

- [ ] **Step 3: 创建 DownloadProvider**

用 Provider 管理下载队列，提供下载中/已完成/失败列表。

- [ ] **Step 4: 下载进度条 UI**

在首页解析结果的下载按钮旁，或者专门的下载页面，显示：
- 进度条（带百分比）
- 下载速度（如 2.5 MB/s）
- 已下载/总大小（如 15.2 MB / 45.8 MB）
- 剩余时间（如 约 12 秒）

- [ ] **Step 5: 验证编译通过**

### Task 5.2：下载通知（后台进度 + 完成通知）

**Files:**
- Modify: `pubspec.yaml`（加 flutter_local_notifications 依赖）
- Modify: `lib/services/download_service.dart`
- Modify: `lib/main.dart`（初始化通知）
- Modify: `android/app/src/main/AndroidManifest.xml`（通知权限）

- [ ] **Step 1: 添加依赖**

在 `pubspec.yaml` 中添加 `flutter_local_notifications: ^17.0.0`。

- [ ] **Step 2: 初始化通知**

在 `main.dart` 中初始化 flutter_local_notifications，创建下载进度通知渠道。

- [ ] **Step 3: 下载进度通知**

下载进行中时，每隔 1-2 秒更新通知栏进度（使用 indeterminate 或 determinate progress）。

- [ ] **Step 4: 下载完成通知**

下载完成后发送通知，点击通知调用 `OpenFile` 或跳转到视频播放器。

- [ ] **Step 5: Android 权限配置**

在 AndroidManifest.xml 中添加通知权限和下载完成通知的 intent 配置。

- [ ] **Step 6: 验证编译通过**

### Task 5.3：批量下载并发控制

**Files:**
- Modify: `lib/providers/download_provider.dart`
- Modify: `lib/providers/settings_provider.dart`
- Modify: `lib/pages/settings/settings_page.dart`

- [ ] **Step 1: 设置中增加并发下载数**

设置项：同时下载数量（1-5），默认 3。

- [ ] **Step 2: DownloadService 实现并发队列**

```dart
class DownloadService {
  int maxConcurrent = 3;
  final Queue<DownloadTask> _pendingQueue = Queue();
  final Map<String, DownloadTask> _activeTasks = {};

  void _tryStartNext() {
    while (_activeTasks.length < maxConcurrent && _pendingQueue.isNotEmpty) {
      final task = _pendingQueue.removeFirst();
      _activeTasks[task.id] = task;
      _executeDownload(task);
    }
  }
}
```

- [ ] **Step 3: 验证编译通过**

---

## 阶段六：UI/UX 全面打磨

### Task 6.1：底部导航过渡动画

**Files:**
- Modify: `lib/main.dart`（主页面框架）

- [ ] **Step 1: 实现带动画的底部导航**

使用 `AnimatedContainer` + `AnimatedSwitcher` 实现：
- 选中图标缩放 + 颜色渐变
- 下方指示器平滑滑动
- 页面切换时使用 `AnimatedSwitcher` + `FadeTransition`

```dart
bottomNavigationBar: Container(
  decoration: BoxDecoration(
    color: Theme.of(context).colorScheme.surface,
    boxShadow: [
      BoxShadow(
        color: Colors.black.withValues(alpha: 0.05),
        blurRadius: 10,
        offset: const Offset(0, -2),
      ),
    ],
  ),
  child: SafeArea(
    child: Padding(
      padding: EdgeInsets.symmetric(horizontal: theme.spacing.sm, vertical: theme.spacing.xs),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: _navItems.asMap().entries.map((entry) {
          final index = entry.key;
          final item = entry.value;
          final isSelected = _currentIndex == index;
          return GestureDetector(
            onTap: () => _onNavTap(index),
            behavior: HitTestBehavior.opaque,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              curve: Curves.easeOutCubic,
              padding: EdgeInsets.symmetric(
                horizontal: theme.spacing.md,
                vertical: theme.spacing.xs,
              ),
              decoration: BoxDecoration(
                color: isSelected
                    ? theme.colorScheme.primaryContainer
                    : Colors.transparent,
                borderRadius: BorderRadius.circular(theme.radius.lg),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 200),
                    transitionBuilder: (child, anim) =>
                        ScaleTransition(scale: anim, child: child),
                    child: Icon(
                      isSelected ? item.activeIcon : item.icon,
                      key: ValueKey(isSelected),
                      color: isSelected
                          ? theme.colorScheme.primary
                          : theme.colorScheme.onSurfaceVariant,
                      size: theme.spacing.iconMd,
                    ),
                  ),
                  SizedBox(height: theme.spacing.xxs / 2),
                  AnimatedDefaultTextStyle(
                    duration: const Duration(milliseconds: 200),
                    style: TextStyle(
                      fontSize: isSelected ? theme.textTheme.labelSmall?.fontSize : theme.textTheme.labelSmall?.fontSize,
                      color: isSelected
                          ? theme.colorScheme.primary
                          : theme.colorScheme.onSurfaceVariant,
                      fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                    ),
                    child: Text(item.label),
                  ),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    ),
  ),
),
```

- [ ] **Step 2: 验证编译通过**

### Task 6.2：页面进入动画

**Files:**
- Modify: 各二级页面跳转处

- [ ] **Step 1: 创建统一的页面路由动画工具**

```dart
class PageRouter {
  /// 从右侧滑入
  static Route<T> slideFromRight<T>(Widget page) {
    return PageRouteBuilder(
      pageBuilder: (context, animation, secondaryAnimation) => page,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        const begin = Offset(1.0, 0.0);
        const end = Offset.zero;
        const curve = Curves.easeOutCubic;
        final tween = Tween(begin: begin, end: end)
            .chain(CurveTween(curve: curve));
        return SlideTransition(
          position: animation.drive(tween),
          child: child,
        );
      },
      transitionDuration: const Duration(milliseconds: 300),
    );
  }

  /// 从底部滑入
  static Route<T> slideFromBottom<T>(Widget page) {
    return PageRouteBuilder(
      pageBuilder: (context, animation, secondaryAnimation) => page,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        const begin = Offset(0.0, 1.0);
        const end = Offset.zero;
        const curve = Curves.easeOutCubic;
        final tween = Tween(begin: begin, end: end)
            .chain(CurveTween(curve: curve));
        return SlideTransition(
          position: animation.drive(tween),
          child: child,
        );
      },
      transitionDuration: const Duration(milliseconds: 350),
    );
  }

  /// 淡入
  static Route<T> fadeIn<T>(Widget page) {
    return PageRouteBuilder(
      pageBuilder: (context, animation, secondaryAnimation) => page,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        return FadeTransition(opacity: animation, child: child);
      },
      transitionDuration: const Duration(milliseconds: 200),
    );
  }
}
```

- [ ] **Step 2: 将所有二级页面跳转改为使用动画路由**

历史记录页、设置页、收藏夹页等二级页面使用 `slideFromRight`。
底部弹窗（字段选择、分享等）使用 `slideFromBottom`。

- [ ] **Step 3: 验证编译通过**

### Task 6.3：智能粘贴识别

**Files:**
- Modify: `lib/widgets/link_input_card.dart`

- [ ] **Step 1: 增加识别标签展示**

在输入框上方增加一行小标签，显示识别结果：
- 平台标签（带 emoji + 平台名，品牌色背景）
- 类型标签（视频/作者/短链，灰色背景）
- 链接数量标签（如 "检测到 3 条链接"）

标签动画：淡入 + 轻微上移。

- [ ] **Step 2: 实时识别**

输入内容变化时，自动识别并更新标签。使用 `debounce` 避免频繁计算。

- [ ] **Step 3: 验证编译通过**

### Task 6.4：输入框长按菜单

**Files:**
- Modify: `lib/widgets/link_input_card.dart`

- [ ] **Step 1: 增加长按手势**

在输入框区域包裹 `GestureDetector`，监听 `onLongPress`。

- [ ] **Step 2: 弹出操作菜单**

长按后弹出 `showModalBottomSheet` 或 `PopupMenuButton`，包含：
- 粘贴
- 清空
- 全选
- 复制

使用 `showModalBottomSheet` + `ListTile` 列表，风格统一。

- [ ] **Step 3: 验证编译通过**

### Task 6.5：全面屏适配

**Files:**
- Modify: `lib/main.dart`
- Modify: 各主要页面

- [ ] **Step 1: SystemChrome 设置**

在 `main.dart` 中设置：

```dart
SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
  statusBarColor: Colors.transparent,
  statusBarIconBrightness: Brightness.dark,
  systemNavigationBarColor: Colors.transparent,
  systemNavigationBarIconBrightness: Brightness.dark,
));
```

- [ ] **Step 2: 确保 Scaffold 使用正确的 SafeArea**

检查所有页面，确保内容不被状态栏和导航栏遮挡。特别是：
- 列表页底部留出导航栏高度
- 输入框弹出键盘时正确避让

- [ ] **Step 3: 验证编译通过**

### Task 6.6：结果卡片长按菜单 + 双击收藏

**Files:**
- Modify: 各结果卡片组件（解析结果、抓取结果、转换结果）

- [ ] **Step 1: 封装通用结果卡片**

创建 `ResultCard` 组件，内置：
- 长按弹出上下文菜单（复制链接、分享、收藏、下载/打开）
- 双击收藏（带心形缩放动画）
- 点击查看详情

```dart
class ResultCard extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final VoidCallback? onDoubleTapFavorite;
  final List<PopupMenuItem> Function(BuildContext)? menuItems;
  final bool isFavorite;

  const ResultCard({
    super.key,
    required this.child,
    this.onTap,
    this.onDoubleTapFavorite,
    this.menuItems,
    this.isFavorite = false,
  });
}
```

双击动画：心形图标从中心放大 + 淡出（参考抖音双击点赞效果）。

- [ ] **Step 2: 各页面替换为通用卡片**

- [ ] **Step 3: 验证编译通过**

### Task 6.7：历史记录下拉刷新 + 分页加载

**Files:**
- Modify: 各历史页面
- Modify: 各历史 Provider

- [ ] **Step 1: Provider 增加分页支持**

```dart
List<ParseRecord> getPagedRecords(int page, int pageSize, {String? search});
bool get hasMore;
Future<void> loadMore();
Future<void> refresh();
```

- [ ] **Step 2: 历史页增加下拉刷新**

用 `RefreshIndicator` 包裹列表，下拉刷新。

- [ ] **Step 3: 上拉加载更多**

监听列表滚动，接近底部时自动加载下一页。底部显示加载更多指示器。

- [ ] **Step 4: 验证编译通过**

### Task 6.8：键盘适配

**Files:**
- Modify: 各含输入框的页面（首页、抓取页、转换页）

- [ ] **Step 1: 使用 resizeToAvoidBottomInset**

确保 Scaffold 的 `resizeToAvoidBottomInset: true`（默认就是 true）。

- [ ] **Step 2: 输入框自动滚动到可见区域**

当输入框获取焦点时，使用 `Scrollable.ensureVisible()` 确保输入框在可视区域内。

- [ ] **Step 3: 验证编译通过**

### Task 6.9：空状态插画 + 骨架屏 + 错误状态

**Files:**
- Create: `lib/widgets/empty_state.dart`
- Create: `lib/widgets/skeleton_loading.dart`
- Create: `lib/widgets/error_state.dart`

- [ ] **Step 1: 空状态组件**

各页面空状态使用 SVG 插画 + 引导文字 + 操作按钮。

```dart
class EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? subtitle;
  final Widget? action;

  const EmptyState({
    super.key,
    required this.icon,
    required this.title,
    this.subtitle,
    this.action,
  });
}
```

- [ ] **Step 2: 骨架屏组件**

通用骨架屏加载器，支持列表、卡片等不同形态。

```dart
class Skeleton extends StatelessWidget {
  final double width;
  final double height;
  final double borderRadius;

  const Skeleton({
    super.key,
    required this.width,
    required this.height,
    this.borderRadius = 8,
  });
}

// 列表骨架
class ListSkeleton extends StatelessWidget {
  final int itemCount;
  const ListSkeleton({super.key, this.itemCount = 5});
}
```

- [ ] **Step 3: 错误状态组件**

```dart
class ErrorState extends StatelessWidget {
  final String message;
  final VoidCallback? onRetry;
  final IconData icon;

  const ErrorState({
    super.key,
    required this.message,
    this.onRetry,
    this.icon = Icons.error_outline,
  });
}
```

- [ ] **Step 4: 各页面集成**

首页解析中显示骨架屏，解析失败显示错误状态，无数据显示空状态。

- [ ] **Step 5: 验证编译通过**

---

## 最终验证

- [ ] **Task Final: 完整编译 + APK 打包**
  - 运行 `flutter analyze`，确保零 error、零 warning
  - 运行 `flutter build apk --release`，构建成功
  - 检查 APK 大小，确认无测试数据打包

---

## 风险与注意事项

1. **Hive 数据迁移**：新增字段时需要处理旧数据的兼容（默认值）
2. **通知权限**：Android 13+ 需要 POST_NOTIFICATIONS 运行时权限
3. **性能**：实时预览大量数据时注意 setState 频率，使用 `ValueNotifier` 或 `Provider` 局部刷新
4. **内存**：断点续传持久化时注意数据量，大任务可能需要分批存储
5. **兼容性**：新功能在旧版 Android 上的表现（如通知样式）
