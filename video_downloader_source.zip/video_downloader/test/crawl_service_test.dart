import 'package:flutter_test/flutter_test.dart';
import 'package:video_downloader/services/crawl_service.dart';

void main() {
  group('CrawlService.extractSecUid', () {
    test('iesdouyin share/user 路径', () {
      expect(
        CrawlService.extractSecUid(
            'https://www.iesdouyin.com/share/user/MS4wLjABAAAAWxLpO0Q437qGFpnEKBIIaU5-xOj2yAhH3MNJi-AUY04'),
        'MS4wLjABAAAAWxLpO0Q437qGFpnEKBIIaU5-xOj2yAhH3MNJi-AUY04',
      );
    });

    test('douyin.com/user 路径', () {
      expect(
        CrawlService.extractSecUid(
            'https://www.douyin.com/user/MS4wLjABAAAAtest1234567890'),
        'MS4wLjABAAAAtest1234567890',
      );
    });

    test('sec_uid 查询参数', () {
      expect(
        CrawlService.extractSecUid(
            'https://www.iesdouyin.com/share/user/88445518961?sec_uid=MS4wLjABAAAAquery123&timestamp=1'),
        'MS4wLjABAAAAquery123',
      );
    });

    test('视频链接返回 null', () {
      expect(
        CrawlService.extractSecUid(
            'https://www.douyin.com/video/7624728488368732900'),
        isNull,
      );
    });
  });

  group('CrawlService.applyFieldSelection', () {
    test('selected 为 null 时原样返回', () {
      final data = {'title': 'x', 'diggCount': 1};
      expect(CrawlService.applyFieldSelection(data, null), data);
    });

    test('正常过滤选中的字段', () {
      final data = {'title': 'x', 'diggCount': 1, 'cover': 'http://c'};
      final result = CrawlService.applyFieldSelection(data, ['title', 'cover']);
      expect(result.keys.toSet(), {'title', 'cover'});
    });

    test('数据非空但选中字段均未抓取到时抛出可读异常', () {
      final data = {'title': 'x'};
      expect(
        () => CrawlService.applyFieldSelection(data, ['diggCount']),
        throwsA(
          isA<CrawlException>().having(
            (e) => e.message,
            'message',
            allOf(contains('所选字段'), contains('title')),
          ),
        ),
      );
    });

    test('数据为空时不抛字段选择异常（由上层抛抓取失败）', () {
      expect(CrawlService.applyFieldSelection({}, ['diggCount']), isEmpty);
    });
  });

  group('CrawlService.detectCrawlType', () {
    test('抖音用户主页识别为 author', () {
      expect(
        CrawlService.detectCrawlType(
            'https://www.douyin.com/user/MS4wLjABAAAAtest'),
        'author',
      );
      expect(
        CrawlService.detectCrawlType(
            'https://www.iesdouyin.com/share/user/MS4wLjABAAAAtest'),
        'author',
      );
    });

    test('带 sec_uid 参数的链接识别为 author', () {
      expect(
        CrawlService.detectCrawlType(
            'https://www.iesdouyin.com/share/user/123?sec_uid=MS4wLjABAAAAtest'),
        'author',
      );
    });

    test('视频链接识别为 video', () {
      expect(
        CrawlService.detectCrawlType(
            'https://www.douyin.com/video/7624728488368732900'),
        'video',
      );
      expect(
        CrawlService.detectCrawlType(
            'https://v.douyin.com/J4IQiholWbo/'),
        'video',
      );
    });

    test('快手主页识别为 author', () {
      expect(
        CrawlService.detectCrawlType('https://www.kuaishou.com/profile/3xabc'),
        'author',
      );
    });
  });

  group('CrawlService.extractKuaishouUserId', () {
    test('profile 路径', () {
      expect(
        CrawlService.extractKuaishouUserId(
            'https://www.kuaishou.com/profile/3xabc123def'),
        '3xabc123def',
      );
    });

    test('chenzhongtech profile 路径', () {
      expect(
        CrawlService.extractKuaishouUserId(
            'https://m.chenzhongtech.com/profile/3xuser99'),
        '3xuser99',
      );
    });

    test('带查询参数', () {
      expect(
        CrawlService.extractKuaishouUserId(
            'https://www.kuaishou.com/profile/3xuser99?fid=1&cc=share'),
        '3xuser99',
      );
    });

    test('fw/user 移动端分享路径（2026-08 短链展开目标）', () {
      expect(
        CrawlService.extractKuaishouUserId(
            'https://kphk9mez.m.chenzhongtech.com/fw/user/3xgrgprm4kru284?cc=share_copylink&userId=3xgrgprm4kru284'),
        '3xgrgprm4kru284',
      );
    });

    test('principalId 查询参数', () {
      expect(
        CrawlService.extractKuaishouUserId(
            'https://live.kuaishou.com/live_api/user?principalId=3xyxvv7zkahjzmg'),
        '3xyxvv7zkahjzmg',
      );
    });

    test('抖音链接返回 null', () {
      expect(
        CrawlService.extractKuaishouUserId(
            'https://www.douyin.com/user/MS4wLjABAAAAtest'),
        isNull,
      );
    });

    test('视频链接返回 null', () {
      expect(
        CrawlService.extractKuaishouUserId(
            'https://www.kuaishou.com/short-video/3xvideo01'),
        isNull,
      );
    });
  });

  group('CrawlService.extractDouyinAwemeId', () {
    test('video 路径', () {
      expect(
        CrawlService.extractDouyinAwemeId(
            'https://www.douyin.com/video/7624728488368732900'),
        '7624728488368732900',
      );
    });

    test('share/video 路径', () {
      expect(
        CrawlService.extractDouyinAwemeId(
            'https://www.iesdouyin.com/share/video/7624728488368732900/?mid=0'),
        '7624728488368732900',
      );
    });

    test('modal_id 参数', () {
      expect(
        CrawlService.extractDouyinAwemeId(
            'https://www.douyin.com/discover?modal_id=7624728488368732900'),
        '7624728488368732900',
      );
    });

    test('note 路径', () {
      expect(
        CrawlService.extractDouyinAwemeId(
            'https://www.iesdouyin.com/share/note/7123456789012345678'),
        '7123456789012345678',
      );
    });

    test('用户链接返回 null', () {
      expect(
        CrawlService.extractDouyinAwemeId(
            'https://www.douyin.com/user/MS4wLjABAAAAtest'),
        isNull,
      );
    });
  });
}
