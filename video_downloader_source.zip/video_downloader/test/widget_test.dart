import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

/// 冒烟测试：验证基础组件可正常构建（App 启动依赖 Hive/插件初始化，
/// 不在单测中拉起完整 App）
void main() {
  testWidgets('MaterialApp 冒烟测试', (WidgetTester tester) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: Scaffold(body: Center(child: Text('smoke'))),
      ),
    );
    expect(find.text('smoke'), findsOneWidget);
  });
}
