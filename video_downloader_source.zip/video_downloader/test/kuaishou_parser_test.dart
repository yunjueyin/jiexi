import 'dart:convert';
import 'dart:typed_data';

import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:video_downloader/services/parser/kuaishou_parser.dart';

typedef ResponseHandler = ResponseBody Function(RequestOptions options);

/// 拦截请求并返回预设响应的 Mock 适配器
class MockAdapter implements HttpClientAdapter {
  final ResponseHandler handler;
  MockAdapter(this.handler);

  @override
  void close({bool force = false}) {}

  @override
  Future<ResponseBody> fetch(
    RequestOptions options,
    Stream<Uint8List>? requestStream,
    Future<void>? cancelFuture,
  ) async {
    return handler(options);
  }
}

ResponseBody jsonResponse(
  Map<String, dynamic> body, {
  Map<String, List<String>> headers = const {},
}) {
  final bytes = Uint8List.fromList(utf8.encode(jsonEncode(body)));
  return ResponseBody(
    Stream.fromIterable([bytes]),
    200,
    headers: {
      ...headers,
      'content-type': ['application/json'],
    },
  );
}

ResponseBody htmlResponse(String html, {List<String>? setCookie}) {
  final bytes = Uint8List.fromList(utf8.encode(html));
  return ResponseBody(
    Stream.fromIterable([bytes]),
    200,
    headers: {
      'content-type': ['text/html'],
      if (setCookie != null) 'set-cookie': setCookie,
    },
  );
}

void main() {
  group('KuaishouParser.fetchPhotoRaw', () {
    test('GraphQL 主路径返回原始 photo 对象', () async {
      final dio = Dio();
      dio.httpClientAdapter = MockAdapter((options) {
        if (options.uri.host == 'www.kuaishou.com' && options.method == 'GET') {
          // 首页请求：返回 Cookie
          return htmlResponse('<html></html>',
              setCookie: ['did=web_test_did; Path=/; Max-Age=2592000']);
        }
        if (options.uri.path == '/graphql') {
          return jsonResponse({
            'data': {
              'visionVideoDetail': {
                'status': '1',
                'photo': {
                  'id': '3xtestphoto01',
                  'caption': '快手测试',
                  'likeCount': 100,
                  'viewCount': 2000,
                },
              },
            },
          });
        }
        return jsonResponse({'error': 'unexpected ${options.uri}'});
      });

      final parser = KuaishouParser(dio: dio);
      final photo =
          await parser.fetchPhotoRaw('https://www.kuaishou.com/short-video/3xtestphoto01');

      expect(photo, isNotNull);
      expect(photo!['id'], '3xtestphoto01');
      expect(photo['caption'], '快手测试');
      expect(photo['likeCount'], 100);
    });

    test('GraphQL 失败时降级到移动端页面提取', () async {
      final mobileHtml = '<html><body><script>'
          'window.__INITIAL_STATE__ = {"pageData":{"photo":{"photoId":"3xmobile01","photoUrl":"https://v.kuaishou.com/m.mp4","caption":"移动端"}}};'
          '</script></body></html>';

      final dio = Dio();
      dio.httpClientAdapter = MockAdapter((options) {
        if (options.uri.host == 'www.kuaishou.com' && options.method == 'GET') {
          return htmlResponse('<html></html>',
              setCookie: ['did=web_test_did; Path=/']);
        }
        if (options.uri.path == '/graphql') {
          // 返回校验错误，触发降级
          return jsonResponse({
            'errors': [
              {'message': 'Cannot query field "images"'}
            ]
          });
        }
        if (options.uri.host == 'm.chenzhongtech.com') {
          return htmlResponse(mobileHtml);
        }
        return jsonResponse({'error': 'unexpected ${options.uri}'});
      });

      final parser = KuaishouParser(dio: dio);
      final photo =
          await parser.fetchPhotoRaw('https://www.kuaishou.com/short-video/3xmobile01');

      expect(photo, isNotNull);
      expect(photo!['photoId'], '3xmobile01');
      expect(photo['photoUrl'], 'https://v.kuaishou.com/m.mp4');
    });

    test('无法提取作品ID时返回 null', () async {
      final parser = KuaishouParser(dio: Dio());
      expect(
        await parser.fetchPhotoRaw('https://www.kuaishou.com/'),
        isNull,
      );
    });
  });
}
