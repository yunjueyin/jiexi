import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:video_downloader/services/crawl/share_page_extractor.dart';

/// 构造抖音视频分享页 HTML（window._ROUTER_DATA，含嵌套 JSON 与
/// 字符串内部的 "};"，用于验证括号配对提取不会被截断）
String buildDouyinVideoHtml() {
  final routerData = {
    'loaderData': {
      'video_(id)/page': {
        'videoInfoRes': {
          'status_code': 0,
          'item_list': [
            {
              'aweme_id': '7624728488368732900',
              'desc': '爱情公寓};第三季｜第257集', // 字符串内含 };
              'create_time': 1712345678,
              'video': {
                'duration': 150000, // 毫秒
                'cover': {
                  'url_list': ['https://p3.douyinpic.com/cover.jpg'],
                },
                'play_addr': {
                  'uri': 'v0d00fg10000',
                  'url_list': [
                    'https://www.douyin.com/aweme/v1/playwm/?video_id=v0d00fg10000',
                  ],
                },
              },
              'statistics': {
                'digg_count': 123456,
                'comment_count': 789,
                'share_count': 1011,
                'collect_count': 1213,
                'play_count': 9876543,
              },
              'author': {
                'uid': '1234567890',
                'sec_uid': 'MS4wLjABAAAAtest',
                'nickname': '测试作者',
                'signature': '个人签名',
                'avatar_thumb': {
                  'url_list': ['https://p3.douyinpic.com/avatar.jpg'],
                },
              },
            },
          ],
        },
      },
    },
  };
  return '<html><head><title>t</title></head><body>'
      '<script>window._ROUTER_DATA = ${jsonEncode(routerData)}</script>'
      '</body></html>';
}

/// 构造抖音用户分享页 HTML（loaderData['user_(id)/page'].userInfo，snake_case）
String buildDouyinUserHtmlSnake() {
  final routerData = {
    'loaderData': {
      'user_(id)/page': {
        'userInfo': {
          'uid': '88445518961',
          'sec_uid': 'MS4wLjABAAAAWxLpO0Q437qGFpnEKBIIaU5',
          'nickname': '用户甲',
          'signature': '你好};世界',
          'avatar_larger': {
            'url_list': ['https://p3.douyinpic.com/large.jpg'],
          },
          'follower_count': '10000', // 字符串数字
          'following_count': '100',
          'total_favorited': '99999',
          'aweme_count': '88',
          'favorite_count': '12',
        },
      },
    },
  };
  return '<html><body>'
      '<script>window._ROUTER_DATA=${jsonEncode(routerData)};</script>'
      '</body></html>';
}

/// 构造新版 camelCase 用户结构
String buildDouyinUserHtmlCamel() {
  final routerData = {
    'loaderData': {
      'user_(id)/page': {
        'user': {
          'userInfos': {
            'uid': '10001',
            'secUid': 'MS4wLjABAAAAcamel',
            'nickname': '用户乙',
            'signature': 'sig',
            'avatarLarger': 'https://p3.douyinpic.com/b.jpg',
            'followerCount': 20000,
            'followingCount': 30,
            'totalFavorited': 500000,
            'awemeCount': 7,
          },
        },
      },
    },
  };
  return '<html><body>'
      '<script>window._ROUTER_DATA = ${jsonEncode(routerData)}</script>'
      '</body></html>';
}

/// RENDER_DATA（URL 编码 JSON）
String buildRenderDataHtml() {
  final data = {
    'app': {'state': {'user': {'nickname': '渲染数据用户'}}},
  };
  final encoded = Uri.encodeComponent(jsonEncode(data));
  return '<html><body><script id="RENDER_DATA" type="application/json">'
      '$encoded</script></body></html>';
}

/// __INITIAL_STATE__（嵌套 + 字符串含 };）
String buildInitialStateHtml() {
  final data = {
    'user': {
      'name': '初始};状态',
      'follower_count': 300,
      'videos': [
        {'aweme_id': '111', 'digg_count': 5},
      ],
    },
  };
  return '<html><body><script>window.__INITIAL_STATE__ = ${jsonEncode(data)};'
      '</script></body></html>';
}

void main() {
  group('extractRouterData', () {
    test('解析 window._ROUTER_DATA = {...}（带空格）', () {
      final result = SharePageExtractor.extractRouterData(buildDouyinVideoHtml());
      expect(result, isNotNull);
      final loader = result!['loaderData'] as Map;
      expect(loader.containsKey('video_(id)/page'), isTrue);
    });

    test('解析 window._ROUTER_DATA={...};（无空格，字符串内含 }; 不截断）', () {
      final result =
          SharePageExtractor.extractRouterData(buildDouyinUserHtmlSnake());
      expect(result, isNotNull);
      final loader = result!['loaderData'] as Map;
      final page = loader['user_(id)/page'] as Map;
      final userInfo = page['userInfo'] as Map;
      expect(userInfo['nickname'], '用户甲');
      expect(userInfo['signature'], '你好};世界');
    });

    test('无标记时返回 null', () {
      expect(SharePageExtractor.extractRouterData('<html></html>'), isNull);
    });
  });

  group('extractRenderData', () {
    test('解析 URL 编码的 RENDER_DATA', () {
      final result = SharePageExtractor.extractRenderData(buildRenderDataHtml());
      expect(result, isNotNull);
      final app = result!['app'] as Map;
      final state = app['state'] as Map;
      final user = state['user'] as Map;
      expect(user['nickname'], '渲染数据用户');
    });
  });

  group('extractInitialState', () {
    test('解析 window.__INITIAL_STATE__（嵌套不截断）', () {
      final result =
          SharePageExtractor.extractInitialState(buildInitialStateHtml());
      expect(result, isNotNull);
      final user = result!['user'] as Map;
      expect(user['name'], '初始};状态');
      expect(user['follower_count'], 300);
    });
  });

  group('extractAnyJson', () {
    test('按顺序提取第一个可用 JSON', () {
      final html =
          '<html>${buildInitialStateHtml()}${buildRenderDataHtml()}</html>';
      final result = SharePageExtractor.extractAnyJson(html);
      expect(result, isNotNull);
      expect(result!.containsKey('user'), isTrue);
    });
  });

  group('douyinVideoFromItem', () {
    test('完整映射视频字段（统计/作者/时间/时长）', () {
      final router =
          SharePageExtractor.extractRouterData(buildDouyinVideoHtml())!;
      final loader = router['loaderData'] as Map;
      final page = loader['video_(id)/page'] as Map;
      final videoInfoRes = page['videoInfoRes'] as Map;
      final item = (videoInfoRes['item_list'] as List).first;

      final fields = SharePageExtractor.douyinVideoFromItem(item);

      expect(fields['videoId'], '7624728488368732900');
      expect(fields['title'], '爱情公寓};第三季｜第257集');
      expect(fields['cover'], 'https://p3.douyinpic.com/cover.jpg');
      expect(fields['diggCount'], 123456);
      expect(fields['commentCount'], 789);
      expect(fields['shareCount'], 1011);
      expect(fields['collectCount'], 1213);
      expect(fields['playCount'], 9876543);
      expect(fields['duration'], 150); // 毫秒转秒
      expect(fields['createTime'], contains('2024')); // 格式化时间
      expect(fields['authorUid'], '1234567890');
      expect(fields['authorNickname'], '测试作者');
      expect(fields['authorAvatar'], 'https://p3.douyinpic.com/avatar.jpg');
      // playwm → play 无水印
      expect(
        fields['videoUrl'],
        'https://www.douyin.com/aweme/v1/play/?video_id=v0d00fg10000',
      );
    });

    test('空对象返回空 Map 而不抛异常', () {
      expect(SharePageExtractor.douyinVideoFromItem({}), isEmpty);
    });
  });

  group('douyinAuthorFromJson', () {
    test('snake_case userInfo 结构', () {
      final router =
          SharePageExtractor.extractRouterData(buildDouyinUserHtmlSnake())!;
      final fields = SharePageExtractor.douyinAuthorFromJson(router);

      expect(fields['uid'], '88445518961');
      expect(fields['secUid'], 'MS4wLjABAAAAWxLpO0Q437qGFpnEKBIIaU5');
      expect(fields['nickname'], '用户甲');
      expect(fields['signature'], '你好};世界');
      expect(fields['avatar'], 'https://p3.douyinpic.com/large.jpg');
      expect(fields['followerCount'], 10000); // 字符串数字转 int
      expect(fields['followingCount'], 100);
      expect(fields['totalFavorited'], 99999);
      expect(fields['awemeCount'], 88);
      expect(fields['favoriteCount'], 12);
    });

    test('camelCase userInfos 结构', () {
      final router =
          SharePageExtractor.extractRouterData(buildDouyinUserHtmlCamel())!;
      final fields = SharePageExtractor.douyinAuthorFromJson(router);

      expect(fields['nickname'], '用户乙');
      expect(fields['uid'], '10001');
      expect(fields['secUid'], 'MS4wLjABAAAAcamel');
      expect(fields['avatar'], 'https://p3.douyinpic.com/b.jpg');
      expect(fields['followerCount'], 20000);
      expect(fields['awemeCount'], 7);
    });

    test('无关 JSON 返回空 Map', () {
      expect(SharePageExtractor.douyinAuthorFromJson({'foo': 'bar'}), isEmpty);
    });
  });

  group('douyinVideoFromHtml', () {
    test('完整提取（统计/作者/时长/时间/无水印地址）', () {
      final fields =
          SharePageExtractor.douyinVideoFromHtml(buildDouyinVideoHtml());
      expect(fields['videoId'], '7624728488368732900');
      expect(fields['diggCount'], 123456);
      expect(fields['commentCount'], 789);
      expect(fields['shareCount'], 1011);
      expect(fields['collectCount'], 1213);
      expect(fields['duration'], 150);
      expect(fields['createTime'], contains('2024'));
      expect(fields['authorNickname'], '测试作者');
    });

    test('无数据页面返回空 Map', () {
      expect(
        SharePageExtractor.douyinVideoFromHtml('<html>空页面</html>'),
        isEmpty,
      );
    });
  });

  group('douyinAuthorFromHtml', () {
    test('snake_case 结构', () {
      final fields =
          SharePageExtractor.douyinAuthorFromHtml(buildDouyinUserHtmlSnake());
      expect(fields['nickname'], '用户甲');
      expect(fields['followerCount'], 10000);
      expect(fields['secUid'], contains('MS4w'));
    });

    test('camelCase 结构', () {
      final fields =
          SharePageExtractor.douyinAuthorFromHtml(buildDouyinUserHtmlCamel());
      expect(fields['nickname'], '用户乙');
      expect(fields['followerCount'], 20000);
    });

    test('RENDER_DATA 结构（URL 编码）', () {
      final html = '<html><body><script id="RENDER_DATA">'
          '${Uri.encodeComponent(jsonEncode({
            'loaderData': {
              'user_(id)/page': {
                'userInfo': {
                  'sec_uid': 'MS4wLjABAAAArender',
                  'nickname': '渲染用户',
                  'follower_count': 500,
                },
              },
            },
          }))}</script></body></html>';
      final fields = SharePageExtractor.douyinAuthorFromHtml(html);
      expect(fields['nickname'], '渲染用户');
      expect(fields['followerCount'], 500);
    });
  });

  group('kuaishouVideoFromPhoto', () {
    test('GraphQL photo 对象映射', () {
      final photo = {
        'id': '3xabc123',
        'duration': 90000, // 毫秒
        'timestamp': 1712345678,
        'caption': '快手测试视频',
        'originCaption': '原始文案',
        'likeCount': 8888,
        'viewCount': 66666,
        'commentCount': 77,
        'coverUrl': 'https://p.kuaishou.com/cover.jpg',
        'photoUrl': 'https://v.kuaishou.com/play.mp4',
      };
      final fields = SharePageExtractor.kuaishouVideoFromPhoto(photo);

      expect(fields['videoId'], '3xabc123');
      expect(fields['title'], '快手测试视频');
      expect(fields['cover'], 'https://p.kuaishou.com/cover.jpg');
      expect(fields['diggCount'], 8888);
      expect(fields['playCount'], 66666);
      expect(fields['commentCount'], 77);
      expect(fields['duration'], 90);
      expect(fields['createTime'], contains('2024'));
      expect(fields['videoUrl'], 'https://v.kuaishou.com/play.mp4');
    });

    test('空对象返回空 Map', () {
      expect(SharePageExtractor.kuaishouVideoFromPhoto({}), isEmpty);
    });

    test('移动端页面 photo 结构（2026-08 实测字段平铺，毫秒时间戳）', () {
      // m.chenzhongtech.com/fw/photo/{id} 页面 INIT_STATE 内嵌结构：
      // 作者字段平铺在 photo 上（userName/userId/headUrl），
      // 封面为 coverUrls 列表，timestamp 为毫秒
      final photo = {
        'photoId': '5189272783933155001',
        'caption': '#快影最强投稿王 艺术体操',
        'likeCount': 1455,
        'viewCount': 21800,
        'commentCount': 1185,
        'shareCount': 3325,
        'timestamp': 1695822858840, // 毫秒
        'duration': 39066, // 毫秒
        'userName': '艺术体操',
        'userId': '2425482710',
        'headUrl': 'https://p2-pro.a.yximgs.com/uhead/xx.jpg',
        'coverUrls': [
          {'url': 'https://p.kuaishou.com/cover1.jpg'},
        ],
        'mainMvUrls': [
          {'url': 'https://v.kuaishou.com/hd.mp4'},
        ],
      };
      final fields = SharePageExtractor.kuaishouVideoFromPhoto(photo);

      expect(fields['videoId'], '5189272783933155001');
      expect(fields['title'], contains('快影最强投稿王'));
      expect(fields['cover'], 'https://p.kuaishou.com/cover1.jpg');
      expect(fields['diggCount'], 1455);
      expect(fields['playCount'], 21800);
      expect(fields['commentCount'], 1185);
      expect(fields['shareCount'], 3325);
      expect(fields['duration'], 39);
      // 毫秒时间戳应正确换算为 2023-09-27（UTC+8）
      expect(fields['createTime'], startsWith('2023-09-2'));
      expect(fields['authorNickname'], '艺术体操');
      expect(fields['authorUid'], '2425482710');
      expect(fields['authorAvatar'], 'https://p2-pro.a.yximgs.com/uhead/xx.jpg');
      expect(fields['videoUrl'], 'https://v.kuaishou.com/hd.mp4');
    });
  });

  group('kuaishouAuthorFromLiveApi（live_api userinfo/byid 结构）', () {
    test('result=1 映射基础字段', () {
      // 2026-08 实测 live.kuaishou.com/live_api/baseuser/userinfo/byid 响应：
      // data.userInfo 含 name/avatar/id；counts 匿名多为空
      final payload = {
        'result': 1,
        'userInfo': {
          'id': '2425482710',
          'name': '美式双份奶',
          'avatar': 'https://p2.a.yximgs.com/uhead/a.jpg',
          'cityName': '北京',
          'counts': {},
        },
      };
      final fields = SharePageExtractor.kuaishouAuthorFromLiveApi(payload);

      expect(fields['uid'], '2425482710');
      expect(fields['nickname'], '美式双份奶');
      expect(fields['avatar'], 'https://p2.a.yximgs.com/uhead/a.jpg');
      expect(fields.containsKey('followerCount'), isFalse);
    });

    test('counts 有值时映射统计字段', () {
      final payload = {
        'result': 1,
        'userInfo': {
          'id': '3xabc',
          'name': '计数用户',
          'counts': {'fan': 12000, 'follow': 100, 'photo': 66},
        },
      };
      final fields = SharePageExtractor.kuaishouAuthorFromLiveApi(payload);

      expect(fields['followerCount'], 12000);
      expect(fields['followingCount'], 100);
      expect(fields['awemeCount'], 66);
    });

    test('无 userInfo 返回空 Map', () {
      expect(SharePageExtractor.kuaishouAuthorFromLiveApi({'result': 1}),
          isEmpty);
      expect(
        SharePageExtractor.kuaishouAuthorFromLiveApi(
            {'result': 400002, 'jsSdkUrl': '//x.js'}),
        isEmpty,
      );
    });
  });

  group('kuaishouVideoFromHtml', () {
    test('从 __INITIAL_STATE__ 提取 photo 数据', () {
      final html = '<html><body><script>'
          'window.__INITIAL_STATE__ = {"pageData":{"photo":{"photoId":"3xhtml01","photoUrl":"https://v.kuaishou.com/h.mp4","caption":"页面提取","likeCount":"42","timestamp":1712345678}}};'
          '</script></body></html>';
      final fields = SharePageExtractor.kuaishouVideoFromHtml(html);

      expect(fields['videoId'], '3xhtml01');
      expect(fields['title'], '页面提取');
      expect(fields['diggCount'], 42);
      expect(fields['videoUrl'], 'https://v.kuaishou.com/h.mp4');
    });

    test('从 window.pageData 提取（快手移动端格式）', () {
      final html = '<html><body><script>'
          'window.pageData = {"photo":{"photoId":"3xpage02","photoUrl":"https://v.kuaishou.com/p.mp4","caption":"pageData格式"}};'
          '</script></body></html>';
      final fields = SharePageExtractor.kuaishouVideoFromHtml(html);

      expect(fields['videoId'], '3xpage02');
      expect(fields['title'], 'pageData格式');
    });

    test('无数据页面返回空 Map', () {
      expect(
        SharePageExtractor.kuaishouVideoFromHtml('<html>空</html>'),
        isEmpty,
      );
    });
  });

  group('authorFromJson（快手/通用结构）', () {
    test('快手 INIT_STATE profile 结构（user_name/fans）', () {
      final data = {
        'user': {
          'profile': {
            'user_id': '3xabc',
            'user_name': '快手用户',
            'fans': '12345',
            'follows': '100',
            'photos': '88',
            'headUrl': 'https://p.kuaishou.com/head.jpg',
          },
        },
      };
      final fields = SharePageExtractor.authorFromJson(data);
      expect(fields['nickname'], '快手用户');
      expect(fields['uid'], '3xabc');
      expect(fields['followerCount'], 12345);
      expect(fields['followingCount'], 100);
      expect(fields['awemeCount'], 88);
      expect(fields['avatar'], 'https://p.kuaishou.com/head.jpg');
    });

    test('无关节点返回空 Map', () {
      expect(SharePageExtractor.authorFromJson({'video': {'name': 'x'}}),
          isEmpty);
    });
  });

  group('douyinAuthorFromUserInfoApi（真实 API 结构）', () {
    // 2026-08 实测 https://www.iesdouyin.com/web/api/v2/user/info/?sec_uid= 响应：
    // 粉丝数字段为 mplatform_followers_count（非 follower_count）
    Map<String, dynamic> buildApiFixture() => {
          'status_code': 0,
          'user_info': {
            'sec_uid': 'MS4wLjABAAAAWxLpO0Q437qGFpnEKBIIaU5',
            'short_id': '0',
            'nickname': 'DOU+小助手',
            'signature': '关注我，带你了解流量',
            'avatar_medium': {
              'url_list': ['https://p3.douyinpic.com/medium.jpg'],
            },
            'aweme_count': 2012,
            'following_count': 10,
            'total_favorited': 57571066,
            'favoriting_count': 0,
            'mplatform_followers_count': 77923000,
          },
        };

    test('映射所有字段（含 mplatform_followers_count）', () {
      final fields = SharePageExtractor.douyinAuthorFromUserInfoApi(buildApiFixture());
      expect(fields['nickname'], 'DOU+小助手');
      expect(fields['secUid'], 'MS4wLjABAAAAWxLpO0Q437qGFpnEKBIIaU5');
      expect(fields['signature'], '关注我，带你了解流量');
      expect(fields['avatar'], 'https://p3.douyinpic.com/medium.jpg');
      expect(fields['followerCount'], 77923000);
      expect(fields['followingCount'], 10);
      expect(fields['totalFavorited'], 57571066);
      expect(fields['awemeCount'], 2012);
      expect(fields['favoriteCount'], 0);
    });

    test('status_code 非零返回空 Map', () {
      final fixture = buildApiFixture();
      fixture['status_code'] = 8;
      fixture.remove('user_info');
      expect(
        SharePageExtractor.douyinAuthorFromUserInfoApi(fixture),
        isEmpty,
      );
    });

    test('兼容旧字段 follower_count', () {
      final fields = SharePageExtractor.douyinAuthorFromUserInfoApi({
        'user_info': {
          'nickname': '老接口',
          'follower_count': 500,
          'uid': '123',
        },
      });
      expect(fields['nickname'], '老接口');
      expect(fields['followerCount'], 500);
      expect(fields['uid'], '123');
    });
  });

  group('kuaishouAuthorFromGraphql（visionProfile 结构）', () {
    Map<String, dynamic> buildGraphqlFixture() => {
          'data': {
            'visionProfile': {
              'userProfile': {
                'profile': {
                  'user_id': '3xksuser01',
                  'user_name': '快手GraphQL用户',
                  'headurl': 'https://p.kuaishou.com/head.jpg',
                },
                'ownerCount': {
                  'fan': 8888,
                  'follow': 66,
                  'photo': 120,
                },
              },
            },
          },
        };

    test('映射 profile + ownerCount 字段', () {
      final fields = SharePageExtractor.kuaishouAuthorFromGraphql(buildGraphqlFixture());
      expect(fields['uid'], '3xksuser01');
      expect(fields['nickname'], '快手GraphQL用户');
      expect(fields['avatar'], 'https://p.kuaishou.com/head.jpg');
      expect(fields['followerCount'], 8888);
      expect(fields['followingCount'], 66);
      expect(fields['awemeCount'], 120);
    });

    test('userProfile 为 null 返回空 Map', () {
      final fields = SharePageExtractor.kuaishouAuthorFromGraphql({
        'data': {'visionProfile': {'userProfile': null}},
      });
      expect(fields, isEmpty);
    });

    test('profile 缺失时 ownerCount 仍可用', () {
      final fields = SharePageExtractor.kuaishouAuthorFromGraphql({
        'data': {
          'visionProfile': {
            'userProfile': {
              'ownerCount': {'fan': 10},
            },
          },
        },
      });
      expect(fields['followerCount'], 10);
    });
  });

  group('filterFields', () {
    test('null 不过滤', () {
      final data = {'a': 1, 'b': 2};
      expect(SharePageExtractor.filterFields(data, null), data);
    });

    test('空列表不过滤', () {
      final data = {'a': 1, 'b': 2};
      expect(SharePageExtractor.filterFields(data, []), data);
    });

    test('只保留选中的字段', () {
      final data = {'a': 1, 'b': 2, 'c': 3};
      final result = SharePageExtractor.filterFields(data, ['a', 'c']);
      expect(result.keys.toSet(), {'a', 'c'});
    });

    test('选中的字段不存在于数据中时被忽略', () {
      final data = {'a': 1};
      expect(SharePageExtractor.filterFields(data, ['x']), isEmpty);
    });
  });
}
